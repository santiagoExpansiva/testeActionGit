var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __assign = function() {
  __assign = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
        t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var __asyncValues = function(o) {
  if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
  var m = o[Symbol.asyncIterator], i;
  return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
    return this;
  }, i);
  function verb(n) {
    i[n] = o[n] && function(v) {
      return new Promise(function(resolve, reject) {
        v = o[n](v), settle(resolve, reject, v.done, v.value);
      });
    };
  }
  function settle(resolve, reject, d, v) {
    Promise.resolve(v).then(function(v2) {
      resolve({ value: v2, done: d });
    }, reject);
  }
};
import { html } from "lit";
import { customElement, query, property } from "lit/decorators.js";
import { convertFileNameToTag } from "./_100554_utilsLit";
import { ServiceBase } from "./_100554_serviceBase";
var ServiceSource100554 = (
  /** @class */
  function(_super) {
    __extends(ServiceSource100554, _super);
    function ServiceSource100554() {
      var _this = _super.call(this) || this;
      _this.msize = "";
      _this.onClickLink = function(op) {
        if (op === "opTS2")
          return true;
        if (op === "opTheme")
          return _this.showPageTheme();
        if (op === "opMonacoConfig")
          return _this.showConfEditor();
        if (op === "opMonacoReset")
          return _this.showMonacoReset();
        if (op === "opHistory")
          return _this.showHistory();
        if (op === "opView")
          return _this.openRepo();
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.onClickIcon = function(op) {
        if (op === "icTs")
          _this.showActiveModel();
        if (op === "icHTML")
          _this.createOrShowModelHTML(true);
      };
      _this.onClickTitle = function() {
        _this.openService("_100554_serviceListFiles", _this.position, 2);
      };
      _this.details = {
        icon: "&#xf121",
        state: "background",
        tooltip: "Source 2",
        visible: true,
        position: "all",
        widget: "_100554_serviceSource",
        level: [2]
      };
      _this.menu = {
        title: {
          icon: "&#xf053",
          text: "L2 - widget1"
        },
        actions: {
          opTheme: "Editor - Themes",
          opMonacoConfig: "Editor - config",
          opMonacoReset: "Editor - reset",
          opHistory: "History",
          opView: "View on repository"
        },
        icons: {
          icTs: "Typescript;f121",
          icHTML: "HTML;f1c9"
        },
        actionDefault: "",
        // call after close icon clicked
        iconDefault: "icTs",
        setMode: void 0,
        // child will set this
        updateTitle: void 0,
        // child will set this
        getLastMode: void 0,
        // child will set this
        lastIcon: void 0,
        // child will set this
        setIconActive: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        onClickIcon: _this.onClickIcon,
        onClickTitle: _this.onClickTitle
      };
      _this.last = void 0;
      _this._onChangedContent = void 0;
      _this.onModelChange = function(e, activeModel, storFile) {
        clearTimeout(_this._onChangedContent);
        _this._onChangedContent = window.setTimeout(function() {
          return __awaiter(_this, void 0, void 0, function() {
            var ignoreChanges, position;
            var _a2;
            return __generator(this, function(_b) {
              switch (_b.label) {
                case 0:
                  return [4, this.updateModelStatus(activeModel, true)];
                case 1:
                  _b.sent();
                  ignoreChanges = e.changes.length === 1 && e.changes[0].range.startLineNumber === 1 && e.changes[0].range.endLineNumber === 1 && e.changes[0].range.endColumn <= 2;
                  if (ignoreChanges)
                    return [
                      2
                      /*return*/
                    ];
                  if (((_a2 = mls.l2.editor.editors[this.confE2("left")]) === null || _a2 === void 0 ? void 0 : _a2.model.id) === activeModel.model.id) {
                    position = "left";
                  } else {
                    position = "right";
                  }
                  mls.events.fireFileAction("changed", storFile, position);
                  return [
                    2
                    /*return*/
                  ];
              }
            });
          });
        }, 400);
      };
      _this.getValueInfo = function(activeModel) {
        return __awaiter(_this, void 0, Promise, function() {
          var rc;
          return __generator(this, function(_a2) {
            rc = {
              content: activeModel.model.getValue(),
              contentType: "string",
              originalShortName: activeModel.originalShortName,
              originalProject: activeModel.originalProject,
              originalCRC: activeModel.originalCRC
            };
            return [2, rc];
          });
        });
      };
      _this.onProjectLoadedEvents = function(ev) {
        return __awaiter(_this, void 0, Promise, function() {
          var projectLoadedInfo, e_1;
          return __generator(this, function(_a2) {
            switch (_a2.label) {
              case 0:
                if (ev.level !== this.level)
                  return [
                    2
                    /*return*/
                  ];
                if (!ev.desc)
                  return [
                    2
                    /*return*/
                  ];
                _a2.label = 1;
              case 1:
                _a2.trys.push([1, 3, , 4]);
                projectLoadedInfo = JSON.parse(ev.desc);
                return [4, this.readAllProjectTypescriptAndCompile(projectLoadedInfo.project, "", projectLoadedInfo.needCompile)];
              case 2:
                _a2.sent();
                return [3, 4];
              case 3:
                e_1 = _a2.sent();
                console.error("Error on serviceSource_onProjectLoadedEvents: ", e_1);
                return [3, 4];
              case 4:
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      };
      _this.isNewFile = false;
      _this.onMLSEvents = function(ev) {
        return __awaiter(_this, void 0, Promise, function() {
          var fileAction, keyFiles, keyFilesHTML, getStorFile, getStorFileHTML, onNew, onOpen, onDelete, onUndo, onRename, onClone, onUpdatedOnServer, _a2;
          var _this2 = this;
          return __generator(this, function(_b) {
            switch (_b.label) {
              case 0:
                if (ev.level !== this.level || ev.type !== "FileAction")
                  return [
                    2
                    /*return*/
                  ];
                if (!ev.desc)
                  return [
                    2
                    /*return*/
                  ];
                fileAction = JSON.parse(ev.desc);
                if (fileAction.position !== this.position)
                  return [
                    2
                    /*return*/
                  ];
                getStorFile = function() {
                  keyFiles = mls.stor.getKeyToFiles(fileAction.project, fileAction.level, fileAction.shortName, fileAction.folder, fileAction.extension);
                  var storFile = mls.stor.files[keyFiles];
                  if (!storFile)
                    throw new Error("Error on open, mls.stor.files dont exists, key:" + keyFiles);
                  return storFile;
                };
                getStorFileHTML = function() {
                  keyFilesHTML = mls.stor.getKeyToFiles(fileAction.project, fileAction.level, fileAction.shortName, fileAction.folder, ".html");
                  return mls.stor.files[keyFilesHTML];
                };
                onNew = function() {
                  return __awaiter(_this2, void 0, Promise, function() {
                    return __generator(this, function(_a3) {
                      switch (_a3.label) {
                        case 0:
                          return [4, this.newFiles(fileAction.newshortName, fileAction.newProject, fileAction.newEnhancement, fileAction.newTSSource)];
                        case 1:
                          _a3.sent();
                          return [
                            2
                            /*return*/
                          ];
                      }
                    });
                  });
                };
                onOpen = function() {
                  return __awaiter(_this2, void 0, Promise, function() {
                    var storFile, storFileHTML;
                    return __generator(this, function(_a3) {
                      switch (_a3.label) {
                        case 0:
                          storFile = getStorFile();
                          storFileHTML = getStorFileHTML();
                          return [4, this.openFiles(storFileHTML, storFile, fileAction.position)];
                        case 1:
                          _a3.sent();
                          return [
                            2
                            /*return*/
                          ];
                      }
                    });
                  });
                };
                onDelete = function() {
                  return __awaiter(_this2, void 0, Promise, function() {
                    var storFile, storFileHTML;
                    return __generator(this, function(_a3) {
                      switch (_a3.label) {
                        case 0:
                          storFile = getStorFile();
                          storFileHTML = getStorFileHTML();
                          return [4, this.deleteFiles(storFileHTML, storFile)];
                        case 1:
                          _a3.sent();
                          return [
                            2
                            /*return*/
                          ];
                      }
                    });
                  });
                };
                onUndo = function() {
                  return __awaiter(_this2, void 0, Promise, function() {
                    var storFile, storFileHTML;
                    return __generator(this, function(_a3) {
                      switch (_a3.label) {
                        case 0:
                          storFile = getStorFile();
                          storFileHTML = getStorFileHTML();
                          return [4, this.undoFiles(storFileHTML, storFile, keyFilesHTML, keyFiles)];
                        case 1:
                          _a3.sent();
                          return [
                            2
                            /*return*/
                          ];
                      }
                    });
                  });
                };
                onRename = function() {
                  return __awaiter(_this2, void 0, Promise, function() {
                    var storFile, storFileHTML;
                    return __generator(this, function(_a3) {
                      switch (_a3.label) {
                        case 0:
                          storFile = getStorFile();
                          storFileHTML = getStorFileHTML();
                          return [4, this.renameFiles(storFileHTML, storFile, fileAction.newProject, fileAction.newshortName, fileAction)];
                        case 1:
                          _a3.sent();
                          return [
                            2
                            /*return*/
                          ];
                      }
                    });
                  });
                };
                onClone = function() {
                  return __awaiter(_this2, void 0, Promise, function() {
                    var storFile;
                    return __generator(this, function(_a3) {
                      switch (_a3.label) {
                        case 0:
                          storFile = getStorFile();
                          return [4, this.cloneFiles(storFile, fileAction.newProject, fileAction.newshortName, fileAction)];
                        case 1:
                          _a3.sent();
                          return [
                            2
                            /*return*/
                          ];
                      }
                    });
                  });
                };
                onUpdatedOnServer = function() {
                  return __awaiter(_this2, void 0, Promise, function() {
                    return __generator(this, function(_a3) {
                      switch (_a3.label) {
                        case 0:
                          return [4, this.updatedOnServer()];
                        case 1:
                          _a3.sent();
                          return [
                            2
                            /*return*/
                          ];
                      }
                    });
                  });
                };
                if (mls.istrace)
                  console.time("onAction_" + fileAction.action + "_" + fileAction.position);
                return [4, this.initMonaco()];
              case 1:
                _b.sent();
                _a2 = fileAction.action;
                switch (_a2) {
                  case "new":
                    return [3, 2];
                  case "open":
                    return [3, 4];
                  case "delete":
                    return [3, 6];
                  case "undo":
                    return [3, 8];
                  case "rename":
                    return [3, 10];
                  case "clone":
                    return [3, 12];
                  case "updatedOnServer":
                    return [3, 14];
                }
                return [3, 16];
              case 2:
                return [4, onNew()];
              case 3:
                _b.sent();
                return [3, 17];
              case 4:
                return [4, onOpen()];
              case 5:
                _b.sent();
                return [3, 17];
              case 6:
                return [4, onDelete()];
              case 7:
                _b.sent();
                return [3, 17];
              case 8:
                return [4, onUndo()];
              case 9:
                _b.sent();
                return [3, 17];
              case 10:
                return [4, onRename()];
              case 11:
                _b.sent();
                return [3, 17];
              case 12:
                return [4, onClone()];
              case 13:
                _b.sent();
                return [3, 17];
              case 14:
                return [4, onUpdatedOnServer()];
              case 15:
                _b.sent();
                return [3, 17];
              case 16:
                {
                }
                _b.label = 17;
              case 17:
                if (mls.istrace)
                  console.timeEnd("onAction_" + fileAction.action + "_" + fileAction.position);
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      };
      _this.monacoGlobalInitialized = false;
      _this.onFirtModel = true;
      _this.timeout_compileConfEditor = 0;
      _this._onChangedContentHTML = void 0;
      _this.onModelHTMLChange = function(e, storFileHTML, model) {
        clearTimeout(_this._onChangedContentHTML);
        _this._onChangedContentHTML = window.setTimeout(function() {
          return __awaiter(_this, void 0, void 0, function() {
            var sameContent;
            return __generator(this, function(_a2) {
              switch (_a2.label) {
                case 0:
                  sameContent = storFileHTML["originalCRC"] === mls.common.crc.crc32(model.getValue()).toString(16);
                  if (!sameContent) return [3, 3];
                  if (storFileHTML.status !== "new" && storFileHTML.status !== "renamed")
                    storFileHTML.status = "nochange";
                  if (!(storFileHTML.status !== "renamed")) return [3, 2];
                  return [4, mls.stor.localStor.setContent(storFileHTML, { content: null })];
                case 1:
                  _a2.sent();
                  _a2.label = 2;
                case 2:
                  return [3, 5];
                case 3:
                  if (storFileHTML.status !== "renamed" && storFileHTML.status !== "new")
                    storFileHTML.status = "changed";
                  return [4, mls.stor.localStor.setContent(storFileHTML, { contentType: "string", content: model.getValue() })];
                case 4:
                  _a2.sent();
                  _a2.label = 5;
                case 5:
                  mls.events.fireFileAction("statusOrErrorChanged", storFileHTML, model["position"]);
                  return [
                    2
                    /*return*/
                  ];
              }
            });
          });
        }, 400);
      };
      _this.getValueInfoHTML = function(activeModel, originalShortName, originalProject, originalCRC) {
        return __awaiter(_this, void 0, Promise, function() {
          var rc;
          return __generator(this, function(_a2) {
            rc = {
              content: activeModel.getValue(),
              contentType: "string",
              originalShortName,
              originalProject,
              originalCRC
            };
            return [2, rc];
          });
        });
      };
      mls.events.addListener(2, "FileAction", _this.onMLSEvents.bind(_this));
      mls.events.addListener(2, "MonacoAction", function(ev) {
        return _this.onMonacoEvents(ev);
      });
      mls.events.addListener(2, "ProjectLoaded", function(ev) {
        return _this.onProjectLoadedEvents(ev);
      });
      _this.initMonaco_GlobalEditor();
      return _this;
    }
    ServiceSource100554_1 = ServiceSource100554;
    ServiceSource100554.prototype.createRenderRoot = function() {
      return this;
    };
    ServiceSource100554.prototype.onServiceClick = function(visible, reinit, el) {
      this._onServiceClick(visible, reinit, el);
    };
    ServiceSource100554.prototype._onServiceClick = function(visible, reinit, el) {
      return __awaiter(this, void 0, void 0, function() {
        var _a2;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              if (!visible) {
                this.saveViewState();
                return [
                  2
                  /*return*/
                ];
              }
              return [4, this.initMonaco()];
            case 1:
              _b.sent();
              if (this.menu.setIconActive)
                this.menu.setIconActive("icTs");
              (_a2 = this.c2) === null || _a2 === void 0 ? void 0 : _a2.setAttribute("msize", this.msize);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.getEditorValue = function() {
      if (!this._ed1)
        return "";
      var model = this._ed1.getModel();
      if (!model)
        return "";
      return model.getValue();
    };
    ServiceSource100554.prototype.setEditorValue = function(val) {
      if (!this._ed1)
        return false;
      var _a2 = mls.l2.editor.editors[this.confE], shortName = _a2.shortName, project = _a2.project;
      var uri = this.getUri("_".concat(project, "_").concat(shortName), ".ts");
      var model = monaco.editor.getModel(uri);
      if (!model)
        return false;
      this.setValueInModeKeepingUndo(model, val, true);
    };
    ServiceSource100554.prototype.setEditorHTMLValue = function(val) {
      if (!this._ed1)
        return false;
      var _a2 = mls.l2.editor.editors[this.confE], shortName = _a2.shortName, project = _a2.project;
      var uri = this.getUri("_".concat(project, "_").concat(shortName), ".html");
      var model = monaco.editor.getModel(uri);
      if (!model)
        return false;
      this.setValueInModeKeepingUndo(model, val, false);
    };
    Object.defineProperty(ServiceSource100554.prototype, "confE", {
      get: function() {
        return "l".concat(this.level, "_").concat(this.position);
      },
      enumerable: false,
      configurable: true
    });
    ServiceSource100554.prototype.confE2 = function(positionToolbar) {
      return "l".concat(this.level, "_").concat(positionToolbar);
    };
    Object.defineProperty(ServiceSource100554.prototype, "confETS", {
      get: function() {
        return this.confE + "_TS";
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(ServiceSource100554.prototype, "confEJS", {
      get: function() {
        return this.confE + "_JS";
      },
      enumerable: false,
      configurable: true
    });
    ServiceSource100554.prototype.saveViewState = function() {
      if (!this._ed1)
        return;
      var activeModel = mls.l2.editor.editors[this.confE];
      if (!activeModel)
        return;
      activeModel["".concat(this.position, "_viewState")] = this._ed1.saveViewState();
    };
    ServiceSource100554.prototype.restaureViewState = function() {
      if (!this._ed1)
        return;
      var activeModel = mls.l2.editor.editors[this.confE];
      if (!activeModel)
        return;
      var viewState = activeModel["".concat(this.position, "_viewState")];
      if (viewState)
        this._ed1.restoreViewState(viewState);
    };
    ServiceSource100554.prototype.setValueInModeKeepingUndo = function(model, val, checkFirstLine) {
      var _a2;
      var fullRange = model.getFullModelRange();
      var newText = val;
      if (checkFirstLine && !val.trim().startsWith("/// <mls shortName")) {
        var firstLine = model.getLineContent(1);
        newText = firstLine + "\n" + newText;
      }
      var lines = newText.split("\n");
      var operations = [{
        range: fullRange,
        text: "",
        forceMoveMarkers: true
      }, {
        range: { startLineNumber: 1, startColumn: 1 },
        text: lines.join("\n"),
        forceMoveMarkers: true
      }];
      model.pushEditOperations([], operations, function() {
        return [];
      });
      (_a2 = this._ed1) === null || _a2 === void 0 ? void 0 : _a2.setPosition({ lineNumber: 1, column: 1 });
    };
    ServiceSource100554.prototype.openRepo = function() {
      var _a2 = mls.l2.editor.editors[this.confE], shortName = _a2.shortName, project = _a2.project;
      var ext = this.menu.lastIcon === "icTs" ? ".ts" : ".html";
      var keyToFile = mls.stor.getKeyToFiles(project, 2, shortName, "", ext);
      var file = mls.stor.files[keyToFile];
      if (!file) {
        window.collabMessages.add("Invalid File", "information");
        throw new Error("invalid file");
      }
      var driver = mls.stor.others.getDefaultDriver(project);
      if (!driver) {
        window.collabMessages.add("Driver not found", "information");
        throw new Error("Driver not found");
      }
      var url = "";
      url = driver.getUrl(file);
      window.open(url, "_blank");
      if (this.menu.closeMenu)
        this.menu.closeMenu();
      return true;
    };
    ServiceSource100554.prototype.showHistory = function() {
      this.showHistorie2();
      return true;
    };
    ServiceSource100554.prototype.showHistorie2 = function() {
      return __awaiter(this, void 0, void 0, function() {
        var _a2, shortName, project, div, scr, i2, ds, obj, wc;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              _a2 = mls.l2.editor.editors[this.confE], shortName = _a2.shortName, project = _a2.project;
              div = document.createElement("div");
              scr = document.createElement("script");
              i2 = "/_".concat("100554", "_").concat("mlsHistoryList");
              scr.type = "module";
              scr.id = i2.replace("/", "");
              scr.src = i2;
              div.appendChild(scr);
              ds = mls.l3.getDSInstance(100554, 0);
              if (!ds) return [3, 2];
              return [4, ds.init()];
            case 1:
              _b.sent();
              ds.components.getCSS("_100554_mlsHistoryList").then(function(css) {
                var style = document.createElement("style");
                style.textContent = css;
                div.appendChild(style);
              });
              _b.label = 2;
            case 2:
              obj = {
                icTs: ".ts",
                icHTML: ".html"
              };
              wc = document.createElement("mls-history-list-100554");
              wc.setAttribute("project", project.toString());
              wc.setAttribute("shortName", shortName);
              wc.setAttribute("level", "2");
              if (this.menu.lastIcon)
                wc.setAttribute("extension", obj[this.menu.lastIcon]);
              wc.setAttribute("position", this.position);
              div.appendChild(wc);
              if (this.menu.setMode)
                this.menu.setMode("page", div);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.showPageTheme = function() {
      if (this.menu.setMode)
        this.menu.setMode("page", this.getGlobalPageSetTHeme());
      return true;
    };
    ServiceSource100554.prototype.showMonacoReset = function() {
      mls.editor.conf[this.confE] = void 0;
      this.loadMonacoConfigurations();
      if (this.menu.setMode)
        this.menu.setMode("initial");
      this.updateMonacoConfigutarions();
      this.saveConfEditorToLocalStorage();
      return true;
    };
    ServiceSource100554.prototype.showConfEditor = function() {
      if (this.menu.setMode)
        this.menu.setMode("editor");
      this.setModelConfEditor();
      return true;
    };
    ServiceSource100554.prototype.readAllProjectTypescriptAndCompile = function(project_1, shortName_1) {
      return __awaiter(this, arguments, Promise, function(project, shortName, needCompile) {
        var promises, keys, _i, keys_1, key, storFile;
        if (needCompile === void 0) {
          needCompile = true;
        }
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (ServiceSource100554_1.projectsLoaded.includes(project))
                return [
                  2
                  /*return*/
                ];
              if (mls.istrace)
                console.log("loading files from project " + project);
              ServiceSource100554_1.projectsLoaded.push(project);
              promises = [];
              keys = Object.keys(mls.stor.files);
              if (window.traceLivecicle)
                console.info("creating: files model ", project);
              for (_i = 0, keys_1 = keys; _i < keys_1.length; _i++) {
                key = keys_1[_i];
                storFile = mls.stor.files[key];
                if (storFile.project === project && storFile.level === 2 && storFile.extension === ".ts" && storFile.shortName !== shortName) {
                  promises.push(this.createModelTS2(storFile, false, false));
                }
              }
              if (mls.istrace)
                console.time("creating models");
              return [4, Promise.all(promises)];
            case 1:
              _a2.sent();
              if (mls.istrace)
                console.timeEnd("creating models");
              if (window.traceLivecicle)
                console.info("firing: mls.l2.editor.compileAllProjectIfNeed ", project);
              if (!needCompile) return [3, 3];
              return [4, mls.l2.editor.compileAllProjectIfNeed(project, true)];
            case 2:
              _a2.sent();
              _a2.label = 3;
            case 3:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.deleteFile = function(storFile) {
      return __awaiter(this, void 0, void 0, function() {
        var activeModel, keyFiles;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              return [4, mls.stor.localStor.setContent(storFile, { contentType: "string", content: null })];
            case 1:
              _a2.sent();
              activeModel = mls.l2.editor.editors[this.confE];
              if (!(activeModel.project === storFile.project && activeModel.shortName === storFile.shortName)) return [3, 3];
              return [4, this.createModelTS_testFile()];
            case 2:
              _a2.sent();
              _a2.label = 3;
            case 3:
              mls.l2.editor.remove(storFile);
              this.removeEventsModelTS(storFile);
              keyFiles = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, storFile.extension);
              delete mls.stor.files[keyFiles];
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.afterUpdate = function(storFile) {
      return __awaiter(this, void 0, void 0, function() {
        var mmodel;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              mmodel = mls.l2.editor.get(storFile);
              if (!mmodel)
                return [
                  2
                  /*return*/
                ];
              if (storFile.status === "deleted") {
                this.deleteFile(storFile);
                return [
                  2
                  /*return*/
                ];
              }
              if (storFile.status === "renamed") {
                mmodel.originalProject = void 0;
                mmodel.originalShortName = void 0;
                mmodel.originalCRC = mls.common.crc.crc32(mmodel.model.getValue()).toString(16);
              }
              return [4, mls.stor.localStor.setContent(storFile, { contentType: "string", content: null })];
            case 1:
              _a2.sent();
              storFile.status = "nochange";
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.addEventsModelTS = function(storFile, model1) {
      var _this = this;
      storFile.onAction = function(action) {
        return _this.afterUpdate(storFile);
      };
      storFile.getValueInfo = function() {
        return _this.getValueInfo(model1);
      };
      model1.model.onDidChangeContent(function(e) {
        return _this.onModelChange(e, model1, storFile);
      });
    };
    ServiceSource100554.prototype.removeEventsModelTS = function(storFile) {
      storFile.onAction = void 0;
      storFile.getValueInfo = void 0;
    };
    ServiceSource100554.prototype.onMonacoEvents = function(ev) {
      if (!ev.desc)
        return;
      var args = JSON.parse(ev.desc);
      if (!args)
        return;
      var action = args.action, filePosition = args.filePosition, position = args.position, project = args.project, shortName = args.shortName;
      if (position !== this.position)
        return;
      if (action === "gotoPosition") {
        this.goToPosition(filePosition, position);
      }
      if (mls.istrace)
        console.info("received monaco actions", args);
    };
    ServiceSource100554.prototype.goToPosition = function(position, editorPosition) {
      if (!this._ed1)
        return;
      var confInvert = "l".concat(this.level, "_").concat(editorPosition === "left" ? "right" : "left");
      var offset = position - 1;
      var _a2 = mls.l2.editor.editors[confInvert].model.getPositionAt(offset), lineNumber = _a2.lineNumber, column = _a2.column;
      this._ed1.revealPositionInCenter({ lineNumber, column }, monaco.editor.ScrollType.Immediate);
      var lineLength = mls.l2.editor.editors[confInvert].model.getLineContent(lineNumber).length + 1;
      var range = new monaco.Range(lineNumber, column, lineNumber, lineLength);
      this._ed1.setSelection(new monaco.Selection(range.startLineNumber, 0, range.startLineNumber, lineLength));
    };
    ServiceSource100554.prototype.deleteFiles = function(storFileHTML, storFileTS) {
      return __awaiter(this, void 0, void 0, function() {
        var _a2, _b, _c, storFile, e_2_1;
        var _d, e_2, _e, _f;
        return __generator(this, function(_g) {
          switch (_g.label) {
            case 0:
              _g.trys.push([0, 5, 6, 11]);
              _a2 = true, _b = __asyncValues([storFileHTML, storFileTS]);
              _g.label = 1;
            case 1:
              return [4, _b.next()];
            case 2:
              if (!(_c = _g.sent(), _d = _c.done, !_d)) return [3, 4];
              _f = _c.value;
              _a2 = false;
              storFile = _f;
              if (!storFile)
                return [3, 3];
              if (storFile.status === "new")
                this.deleteFile(storFile);
              else
                storFile.status = "deleted";
              mls.events.fireFileAction("statusOrErrorChanged", storFile, this.position);
              _g.label = 3;
            case 3:
              _a2 = true;
              return [3, 1];
            case 4:
              return [3, 11];
            case 5:
              e_2_1 = _g.sent();
              e_2 = { error: e_2_1 };
              return [3, 11];
            case 6:
              _g.trys.push([6, , 9, 10]);
              if (!(!_a2 && !_d && (_e = _b.return))) return [3, 8];
              return [4, _e.call(_b)];
            case 7:
              _g.sent();
              _g.label = 8;
            case 8:
              return [3, 10];
            case 9:
              if (e_2) throw e_2.error;
              return [
                7
                /*endfinally*/
              ];
            case 10:
              return [
                7
                /*endfinally*/
              ];
            case 11:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.cloneFiles = function(storFileTS, newProject, newShortName, oldFileAction) {
      return __awaiter(this, void 0, void 0, function() {
        var fileAction, ev;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              return [4, this.createModelTS_loading()];
            case 1:
              _a2.sent();
              this.activeThisService();
              return [4, this.createModelTS_clone(storFileTS, newProject, newShortName)];
            case 2:
              _a2.sent();
              return [4, this.createModelHTML_clone(storFileTS, newProject, newShortName)];
            case 3:
              _a2.sent();
              mls.actual[this.level][this.position] = {
                project: newProject,
                shortName: newShortName
              };
              fileAction = __assign(__assign({}, oldFileAction), { project: newProject, shortName: newShortName, action: "open", newProject: void 0, newshortName: void 0 });
              ev = {
                level: this.level,
                type: "FileAction",
                desc: JSON.stringify(fileAction)
              };
              this.onMLSEvents(ev);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.newFiles = function(newShortName, newProject, newEnhancement, tsSource) {
      return __awaiter(this, void 0, void 0, function() {
        var newTSSource;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              this.isNewFile = true;
              this.activeThisService();
              this.closeMenu();
              newTSSource = tsSource || '/// <mls shortName="'.concat(newShortName, '" project="').concat(newProject, '" enhancement="').concat(newEnhancement, '" />\n				\n// typescript new file\n');
              return [4, this.createModelTS1(newShortName, newProject, newTSSource, true)];
            case 1:
              _a2.sent();
              return [4, this.createOrShowModelHTML(false)];
            case 2:
              _a2.sent();
              this.showActiveModel();
              this.isNewFile = false;
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.openFiles = function(storFileHTML, storFileTS, position) {
      return __awaiter(this, void 0, void 0, function() {
        var fileModel;
        var _this = this;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              return [4, this.createModelTS_loading()];
            case 1:
              _a2.sent();
              this.activeThisService();
              this.closeMenu();
              fileModel = mls.l2.editor.get(storFileTS);
              if (!!fileModel) return [3, 4];
              return [4, this.createModelTS2(storFileTS, true, true)];
            case 2:
              _a2.sent();
              this.showActiveModel();
              return [4, this.readAllProjectTypescriptAndCompile(storFileTS.project, storFileTS.shortName, true).then(function() {
                return __awaiter(_this, void 0, void 0, function() {
                  return __generator(this, function(_a3) {
                    switch (_a3.label) {
                      case 0:
                        return [4, this.createOrShowModelHTML(false)];
                      case 1:
                        _a3.sent();
                        return [
                          2
                          /*return*/
                        ];
                    }
                  });
                });
              })];
            case 3:
              _a2.sent();
              return [3, 6];
            case 4:
              mls.l2.editor.editors[this.confE] = fileModel;
              mls.l2.editor.forceModelUpdate(fileModel.model);
              return [4, this.createOrShowModelHTML(false)];
            case 5:
              _a2.sent();
              this.showActiveModel();
              _a2.label = 6;
            case 6:
              if (storFileTS && !storFileTS.inLocalStorage && storFileTS.isLocalVersionOutdated)
                storFileTS.isLocalVersionOutdated = false;
              if (storFileHTML && !storFileHTML.inLocalStorage && storFileHTML.isLocalVersionOutdated)
                storFileHTML.isLocalVersionOutdated = false;
              this.saveLocalStorageLastOpen(storFileTS, position);
              if (!this._ed1)
                return [
                  2
                  /*return*/
                ];
              this.restaureViewState();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.renameFiles = function(storFileHTML, storFileTS, newProject, newShortName, oldFileAction) {
      return __awaiter(this, void 0, void 0, function() {
        var model1, fileAction, ev;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              return [4, this.createModelTS_loading()];
            case 1:
              _a2.sent();
              this.activeThisService();
              model1 = mls.l2.editor.get(storFileTS);
              if (!!model1) return [3, 3];
              return [4, this.createModelTS2(storFileTS, false, true)];
            case 2:
              model1 = _a2.sent();
              _a2.label = 3;
            case 3:
              this.renameTSFile(model1, storFileTS, newProject, newShortName);
              mls.l2.editor.editors[this.confE] = model1;
              this.renameHTMLFile(storFileHTML, newProject, newShortName);
              mls.actual[this.level][this.position] = {
                project: newProject,
                shortName: newShortName
              };
              fileAction = __assign(__assign({}, oldFileAction), { project: newProject, shortName: newShortName, action: "open", newProject: void 0, newshortName: void 0 });
              ev = {
                level: this.level,
                type: "FileAction",
                desc: JSON.stringify(fileAction)
              };
              this.onMLSEvents(ev);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.updatedOnServer = function() {
      return __awaiter(this, void 0, void 0, function() {
        var keys, arr_2, needMsg, _a2, arr_1, arr_1_1, storFile, e_3_1, e_4;
        var _b, e_3, _c, _d;
        return __generator(this, function(_e) {
          switch (_e.label) {
            case 0:
              _e.trys.push([0, 16, , 17]);
              keys = Object.keys(mls.stor.files);
              arr_2 = [];
              needMsg = false;
              keys.forEach(function(key) {
                var f = mls.stor.files[key];
                if (!f)
                  return;
                if (f.inLocalStorage || !f.isLocalVersionOutdated)
                  return;
                arr_2.push(f);
              });
              return [4, mls.l2.editor.compileAllProjectIfNeed(mls.actual[5].project, true, false)];
            case 1:
              _e.sent();
              _e.label = 2;
            case 2:
              _e.trys.push([2, 9, 10, 15]);
              _a2 = true, arr_1 = __asyncValues(arr_2);
              _e.label = 3;
            case 3:
              return [4, arr_1.next()];
            case 4:
              if (!(arr_1_1 = _e.sent(), _b = arr_1_1.done, !_b)) return [3, 8];
              _d = arr_1_1.value;
              _a2 = false;
              storFile = _d;
              mls.l2.editor.remove(storFile);
              this.removeEventsModelTS(storFile);
              return [4, mls.stor.localStor.setContent(storFile, { contentType: "string", content: null })];
            case 5:
              _e.sent();
              return [4, this.createModelTS2(storFile, false, true)];
            case 6:
              _e.sent();
              if (storFile.project === 100554)
                needMsg = true;
              _e.label = 7;
            case 7:
              _a2 = true;
              return [3, 3];
            case 8:
              return [3, 15];
            case 9:
              e_3_1 = _e.sent();
              e_3 = { error: e_3_1 };
              return [3, 15];
            case 10:
              _e.trys.push([10, , 13, 14]);
              if (!(!_a2 && !_b && (_c = arr_1.return))) return [3, 12];
              return [4, _c.call(arr_1)];
            case 11:
              _e.sent();
              _e.label = 12;
            case 12:
              return [3, 14];
            case 13:
              if (e_3) throw e_3.error;
              return [
                7
                /*endfinally*/
              ];
            case 14:
              return [
                7
                /*endfinally*/
              ];
            case 15:
              if (needMsg) {
                window.collabMessages.add("Files changed in server , please use F5 to reload", "information", { autoClose: false, clearOnClose: false });
              }
              return [3, 17];
            case 16:
              e_4 = _e.sent();
              console.info("Erro service source: onUpdatedOnServer");
              return [3, 17];
            case 17:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.undoFiles = function(storFileHTML, storFileTS, keyFileHTML, keyFileTS) {
      return __awaiter(this, void 0, void 0, function() {
        var _a2, _b, _c, data, imFile, uri, model, e_5_1;
        var _d, e_5, _e, _f;
        return __generator(this, function(_g) {
          switch (_g.label) {
            case 0:
              _g.trys.push([0, 13, 14, 19]);
              _a2 = true, _b = __asyncValues([{ storFile: storFileHTML, keyFiles: keyFileHTML }, { storFile: storFileTS, keyFiles: keyFileTS }]);
              _g.label = 1;
            case 1:
              return [4, _b.next()];
            case 2:
              if (!(_c = _g.sent(), _d = _c.done, !_d)) return [3, 12];
              _f = _c.value;
              _a2 = false;
              data = _f;
              if (!data.storFile)
                return [3, 11];
              if (data.storFile.status === "deleted") {
                data.storFile.status = "changed";
                mls.events.fireFileAction("statusOrErrorChanged", data.storFile, this.position);
                return [3, 11];
              }
              if (data.storFile.status === "renamed") {
                throw new Error("not implemented");
              }
              if (!(data.storFile.extension === ".ts")) return [3, 5];
              imFile = mls.l2.editor.editors[this.confE];
              if (!(imFile.project === data.storFile.project && imFile.shortName === data.storFile.shortName)) return [3, 4];
              return [4, this.createModelTS_testFile()];
            case 3:
              _g.sent();
              _g.label = 4;
            case 4:
              mls.l2.editor.remove(data.storFile);
              this.removeEventsModelTS(data.storFile);
              _g.label = 5;
            case 5:
              return [4, mls.stor.localStor.setContent(data.storFile, { contentType: "string", content: null })];
            case 6:
              _g.sent();
              if (data.storFile.status === "new") {
                delete mls.stor.files[data.keyFiles];
                mls.events.fireFileAction("statusOrErrorChanged", data.storFile, this.position);
                return [3, 11];
              }
              if (data.storFile.status === "changed") {
                data.storFile.status = "nochange";
                if (data.storFile.isLocalVersionOutdated && data.storFile.newVersionRefIfOutdated) {
                  data.storFile.versionRef = data.storFile.newVersionRefIfOutdated;
                  data.storFile.isLocalVersionOutdated = false;
                  data.storFile.newVersionRefIfOutdated = void 0;
                }
              } else {
                data.storFile.status = "changed";
              }
              if (!(data.storFile.extension === ".ts")) return [3, 8];
              return [4, this.createModelTS2(data.storFile, false, true)];
            case 7:
              _g.sent();
              return [3, 10];
            case 8:
              uri = this.getUri("_".concat(data.storFile.project, "_").concat(data.storFile.shortName), ".html");
              model = monaco.editor.getModel(uri);
              if (model)
                model.dispose();
              return [4, this.createOrShowModelHTML(false)];
            case 9:
              _g.sent();
              _g.label = 10;
            case 10:
              mls.events.fireFileAction("statusOrErrorChanged", data.storFile, this.position);
              _g.label = 11;
            case 11:
              _a2 = true;
              return [3, 1];
            case 12:
              return [3, 19];
            case 13:
              e_5_1 = _g.sent();
              e_5 = { error: e_5_1 };
              return [3, 19];
            case 14:
              _g.trys.push([14, , 17, 18]);
              if (!(!_a2 && !_d && (_e = _b.return))) return [3, 16];
              return [4, _e.call(_b)];
            case 15:
              _g.sent();
              _g.label = 16;
            case 16:
              return [3, 18];
            case 17:
              if (e_5) throw e_5.error;
              return [
                7
                /*endfinally*/
              ];
            case 18:
              return [
                7
                /*endfinally*/
              ];
            case 19:
              ;
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.activeThisService = function() {
      this.openMe();
      mls.editor.setActiveInstance(this.level, this.position);
    };
    ServiceSource100554.prototype.closeMenu = function() {
      if (this.menu.closeMenu)
        this.menu.closeMenu();
    };
    ServiceSource100554.prototype.updateModelStatus = function(model1, changed) {
      return __awaiter(this, void 0, Promise, function() {
        var cr, hasError, key, storFile, d, enhancementInstance;
        var _a2;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              if (model1.project === 0)
                changed = true;
              model1.changed = changed;
              return [4, mls.l2.editor.getCompilerResultTS({ project: model1.project, shortName: model1.shortName }, true)];
            case 1:
              cr = _b.sent();
              hasError = cr.errors.length > 0;
              model1.error = hasError;
              key = mls.stor.getKeyToFiles(model1.project, this.level, model1.shortName, "", model1.extension);
              storFile = mls.stor.files[key];
              d = { project: model1.project, shortName: model1.shortName, level: this.level, position: this.position };
              if (!!hasError) return [3, 5];
              return [4, mls.l2.enhancement.getEnhancementInstance(model1).catch(function(e) {
                return void 0;
              })];
            case 2:
              enhancementInstance = _b.sent();
              if (!enhancementInstance) return [3, 4];
              return [4, enhancementInstance.onAfterChange(model1)];
            case 3:
              _b.sent();
              _b.label = 4;
            case 4:
              hasError = storFile.hasError;
              _b.label = 5;
            case 5:
              return [4, this.changeStatusFile(model1, storFile, (_a2 = cr.tripleSlashMLS) === null || _a2 === void 0 ? void 0 : _a2.variables, hasError)];
            case 6:
              _b.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.changeStatusFile = function(model1, storFile, variables, hasError) {
      return __awaiter(this, void 0, Promise, function() {
        var oldStatus, sameContent, _a2, _b, _c;
        return __generator(this, function(_d) {
          switch (_d.label) {
            case 0:
              if (!storFile)
                return [
                  2
                  /*return*/
                ];
              oldStatus = storFile.status;
              storFile.hasError = hasError;
              sameContent = model1.originalCRC === mls.common.crc.crc32(model1.model.getValue()).toString(16);
              if (!sameContent) return [3, 2];
              if (storFile.status !== "new")
                storFile.status = "nochange";
              return [4, mls.stor.localStor.setContent(storFile, { content: null })];
            case 1:
              _d.sent();
              return [3, 5];
            case 2:
              if (storFile.status !== "renamed" && storFile.status !== "new")
                storFile.status = "changed";
              _b = (_a2 = mls.stor.localStor).setContent;
              _c = [storFile];
              return [4, this.getValueInfo(model1)];
            case 3:
              return [4, _b.apply(_a2, _c.concat([_d.sent()]))];
            case 4:
              _d.sent();
              _d.label = 5;
            case 5:
              if (oldStatus !== storFile.status) {
                mls.events.fireFileAction("statusOrErrorChanged", storFile, this.position);
              }
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.renameTSFile = function(model1, storFile, newProject, newShortName) {
      if (storFile.hasError)
        throw new Error("Error on rename, clear errors before rename");
      if (!this.isNewNameValid(newShortName))
        throw new Error("Error on rename, new shortName is a invalid name");
      var newSts = { shortName: newShortName, project: newProject };
      if (!mls.l2.editor.rename(model1, newSts))
        throw new Error("Error on rename mls.l2.editor.mfiles");
      if (!mls.stor.renameFile(storFile, newSts))
        throw new Error("Error on rename mls.stor.files");
      mls.common.tripleslash.changeVariable(model1, "shortName", newShortName);
      mls.common.tripleslash.changeVariable(model1, "project", newProject.toString());
      if (storFile.status === "new")
        return;
      storFile.status = "renamed";
    };
    ServiceSource100554.prototype.isNewNameValid = function(newShortName) {
      if (newShortName.length === 0 || newShortName.length > 255)
        return false;
      var invalidCharacters = /[_\/{}\t\[\]\*$@#=\-+!|?,<>=.;^~��""''``�������������������������������]/;
      return !invalidCharacters.test(newShortName);
    };
    ServiceSource100554.prototype.showActiveModel = function() {
      var _a2;
      var activeModel = mls.l2.editor.editors[this.confE];
      if (activeModel && activeModel.project === 0 && activeModel.shortName === "testFile" && !this.isNewFile) {
        var ret = this.openLastFile(this.level, this.position);
        if (ret)
          activeModel = mls.l2.editor.editors[this.confE];
      }
      if (!this._ed1 || !activeModel || !this.menu.getLastMode)
        return false;
      var changedFile = this.menu.title !== activeModel.shortName;
      this.menu.title.text = "_".concat(activeModel.project, "_").concat(activeModel.shortName);
      var lastMode = this.menu.getLastMode();
      if (changedFile && lastMode !== "initial") {
        this._ed1.setModel(activeModel.model);
        if (this.menu.setMode)
          this.menu.setMode("initial");
      } else if (lastMode === "initial") {
        this._ed1.setModel(activeModel.model);
        if (this.menu.updateTitle)
          this.menu.updateTitle();
      } else if (lastMode === "editor") {
      } else if (lastMode === "page") {
        this._ed1.setModel(activeModel.model);
      }
      (_a2 = this.c2) === null || _a2 === void 0 ? void 0 : _a2.setAttribute("msize", this.msize);
      return true;
    };
    ServiceSource100554.prototype.initMonaco = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (!!this._ed1) return [3, 2];
              return [4, this.initMonaco_Editor()];
            case 1:
              _a2.sent();
              if (this.serviceContent && typeof this.serviceContent.layout === "function")
                this.serviceContent.layout();
              _a2.label = 2;
            case 2:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.initMonaco_GlobalEditor = function() {
      return __awaiter(this, void 0, Promise, function() {
        return __generator(this, function(_a2) {
          this.loadMonacoConfigurations();
          if (this.monacoGlobalInitialized)
            return [
              2
              /*return*/
            ];
          this.monacoGlobalInitialized = true;
          this.loadMonacoThemeFromLocalStorage();
          this.updateMonacoGlobalTheme();
          mls.editor.InitMonaco();
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServiceSource100554.prototype.initMonaco_Editor = function() {
      return __awaiter(this, void 0, Promise, function() {
        var addEventsEditor;
        var _this = this;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              addEventsEditor = function() {
                if (!_this._ed1)
                  return;
                _this._ed1.onDidFocusEditorWidget(function() {
                  if (_this.menu.lastIcon === "icHTML")
                    return;
                  mls.editor.setActiveInstance(_this.level, _this.position);
                });
              };
              if (!this.c2)
                return [
                  2
                  /*return*/
                ];
              this._ed1 = monaco.editor.create(this.c2, mls.editor.conf[this.confE]);
              this.c2["mlsEditor"] = this._ed1;
              mls.editor.instances[this.confE] = this._ed1;
              mls.editor.InitEditor(this._ed1);
              addEventsEditor();
              this.createModelTS_loading();
              this.createModelConf("// loading ...");
              return [4, this.createModelTS_testFile()];
            case 1:
              _a2.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.loadMonacoConfigurations = function() {
      if (!mls.editor.conf || Object.keys(mls.editor.conf).length === 0) {
        this.loadConfEditorFromLocalStorage();
      }
      if (mls.editor.conf[this.confE])
        return;
      mls.editor.conf[this.confE] = {
        contextmenu: true,
        autoIndent: "full",
        wordWrap: "on",
        wrappingIndent: "indent",
        tabCompletion: "on",
        renderControlCharacters: false,
        showUnused: true,
        glyphMargin: true,
        // acceptSuggestionOnEnter: "off",  // "on", "smart" -> ex: "dd" , invalid work will be get for next suggestion, bad
        minimap: { enabled: false },
        useTabStops: true,
        scrollBeyondLastColumn: 2,
        scrollBeyondLastLine: false,
        formatOnType: true,
        fixedOverflowWidgets: true,
        codeLens: true,
        showFoldingControls: "mouseover",
        suggestSelection: "first",
        stickyScroll: { enabled: false, maxLineCount: 3 },
        stickyTabStops: true,
        fontSize: 20,
        automaticLayout: true
      };
    };
    ServiceSource100554.prototype.getUri = function(shortFN, ftype) {
      return monaco.Uri.parse("file://server/".concat(shortFN).concat(ftype));
    };
    ServiceSource100554.prototype.createModelTS_testFile = function() {
      return __awaiter(this, void 0, void 0, function() {
        var shortName, project, defaultTS;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              shortName = "testFile";
              project = 0;
              defaultTS = '/// <mls shortName="'.concat(shortName, '" project="').concat(project, '" enhancement="config_ts_web-component" />\n// typescript example');
              return [4, this.createModelTS1(shortName, project, defaultTS, true)];
            case 1:
              _a2.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.createModelTS_loading = function() {
      return __awaiter(this, void 0, void 0, function() {
        var shortName, project, defaultTS, mfile;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              shortName = "loading...";
              project = 0;
              defaultTS = "wait...";
              return [4, this.createModelTS1(shortName, project, defaultTS, true)];
            case 1:
              mfile = _a2.sent();
              if (this.onFirtModel && this._ed1) {
                this.onFirtModel = false;
                this._ed1.setModel(mfile.model);
              }
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.createModelTS_clone = function(storFile, newProject, newShortName) {
      return __awaiter(this, void 0, void 0, function() {
        var model1, defaultTS, baseTag, newTag, regex;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              model1 = mls.l2.editor.get(storFile);
              if (!!model1) return [3, 2];
              return [4, this.createModelTS2(storFile, false, true)];
            case 1:
              model1 = _a2.sent();
              _a2.label = 2;
            case 2:
              defaultTS = model1.model.getValue();
              baseTag = convertFileNameToTag("_".concat(storFile.project, "_").concat(storFile.shortName));
              newTag = convertFileNameToTag("_".concat(newProject, "_").concat(newShortName));
              regex = new RegExp(baseTag, "g");
              defaultTS = defaultTS.replace(regex, newTag);
              defaultTS = this.changeClassName(defaultTS, newProject, newShortName);
              return [4, this.createModelTS1(newShortName, newProject, defaultTS, true)];
            case 3:
              model1 = _a2.sent();
              mls.common.tripleslash.changeVariable(model1, "shortName", newShortName);
              mls.common.tripleslash.changeVariable(model1, "project", newProject.toString());
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.changeClassName = function(source, project, shortname) {
      var regex = /export\s+class\s+(\w+)\s+extends/g;
      var match = regex.exec(source);
      var newClassName = shortname.charAt(0).toUpperCase() + shortname.substring(1, shortname.length) + project.toString();
      if (match) {
        var originalTag = match[1];
        var replacedSource = source.replace(originalTag, newClassName);
        return replacedSource;
      }
      return source;
    };
    ServiceSource100554.prototype.createModelHTML_clone = function(storFile, newProject, newShortName) {
      return __awaiter(this, void 0, void 0, function() {
        var shortName, project, uri, model, cont, key, baseTag, newTag, regex, file, fileInfo;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              shortName = storFile.shortName, project = storFile.project;
              uri = this.getUri("_".concat(project, "_").concat(shortName), ".html");
              model = monaco.editor.getModel(uri);
              cont = "<h1>Edit this</h1>";
              key = "";
              if (!model) return [3, 1];
              cont = model.getValue();
              return [3, 3];
            case 1:
              key = mls.stor.getKeyToFiles(project, storFile.level, shortName, "", ".html");
              if (!mls.stor.files[key]) return [3, 3];
              return [4, mls.stor.files[key].getContent()];
            case 2:
              cont = _a2.sent();
              _a2.label = 3;
            case 3:
              baseTag = convertFileNameToTag("_".concat(storFile.project, "_").concat(storFile.shortName));
              newTag = convertFileNameToTag("_".concat(newProject, "_").concat(newShortName));
              regex = new RegExp(baseTag, "g");
              cont = cont.replace(regex, newTag);
              key = mls.stor.getKeyToFiles(newProject, storFile.level, newShortName, "", ".html");
              file = mls.stor.files[key];
              if (!!file) return [3, 5];
              return [4, mls.stor.addOrUpdateFile({ project, level: storFile.level, shortName: newShortName, extension: ".html", versionRef: (/* @__PURE__ */ new Date()).toISOString(), folder: "" })];
            case 4:
              file = _a2.sent();
              file.status = "new";
              _a2.label = 5;
            case 5:
              fileInfo = {
                content: cont,
                contentType: "string"
              };
              return [4, mls.stor.localStor.setContent(file, fileInfo)];
            case 6:
              _a2.sent();
              return [4, this.getOrCreateModelHTML(newShortName, newProject, file, fileInfo)];
            case 7:
              _a2.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.createModelTS1 = function(shortName, project, defaultTS, activateModel) {
      return __awaiter(this, void 0, Promise, function() {
        var level, extension, key, storFile, model1, src2, _a2, ftype, uri, model;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              level = 2;
              extension = ".ts";
              if (!(project > 1)) return [3, 2];
              return [4, mls.stor.server.loadProjectInfoIfNeeded(project)];
            case 1:
              _b.sent();
              _b.label = 2;
            case 2:
              key = mls.stor.getKeyToFiles(project, level, shortName, "", extension);
              storFile = mls.stor.files[key];
              if (!!storFile) return [3, 4];
              return [4, mls.stor.addOrUpdateFile({ project, level, shortName, extension, versionRef: (/* @__PURE__ */ new Date()).toISOString(), folder: "" })];
            case 3:
              storFile = _b.sent();
              storFile.status = "new";
              _b.label = 4;
            case 4:
              model1 = mls.l2.editor.get({ project, shortName });
              if (!!model1) return [3, 8];
              if (!storFile) return [3, 6];
              return [4, storFile.getContent(defaultTS)];
            case 5:
              _a2 = _b.sent() || defaultTS;
              return [3, 7];
            case 6:
              _a2 = defaultTS;
              _b.label = 7;
            case 7:
              src2 = _a2;
              ftype = src2.split("\n")[0].indexOf(' type="definition"') > 0 ? ".d.ts" : ".ts";
              uri = this.getUri("_".concat(project, "_").concat(shortName), ftype);
              model1 = mls.l2.editor.get({ project, shortName });
              if (model1)
                return [2, model1];
              model = monaco.editor.createModel(src2, "typescript", uri);
              model1 = {
                changed: true,
                error: false,
                project,
                shortName,
                extension,
                model,
                storFile,
                codeLens: []
              };
              mls.l2.editor.add(model1);
              this.addEventsModelTS(storFile, model1);
              _b.label = 8;
            case 8:
              return [4, this.updateModelStatus(model1, false)];
            case 9:
              _b.sent();
              if (activateModel)
                mls.l2.editor.editors[this.confE] = model1;
              return [2, model1];
          }
        });
      });
    };
    ServiceSource100554.prototype.createModelTS2 = function(storFile, activedModel, compile) {
      return __awaiter(this, void 0, Promise, function() {
        var project, shortName, extension, model1, info, _a2, haveInfo, src2, _b, originalCRC, originalProject, originalShortName, ftype, uri, model;
        return __generator(this, function(_c) {
          switch (_c.label) {
            case 0:
              project = storFile.project, shortName = storFile.shortName, extension = storFile.extension;
              model1 = mls.l2.editor.get({ project, shortName });
              if (model1)
                return [2, model1];
              if (!storFile.getValueInfo) return [3, 2];
              return [4, storFile.getValueInfo()];
            case 1:
              _a2 = _c.sent();
              return [3, 3];
            case 2:
              _a2 = null;
              _c.label = 3;
            case 3:
              info = _a2;
              haveInfo = info && !!info.content;
              if (!haveInfo) return [3, 4];
              _b = info === null || info === void 0 ? void 0 : info.content;
              return [3, 6];
            case 4:
              return [4, storFile.getContent()];
            case 5:
              _b = _c.sent();
              _c.label = 6;
            case 6:
              src2 = _b;
              if (src2 instanceof Blob)
                throw new Error("ts file must be string");
              if (!src2)
                throw new Error("ts file is undefined");
              ;
              originalCRC = haveInfo ? info === null || info === void 0 ? void 0 : info.originalCRC : mls.common.crc.crc32(src2).toString(16);
              originalProject = haveInfo ? info === null || info === void 0 ? void 0 : info.originalProject : void 0;
              originalShortName = haveInfo ? info === null || info === void 0 ? void 0 : info.originalShortName : void 0;
              ftype = src2.split("\n")[0].indexOf(' type="definition"') > 0 ? ".d.ts" : ".ts";
              uri = this.getUri("_".concat(project, "_").concat(shortName), ftype);
              model = monaco.editor.createModel(src2, "typescript", uri);
              model1 = {
                changed: false,
                // not changed in this section, but storFile.changed is about all sections
                error: false,
                project,
                shortName,
                extension,
                model,
                storFile,
                originalCRC,
                originalProject,
                originalShortName,
                codeLens: []
              };
              mls.l2.editor.add(model1);
              this.addEventsModelTS(storFile, model1);
              if (!compile) return [3, 8];
              return [4, this.updateModelStatus(model1, false)];
            case 7:
              _c.sent();
              _c.label = 8;
            case 8:
              if (activedModel) {
                mls.l2.editor.editors[this.confE] = model1;
              }
              return [2, model1];
          }
        });
      });
    };
    ServiceSource100554.prototype.setModelConfEditor = function() {
      if (!this._ed1 || !this.mConfEditor)
        return;
      var src2 = this.getConfEditorToTypescript();
      this.mConfEditor["mlsConf"] = "confEditor";
      this.mConfEditor.setValue(src2);
      this._ed1.setModel(this.mConfEditor);
    };
    ServiceSource100554.prototype.createModelConf = function(src2) {
      return __awaiter(this, void 0, void 0, function() {
        var shortName, level, project, extension, storFile, uri, model;
        var _this = this;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (mls.istrace)
                console.log("ServiceSource, createModelConf_".concat(this.position, ", ").concat(!!this.mConfEditor));
              if (this.mConfEditor)
                return [
                  2
                  /*return*/
                ];
              shortName = this.confE + "_service_source.confEditor";
              level = 2;
              project = 0;
              extension = ".ts";
              return [4, mls.stor.addOrUpdateFile({ project, level, shortName, extension, versionRef: (/* @__PURE__ */ new Date()).toISOString(), folder: "" })];
            case 1:
              storFile = _a2.sent();
              uri = this.getUri(shortName, extension);
              model = monaco.editor.getModel(uri);
              if (model) {
                this.mConfEditor = model;
              } else
                this.mConfEditor = monaco.editor.createModel(src2, "typescript", uri);
              mls.l2.editor.add({
                changed: false,
                error: false,
                model: this.mConfEditor,
                storFile,
                project: 0,
                shortName,
                extension,
                codeLens: []
              });
              this.mConfEditor.onDidChangeContent(function(e) {
                var mode = _this.mConfEditor["mlsConf"];
                if (!mode || !_this.mConfEditor)
                  return;
                src2 = _this.mConfEditor.getValue();
                _this.compileSrcEditor(mode, src2);
              });
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.compileSrcEditor = function(mode, src2) {
      var _this = this;
      clearTimeout(this.timeout_compileConfEditor);
      this.timeout_compileConfEditor = window.setTimeout(function() {
        return __awaiter(_this, void 0, void 0, function() {
          var mmodel, rcc;
          return __generator(this, function(_a2) {
            switch (_a2.label) {
              case 0:
                if (!this.mConfEditor)
                  return [
                    2
                    /*return*/
                  ];
                mmodel = mls.l2.editor.find(this.mConfEditor.id);
                if (!mmodel)
                  return [
                    2
                    /*return*/
                  ];
                return [4, mls.l2.editor.getCompilerResultTS(mmodel, true)];
              case 1:
                rcc = _a2.sent();
                if (rcc.errors.length !== 0 || !rcc.prodJS)
                  return [
                    2
                    /*return*/
                  ];
                if (mode === "confEditor")
                  this.setConfEditorFromJavascript(rcc.prodJS, src2);
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      }, 500);
    };
    ServiceSource100554.prototype.loadConfEditorFromLocalStorage = function() {
      var json = localStorage.getItem("mlsConfEditor");
      if (json) {
        mls.editor.loadConfFromJSON(json);
      }
    };
    ServiceSource100554.prototype.saveConfEditorToLocalStorage = function() {
      localStorage.setItem("mlsConfEditor", JSON.stringify(mls.editor.conf));
    };
    ServiceSource100554.prototype.loadMonacoThemeFromLocalStorage = function() {
      if (!mls.editor.themeName)
        mls.editor.setThemeName(localStorage.getItem("mlsConfTheme"));
    };
    ServiceSource100554.prototype.saveMonacoGlobalThemeToLS = function() {
      localStorage.setItem("mlsConfTheme", mls.editor.themeName);
    };
    ServiceSource100554.prototype.getConfEditorToTypescript = function() {
      return `/// <mls shortName="config_monaco_editor" project="0" enhancement="config_config" />
		
mls.editor.conf['`.concat(this.confE, "'] = ") + JSON.stringify(mls.editor.conf[this.confE], null, 2) + ";\n";
    };
    ServiceSource100554.prototype.setConfEditorFromJavascript = function(javastr, src) {
      if (this.level < 1)
        return;
      var that = this;
      (function scope() {
        eval(javastr);
        if (mls.editor.conf[that.confE] && typeof mls.editor.conf[that.confE] === "object") {
          that.updateMonacoConfigutarions();
          that.saveConfEditorToLocalStorage();
        }
      }).call(this);
    };
    ServiceSource100554.prototype.updateMonacoConfigutarions = function() {
      return __awaiter(this, void 0, Promise, function() {
        return __generator(this, function(_a2) {
          if (this._ed1)
            this._ed1.updateOptions(mls.editor.conf[this.confE]);
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServiceSource100554.prototype.updateMonacoGlobalTheme = function() {
      var rc = true;
      if (mls.istrace)
        console.log("service source, updating monaco theme: ".concat(this.position));
      var internalThemes = ["VS", "VS Dark", "High Contrast (Dark)"];
      var internalThemes2 = ["vs", "vs-dark", "hc-black", "hc-light"];
      var name2 = "";
      try {
        var internalIndex = internalThemes.indexOf(mls.editor.themeName);
        if (internalIndex < 0) {
          name2 = "mytheme";
          var path = mls["baseMonaco"] + "../themes/" + mls.editor.themeName + ".json";
          mls.api.get(path, {}, function(data) {
            var json = JSON.parse(data);
            monaco.editor.defineTheme(name2, json);
            monaco.editor.setTheme(name2);
          });
        } else {
          name2 = internalThemes2[internalIndex];
          monaco.editor.setTheme(name2);
        }
      } catch (ex) {
        console.error("error on set theme " + name2, ex);
        rc = false;
      }
      return rc;
    };
    ServiceSource100554.prototype.getGlobalPageSetTHeme = function() {
      var _this = this;
      var div1 = document.createElement("div");
      div1.innerHTML = "<div>" + "<p id='theme-actual'>Theme actual: ".concat(mls.editor.themeName, " </p><br>") + '<p>Set Theme (only 1 theme in all editors)</p><select class="hidden" id="theme-select" style="display: initial;"><option>select ...</option><option value="vs">VS</option><option value="vs-dark">VS Dark</option><option value="hc-black">High Contrast (Dark)</option><option value="active4d">Active4D</option><option value="all-hallows-eve">All Hallows Eve</option><option value="amy">Amy</option><option value="birds-of-paradise">Birds of Paradise</option><option value="blackboard">Blackboard</option><option value="brilliance-black">Brilliance Black</option><option value="brilliance-dull">Brilliance Dull</option><option value="chrome-devtools">Chrome DevTools</option><option value="clouds-midnight">Clouds Midnight</option><option value="clouds">Clouds</option><option value="cobalt">Cobalt</option><option value="cobalt2">Cobalt2</option><option value="dawn">Dawn</option><option value="dracula">Dracula</option><option value="dreamweaver">Dreamweaver</option><option value="eiffel">Eiffel</option><option value="espresso-libre">Espresso Libre</option><option value="github">GitHub</option><option value="idle">IDLE</option><option value="katzenmilch">Katzenmilch</option><option value="kuroir-theme">Kuroir Theme</option><option value="lazy">LAZY</option><option value="magicwb--amiga-">MagicWB (Amiga)</option><option value="merbivore-soft">Merbivore Soft</option><option value="merbivore">Merbivore</option><option value="monokai-bright">Monokai Bright</option><option value="monokai">Monokai</option><option value="night-owl">Night Owl</option><option value="oceanic-next">Oceanic Next</option><option value="pastels-on-dark">Pastels on Dark</option><option value="slush-and-poppies">Slush and Poppies</option><option value="solarized-dark">Solarized-dark</option><option value="solarized-light">Solarized-light</option><option value="spacecadet">SpaceCadet</option><option value="sunburst">Sunburst</option><option value="textmate--mac-classic-">Textmate (Mac Classic)</option><option value="tomorrow-night-blue">Tomorrow-Night-Blue</option><option value="tomorrow-night-bright">Tomorrow-Night-Bright</option><option value="tomorrow-night-eighties">Tomorrow-Night-Eighties</option><option value="tomorrow-night">Tomorrow-Night</option><option value="tomorrow">Tomorrow</option><option value="twilight">Twilight</option><option value="upstream-sunburst">Upstream Sunburst</option><option value="vibrant-ink">Vibrant Ink</option><option value="xcode-default">Xcode_default</option><option value="zenburnesque">Zenburnesque</option><option value="iplastic">iPlastic</option><option value="idlefingers">idleFingers</option><option value="krtheme">krTheme</option><option value="monoindustrial">monoindustrial</option></select>';
      var sel = div1.querySelector("#theme-select");
      if (!sel)
        return div1;
      sel.oninput = function(ev) {
        var _a2, _b;
        if (((_a2 = ev === null || ev === void 0 ? void 0 : ev.srcElement) === null || _a2 === void 0 ? void 0 : _a2.localName) === "select") {
          var el = ev.srcElement;
          var actual = div1.querySelector("#theme-actual");
          if (el.selectedIndex < 1)
            return;
          mls.editor.setThemeName(((_b = el.options) === null || _b === void 0 ? void 0 : _b[el.selectedIndex].text) || "default");
          _this.saveMonacoGlobalThemeToLS();
          _this.updateMonacoGlobalTheme();
          if (actual)
            actual.innerHTML = "Theme changed to: ".concat(mls.editor.themeName);
        }
      };
      return div1;
    };
    ServiceSource100554.prototype.createOrShowModelHTML = function(open, fileInfo) {
      return __awaiter(this, void 0, Promise, function() {
        var _a2, shortName, project, uri, model, key, storFileHTML, src2, info, _b, haveInfo, originalCRC;
        return __generator(this, function(_c) {
          switch (_c.label) {
            case 0:
              _a2 = mls.l2.editor.editors[this.confE], shortName = _a2.shortName, project = _a2.project;
              uri = this.getUri("_".concat(project, "_").concat(shortName), ".html");
              model = monaco.editor.getModel(uri);
              key = mls.stor.getKeyToFiles(project, this.level, shortName, "", ".html");
              storFileHTML = mls.stor.files[key];
              if (!!storFileHTML) return [3, 2];
              return [4, this.createHTMLFile(project, shortName, "<h1>_".concat(project, "_").concat(shortName, "</h1>"))];
            case 1:
              _c.sent();
              storFileHTML = mls.stor.files[key];
              _c.label = 2;
            case 2:
              if (!!model) return [3, 4];
              return [4, this.getOrCreateModelHTML(shortName, project, storFileHTML, fileInfo)];
            case 3:
              model = _c.sent();
              _c.label = 4;
            case 4:
              if (!storFileHTML.getValueInfo) return [3, 6];
              return [4, storFileHTML.getValueInfo()];
            case 5:
              _b = _c.sent();
              return [3, 7];
            case 6:
              _b = null;
              _c.label = 7;
            case 7:
              info = _b;
              haveInfo = info && !!info.content;
              src2 = haveInfo ? info === null || info === void 0 ? void 0 : info.content : "";
              if (!!src2) return [3, 9];
              return [4, storFileHTML.getContent()];
            case 8:
              src2 = _c.sent();
              if (!src2)
                console.log("error on getContent, src is null");
              _c.label = 9;
            case 9:
              if (src2 instanceof Blob)
                throw new Error("html file must be string");
              if (!src2)
                src2 = "";
              originalCRC = haveInfo ? info === null || info === void 0 ? void 0 : info.originalCRC : mls.common.crc.crc32(src2).toString(16);
              model["originalCRC"] = originalCRC;
              if (src2)
                model.setValue(src2);
              if (open && this._ed1)
                this._ed1.setModel(model);
              return [2, storFileHTML];
          }
        });
      });
    };
    ServiceSource100554.prototype.createHTMLFile = function(project, shortName, content) {
      return __awaiter(this, void 0, void 0, function() {
        var params, file, fileInfo;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              params = {
                project,
                level: 2,
                shortName,
                extension: ".html",
                versionRef: "0",
                folder: ""
              };
              return [4, mls.stor.addOrUpdateFile(params)];
            case 1:
              file = _a2.sent();
              file.status = "new";
              fileInfo = {
                content,
                contentType: "string"
              };
              return [4, mls.stor.localStor.setContent(file, fileInfo)];
            case 2:
              _a2.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.getOrCreateModelHTML = function(shortName, project, storFileHTML, fileInfo) {
      return __awaiter(this, void 0, Promise, function() {
        var uri, model, content, _a2;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              uri = this.getUri("_".concat(project, "_").concat(shortName), ".html");
              model = monaco.editor.getModel(uri);
              if (model)
                return [2, model];
              if (!fileInfo) return [3, 1];
              _a2 = fileInfo.content;
              return [3, 3];
            case 1:
              return [4, storFileHTML.getContent()];
            case 2:
              _a2 = _b.sent();
              _b.label = 3;
            case 3:
              content = _a2;
              model = monaco.editor.createModel(content, "html", uri);
              model["position"] = this.position;
              storFileHTML["originalCRC"] = storFileHTML.inLocalStorage ? "undefined" : mls.common.crc.crc32(model.getValue()).toString(16);
              if (storFileHTML.status === "renamed" && fileInfo) {
                this.setEventsModelHTML(model, storFileHTML, fileInfo.originalShortName, fileInfo.originalProject);
                model.setValue(fileInfo.content);
              } else {
                this.setEventsModelHTML(model, storFileHTML, storFileHTML.shortName, storFileHTML.project);
              }
              return [2, model];
          }
        });
      });
    };
    ServiceSource100554.prototype.setEventsModelHTML = function(model, storFileHTML, shortName, project) {
      var _this = this;
      storFileHTML.onAction = function(action) {
        return _this.afterUpdateHTML(storFileHTML, model);
      };
      storFileHTML.getValueInfo = function() {
        return _this.getValueInfoHTML(model, shortName, project, storFileHTML["originalCRC"]);
      };
      if (model)
        model.onDidChangeContent(function(e) {
          return _this.onModelHTMLChange(e, storFileHTML, model);
        });
    };
    ServiceSource100554.prototype.renameHTMLFile = function(storFileHTML, newProject, newShortName) {
      return __awaiter(this, void 0, void 0, function() {
        var newSts, valueInfo, status, key, newStorFileHTML;
        var _this = this;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (!storFileHTML)
                return [
                  2
                  /*return*/
                ];
              newSts = { shortName: newShortName, project: newProject };
              return [4, this.getOrCreateModelHTML(storFileHTML.shortName, storFileHTML.project, storFileHTML)];
            case 1:
              _a2.sent();
              if (!storFileHTML.getValueInfo)
                return [
                  2
                  /*return*/
                ];
              return [4, storFileHTML.getValueInfo()];
            case 2:
              valueInfo = _a2.sent();
              status = storFileHTML.status;
              if (!mls.stor.renameFile(storFileHTML, newSts))
                throw new Error("Error on rename mls.stor.files");
              key = mls.stor.getKeyToFiles(newProject, this.level, newShortName, "", ".html");
              newStorFileHTML = mls.stor.files[key];
              newStorFileHTML.status = "renamed";
              return [4, mls.stor.localStor.setContent(newStorFileHTML, valueInfo)];
            case 3:
              _a2.sent();
              setTimeout(function() {
                return __awaiter(_this, void 0, void 0, function() {
                  var file;
                  return __generator(this, function(_a3) {
                    switch (_a3.label) {
                      case 0:
                        return [4, this.createOrShowModelHTML(false, valueInfo)];
                      case 1:
                        file = _a3.sent();
                        if (status === "new")
                          file.status = status;
                        return [
                          2
                          /*return*/
                        ];
                    }
                  });
                });
              }, 500);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.afterUpdateHTML = function(storFile, model) {
      return __awaiter(this, void 0, void 0, function() {
        var keyFiles;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (!(storFile.status === "deleted")) return [3, 2];
              return [4, mls.stor.localStor.setContent(storFile, { contentType: "string", content: null })];
            case 1:
              _a2.sent();
              keyFiles = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, storFile.extension);
              delete mls.stor.files[keyFiles];
              return [
                2
                /*return*/
              ];
            case 2:
              if (storFile.status === "renamed") {
                storFile["originalCRC"] = mls.common.crc.crc32(model.getValue()).toString(16);
              }
              return [4, mls.stor.localStor.setContent(storFile, { contentType: "string", content: null })];
            case 3:
              _a2.sent();
              storFile.status = "nochange";
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSource100554.prototype.updated = function(changedProperties) {
      var _a2;
      if (changedProperties.has("msize")) {
        if (!this.visible)
          return;
        (_a2 = this.c2) === null || _a2 === void 0 ? void 0 : _a2.setAttribute("msize", this.msize);
      }
    };
    ServiceSource100554.prototype.render = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['\n            <mls-editor-100529 ismls2="true"></mls-editor-100529>\n        '], ['\n            <mls-editor-100529 ismls2="true"></mls-editor-100529>\n        '])));
    };
    ServiceSource100554.prototype.saveLocalStorageLastOpen = function(storFile, position) {
      try {
        var last = localStorage.getItem("_100554_serviceSource");
        last = last ? last : "{}";
        var info = JSON.parse(last);
        var keyLocal = "last_" + this.level + "_" + position;
        if (info[keyLocal]) {
          info[keyLocal].project = storFile.project;
          info[keyLocal].shortName = storFile.shortName;
          info[keyLocal].extension = storFile.extension;
          info[keyLocal].level = storFile.level;
          info[keyLocal].folder = storFile.folder;
        } else {
          info[keyLocal] = {
            project: storFile.project,
            shortName: storFile.shortName,
            extension: storFile.extension,
            level: storFile.level,
            folder: storFile.folder
          };
        }
        localStorage.setItem("_100554_serviceSource", JSON.stringify(info));
      } catch (e) {
        localStorage.setItem("_100554_serviceSource", JSON.stringify({}));
      }
    };
    ServiceSource100554.prototype.openLastFile = function(level, position) {
      try {
        var last = localStorage.getItem("_100554_serviceSource");
        last = last ? last : "{}";
        var info = JSON.parse(last);
        var keyLocal = "last_" + level + "_" + position;
        if (!info[keyLocal])
          return false;
        var key = mls.l2.editor.getKey({
          project: +info[keyLocal].project,
          shortName: info[keyLocal].shortName
        });
        var model = mls.l2.editor.mfiles[key];
        if (!model)
          return false;
        mls.l2.editor.editors[this.confE] = model;
        mls.actual[this.level].setFullName("_".concat(info[keyLocal].project, "_").concat(info[keyLocal].shortName));
        mls.actual[this.level][position] = {
          project: model.storFile.project,
          shortName: model.storFile.shortName,
          extension: model.storFile.extension,
          folder: model.storFile.folder
        };
        return true;
      } catch (e) {
        return false;
      }
    };
    ServiceSource100554.prototype.getActualRef = function() {
      try {
        var ret = "";
        if (!mls.actual[2] || !mls.actual[2][this.position])
          return ret;
        var actual = mls.actual[2][this.position];
        var ext = this.menu.lastIcon === "icTs" ? ".ts" : ".html";
        if (!actual)
          return ret;
        ret = mls.stor.getKeyToFiles(actual.project, 2, actual.shortName, actual.folder, ext);
        return ret;
      } catch (e) {
        return "";
      }
    };
    var ServiceSource100554_1;
    var _a;
    ServiceSource100554.projectsLoaded = [];
    __decorate([
      property({ type: String }),
      __metadata("design:type", Object)
    ], ServiceSource100554.prototype, "msize", void 0);
    __decorate([
      query("mls-editor-100529"),
      __metadata("design:type", typeof (_a = typeof HTMLElement !== "undefined" && HTMLElement) === "function" ? _a : Object)
    ], ServiceSource100554.prototype, "c2", void 0);
    ServiceSource100554 = ServiceSource100554_1 = __decorate([
      customElement("service-source-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceSource100554);
    return ServiceSource100554;
  }(ServiceBase)
);
var templateObject_1;
export {
  ServiceSource100554
};
