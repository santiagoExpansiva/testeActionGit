var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, unsafeHTML } from "lit";
import { customElement } from "lit/decorators.js";
import { CollabLitElement } from "./_100554_collabLitElement";
function initCodelensComponentDetails() {
  return true;
}
var message_pt = {
  usage: "Uso",
  p1: "O par\uFFFDmetro mlsComponentDetails \uFFFD usado para determinar se h\uFFFD depend\uFFFDncias em quaisquer componentes da web. Esta defini\uFFFD\uFFFDo \uFFFD importante para o funcionamento/compila\uFFFD\uFFFDo adequada do componente.<br> Para fazer esta defini\uFFFD\uFFFDo, use JsDoc no in\uFFFDcio do arquivo, configurando a tag mlsComponentDetails."
};
var message_en = {
  usage: "Usage",
  p1: "The parameter mlsComponentDetails is used to determine if there are any dependencies on any web components. This definition is important for the proper functioning/compilation of the component.<br> To make this definition, use JsDoc at the beginning of the file, setting the mlsComponentDetails tag."
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var CodeLensComponentDetails100554 = (
  /** @class */
  function(_super) {
    __extends(CodeLensComponentDetails1005542, _super);
    function CodeLensComponentDetails1005542() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.msg = messages["en"];
      _this.textCode = `
        /**
         <br>
         * @mlsComponentDetails {"webComponentDependencies": ["my-web-component-100541"]}
        <br>
         */
        <br>
        <br>

        import { html, LitElement } from 'lit';
        <br>
        import { customElement } from 'lit/decorators.js';
        <br>
         <br>
        @customElement('example-100541')
        <br>
        export class Example extends LitElement { [...] }

    `;
      return _this;
    }
    CodeLensComponentDetails1005542.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n        <h1> mlsComponentDetails</h1>\n        <p> ", " </p>\n        \n        <hr>\n        <h2>", ":</h2>\n        <code>", "</code>\n\n        "], ["\n        <h1> mlsComponentDetails</h1>\n        <p> ", " </p>\n        \n        <hr>\n        <h2>", ":</h2>\n        <code>", "</code>\n\n        "])), this.msg.p1, this.msg.usage, unsafeHTML(this.textCode));
    };
    CodeLensComponentDetails1005542.styles = css(templateObject_2 || (templateObject_2 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    CodeLensComponentDetails1005542 = __decorate([
      customElement("codelens-component-details-100554")
    ], CodeLensComponentDetails1005542);
    return CodeLensComponentDetails1005542;
  }(CollabLitElement)
);
var templateObject_1, templateObject_2;
export {
  CodeLensComponentDetails100554,
  initCodelensComponentDetails
};
