import { IcaLitElement } from "./_100554_icaLitElement";
class IcaLayoutFlowColumnBase extends IcaLitElement {
}
export {
  IcaLayoutFlowColumnBase
};
