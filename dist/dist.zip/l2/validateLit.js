import { convertFileNameToTag } from "./_100554_utilsLit";
function validateTagName(mfile) {
  mfile.storFile.hasError = false;
  clearErrorsOnModel(mfile.model);
  if (!mfile || !mfile.compilerResults)
    return false;
  if (mfile.shortName === "enhancementLit" && mfile.project === 100554)
    return false;
  var decorators = JSON.parse(mfile.compilerResults.decorators);
  if (!decorators)
    return false;
  var decoratorToCheck = "customElement";
  var rc = false;
  Object.entries(decorators).forEach(function(entrie) {
    var decoratorInfo = entrie[1];
    if (!decoratorInfo || decoratorInfo.type !== "ClassDeclaration")
      return;
    decoratorInfo.decorators.forEach(function(_decorator) {
      var decoratorInfo2 = getDecoratorClassInfo(_decorator.text);
      if (!decoratorInfo2 || decoratorInfo2.decoratorName !== decoratorToCheck)
        return;
      var correctTagName = convertFileNameToTag("_".concat(mfile.project, "_").concat(mfile.shortName));
      if (correctTagName !== decoratorInfo2.tagName) {
        rc = true;
        setErrorOnModel(mfile.model, _decorator.line + 1, decoratorToCheck.length + 3, _decorator.text.length + 1, "Invalid web component tag name, the correct definition is: ".concat(correctTagName), monaco.MarkerSeverity.Error);
        mfile.storFile.hasError = true;
      }
    });
  });
  return rc;
}
function validateRender(mfile) {
  mfile.storFile.hasError = false;
  clearErrorsOnModel(mfile.model);
  if (!mfile || !mfile.compilerResults)
    return false;
  if (mfile.shortName === "enhancementLit" && mfile.project === 100554)
    return false;
  var shortName = "_".concat(mfile.project, "_").concat(mfile.shortName);
  return verify(mfile.model, shortName, mfile);
}
function getDecoratorClassInfo(decoratorString) {
  var regex = /(\w+)\(['"](.+?)['"]\)/;
  var match = decoratorString.match(regex);
  var result = void 0;
  if (match && match.length > 2) {
    var decoratorName = match[1];
    var tagName = match[2];
    result = {
      decoratorName,
      tagName
    };
  }
  return result;
}
function getLineIndent(model, lineNumber) {
  if (model) {
    var lineContent = model.getLineContent(lineNumber);
    var match = lineContent.match(/^\s*/);
    return match ? match[0].length : 0;
  }
  return 0;
}
function setErrorOnModel(model, line, startColumn, endColumn, message, severity) {
  var lineIndent = getLineIndent(model, line);
  var markerOptions = {
    severity,
    message,
    startLineNumber: line,
    startColumn: startColumn + lineIndent,
    endLineNumber: line,
    endColumn: endColumn + lineIndent
  };
  monaco.editor.setModelMarkers(model, "markerSource", [markerOptions]);
}
function clearErrorsOnModel(model) {
  monaco.editor.setModelMarkers(model, "markerSource", []);
}
function verify(model, shortName, mfile) {
  var lines = model.getLinesContent();
  var tag = convertFileNameToTag(shortName);
  var msgError = "Do not use the same component tag (".concat(tag, ") inside the rendering, possible looping");
  var htmlCount = 0;
  var rc = false;
  for (var i = 0; i < lines.length; i++) {
    var line = lines[i];
    line = line.replace(/\/\/.*/, "");
    var lineInCommentBlock = isInCommentBlock(lines, i + 1);
    line = line.replace(/\s+/g, "");
    if (line.indexOf("document.createElement('".concat(tag, "')")) >= 0 || line.indexOf('document.createElement("'.concat(tag, '")')) >= 0) {
      setErrorOnModel(model, i + 1, 0, line.length, msgError, monaco.MarkerSeverity.Warning);
      rc = true;
      break;
    }
    if (line.indexOf("html`") >= 0 && !lineInCommentBlock)
      htmlCount += 1;
    if (line.indexOf("`") >= 0 && line.indexOf("html`") === -1 && !lineInCommentBlock)
      htmlCount -= 1;
    if (htmlCount != 0) {
      if (line.indexOf("<" + tag) >= 0) {
        var column = model.getLineFirstNonWhitespaceColumn(i + 1);
        var length = model.getLineLength(i + 1);
        setErrorOnModel(model, i + 1, column, length, msgError, monaco.MarkerSeverity.Warning);
        rc = true;
        break;
      }
    }
  }
  return rc;
}
function isInCommentBlock(lines, lineNumber) {
  var countStartBlockComment = 0;
  var countEndBlockComment = 0;
  for (var i = 0; i <= lineNumber - 1; i++) {
    var line = lines[i];
    if (line.indexOf("/*") >= 0)
      countStartBlockComment += 1;
    if (line.indexOf("*/") >= 0 && i !== lineNumber - 1)
      countEndBlockComment += 1;
  }
  var isInBlockComment = countStartBlockComment > countEndBlockComment;
  return isInBlockComment;
}
;
export {
  setErrorOnModel,
  validateRender,
  validateTagName
};
