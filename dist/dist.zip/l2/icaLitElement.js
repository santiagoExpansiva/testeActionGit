var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
import { state1 } from "./_100554_icaDecorators";
import { CollabLitElement } from "./_100554_collabLitElement";
export * from "./_100554_icaDecorators";
var isTrace = false;
var IcaLitElement = (
  /** @class */
  function(_super) {
    __extends(IcaLitElement2, _super);
    function IcaLitElement2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.stateKeys = /* @__PURE__ */ new Set();
      return _this;
    }
    IcaLitElement2.prototype.connectedCallback = function() {
      _super.prototype.connectedCallback.call(this);
      if (isTrace)
        console.info("connectedCallback, subscribe fields: ".concat(Array.from(this.stateKeys)));
      state1.subscribe(Array.from(this.stateKeys), this);
    };
    IcaLitElement2.prototype.disconnectedCallback = function() {
      _super.prototype.disconnectedCallback.call(this);
      state1.unsubscribe(Array.from(this.stateKeys), this);
    };
    IcaLitElement2.prototype.handleIcaStateChange = function(key, value) {
      var _this = this;
      function isEqual(newValue, oldValue) {
        return JSON.stringify(newValue) === JSON.stringify(oldValue);
      }
      var ob1 = this;
      Array.from(this.stateKeys).forEach(function(stateKey) {
        var _a = stateKey.split(";"), propName = _a[0], path = _a[1];
        if (path !== key || !ob1.hasAttribute(propName))
          return;
        var propValue = ob1["_".concat(propName)];
        if (!isEqual(value, propValue)) {
          ob1["_".concat(propName)] = value;
          _this.requestUpdate();
        }
      });
    };
    return IcaLitElement2;
  }(CollabLitElement)
);
export {
  IcaLitElement
};
