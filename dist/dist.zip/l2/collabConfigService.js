var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var __spreadArray = function(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};
import { html, css, repeat } from "lit";
import { customElement, property } from "lit/decorators.js";
import { CollabLitElement } from "./_100554_collabLitElement";
var message_pt = {
  addService: "Adicionar Servi\uFFFDo",
  back: "Voltar",
  hidden: "Oculto",
  style: "Estilo"
};
var message_en = {
  addService: "Add Service",
  back: "Back",
  hidden: "Hidden",
  style: "Style"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var CollabConfig100554 = (
  /** @class */
  function(_super) {
    __extends(CollabConfig1005542, _super);
    function CollabConfig1005542() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.msg = messages["en"];
      _this.currentScenario = "list";
      _this.error = "";
      _this.positionToolbar = "left";
      _this.actualLevel = -1;
      _this.userServices = [];
      _this.avaliableServices = [];
      _this.infos = {};
      return _this;
    }
    CollabConfig1005542.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      this.style.height = "100%";
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['\n        <div class="bodyServiceConfig">\n            ', "\n        </div>"], ['\n        <div class="bodyServiceConfig">\n            ', "\n        </div>"])), this.currentScenario === "list" ? html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n                    ", "\n                    ", "\n                "], ["\n                    ", "\n                    ", "\n                "])), this.renderHeader(), this.renderListServices()) : html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n                    ", "\n                    ", " \n                "], ["\n                    ", "\n                    ", " \n                "])), this.renderHeader(), this.renderListAddServices()));
    };
    CollabConfig1005542.prototype.connectedCallback = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              _super.prototype.connectedCallback.call(this);
              this.setInfos();
              return [4, this.getServices()];
            case 1:
              _a.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    CollabConfig1005542.prototype.renderHeader = function() {
      return html(templateObject_10 || (templateObject_10 = __makeTemplateObject(['\n        \n        <div class="header">\n            \n            ', "\n            ", '\n            <div style="font-size:90%; display: flex; justify-content: center; align-items: center; padding-right: 0.5rem;">\n                <span style="margin-right:5px">Position:</span>\n                ', "\n                \n            </div>\n        </div>\n        "], ['\n        \n        <div class="header">\n            \n            ', "\n            ", '\n            <div style="font-size:90%; display: flex; justify-content: center; align-items: center; padding-right: 0.5rem;">\n                <span style="margin-right:5px">Position:</span>\n                ', "\n                \n            </div>\n        </div>\n        "])), this.currentScenario === "list" ? html(templateObject_4 || (templateObject_4 = __makeTemplateObject(['\n                    <button @click="', '">', "</button>\n                "], ['\n                    <button @click="', '">', "</button>\n                "])), this.goToScenaryAdd, this.msg.addService) : html(templateObject_5 || (templateObject_5 = __makeTemplateObject(['\n                    <button @click="', '">', "</button>\n                "], ['\n                    <button @click="', '">', "</button>\n                "])), this.goToScenaryList, this.msg.back), this.error ? html(templateObject_6 || (templateObject_6 = __makeTemplateObject(['\n                    <div style="color:red">', "</div>\n                "], ['\n                    <div style="color:red">', "</div>\n                "])), this.error) : html(templateObject_7 || (templateObject_7 = __makeTemplateObject([""], [""]))), this.positionToolbar === "left" ? html(templateObject_8 || (templateObject_8 = __makeTemplateObject(['<input type="radio" value="left" id="leftradioopt" name="radioOpt" checked \n                @click="', '" />\n                <label for="leftradioopt" style="margin-right:5px">left</label>\n                <input type="radio" value="right" id="rightradioopt" name="radioOpt" @click="', '"/>\n                <label for="rightradioopt">right</label>'], ['<input type="radio" value="left" id="leftradioopt" name="radioOpt" checked \n                @click="', '" />\n                <label for="leftradioopt" style="margin-right:5px">left</label>\n                <input type="radio" value="right" id="rightradioopt" name="radioOpt" @click="', '"/>\n                <label for="rightradioopt">right</label>'])), this.onclickPositionLeft, this.onclickPositionRight) : html(templateObject_9 || (templateObject_9 = __makeTemplateObject(['<input type="radio" value="left" id="leftradioopt" name="radioOpt"  \n                @click="', '" />\n                <label for="leftradioopt" style="margin-right:5px">left</label>\n                <input type="radio" value="right" id="rightradioopt" name="radioOpt" @click="', '" checked/>\n                <label for="rightradioopt">right</label>'], ['<input type="radio" value="left" id="leftradioopt" name="radioOpt"  \n                @click="', '" />\n                <label for="leftradioopt" style="margin-right:5px">left</label>\n                <input type="radio" value="right" id="rightradioopt" name="radioOpt" @click="', '" checked/>\n                <label for="rightradioopt">right</label>'])), this.onclickPositionLeft, this.onclickPositionRight));
    };
    CollabConfig1005542.prototype.onclickPositionLeft = function() {
      this.positionToolbar = "left";
      this.getServices();
    };
    CollabConfig1005542.prototype.onclickPositionRight = function() {
      this.positionToolbar = "right";
      this.getServices();
    };
    CollabConfig1005542.prototype.renderListAddServices = function() {
      var _this = this;
      return html(templateObject_12 || (templateObject_12 = __makeTemplateObject(['\n        <ul class="listView">\n            ', "    \n        </ul>\n        "], ['\n        <ul class="listView">\n            ', "    \n        </ul>\n        "])), repeat(this.avaliableServices, function(item) {
        return item.icon;
      }, function(service, index) {
        return html(templateObject_11 || (templateObject_11 = __makeTemplateObject(['\n                        <li>\n                            <div class="groupInfos" style="justify-content:start;">\n                                <div>#', "</div>\n                                <div>\n                                    ", '\n                                </div>\n                            </div>\n                            <div class="groupInfos" style="justify-content:end;">\n                                <div>\n                                    <a myIndex="', '" @click="', '">Active</a>\n                                </div>\n                            </div>\n                        </li>\n                    '], ['\n                        <li>\n                            <div class="groupInfos" style="justify-content:start;">\n                                <div>#', "</div>\n                                <div>\n                                    ", '\n                                </div>\n                            </div>\n                            <div class="groupInfos" style="justify-content:end;">\n                                <div>\n                                    <a myIndex="', '" @click="', '">Active</a>\n                                </div>\n                            </div>\n                        </li>\n                    '])), index + 1, service.tooltip, index, _this.activeService);
      }));
    };
    CollabConfig1005542.prototype.renderListServices = function() {
      var _this = this;
      return html(templateObject_14 || (templateObject_14 = __makeTemplateObject(['\n        <ul class="listView">\n            ', "\n        </ul>\n        "], ['\n        <ul class="listView">\n            ', "\n        </ul>\n        "])), repeat(this.userServices, function(item) {
        return item.widget;
      }, function(service, index) {
        return html(templateObject_13 || (templateObject_13 = __makeTemplateObject(['\n                    <li>\n                        <div class="groupInfos" style="justify-content:start;">\n                            <div>#', "</div>\n                            <div>\n                                ", '\n                                <span class="badge" style="display:', '">', '<span>\n                            </div>\n                        </div>\n                        <div class="groupInfos" style="justify-content:end;display:flex; gap:1rem;">\n                            <div style="display: flex; justify-content: center; align-items: center;">\n                                <span class="fa fa-ellipsis-vertical" style="cursor:pointer" @click="', '"></span>\n                                <span class="groupHidden" style="display:none">\n                                    <a myIndex="', '" @click="', '">Desactivate</a>\n                                    <span style="margin: 0px 1rem">|</span>\n                                    <label>', '</label>\n                                    <select  myIndex="', '" @change="', '"> \n                                        <option value="" ?selected="', '"></option>\n                                        <option value="separator-left" ?selected="', '">separator-left</option>\n                                        <option value="separator-right" ?selected="', '">separator-right</option>\n                                    </select>\n                                    \n                                </span>\n                            </div>\n                            <div>\n                                <span class="fa fa-arrow-up-long" style="cursor:pointer" move="up" myIndex="', '" @click="', '"></span>\n                                <span class="fa fa-arrow-down-long" style="cursor:pointer" move="down" myIndex="', '" @click="', '"></span>\n                            </div>\n                        </div>\n                    </li>\n                    '], ['\n                    <li>\n                        <div class="groupInfos" style="justify-content:start;">\n                            <div>#', "</div>\n                            <div>\n                                ", '\n                                <span class="badge" style="display:', '">', '<span>\n                            </div>\n                        </div>\n                        <div class="groupInfos" style="justify-content:end;display:flex; gap:1rem;">\n                            <div style="display: flex; justify-content: center; align-items: center;">\n                                <span class="fa fa-ellipsis-vertical" style="cursor:pointer" @click="', '"></span>\n                                <span class="groupHidden" style="display:none">\n                                    <a myIndex="', '" @click="', '">Desactivate</a>\n                                    <span style="margin: 0px 1rem">|</span>\n                                    <label>', '</label>\n                                    <select  myIndex="', '" @change="', '"> \n                                        <option value="" ?selected="', '"></option>\n                                        <option value="separator-left" ?selected="', '">separator-left</option>\n                                        <option value="separator-right" ?selected="', '">separator-right</option>\n                                    </select>\n                                    \n                                </span>\n                            </div>\n                            <div>\n                                <span class="fa fa-arrow-up-long" style="cursor:pointer" move="up" myIndex="', '" @click="', '"></span>\n                                <span class="fa fa-arrow-down-long" style="cursor:pointer" move="down" myIndex="', '" @click="', '"></span>\n                            </div>\n                        </div>\n                    </li>\n                    '])), index + 1, service.tooltip, service.visible ? "none" : "inline-block", _this.msg.hidden, _this.openHiddenConfigs, index, _this.desactiveService, _this.msg.style, index, _this.changeClassName, service && !["separator-left", "separator-right"].includes(service.classname), service.classname === "separator-left", service.classname === "separator-right", index, _this.moveElement, index, _this.moveElement);
      }));
    };
    CollabConfig1005542.prototype.setInfos = function() {
      var _a;
      this.infos.nav = (_a = this.closest("collab-nav-3")) === null || _a === void 0 ? void 0 : _a.previousElementSibling;
      if (!this.infos.nav)
        return;
      var level = this.infos.nav.getAttribute("level");
      this.actualLevel = level ? +level : -1;
    };
    CollabConfig1005542.prototype.goToScenaryAdd = function() {
      this.currentScenario = "add";
    };
    CollabConfig1005542.prototype.goToScenaryList = function() {
      this.currentScenario = "list";
    };
    CollabConfig1005542.prototype.openHiddenConfigs = function(e) {
      var _a;
      e.stopPropagation();
      var el = e.target;
      if (!el)
        return;
      var elHidden = (_a = el.parentElement) === null || _a === void 0 ? void 0 : _a.querySelector(".groupHidden");
      if (!elHidden)
        return;
      var state = elHidden.style.display === "" ? "none" : "";
      elHidden.style.display = state;
    };
    CollabConfig1005542.prototype.changeClassName = function(e) {
      var el = e.target;
      if (!el)
        return;
      var indexs = el.getAttribute("myIndex");
      var indexOri = indexs ? +indexs : -1;
      if (!this.userServices[indexOri])
        return;
      this.userServices = __spreadArray([], this.userServices, true);
      this.fireChangeClassName(indexOri, el.value);
    };
    CollabConfig1005542.prototype.desactiveService = function(e) {
      var _this = this;
      e.stopPropagation();
      var el = e.target;
      if (!el)
        return;
      var indexs = el.getAttribute("myIndex");
      var indexOri = indexs ? +indexs : -1;
      var userArray = __spreadArray([], this.userServices, true);
      var avaliableArray = __spreadArray([], this.avaliableServices, true);
      var obj = userArray[indexOri];
      if (!obj || obj.isStatic) {
        this.error = "This service cannot be deactivated!";
        setTimeout(function() {
          _this.error = "";
        }, 3e3);
        return;
      }
      ;
      avaliableArray.push(obj);
      userArray.splice(indexOri, 1);
      this.userServices = userArray;
      this.avaliableServices = avaliableArray;
      this.fireRemoveService(indexOri);
    };
    CollabConfig1005542.prototype.activeService = function(e) {
      e.stopPropagation();
      var el = e.target;
      if (!el)
        return;
      var indexs = el.getAttribute("myIndex");
      var indexOri = indexs ? +indexs : -1;
      var userArray = __spreadArray([], this.userServices, true);
      var avaliableArray = __spreadArray([], this.avaliableServices, true);
      var obj = avaliableArray[indexOri];
      if (!obj)
        return;
      userArray.push(obj);
      avaliableArray.splice(indexOri, 1);
      this.userServices = userArray;
      this.avaliableServices = avaliableArray;
      this.fireAddService(obj);
    };
    CollabConfig1005542.prototype.moveElement = function(e) {
      var _this = this;
      e.stopPropagation();
      var el = e.target;
      if (!el)
        return;
      var move = el.getAttribute("move");
      var indexs = el.getAttribute("myIndex");
      var indexOri = indexs ? +indexs : -1;
      var indexDest = -1;
      if (indexOri < 0 || move === "up" && indexOri === 0 || move === "down" && indexOri === this.userServices.length - 1)
        return;
      indexDest = move === "up" ? indexOri - 1 : indexDest = indexOri + 1;
      if (indexDest === indexOri)
        return;
      var objTo = this.userServices[indexDest];
      var objFrom = this.userServices[indexOri];
      if (objTo.isStatic) {
        this.error = "This service cannot be moved to this position!";
        setTimeout(function() {
          _this.error = "";
        }, 3e3);
        return;
      }
      if (!objFrom)
        return;
      if (objFrom.isStatic) {
        this.error = "This service is static, cannot be moved";
        setTimeout(function() {
          _this.error = "";
        }, 3e3);
        return;
      }
      if (indexOri < indexDest) {
        this.userServices.splice(indexDest + 1, 0, objFrom);
        this.userServices.splice(indexOri, 1);
      } else {
        this.userServices.splice(indexDest, 0, objFrom);
        this.userServices.splice(indexOri + 1, 1);
      }
      this.userServices = __spreadArray([], this.userServices, true);
      this.fireMoveService(indexOri, indexDest);
    };
    CollabConfig1005542.prototype.getServices = function() {
      return __awaiter(this, void 0, void 0, function() {
        var arrayUserServices, arrayAvaliableServices;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              return [4, this.getUserServices()];
            case 1:
              arrayUserServices = _a.sent();
              return [4, this.getAvaliableServices()];
            case 2:
              arrayAvaliableServices = _a.sent();
              this.userServices = arrayUserServices[this.actualLevel][this.positionToolbar];
              this.avaliableServices = arrayAvaliableServices[this.actualLevel][this.positionToolbar];
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    CollabConfig1005542.prototype.getAvaliableServices = function() {
      return __awaiter(this, void 0, void 0, function() {
        var avaliableServices;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (!this.infos.nav)
                return [2, []];
              return [4, this.infos.nav.getAvaliableServices()];
            case 1:
              avaliableServices = _a.sent();
              return [2, avaliableServices];
          }
        });
      });
    };
    CollabConfig1005542.prototype.getUserServices = function() {
      return __awaiter(this, void 0, void 0, function() {
        var avaliableServices;
        return __generator(this, function(_a) {
          if (!this.infos.nav)
            return [2, []];
          avaliableServices = this.infos.nav.getUserServices();
          return [2, avaliableServices];
        });
      });
    };
    CollabConfig1005542.prototype.fireChangeClassName = function(index, cls) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (!this.infos.nav)
                return [
                  2
                  /*return*/
                ];
              return [4, this.infos.nav.updateClassName(index, cls, this.actualLevel, this.positionToolbar)];
            case 1:
              _a.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    CollabConfig1005542.prototype.fireAddService = function(service) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (!this.infos.nav)
                return [
                  2
                  /*return*/
                ];
              return [4, this.infos.nav.addService(service, this.actualLevel, this.positionToolbar)];
            case 1:
              _a.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    CollabConfig1005542.prototype.fireRemoveService = function(index) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (!this.infos.nav)
                return [
                  2
                  /*return*/
                ];
              return [4, this.infos.nav.removeService(index, this.actualLevel, this.positionToolbar)];
            case 1:
              _a.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    CollabConfig1005542.prototype.fireMoveService = function(indexOri, indexDest) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (!this.infos.nav)
                return [
                  2
                  /*return*/
                ];
              return [4, this.infos.nav.moveService(indexOri, indexDest, this.actualLevel, this.positionToolbar)];
            case 1:
              _a.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    CollabConfig1005542.styles = css(templateObject_15 || (templateObject_15 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], CollabConfig1005542.prototype, "currentScenario", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], CollabConfig1005542.prototype, "error", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], CollabConfig1005542.prototype, "positionToolbar", void 0);
    __decorate([
      property({ type: Number }),
      __metadata("design:type", Number)
    ], CollabConfig1005542.prototype, "actualLevel", void 0);
    __decorate([
      property({ type: Array }),
      __metadata("design:type", Array)
    ], CollabConfig1005542.prototype, "userServices", void 0);
    __decorate([
      property({ type: Array }),
      __metadata("design:type", Array)
    ], CollabConfig1005542.prototype, "avaliableServices", void 0);
    CollabConfig1005542 = __decorate([
      customElement("collab-config-service-100554")
    ], CollabConfig1005542);
    return CollabConfig1005542;
  }(CollabLitElement)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6, templateObject_7, templateObject_8, templateObject_9, templateObject_10, templateObject_11, templateObject_12, templateObject_13, templateObject_14, templateObject_15;
export {
  CollabConfig100554
};
