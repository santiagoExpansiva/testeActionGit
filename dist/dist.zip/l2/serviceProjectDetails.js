var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css } from "lit";
import { customElement, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
var message_pt = {
  noProjectSelected: "Nenhum projeto selecionado!",
  resume: "Resumo",
  name: "Nome",
  projectDriver: "Driver do Projeto",
  projectURL: "URL do Projeto",
  designSystems: "Sistemas de Design",
  files: "Arquivos",
  keyGithub: "Chave do GitHub"
};
var message_en = {
  noProjectSelected: "No project selected!",
  resume: "Resume",
  name: "Name",
  projectDriver: "ProjectDriver",
  projectURL: "ProjectURL",
  designSystems: "DesignSystems",
  files: "Files",
  keyGithub: "Key Github"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceProjectDetails100554 = (
  /** @class */
  function(_super) {
    __extends(ServiceProjectDetails1005542, _super);
    function ServiceProjectDetails1005542() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.details = {
        icon: "&#xf15b",
        state: "foreground",
        position: "right",
        tooltip: "Project Details",
        visible: true,
        widget: "_100554_serviceProjectDetails",
        level: [5]
      };
      _this.onClickLink = function(op) {
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.menu = {
        title: "Project",
        actions: {},
        icons: {},
        actionDefault: "",
        // call after close icon clicked
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        getLastMode: void 0,
        updateTitle: void 0
      };
      mls.events.addListener(5, "ProjectSelected", function(ev) {
        return _this.onProjectSelected(ev);
      });
      return _this;
    }
    ServiceProjectDetails1005542.prototype.onServiceClick = function(visible, reinit, el) {
    };
    ServiceProjectDetails1005542.prototype.getDetailsProject = function(project) {
      var details = mls.l5.getProjectSettings(project);
      if (!this.actualProjectDetails)
        this.actualProjectDetails = {};
      this.actualProjectDetails.designSystems = details.designSystems ? details.designSystems.length : 0;
      this.actualProjectDetails.name = details.name;
      this.actualProjectDetails.projectDriver = details.projectDriver;
      this.actualProjectDetails.projectURL = details.projectURL;
      this.actualProjectDetails.files = Object.keys(mls.stor.files).filter(function(item) {
        return item.startsWith(project.toString());
      }).length;
      this.actualKeyGitHub = localStorage === null || localStorage === void 0 ? void 0 : localStorage.getItem("keyGitHub");
      this.requestUpdate();
    };
    ServiceProjectDetails1005542.prototype.onProjectSelected = function(ev) {
      if (!ev.desc)
        return;
      var data = JSON.parse(ev.desc);
      this.getDetailsProject(data.value);
    };
    ServiceProjectDetails1005542.prototype.getLastProject = function() {
      var lastPrjId = localStorage.getItem("l5-last-project");
      if (lastPrjId)
        this.getDetailsProject(+lastPrjId);
    };
    ServiceProjectDetails1005542.prototype.handleChangeKey = function() {
      if (this.actualKeyGitHub) {
        localStorage === null || localStorage === void 0 ? void 0 : localStorage.setItem("keyGitHub", this.actualKeyGitHub);
      }
    };
    ServiceProjectDetails1005542.prototype.handleInputChangeKey = function(value) {
      this.actualKeyGitHub = value;
    };
    ServiceProjectDetails1005542.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      this.getLastProject();
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(["\n            ", ""], ["\n            ", ""])), !this.actualProjectDetails ? html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["<h4> ", "</h4>"], ["<h4> ", "</h4>"])), this.msg.noProjectSelected) : html(templateObject_2 || (templateObject_2 = __makeTemplateObject(['\n                <section class="section-details">\n                    <details open>\n                        <summary>', "</summary>\n                        <ul>\n                            <li>", ": ", "</li>\n                            <li>", ": ", "</li>\n                            <li>", ": ", "</li>\n                            <li>", ": ", "</li>\n                            <li>", ": ", "</li>\n                        </ul>\n                    </details>\n                </section>\n                <section\n                    style=", ' \n                    class="section-config-github">\n                    <div>\n                        <label>', "</label>\n                        <textarea .value=", ' @input="', '"></textarea rows=4>\n                        <button @click=', ">Alterar</button>\n                    </div>\n                </section>\n\n\n                "], ['\n                <section class="section-details">\n                    <details open>\n                        <summary>', "</summary>\n                        <ul>\n                            <li>", ": ", "</li>\n                            <li>", ": ", "</li>\n                            <li>", ": ", "</li>\n                            <li>", ": ", "</li>\n                            <li>", ": ", "</li>\n                        </ul>\n                    </details>\n                </section>\n                <section\n                    style=", ' \n                    class="section-config-github">\n                    <div>\n                        <label>', "</label>\n                        <textarea .value=", ' @input="', '"></textarea rows=4>\n                        <button @click=', ">Alterar</button>\n                    </div>\n                </section>\n\n\n                "])), this.msg.resume, this.msg.name, this.actualProjectDetails.name, this.msg.projectDriver, this.actualProjectDetails.projectDriver, this.msg.projectURL, this.actualProjectDetails.projectURL, this.msg.designSystems, this.actualProjectDetails.designSystems, this.msg.files, this.actualProjectDetails.files, this.actualProjectDetails.projectDriver === "github" ? "display: block" : "display:none", this.msg.keyGithub, this.actualKeyGitHub, this.handleInputChangeKey, this.handleChangeKey));
    };
    ServiceProjectDetails1005542.styles = css(templateObject_4 || (templateObject_4 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", Object)
    ], ServiceProjectDetails1005542.prototype, "actualProjectDetails", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceProjectDetails1005542.prototype, "actualKeyGitHub", void 0);
    ServiceProjectDetails1005542 = __decorate([
      customElement("service-project-details-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceProjectDetails1005542);
    return ServiceProjectDetails1005542;
  }(ServiceBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4;
export {
  ServiceProjectDetails100554
};
