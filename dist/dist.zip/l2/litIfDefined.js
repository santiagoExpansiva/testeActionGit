/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { nothing } from "./_100554_litHtml";
var ifDefined = function(value) {
  return value !== null && value !== void 0 ? value : nothing;
};
export {
  ifDefined
};
