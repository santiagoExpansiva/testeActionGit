/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { nothing } from "./_100554_litHtml";
const ifDefined = (value) => value != null ? value : nothing;
export {
  ifDefined
};
