import { IcaLitElement } from "./_100554_icaLitElement";
class IcaLayoutFlowRowBase extends IcaLitElement {
  // An optional descriptive hint for the field
}
export {
  IcaLayoutFlowRowBase
};
