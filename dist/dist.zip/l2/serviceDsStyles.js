var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { html } from "lit";
import { customElement, query, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
import { convertFileNameToTag } from "./_100554_utilsLit";
var message_pt = {};
var message_en = {};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceDsStyles = (
  /** @class */
  function(_super) {
    __extends(ServiceDsStyles2, _super);
    function ServiceDsStyles2() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.details = {
        icon: "&#xf5ad",
        state: "foreground",
        tooltip: "Styles",
        visible: true,
        position: "left",
        widget: "_100554_serviceDsStyles",
        tags: ["ds_styles"],
        level: [3]
      };
      _this.onClickLink = function(op) {
        if (op === "opResultCss")
          return _this.showResultCss();
        if (op === "opStyle")
          return _this.showStyle();
        if (op === "opStyle2")
          return _this.showStyle2();
        if (op === "opView")
          return _this.openRepo();
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.menu = {
        title: "Styles",
        actions: {
          opStyle: "Styles Geral",
          opResultCss: "Result CSS",
          opView: "View on repository"
        },
        actionDefault: "opStyle2",
        // call after close icon clicked
        icons: {},
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink
      };
      _this.msize = "";
      _this.isComponent = false;
      _this.stylesComponent = [];
      _this.modeComponent = "add";
      _this.firstStyleIndex = 0;
      _this.actionsMode = "default";
      _this.timeoutChangesEditorStyle = 0;
      _this.timeoutCursorChangesEditorStyle = 0;
      _this.componentName = "";
      _this.isStyleRename = false;
      _this.isSetStyle = false;
      _this.oldStyleName = "";
      _this.rightServiceOpened = "";
      _this.lastEditorInfo = {
        line: 0,
        content: ""
      };
      _this.models = {};
      _this.defaultServices = {
        componentStyle: "",
        globalStyle: "_100554_service_styles_preview"
      };
      _this.isEventAdd = false;
      _this.isHelperContainerOpen = false;
      _this.myStyle = "\n\n        .container-open-helper{\n            height: 100%;\n            position: absolute;\n            top: 0;\n            background: #f6f6f6;\n            right: 0;\n            width: 0;\n            z-index: 9999;\n            transition: width 0.5s ease;\n        }\n        .container-open-helper.open{\n            width: 40%;\n        }\n        .container-open-helper.open .helper{\n            opacity: 1;\n        }\n        .container-open-helper .helper{\n            opacity: 0.1;\n            overflow:hidden;\n        }\n        .container-open-helper .toogle{\n            position: absolute;\n            width: 30px;\n            height: 80px;\n            background: #f6f6f6;\n            top: 50%;\n            left: -30px;\n            z-index: 9999;\n            transform: translate(0%, -50%);\n            border-top-left-radius: 5px;\n            cursor: pointer;\n            border-bottom-left-radius: 5px;\n            display: flex;\n            justify-content: center;\n            align-items: center;\n        }\n        .styles-if-component {\n            padding: 6px;\n            display: flex;\n            gap: 1rem;\n            justify-content: center;\n\n            select{\n                width: 200px;\n            }\n            input{\n                margin-right: 1rem;\n                line-height: 0.5;\n                padding: 0.1rem;\n            }\n            .actions{\n                display: flex;\n                align-items: center;\n                gap: 1rem;\n                padding: 0.5rem;\n                border: 1px solid #cecece;\n                i{\n                    cursor:pointer;\n                }\n            }\n        }\n    ";
      _this.init();
      return _this;
    }
    ServiceDsStyles_1 = ServiceDsStyles2;
    ServiceDsStyles2.prototype.setEditorSource = function(less) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              return [4, this.setStyle(less)];
            case 1:
              _a2.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.getEditorSource = function() {
      var _a2;
      var model = (_a2 = this._ed1) === null || _a2 === void 0 ? void 0 : _a2.getModel();
      var val = (model === null || model === void 0 ? void 0 : model.getValue()) || "";
      return val;
    };
    ServiceDsStyles2.prototype.getEditorComponentSource = function() {
      var _a2;
      var model = (_a2 = this._ed1) === null || _a2 === void 0 ? void 0 : _a2.getModel();
      var val = (model === null || model === void 0 ? void 0 : model.getValue()) || "";
      val = this.removeTokensForSource(val);
      return val;
    };
    ServiceDsStyles2.prototype.getActualRef = function() {
      if (!this.dsInstance)
        return "";
      if (this.isComponent && this.selectStyles) {
        var selectStyle = this.stylesComponent[+this.selectStyles.value];
        var folder = this.dsInstance.methods["getDsComponentStyleFilePath"](this.componentName);
        mls.actual[0].setFullName(this.componentName);
        var _a2 = mls.actual[0], project = _a2.project, path = _a2.path;
        if (project === void 0 || !path)
          return "";
        var key_1 = mls.stor.getKeyToFiles(project, 3, selectStyle.stylename, folder, ".less");
        return key_1;
      }
      var folderGlobal = this.dsInstance.methods["getDsCssFilePath"]();
      var key = mls.stor.getKeyToFiles(this.dsInstance.project, 3, "definitions", folderGlobal, ".less");
      return key;
    };
    ServiceDsStyles2.prototype.createRenderRoot = function() {
      return this;
    };
    ServiceDsStyles2.prototype.onServiceClick = function(visible, reinit, el) {
      this._onServiceClick(visible, reinit, el);
    };
    ServiceDsStyles2.prototype._onServiceClick = function(visible, reinit, el) {
      return __awaiter(this, void 0, void 0, function() {
        var params2;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (reinit) {
                this.checkComponentOpenInL2();
                return [
                  2
                  /*return*/
                ];
              }
              if (!(visible && !reinit)) return [3, 3];
              this.isComponent = false;
              return [4, this.start1()];
            case 1:
              _a2.sent();
              return [4, this.checkComponentOpenInL2()];
            case 2:
              _a2.sent();
              return [
                2
                /*return*/
              ];
            case 3:
              params2 = {
                service: [],
                isComponent: this.isComponent,
                component: this.componentName
              };
              mls.events.fire([this.level], ["DSStyleUnSelected"], JSON.stringify(params2), 0);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.start1 = function() {
      return __awaiter(this, void 0, void 0, function() {
        var serviceDef, params;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              return [4, this.createEditor()];
            case 1:
              _a2.sent();
              serviceDef = this.isComponent ? this.defaultServices.componentStyle : this.defaultServices.globalStyle;
              params = {
                service: [serviceDef],
                isComponent: this.isComponent,
                component: this.componentName
              };
              mls.events.fire([this.level], ["DSStyleSelected"], JSON.stringify(params), 100);
              this.openServiceHelper(serviceDef);
              this.rightServiceOpened = this.getServiceRightOpened();
              this.setMsizeEditor();
              if (this.serviceContent && typeof this.serviceContent.layout === "function")
                this.serviceContent.layout();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.reinit = function() {
      if (this._ed1)
        this._ed1.setModel(this.models["style"]);
      if (this.menu.setMode)
        this.menu.setMode("initial");
    };
    ServiceDsStyles2.prototype.init = function() {
      this.getModelOrCreate("", "results");
      this.setEvents();
    };
    ServiceDsStyles2.prototype.setEvents = function() {
      var _this = this;
      mls.events.addEventListener([3], ["DSStyleChanged"], function(ev) {
        _this.onDSStyleChanged(ev);
      });
    };
    ServiceDsStyles2.prototype.checkComponentOpenInL2 = function() {
      return __awaiter(this, void 0, void 0, function() {
        var actualL2, _a2, project, path, folderFileLess, key, file, newCompExist, desc, params;
        var _b2;
        return __generator(this, function(_c2) {
          switch (_c2.label) {
            case 0:
              actualL2 = mls.actual[2].getFullName();
              if (!actualL2) {
                this.showStyle();
                return [
                  2
                  /*return*/
                ];
              }
              _a2 = mls.actual[2], project = _a2.project, path = _a2.path;
              if (!project || !path) {
                this.showStyle();
                return [
                  2
                  /*return*/
                ];
              }
              ;
              return [4, this.initDsInstance()];
            case 1:
              _c2.sent();
              if (!this.dsInstance)
                return [
                  2
                  /*return*/
                ];
              folderFileLess = this.dsInstance.methods["getDsComponentStyleFilePath"](actualL2);
              key = mls.stor.getKeyToFiles(project, 3, path, folderFileLess, ".less");
              file = mls.stor.files[key];
              if (actualL2 === this.componentName && file && file.status === "changed")
                return [
                  2
                  /*return*/
                ];
              newCompExist = (_b2 = this.dsInstance) === null || _b2 === void 0 ? void 0 : _b2.components.find(actualL2);
              if (!newCompExist) {
                this.showStyle();
                return [
                  2
                  /*return*/
                ];
              }
              ;
              desc = {
                emitter: "right",
                helper: "_100554_servicePreview",
                isComponent: true,
                widget: actualL2,
                less: "",
                origemLevel: 3,
                value: [],
                selector: ""
              };
              params = {
                level: 3,
                type: "DSStyleChanged",
                desc: JSON.stringify(desc)
              };
              this.isComponent = true;
              this.isSetStyle = true;
              this.isEventAdd = true;
              this.onDSStyleChanged(params);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.showStyle = function() {
      this.componentName = "";
      this.isComponent = false;
      this.reinit();
      return true;
    };
    ServiceDsStyles2.prototype.openRepo = function() {
      if (!this.dsInstance)
        return false;
      var fname = "definitions";
      var ffolder = this.dsInstance.methods.getDsCssFilePath();
      var project = this.dsInstance.project;
      if (this.isComponent && this.selectStyles) {
        var style = this.stylesComponent[+this.selectStyles.value];
        if (!style)
          return false;
        fname = style.stylename;
        ffolder = this.dsInstance.methods.getDsComponentStyleFilePath(this.componentName);
        mls.actual[0].setFullName(this.componentName);
        if (!mls.actual[0].project)
          return false;
        project = mls.actual[0].project;
      }
      var keyToFile = mls.stor.getKeyToFiles(project, 3, fname, ffolder, ".less");
      var file = mls.stor.files[keyToFile];
      if (!file) {
        window.collabMessages.add("Invalid File", "information");
        throw new Error("invalid file");
      }
      var driver = mls.stor.others.getDefaultDriver(project);
      if (!driver) {
        window.collabMessages.add("Driver not found", "information");
        throw new Error("Driver not found");
      }
      var url = "";
      url = driver.getUrl(file);
      window.open(url, "_blank");
      if (this.menu.closeMenu)
        this.menu.closeMenu();
      return true;
    };
    ServiceDsStyles2.prototype.showResultCss = function() {
      var _a2;
      if (!this._ed1)
        return false;
      var modelResults = this.models["results"];
      this._ed1.setModel(modelResults);
      if (this.menu.setMode)
        this.menu.setMode("editor");
      (_a2 = this.serviceContent) === null || _a2 === void 0 ? void 0 : _a2.layout();
      this._ed1.updateOptions({ readOnly: true });
      modelResults.setValue("Compiling...");
      if (!this.dsInstance)
        return false;
      this.dsInstance.components.getCSS(this.componentName).then(function(result) {
        modelResults.setValue(result);
      }).catch(function(err) {
        modelResults.setValue(err);
      });
      return true;
    };
    ServiceDsStyles2.prototype.delay = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              return [4, new Promise(function(resolve) {
                return setTimeout(resolve, 100);
              })];
            case 1:
              _a2.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.createEditor = function() {
      return __awaiter(this, void 0, void 0, function() {
        var _this = this;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (this._ed1)
                return [
                  2
                  /*return*/
                ];
              if (!!this.c2) return [3, 2];
              return [4, this.delay()];
            case 1:
              _a2.sent();
              this.createEditor();
              return [
                2
                /*return*/
              ];
            case 2:
              this._ed1 = monaco.editor.create(this.c2, {
                language: "less",
                minimap: {
                  enabled: false
                  // Desativa o minimap
                }
              });
              this._ed1.onDidChangeCursorPosition(function(e) {
                if (!_this._ed1)
                  return;
                var modelStyle = _this.getActualModel();
                if (!modelStyle)
                  return;
                var actualModel = _this._ed1.getModel();
                if (!modelStyle || actualModel !== modelStyle)
                  return;
                var lineNumber = e.position.lineNumber;
                var content = modelStyle.getLineContent(lineNumber);
                var isReadOnlyArea = _this.isReadOnlyArea(lineNumber);
                _this._ed1.updateOptions({ readOnly: isReadOnlyArea });
                if (isReadOnlyArea) {
                  var serviceDef = _this.isComponent ? _this.defaultServices.componentStyle : _this.defaultServices.globalStyle;
                  var params = _this.getParamsServices();
                  mls.events.fire([_this.level], ["DSStyleUnSelected"], JSON.stringify(params), 0);
                  _this.openServiceHelper(serviceDef);
                  _this.lastEditorInfo.content = content;
                  _this.lastEditorInfo.line = lineNumber;
                  return;
                }
                if (_this.timeoutCursorChangesEditorStyle)
                  clearTimeout(_this.timeoutCursorChangesEditorStyle);
                _this.timeoutCursorChangesEditorStyle = setTimeout(function() {
                  _this.onCursorChange(lineNumber, content);
                }, 500);
              });
              this.c2["mlsEditor"] = this._ed1;
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.getUri = function(shortFN) {
      ServiceDsStyles_1.modelCount = ServiceDsStyles_1.modelCount + 1 || 1;
      return monaco.Uri.parse("file://server/".concat(shortFN, "_").concat(ServiceDsStyles_1.modelCount, ".ts"));
    };
    ServiceDsStyles2.prototype.setModelAPI = function(model) {
      var _this = this;
      if (!model)
        return;
      var modelStyle = model;
      modelStyle.add = function(text, lineNumber, refLine) {
        var lineToChange = lineNumber;
        var blockInfo = modelStyle.getBlockInfo();
        if (!lineToChange) {
          var newLineNumber = refLine === blockInfo.endLine ? refLine : refLine + 1;
          var columnStartRefLine = modelStyle.getLineIndentColumn(refLine);
          var newLine = {
            range: new monaco.Range(newLineNumber, 1, newLineNumber, 1),
            text: " ".repeat(columnStartRefLine - 1) + "\n",
            forceMoveMarkers: true
          };
          if (_this._ed1) {
            _this.isEventAdd = true;
            _this._ed1.executeEdits("style", [newLine]);
          }
          lineToChange = newLineNumber;
        }
        var columnStart = modelStyle["getLineIndentColumn"](lineToChange);
        var columnEnd = modelStyle.getLineLength(lineToChange) + 1;
        var range = new monaco.Range(lineToChange, columnStart, lineToChange, columnEnd);
        if (_this._ed1) {
          _this.isEventAdd = true;
          _this._ed1.executeEdits("style", [{ range, text }]);
        }
        var endLineLength = modelStyle.getLineLength(blockInfo.endLine) + 1;
        var rangeBlock = new monaco.Range(blockInfo.startLine, 1, blockInfo.endLine, endLineLength);
        modelStyle.removeBlankLines(rangeBlock);
      };
      modelStyle.changeBlock = function(key, value, comment) {
        if (!_this._ed1)
          return;
        var blockLess = modelStyle.getLessBlock();
        var lineNumber = _this._ed1.getPosition().lineNumber;
        var text = "".concat(key, ": ").concat(value, ";//").concat(comment);
        var objChanged = {
          lineChange: void 0,
          prop: key,
          newValue: value,
          oldValue: ""
        };
        if (!blockLess)
          return;
        blockLess.lines.forEach(function(item) {
          if (item.key === key) {
            objChanged.lineChange = item.line;
            objChanged.oldValue = item.value;
          }
        });
        if (!objChanged.newValue) {
          var linewithSameKey = blockLess.lines.find(function(line) {
            return line.key === objChanged.prop;
          });
          if (!linewithSameKey)
            return;
          modelStyle.removeLine(linewithSameKey.line);
          return;
        }
        if (!objChanged.lineChange) {
          modelStyle.add(text, objChanged.lineChange, lineNumber);
          return;
        }
        modelStyle.add(text, objChanged.lineChange);
      };
      modelStyle.removeLine = function(lineNumber) {
        var columnEnd = modelStyle.getLineLength(lineNumber) + 1;
        var columnStart = modelStyle.getLineIndentColumn(lineNumber);
        var range = new monaco.Range(lineNumber, columnStart, lineNumber, columnEnd);
        if (_this._ed1) {
          _this.isEventAdd = true;
          _this._ed1.executeEdits("", [{ range, text: null }]);
        }
      };
      modelStyle.removeBlankLines = function(range) {
        var _a2;
        if (!_this._ed1)
          return;
        var text = (_a2 = _this._ed1.getModel()) === null || _a2 === void 0 ? void 0 : _a2.getValueInRange(range);
        if (!text)
          return;
        var newText = text.replace(/^\s*[\r\n]/gm, "");
        var edit = { range, text: newText };
        _this.isEventAdd = true;
        _this._ed1.executeEdits("style", [edit]);
      };
      modelStyle.getLessBlock = function() {
        var _a2 = modelStyle.getBlockInfo(), isValidBlock = _a2.isValidBlock, endLine = _a2.endLine, startLine = _a2.startLine, selector = _a2.selector;
        if (!isValidBlock)
          return void 0;
        var rc = {
          lines: [],
          selector
        };
        var lines = modelStyle.getLinesContent();
        var bracketsOpenCount = 0;
        var bracketsCloseCount = 0;
        var _loop_1 = function(i2) {
          var line = lines[i2];
          line = line.replace(/\/\/.*/, "");
          var isInBlockComment = modelStyle.isInCommentBlock(lines, i2 + 1);
          if (isInBlockComment)
            return "continue";
          if (line.indexOf("{") >= 0)
            bracketsOpenCount += 1;
          if (line.indexOf("}") >= 0)
            bracketsCloseCount += 1;
          if (bracketsOpenCount - bracketsCloseCount > 1)
            return "continue";
          var rules = line.split(";");
          rules.forEach(function(rule) {
            if (!rule)
              return;
            var item = modelStyle.convertRuleToKeyValue(rule);
            if (!item)
              return;
            item.line = i2 + 1;
            rc.lines.push(item);
          });
        };
        for (var i = startLine - 1; i <= endLine - 1; i++) {
          _loop_1(i);
        }
        return rc;
      };
      modelStyle.getHelperNameByLine = function(lineNumber) {
        var lineContent = modelStyle.getLineContent(lineNumber);
        var _a2 = lineContent.split("//"), helperName = _a2[1];
        return helperName;
      };
      modelStyle.isCursorInBlockValid = function() {
        var blockInfo = modelStyle.getBlockInfo();
        return blockInfo.isValidBlock;
      };
      modelStyle.getBlockInfoByLine = function(lineNumber) {
        var lines = modelStyle.getLinesContent();
        var startBlockInfo = modelStyle.haveStartBlock(lines, lineNumber);
        var endBlockInfo = modelStyle.haveEndBlock(lines, lineNumber);
        var rc = {
          selector: "",
          endLine: endBlockInfo.line,
          hasEndBlock: endBlockInfo.haveEndBlock,
          hasStartBlock: startBlockInfo.haveStartBlock,
          startLine: startBlockInfo.line,
          isValidBlock: startBlockInfo.haveStartBlock && endBlockInfo.haveEndBlock
        };
        if (startBlockInfo.line > 0 && rc.isValidBlock) {
          var lineStartContent = modelStyle.getLineContent(startBlockInfo.line);
          rc.selector = lineStartContent.replace(/\/\/.*/, "").replace(/\{.*$/, "").trim();
        }
        return rc;
      };
      modelStyle.getBlockInfo = function() {
        var _a2;
        var lineNumber = ((_a2 = _this._ed1) === null || _a2 === void 0 ? void 0 : _a2.getPosition()).lineNumber;
        var rc = modelStyle.getBlockInfoByLine(lineNumber);
        return rc;
      };
      modelStyle.isInCommentBlock = function(lines, lineNumber) {
        var countStartBlockComment = 0;
        var countEndBlockComment = 0;
        for (var i = 0; i <= lineNumber - 1; i++) {
          var line = lines[i];
          if (line.indexOf("/*") >= 0)
            countStartBlockComment += 1;
          if (line.indexOf("*/") >= 0 && i !== lineNumber - 1)
            countEndBlockComment += 1;
        }
        var isInBlockComment = countStartBlockComment > countEndBlockComment;
        return isInBlockComment;
      };
      modelStyle.haveStartBlock = function(lines, lineNumber) {
        var rc = {
          haveStartBlock: false,
          line: -1
        };
        var bracketsCount = 1;
        var actualLine = lines[lineNumber - 1];
        if (actualLine.trim().startsWith("//"))
          return rc;
        actualLine = actualLine.replace(/\/\/.*/, "").replace(/\/\*.*/, "");
        if (actualLine.indexOf("{") >= 0) {
          rc.haveStartBlock = true;
          rc.line = lineNumber;
          return rc;
        }
        if (actualLine.indexOf("}") >= 0)
          bracketsCount -= 1;
        var isInBlockComment = modelStyle.isInCommentBlock(lines, lineNumber);
        if (isInBlockComment)
          return rc;
        for (var i = lineNumber - 1; i >= 0; i--) {
          var line = lines[i];
          line = line.replace(/\/\/.*/, "");
          var lineInCommentBlock = modelStyle.isInCommentBlock(lines, i + 1);
          if (line.indexOf("}") >= 0 && !lineInCommentBlock)
            bracketsCount += 1;
          if (line.indexOf("{") >= 0 && !lineInCommentBlock)
            bracketsCount -= 1;
          if (bracketsCount === 0) {
            rc.haveStartBlock = true;
            rc.line = i + 1;
            break;
          }
        }
        return rc;
      };
      modelStyle.haveEndBlock = function(lines, lineNumber) {
        var rc = {
          haveEndBlock: false,
          line: -1
        };
        var bracketsCount = 1;
        var actualLine = lines[lineNumber - 1];
        if (actualLine.trim().startsWith("//"))
          return rc;
        actualLine = actualLine.replace(/\/\/.*/, "").replace(/\/\*.*/, "");
        if (actualLine.indexOf("}") >= 0) {
          rc.haveEndBlock = true;
          rc.line = lineNumber;
          return rc;
        }
        if (actualLine.indexOf("{") >= 0)
          bracketsCount -= 1;
        var isInBlockComment = modelStyle.isInCommentBlock(lines, lineNumber);
        if (isInBlockComment)
          return rc;
        for (var i = lineNumber - 1; i <= lines.length - 1; i++) {
          var line = lines[i];
          line = line.replace(/\/\/.*/, "");
          var lineInCommentBlock = modelStyle.isInCommentBlock(lines, i + 1);
          if (line.indexOf("{") >= 0 && !lineInCommentBlock)
            bracketsCount += 1;
          if (line.indexOf("}") >= 0 && !lineInCommentBlock)
            bracketsCount -= 1;
          if (bracketsCount === 0) {
            rc.haveEndBlock = true;
            rc.line = i + 1;
            break;
          }
        }
        return rc;
      };
      modelStyle.convertRuleToKeyValue = function(content) {
        var blockLine = {};
        var _a2 = content.split(":"), key = _a2[0], value = _a2[1];
        if (!key || !value)
          return void 0;
        blockLine.key = key.trim();
        blockLine.value = value.trim();
        return blockLine;
      };
    };
    ServiceDsStyles2.prototype.getModelOrCreate = function(modelName, value) {
      var _this = this;
      var mod = this.models[modelName];
      if (!modelName)
        return void 0;
      if (!mod) {
        var uri = this.getUri("l3_styles");
        this.models[modelName] = monaco.editor.createModel(value, "less", uri);
        var model = this.models[modelName];
        this.setModelAPI(model);
        model.onDidChangeContent(function(event) {
          if (_this.timeoutChangesEditorStyle)
            clearTimeout(_this.timeoutChangesEditorStyle);
          _this.timeoutChangesEditorStyle = setTimeout(function() {
            _this.onEditorChange(false);
          }, 1e3);
        });
      } else {
        mod.setValue(value);
      }
      return this.models[modelName];
    };
    ServiceDsStyles2.prototype.getModelComponentKey = function() {
      if (!this.selectStyles)
        return;
      var s = this.stylesComponent[+this.selectStyles.value];
      var modelKey = this.componentName + "_" + s.stylename;
      return modelKey;
    };
    ServiceDsStyles2.prototype.getActualModel = function() {
      if (this.isComponent) {
        var modelKey = this.getModelComponentKey();
        if (!modelKey)
          return;
        return this.models[modelKey];
      }
      return this.models["style"];
    };
    ServiceDsStyles2.prototype.setStyle = function(styleLess) {
      return __awaiter(this, void 0, void 0, function() {
        var lessTokens, textByRange, content, model, modelKey, range, position;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (!this._ed1)
                return [
                  2
                  /*return*/
                ];
              return [4, this.getTokens()];
            case 1:
              lessTokens = _a2.sent();
              textByRange = styleLess;
              content = "".concat(textByRange.trim(), "\n\n//Start Less Tokens\n").concat(lessTokens, "\n//End Less Tokens\n");
              if (this.isComponent) {
                modelKey = this.getModelComponentKey();
                if (!modelKey)
                  return [
                    2
                    /*return*/
                  ];
                model = this.getModelOrCreate(modelKey, content);
              } else
                model = this.getModelOrCreate("style", content);
              if (!model)
                return [
                  2
                  /*return*/
                ];
              this._ed1.setModel(model);
              range = new monaco.Range(0, 0, model.getLineCount() + 1, 0);
              this._ed1.updateOptions({ readOnly: false });
              this._ed1.setScrollPosition({ scrollTop: 0 });
              position = new monaco.Position(0, 0);
              this._ed1.setPosition(position);
              this.onEditorChange(false);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.getIntervalLinesReadOnly = function() {
      if (!this._ed1)
        return;
      var model = this._ed1.getModel();
      if (!model)
        return;
      var startLine = model.findMatches("//Start Less Tokens", true, false, false, null, true)[0];
      var endLine = model.findMatches("//End Less Tokens", true, false, false, null, true)[0];
      return {
        end: endLine ? endLine.range.startLineNumber : void 0,
        start: startLine ? startLine.range.startLineNumber : void 0
      };
    };
    ServiceDsStyles2.prototype.changeEditor = function(lines, helper) {
      var modelStyle = this.getActualModel();
      if (!modelStyle)
        return;
      lines.forEach(function(line) {
        modelStyle.changeBlock(line.key, line.value, helper);
      });
    };
    ServiceDsStyles2.prototype.getParamsServices = function() {
      var serviceDef = this.isComponent ? this.defaultServices.componentStyle : this.defaultServices.globalStyle;
      var params = {
        service: [serviceDef],
        isComponent: this.isComponent,
        component: this.componentName
      };
      return params;
    };
    ServiceDsStyles2.prototype.showStyle2 = function() {
      var _this = this;
      var _a2;
      if (!this._ed1)
        return false;
      (_a2 = this.serviceContent) === null || _a2 === void 0 ? void 0 : _a2.layout();
      this._ed1.updateOptions({ readOnly: false });
      this.getStyle().then(function(styleGlobal) {
        if (_this.isComponent)
          return;
        _this.setStyle(styleGlobal);
      });
      return true;
    };
    ServiceDsStyles2.prototype.onEditorChange = function(isGet) {
      return __awaiter(this, void 0, void 0, function() {
        var model, value, less, rc, cssItem, err_1, errorInfo, _a2;
        return __generator(this, function(_b2) {
          switch (_b2.label) {
            case 0:
              if (this.isSetStyle) {
                this.isSetStyle = false;
                return [
                  2
                  /*return*/
                ];
              }
              this.clearErrors();
              model = this.getActualModel();
              if (!model)
                return [
                  2
                  /*return*/
                ];
              value = model.getLessBlock();
              less = model.getValue().trim();
              rc = {
                emitter: "left",
                helper: this.rightServiceOpened || this.getServiceRightOpened(),
                value: (value === null || value === void 0 ? void 0 : value.lines) || [],
                less,
                selector: (value === null || value === void 0 ? void 0 : value.selector) || "",
                isComponent: this.isComponent,
                origemLevel: 3
              };
              if (!isGet)
                rc.less = this.removeTokensForSource(rc.less);
              if (!(!this.isComponent && !isGet)) return [3, 4];
              if (!this.dsInstance)
                return [
                  2
                  /*return*/
                ];
              cssItem = this.dsInstance.css.list["definitions"];
              if (!cssItem)
                return [
                  2
                  /*return*/
                ];
              _b2.label = 1;
            case 1:
              _b2.trys.push([1, 3, , 4]);
              return [4, cssItem.setContent(rc.less)];
            case 2:
              _b2.sent();
              return [3, 4];
            case 3:
              err_1 = _b2.sent();
              errorInfo = this.extractErrorDetails(err_1.message);
              if (errorInfo)
                this.setErrorOnEditor(errorInfo);
              return [3, 4];
            case 4:
              if (!this.isComponent) return [3, 6];
              _a2 = rc;
              return [4, this.onChangeEditorIfComponent(rc)];
            case 5:
              _a2.less = _b2.sent();
              _b2.label = 6;
            case 6:
              if (!this.isEventAdd) {
                mls.events.fire([3], ["DSStyleChanged"], JSON.stringify(rc), 300);
              } else
                this.isEventAdd = false;
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.removeTokensForSource = function(src) {
      var regex = /\/\/Start Less Tokens[\s\S]*?\/\/End Less Tokens/g;
      return src.replace(regex, "");
    };
    ServiceDsStyles2.prototype.onAfterAdd = function() {
      return __awaiter(this, void 0, void 0, function() {
        var style, less;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (!this.selectStyles)
                return [
                  2
                  /*return*/
                ];
              style = this.stylesComponent[+this.selectStyles.value];
              return [4, style.getStyleLessIO()];
            case 1:
              less = _a2.sent();
              this.onChangeWidgetStyle(less);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.onChangeEditorIfComponent = function(params) {
      return __awaiter(this, void 0, Promise, function() {
        var style, isFirstLineCorrect, _a2, mfile, enhancement, searchString, replacementString, regex, modifiedString;
        return __generator(this, function(_b2) {
          switch (_b2.label) {
            case 0:
              if (!this.selectStyles)
                return [2, ""];
              style = this.stylesComponent[+this.selectStyles.value];
              if (!style)
                return [2, params.less];
              isFirstLineCorrect = this.checkIfFirtsLineCorrect(params.less, style.stylename);
              if (!isFirstLineCorrect) {
                this.setError("Invalid first line, must be start with component tag name my-tag.mystyle");
                throw new Error("Invalid first line");
              }
              if (!this.isStyleRename) return [3, 2];
              _a2 = params;
              return [4, this.renameStyleComponent(params.less, style)];
            case 1:
              _a2.less = _b2.sent();
              return [2, params.less];
            case 2:
              return [4, this.saveStyleLess(params.less, style)];
            case 3:
              _b2.sent();
              mfile = mls.l2.editor["mfiles"][this.componentName];
              if (!(mfile && mfile.compilerResults)) return [3, 9];
              mfile.compilerResults.modelNeedCompile = true;
              return [4, mls.l2.editor.getCompilerResultTS(mfile, true)];
            case 4:
              _b2.sent();
              return [4, mls.l2.enhancement.getEnhancementInstance(mfile)];
            case 5:
              enhancement = _b2.sent();
              if (!enhancement) return [3, 7];
              return [4, enhancement.onAfterChange(mfile)];
            case 6:
              _b2.sent();
              _b2.label = 7;
            case 7:
              searchString = "css";
              replacementString = "";
              regex = new RegExp(searchString, "g");
              modifiedString = mfile.compilerResults["cacheVersion"].replace(regex, replacementString);
              mfile.compilerResults["cacheVersion"] = modifiedString + "css" + Math.floor(Math.random() * (1e3 - 9999999 + 1)) + 9999999;
              if (!mfile.compilerResults.prodJS) return [3, 9];
              return [4, mls.stor.cache.AddMfileIfNeed(mfile)];
            case 8:
              _b2.sent();
              _b2.label = 9;
            case 9:
              return [2, params.less];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.saveStyleLess = function(less, style) {
      return __awaiter(this, void 0, void 0, function() {
        var validComponentStyle, err_2, errorInfo;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              validComponentStyle = this.checkIfValidComponentStyle(less);
              if (!validComponentStyle)
                return [
                  2
                  /*return*/
                ];
              _a2.label = 1;
            case 1:
              _a2.trys.push([1, 3, , 4]);
              return [4, style.setStyleLessIO(less)];
            case 2:
              _a2.sent();
              return [3, 4];
            case 3:
              err_2 = _a2.sent();
              errorInfo = this.extractErrorDetails(err_2.message);
              if (errorInfo)
                this.setErrorOnEditor(errorInfo);
              return [3, 4];
            case 4:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.renameStyleComponent = function(less, style) {
      return __awaiter(this, void 0, Promise, function() {
        var allLines, newless, err_3, errorInfo;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              this.isStyleRename = false;
              allLines = less.split("\n");
              allLines[0] = allLines[0].replace(this.oldStyleName, style.stylename);
              newless = allLines.join("\n");
              _a2.label = 1;
            case 1:
              _a2.trys.push([1, 4, , 5]);
              return [4, style.setStyleLessIO(newless)];
            case 2:
              _a2.sent();
              return [4, this.setStyle(newless)];
            case 3:
              _a2.sent();
              return [2, newless];
            case 4:
              err_3 = _a2.sent();
              errorInfo = this.extractErrorDetails(err_3.message);
              if (errorInfo)
                this.setErrorOnEditor(errorInfo);
              return [2, less];
            case 5:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.checkIfValidComponentStyle = function(less) {
      var bracketsOpenCount = 0;
      var bracketsCloseCount = 0;
      var isvalid = true;
      var lineStartInvalid = 0;
      var lines = less.split("\n");
      var modelStyle = this.getActualModel();
      if (!modelStyle)
        return false;
      for (var i = 0; i <= lines.length - 1; i++) {
        var line = lines[i];
        line = line.replace(/\/\/.*/, "");
        var isInBlockComment = modelStyle.isInCommentBlock(lines, i + 1);
        if (isInBlockComment)
          continue;
        if (line.indexOf("{") >= 0)
          bracketsOpenCount += 1;
        if (line.indexOf("}") >= 0)
          bracketsCloseCount += 1;
        if (bracketsOpenCount > 0 && bracketsOpenCount === bracketsCloseCount) {
          lineStartInvalid = i + 2;
          break;
        }
      }
      if (lineStartInvalid) {
        for (var i = lineStartInvalid - 1; i <= lines.length - 1; i++) {
          var line = lines[i];
          line = line.replace(/\/\/.*/, "");
          if (line.indexOf("{") >= 0) {
            isvalid = false;
            var errorInfo = {
              column: 0,
              errorMessage: "This block is invalid, in style component use once this first block",
              line: i + 1
            };
            this.setErrorOnEditor(errorInfo);
            break;
          }
        }
      }
      return isvalid;
    };
    ServiceDsStyles2.prototype.checkIfFirtsLineCorrect = function(less, stylename) {
      var firstLine = less.split("\n")[0];
      var tagName = this.getWidgetTagName(this.componentName);
      if (stylename === this.componentName.substr(8, this.componentName.length)) {
        if (!this.isStyleRename && !firstLine.startsWith(tagName))
          return false;
        return true;
      }
      if (!this.isStyleRename && !firstLine.startsWith(tagName + "." + stylename))
        return false;
      return true;
    };
    ServiceDsStyles2.prototype.extractErrorDetails = function(errorString) {
      var pattern = /Error [A-Za-z]+: [A-Za-z]+: (.+) on line (\d+), column (\d+)/;
      var match = pattern.exec(errorString);
      if (match) {
        var errorMessage = match[1];
        var line = parseInt(match[2], 10);
        var column = parseInt(match[3], 10);
        return {
          errorMessage,
          line,
          column
        };
      }
      return null;
    };
    ServiceDsStyles2.prototype.clearErrors = function() {
      if (!this._ed1)
        return;
      var model = this._ed1.getModel();
      if (!model)
        return;
      monaco.editor.setModelMarkers(model, "markerSource", []);
    };
    ServiceDsStyles2.prototype.setErrorOnEditor = function(info) {
      var markerOptions = {
        severity: monaco.MarkerSeverity.Error,
        message: info.errorMessage,
        startLineNumber: info.line,
        startColumn: info.column,
        endLineNumber: info.line,
        endColumn: info.column
      };
      if (!this._ed1)
        return;
      var model = this._ed1.getModel();
      if (!model)
        return;
      monaco.editor.setModelMarkers(model, "markerSource", [markerOptions]);
    };
    ServiceDsStyles2.prototype.getServiceRightOpened = function() {
      var _a2, _b2, _c2, _d2;
      var toolbar = (_a2 = this.serviceContent) === null || _a2 === void 0 ? void 0 : _a2.closest("mls-toolbar-100529");
      var nextToolbarRef = "";
      if (toolbar) {
        var nextToolbar = (_b2 = toolbar.nextElementSibling) === null || _b2 === void 0 ? void 0 : _b2.nextElementSibling;
        var nextToolbarItemSelected = nextToolbar === null || nextToolbar === void 0 ? void 0 : nextToolbar.querySelector("mls-toolbar-item-100529 .toolbar-item.selected");
        nextToolbarRef = nextToolbarItemSelected ? (_c2 = nextToolbarItemSelected.parentElement) === null || _c2 === void 0 ? void 0 : _c2.getAttribute("ref") : "";
      } else {
        var page = (_d2 = this.serviceContent) === null || _d2 === void 0 ? void 0 : _d2.closest("collab-page");
        var nav2 = page === null || page === void 0 ? void 0 : page.querySelector('collab-nav-2[toolbarposition="right"].selected');
        if (nav2)
          nextToolbarRef = nav2.getAttribute("data-service");
      }
      return nextToolbarRef;
    };
    ServiceDsStyles2.prototype.onCursorChange = function(lineNumber, content) {
      var modelStyle = this.getActualModel();
      if (!modelStyle)
        return;
      if (lineNumber === this.lastEditorInfo.line && content === this.lastEditorInfo.content)
        return;
      this.lastEditorInfo.content = content;
      this.lastEditorInfo.line = lineNumber;
      var serviceDef = this.isComponent ? this.defaultServices.componentStyle : this.defaultServices.globalStyle;
      var helperName = serviceDef;
      var validPosition = modelStyle.isCursorInBlockValid();
      var params = {
        service: [serviceDef],
        isComponent: this.isComponent,
        component: this.componentName
      };
      if (!validPosition)
        mls.events.fire([this.level], ["DSStyleUnSelected"], JSON.stringify(params), 0);
      else {
        params.service = [];
        mls.events.fire([this.level], ["DSStyleSelected"], JSON.stringify(params), 0);
        helperName = modelStyle.getHelperNameByLine(lineNumber);
      }
      this.openServiceHelper(helperName);
    };
    ServiceDsStyles2.prototype.isReadOnlyArea = function(lineNumber) {
      var obj = this.getIntervalLinesReadOnly();
      if (!obj)
        return false;
      if (!obj.end || !obj.start)
        return false;
      if (lineNumber >= obj.start && lineNumber <= obj.end)
        return true;
      return false;
    };
    ServiceDsStyles2.prototype.isReadOnlyAreaIfIsComponent = function(lineNumber) {
      return false;
    };
    ServiceDsStyles2.prototype.initDsInstance = function() {
      return __awaiter(this, void 0, void 0, function() {
        var project, mode;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              project = mls.actual[5].project;
              mode = mls.actual[3].mode;
              if (project === void 0)
                throw new Error("No project selected!");
              this.dsInstance = mls.l3.getDSInstance(project, mode);
              return [4, this.dsInstance.init()];
            case 1:
              _a2.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.getStyle = function() {
      return __awaiter(this, void 0, void 0, function() {
        var cssItem, content;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              return [4, this.initDsInstance()];
            case 1:
              _a2.sent();
              if (!this.dsInstance)
                return [2, ""];
              cssItem = this.dsInstance.css.list["definitions"];
              if (!cssItem)
                return [2, ""];
              return [4, cssItem.getContent()];
            case 2:
              content = _a2.sent();
              return [2, content];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.getTokens = function() {
      return __awaiter(this, void 0, void 0, function() {
        var list, tokens, tokensColors, tokensTypo, tokensCustom, strColors, strTypo, strCustom, resumeTokens;
        return __generator(this, function(_a2) {
          if (!this.dsInstance)
            return [
              2
              /*return*/
            ];
          list = this.dsInstance.tokens.list;
          tokens = [];
          Object.keys(list).forEach(function(tok) {
            tokens.push(list[tok]);
          });
          tokensColors = tokens.filter(function(tok) {
            return tok.category === "color" && !tok.key.startsWith("_dark-");
          });
          tokensTypo = tokens.filter(function(tok) {
            return tok.category === "typography";
          });
          tokensCustom = tokens.filter(function(tok) {
            return tok.category === "custom";
          });
          strColors = tokensColors.map(function(item) {
            return "@".concat(item.key, ": ").concat(item.value, ";");
          }).join("\n");
          strTypo = tokensTypo.map(function(item) {
            return "@".concat(item.key, ": ").concat(item.value, ";");
          }).join("\n");
          strCustom = tokensCustom.map(function(item) {
            return "@".concat(item.key, ": ").concat(item.value, ";");
          }).join("\n");
          resumeTokens = ["// Tokens Colors", strColors, "// Tokens Typography", strTypo, "//Tokens Custom", strCustom].join("\n");
          return [2, resumeTokens];
        });
      });
    };
    ServiceDsStyles2.prototype.openServiceHelper = function(helperName) {
      this.rightServiceOpened = helperName;
      var rc = {
        emitter: "left",
        helper: helperName
      };
      mls.events.fire([this.level], ["DSStyleCursorChanged"], JSON.stringify(rc));
    };
    ServiceDsStyles2.prototype.onDSStyleChanged = function(obj) {
      return __awaiter(this, void 0, void 0, function() {
        var desc, widget, params;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (!obj.desc)
                return [
                  2
                  /*return*/
                ];
              desc = JSON.parse(obj.desc);
              if (desc.emitter === "left")
                return [
                  2
                  /*return*/
                ];
              if (desc.emitter === "right-get") {
                this.onEditorChange(true);
                return [
                  2
                  /*return*/
                ];
              }
              if (!desc.isComponent) return [3, 2];
              mls.actual[3].mode = desc.dsindex || 0;
              this.isComponent = true;
              this.defaultServices.componentStyle = desc.helper;
              widget = desc.widget;
              if (!widget)
                return [
                  2
                  /*return*/
                ];
              this.componentName = widget;
              return [4, this.loadStylesComponent(this.componentName)];
            case 1:
              _a2.sent();
              params = this.getParamsServices();
              mls.events.fire([this.level], ["DSStyleSelected"], JSON.stringify(params), 0);
              this.openService(this.defaultServices.componentStyle, "right", 3);
              return [
                2
                /*return*/
              ];
            case 2:
              this.changeEditor(desc.value, desc.helper);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.onChangeWidgetStyle = function(less) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              return [4, this.setStyle(less)];
            case 1:
              _a2.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.onAddWidgetStyle = function(value) {
      return __awaiter(this, void 0, void 0, function() {
        var tagName, styleName, less, err_4;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              this.setError("");
              tagName = this.getWidgetTagName(this.componentName);
              styleName = value;
              less = "".concat(tagName, ".").concat(styleName, " { // don't change this line \n 	// here your style \n}");
              _a2.label = 1;
            case 1:
              _a2.trys.push([1, 3, , 4]);
              if (!this.dsInstance)
                return [
                  2
                  /*return*/
                ];
              return [4, this.dsInstance.components.styles.add(this.componentName, styleName, less)];
            case 2:
              _a2.sent();
              return [3, 4];
            case 3:
              err_4 = _a2.sent();
              this.setError(err_4.message);
              return [3, 4];
            case 4:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.onDeleteWidgetStyle = function(style) {
      return __awaiter(this, void 0, void 0, function() {
        var rc, err_5;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              this.setError("");
              _a2.label = 1;
            case 1:
              _a2.trys.push([1, 3, , 4]);
              return [4, style.setStyleLessIO(null)];
            case 2:
              _a2.sent();
              rc = {
                emitter: "left",
                helper: this.rightServiceOpened || this.getServiceRightOpened(),
                value: [],
                less: "",
                selector: "",
                isComponent: this.isComponent,
                origemLevel: 3
              };
              mls.events.fire([this.level], ["DSStyleChanged"], JSON.stringify(rc));
              return [3, 4];
            case 3:
              err_5 = _a2.sent();
              this.setError(err_5.message);
              return [3, 4];
            case 4:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.onRenameWidgetStyle = function(style, value) {
      return __awaiter(this, void 0, void 0, function() {
        var err_6;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              this.setError("");
              _a2.label = 1;
            case 1:
              _a2.trys.push([1, 3, , 4]);
              this.isStyleRename = true;
              this.oldStyleName = style.stylename;
              if (!this.dsInstance)
                return [
                  2
                  /*return*/
                ];
              return [4, this.dsInstance.components.styles.rename(this.componentName, style.stylename, value)];
            case 2:
              _a2.sent();
              this.onEditorChange(false);
              return [3, 4];
            case 3:
              err_6 = _a2.sent();
              this.setError(err_6.message);
              return [3, 4];
            case 4:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.loadStylesComponent = function(componentName, index) {
      return __awaiter(this, void 0, void 0, function() {
        var dsindex, project, dsInstance, comp, tag, stName;
        var _this = this;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              dsindex = mls.actual[3].mode || 0;
              project = mls.actual[5].project;
              if (project === void 0)
                return [
                  2
                  /*return*/
                ];
              this.firstStyleIndex = index || 0;
              dsInstance = mls.l3.getDSInstance(project, dsindex);
              return [4, dsInstance.init()];
            case 1:
              _a2.sent();
              return [4, dsInstance.components.find(componentName)];
            case 2:
              comp = _a2.sent();
              if (!comp)
                return [
                  2
                  /*return*/
                ];
              this.stylesComponent = comp.styles;
              if (!(this.stylesComponent.length === 0)) return [3, 4];
              tag = this.getWidgetTagName(comp.name);
              stName = comp.name;
              return [4, dsInstance.components.styles.add(comp.name, stName.substr(8, stName.length), "".concat(tag, " { //don't change this line \n 	 \n}"))];
            case 3:
              _a2.sent();
              this.stylesComponent = comp.styles;
              _a2.label = 4;
            case 4:
              setTimeout(function() {
                _this.handleChangeSelectStyles();
              }, 200);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.handleChangeSelectStyles = function() {
      return __awaiter(this, void 0, void 0, function() {
        var style, less;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (!this.selectStyles)
                return [
                  2
                  /*return*/
                ];
              if (this.selectStyles.value === "0")
                this.showDefaultMode();
              else
                this.showActionsMode();
              style = this.stylesComponent[+this.selectStyles.value];
              return [4, style.getStyleLessIO()];
            case 1:
              less = _a2.sent();
              this.isSetStyle = true;
              this.isEventAdd = true;
              this.onChangeWidgetStyle(less);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.showConfirmMode = function() {
      this.actionsMode = "confirm";
    };
    ServiceDsStyles2.prototype.showActionsMode = function() {
      this.actionsMode = "actions";
      if (this.inputAddStyles)
        this.inputAddStyles.value = "";
    };
    ServiceDsStyles2.prototype.showDefaultMode = function() {
      this.actionsMode = "default";
    };
    ServiceDsStyles2.prototype.handleAddStylesClick = function() {
      this.modeComponent = "add";
      this.showConfirmMode();
    };
    ServiceDsStyles2.prototype.handleRenameStylesClick = function() {
      this.modeComponent = "rename";
      this.showConfirmMode();
    };
    ServiceDsStyles2.prototype.handleDeleteStylesClick = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (!this.selectStyles)
                return [
                  2
                  /*return*/
                ];
              return [4, this.onDeleteWidgetStyle(this.stylesComponent[+this.selectStyles.value])];
            case 1:
              _a2.sent();
              return [4, this.loadStylesComponent(this.componentName)];
            case 2:
              _a2.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.handleCancelStylesClick = function() {
      if (!this.selectStyles)
        return;
      var st = this.stylesComponent[+this.selectStyles.value];
      if (st.stylename === this.componentName.substr(8, this.componentName.length))
        this.showDefaultMode();
      else
        this.showActionsMode();
    };
    ServiceDsStyles2.prototype.handleConfirmStylesClick = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (!this.selectStyles || !this.inputAddStyles)
                return [
                  2
                  /*return*/
                ];
              if (!(this.modeComponent === "rename")) return [3, 3];
              return [4, this.onRenameWidgetStyle(this.stylesComponent[+this.selectStyles.value], this.inputAddStyles.value)];
            case 1:
              _a2.sent();
              return [4, this.loadStylesComponent(this.componentName)];
            case 2:
              _a2.sent();
              this.showActionsMode();
              return [3, 7];
            case 3:
              if (!(this.modeComponent === "add")) return [3, 7];
              return [4, this.onAddWidgetStyle(this.inputAddStyles.value)];
            case 4:
              _a2.sent();
              return [4, this.loadStylesComponent(this.componentName, this.stylesComponent.length)];
            case 5:
              _a2.sent();
              return [4, this.onAfterAdd()];
            case 6:
              _a2.sent();
              this.showActionsMode();
              _a2.label = 7;
            case 7:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.getWidgetTagName = function(widgetName) {
      var parts = widgetName.split("_");
      parts.shift();
      var project = parts.shift() || "";
      var formattedString = "".concat(parts.join("-"), "-").concat(project);
      formattedString = formattedString.replace(/([^A-Z-]|^)([A-Z])/g, function(_, prefix, letter) {
        return "".concat(prefix, "-").concat(letter.toLowerCase());
      }).toLowerCase();
      return formattedString;
    };
    ServiceDsStyles2.prototype.updated = function(changedProperties) {
      if (changedProperties.has("msize")) {
        this.setMsizeEditor();
      }
    };
    ServiceDsStyles2.prototype.setMsizeEditor = function() {
      var _a2, _b2;
      if (!this.visible)
        return;
      if (this.isComponent) {
        var _c2 = this.msize.split(","), w = _c2[0], h = _c2[1], t = _c2[2], l = _c2[3];
        var newH = +h - 50;
        var newT = +t + 50;
        var newMsize = [w, newH, newT, l].join(",");
        (_a2 = this.c2) === null || _a2 === void 0 ? void 0 : _a2.setAttribute("msize", newMsize);
        return;
      }
      (_b2 = this.c2) === null || _b2 === void 0 ? void 0 : _b2.setAttribute("msize", this.msize);
    };
    ServiceDsStyles2.prototype.handleOpenHelperClick = function() {
      return __awaiter(this, void 0, void 0, function() {
        var tagName, el;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (!this.containerHelpers)
                return [
                  2
                  /*return*/
                ];
              if (!this.isHelperContainerOpen) return [3, 1];
              this.containerHelpers.classList.remove("open");
              this.isHelperContainerOpen = false;
              return [3, 4];
            case 1:
              this.containerHelpers.classList.add("open");
              if (!(this.helperDiv && this.helperDiv.children.length === 0)) return [3, 3];
              return [4, import("./_100554_serviceDsStyleBorder")];
            case 2:
              _a2.sent();
              tagName = convertFileNameToTag("_100554_serviceDsStyleBorder");
              el = document.createElement(tagName);
              this.helperDiv.appendChild(el);
              _a2.label = 3;
            case 3:
              this.isHelperContainerOpen = true;
              _a2.label = 4;
            case 4:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsStyles2.prototype.render = function() {
      var _this = this;
      this.style.position = "relative";
      this.style.display = "block";
      return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n            <style>", '</style>\n            <div class="container-open-helper">\n                <div class="toogle" @click=', '> \n                    <i class="', '"></i>\n                </div>\n                <div class="helper"></div>\n            </div>\n            <div class="styles-if-component" style=', '>\n                <select \n                    id="service_styles_select_comp_styles"\n                    .selectedIndex=', "\n                    @change=", "\n                >\n                    ", '\n                    \n                </select>\n                <div class="actions">\n                    <input id="service_styles_input_comp_styles" style=', '></input>\n                    <i class="fa fa-plus" @click=', " style=", '></i>\n                    <i class="fa fa-trash" @click=', " style=", '></i>\n                    <i class="fa fa-pencil" @click=', " style=", '></i>\n                    <i class="fa fa-check" @click=', " style=", '></i>\n                    <i class="fa fa-times" @click=', " style=", '></i>\n                </div>\n            </div>\n            \n            <mls-editor-100529 ismls2="true"></mls-editor-100529>\n        \n        '], ["\n            <style>", '</style>\n            <div class="container-open-helper">\n                <div class="toogle" @click=', '> \n                    <i class="', '"></i>\n                </div>\n                <div class="helper"></div>\n            </div>\n            <div class="styles-if-component" style=', '>\n                <select \n                    id="service_styles_select_comp_styles"\n                    .selectedIndex=', "\n                    @change=", "\n                >\n                    ", '\n                    \n                </select>\n                <div class="actions">\n                    <input id="service_styles_input_comp_styles" style=', '></input>\n                    <i class="fa fa-plus" @click=', " style=", '></i>\n                    <i class="fa fa-trash" @click=', " style=", '></i>\n                    <i class="fa fa-pencil" @click=', " style=", '></i>\n                    <i class="fa fa-check" @click=', " style=", '></i>\n                    <i class="fa fa-times" @click=', " style=", '></i>\n                </div>\n            </div>\n            \n            <mls-editor-100529 ismls2="true"></mls-editor-100529>\n        \n        '])), this.myStyle, this.handleOpenHelperClick, this.isHelperContainerOpen ? "fa fa-chevron-right" : "fa fa-chevron-left", this.isComponent ? "display:'';" : "display:none", this.firstStyleIndex, function() {
        _this.handleChangeSelectStyles();
      }, this.stylesComponent.map(function(st, index) {
        return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['\n                            <option value="', '">\n                                ', "\n                            </option>\n                        "], ['\n                            <option value="', '">\n                                ', "\n                            </option>\n                        "])), index, st.stylename !== _this.componentName.substr(8, _this.componentName.length) ? st.stylename : "Default");
      }), this.actionsMode === "confirm" ? "display:block" : "display:none", function() {
        _this.handleAddStylesClick();
      }, this.actionsMode === "confirm" ? "display:none" : "display:block", function() {
        _this.handleDeleteStylesClick();
      }, this.actionsMode === "actions" ? "display:block" : "display:none", function() {
        _this.handleRenameStylesClick();
      }, this.actionsMode === "actions" ? "display:block" : "display:none", function() {
        _this.handleConfirmStylesClick();
      }, this.actionsMode === "confirm" ? "display:block" : "display:none", function() {
        _this.handleCancelStylesClick();
      }, this.actionsMode === "confirm" ? "display:block" : "display:none");
    };
    var ServiceDsStyles_1;
    var _a, _b, _c, _d, _e;
    ServiceDsStyles2.modelCount = 0;
    __decorate([
      property({ type: String }),
      __metadata("design:type", Object)
    ], ServiceDsStyles2.prototype, "msize", void 0);
    __decorate([
      property(),
      __metadata("design:type", Boolean)
    ], ServiceDsStyles2.prototype, "isComponent", void 0);
    __decorate([
      property(),
      __metadata("design:type", Array)
    ], ServiceDsStyles2.prototype, "stylesComponent", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceDsStyles2.prototype, "actionsMode", void 0);
    __decorate([
      query("mls-editor-100529"),
      __metadata("design:type", typeof (_a = typeof HTMLElement !== "undefined" && HTMLElement) === "function" ? _a : Object)
    ], ServiceDsStyles2.prototype, "c2", void 0);
    __decorate([
      query("#service_styles_select_comp_styles"),
      __metadata("design:type", typeof (_b = typeof HTMLSelectElement !== "undefined" && HTMLSelectElement) === "function" ? _b : Object)
    ], ServiceDsStyles2.prototype, "selectStyles", void 0);
    __decorate([
      query("#service_styles_input_comp_styles"),
      __metadata("design:type", typeof (_c = typeof HTMLInputElement !== "undefined" && HTMLInputElement) === "function" ? _c : Object)
    ], ServiceDsStyles2.prototype, "inputAddStyles", void 0);
    __decorate([
      query(".container-open-helper"),
      __metadata("design:type", typeof (_d = typeof HTMLDivElement !== "undefined" && HTMLDivElement) === "function" ? _d : Object)
    ], ServiceDsStyles2.prototype, "containerHelpers", void 0);
    __decorate([
      query(".helper"),
      __metadata("design:type", typeof (_e = typeof HTMLDivElement !== "undefined" && HTMLDivElement) === "function" ? _e : Object)
    ], ServiceDsStyles2.prototype, "helperDiv", void 0);
    __decorate([
      property(),
      __metadata("design:type", Boolean)
    ], ServiceDsStyles2.prototype, "isHelperContainerOpen", void 0);
    ServiceDsStyles2 = ServiceDsStyles_1 = __decorate([
      customElement("service-ds-styles-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceDsStyles2);
    return ServiceDsStyles2;
  }(ServiceBase)
);
var templateObject_1, templateObject_2;
export {
  ServiceDsStyles
};
