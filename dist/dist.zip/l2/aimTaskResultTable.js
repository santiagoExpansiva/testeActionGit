var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from "lit";
import { customElement } from "lit/decorators.js";
import { AimTaskBase } from "./_100554_aimTaskBase";
var AimTaskResultTable = (
  /** @class */
  function(_super) {
    __extends(AimTaskResultTable2, _super);
    function AimTaskResultTable2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    AimTaskResultTable2.prototype.onInitializing = function() {
      this.notifyCompleteByStatus("ok", "");
    };
    AimTaskResultTable2.prototype.renderBody = function(taskRoot, child) {
      var title = child.title;
      var body = child._tempResult || "";
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n        <details open>\n            <summary>", "</summary>\n            <div style='margin: 10px'>", "</div> \n        </details>\n        "], ["\n        <details open>\n            <summary>", "</summary>\n            <div style='margin: 10px'>", "</div> \n        </details>\n        "])), title, this.renderTable2(this.parseTable2(body)));
    };
    AimTaskResultTable2.prototype.parseTable = function(body) {
      var i1 = body.indexOf("|");
      if (i1 < 0)
        return [];
      var lines = body.substring(i1).split("\n");
      var tab1 = [];
      for (var _i = 0, lines_1 = lines; _i < lines_1.length; _i++) {
        var line = lines_1[_i];
        if (!line.startsWith("|"))
          continue;
        var cols = line.trim().split("|");
        tab1.push(cols);
      }
      return tab1;
    };
    AimTaskResultTable2.prototype.parseTable2 = function(body) {
      var regex = /\|/g;
      var lines = body.split("\n");
      var linesWithValues = lines.filter(function(line) {
        return line.trim() !== "";
      });
      var table = linesWithValues.map(function(line) {
        return line.split(regex);
      });
      var tableWithNoEspaces = table.map(function(line) {
        return line.map(function(cel) {
          return cel.trim();
        });
      });
      return tableWithNoEspaces;
    };
    AimTaskResultTable2.prototype.renderTable2 = function(tab1) {
      if (tab1.length < 2)
        return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["invalid table"], ["invalid table"])));
      return html(templateObject_6 || (templateObject_6 = __makeTemplateObject(['\n        <table class="tb">\n            <thead>\n            <tr>', "</tr>\n            </thead>\n            <tbody>\n            ", "\n            </tbody>\n        </table>\n        "], ['\n        <table class="tb">\n            <thead>\n            <tr>', "</tr>\n            </thead>\n            <tbody>\n            ", "\n            </tbody>\n        </table>\n        "])), tab1[0].map(function(header) {
        return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['<th class="th">', "</th>"], ['<th class="th">', "</th>"])), header);
      }), tab1.slice(1).map(function(row) {
        return html(templateObject_5 || (templateObject_5 = __makeTemplateObject(["\n                <tr>", "</tr>\n            "], ["\n                <tr>", "</tr>\n            "])), row.map(function(cell) {
          return html(templateObject_4 || (templateObject_4 = __makeTemplateObject(['<td class="td">', "</td>"], ['<td class="td">', "</td>"])), cell);
        }));
      }));
    };
    AimTaskResultTable2 = __decorate([
      customElement("aim-task-result-table-100554")
    ], AimTaskResultTable2);
    return AimTaskResultTable2;
  }(AimTaskBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6;
export {
  AimTaskResultTable
};
