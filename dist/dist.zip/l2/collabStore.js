var COUNTHITSPAGES = "CountHitsPages";
export {
  COUNTHITSPAGES
};
