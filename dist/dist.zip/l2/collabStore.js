const COUNTHITSPAGES = "CountHitsPages";
export {
  COUNTHITSPAGES
};
