var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css } from "lit";
import { customElement, property, query } from "lit/decorators.js";
import { collab_check, collab_copy, collab_double_check } from "./_100554_collabIcons";
import { CollabLitElement } from "./_100554_collabLitElement";
function initCollabShowCodeSnippet100554() {
  return true;
}
var message_pt = {
  copy: "Copiar",
  copied: "Copiado",
  accept: "Aceitar",
  accepted: "Aceito"
};
var message_en = {
  copy: "Copy",
  copied: "Copied",
  accept: "Accept",
  accepted: "Accepted"
};
var messages = {
  "en-us": message_en,
  "pt-br": message_pt
};
var CollabShowCodeSnippet100554 = (
  /** @class */
  function(_super) {
    __extends(CollabShowCodeSnippet1005542, _super);
    function CollabShowCodeSnippet1005542() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.msg = messages["en-us"];
      _this.language = "typescript";
      _this.withCopy = true;
      _this.withAccept = false;
      _this.coping = false;
      _this.accepting = false;
      _this.text = "";
      _this.onAccept = function() {
        console.info("not implement");
      };
      return _this;
    }
    Object.defineProperty(CollabShowCodeSnippet1005542.prototype, "textIn", {
      set: function(text) {
        var _this = this;
        this.text = text;
        if (!this.codeBlock)
          return;
        this.waitForLoadIfNeeded(function() {
          _this.setCode();
        });
      },
      enumerable: false,
      configurable: true
    });
    CollabShowCodeSnippet1005542.prototype.updated = function(changedProperties) {
      var _this = this;
      if (changedProperties.has("language")) {
        if (!window.hljsLoaded) {
          var script = document.createElement("script");
          script.src = "https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js";
          script.onload = function() {
            window.hljsLoaded = true;
            _this.setCode();
          };
          document.head.appendChild(script);
        } else {
          this.setCode();
        }
      }
    };
    CollabShowCodeSnippet1005542.prototype.waitForLoadIfNeeded = function(callback, timeout, interval) {
      if (timeout === void 0) {
        timeout = 1e4;
      }
      if (interval === void 0) {
        interval = 100;
      }
      var elapsedTime = 0;
      var checkVariable = function() {
        if (window.hljsLoaded) {
          callback();
        } else if (elapsedTime < timeout) {
          elapsedTime += interval;
          setTimeout(checkVariable, interval);
        } else {
          console.error("Error on load highlight.js. please tyy again");
        }
      };
      checkVariable();
    };
    CollabShowCodeSnippet1005542.prototype.setCode = function() {
      if (!this.codeBlock)
        return;
      this.codeBlock.innerHTML = "";
      this.codeBlock.removeAttribute("data-highlighted");
      this.codeBlock.classList.add("language-" + this.language);
      var res = window.hljs.highlight(this.text, { language: this.language });
      window.hljs.highlightElement(this.codeBlock, { language: this.language });
      this.codeBlock.innerHTML = res.value;
    };
    CollabShowCodeSnippet1005542.prototype.onCopyClick = function() {
      var _this = this;
      this.coping = true;
      navigator.clipboard.writeText(this.text);
      setTimeout(function() {
        _this.coping = false;
      }, 3e3);
    };
    CollabShowCodeSnippet1005542.prototype.onAcceptClick = function() {
      var _this = this;
      if (this.onAccept && typeof this.onAccept === "function") {
        this.accepting = true;
        this.onAccept();
        setTimeout(function() {
          _this.accepting = false;
        }, 3e3);
      }
    };
    CollabShowCodeSnippet1005542.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['\n       <div class="actions">\n            <span class="language">', '</span>\n            <div class="actions-list">\n             ', "\n             ", '\n            </div>\n       </div>\n\n       <pre><code class="code"></code></pre>\n    '], ['\n       <div class="actions">\n            <span class="language">', '</span>\n            <div class="actions-list">\n             ', "\n             ", '\n            </div>\n       </div>\n\n       <pre><code class="code"></code></pre>\n    '])), this.language, this.withAccept ? this.renderWithAccept() : "", this.withCopy ? this.renderWithCopy() : "");
    };
    CollabShowCodeSnippet1005542.prototype.renderWithCopy = function() {
      return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n      <div @click=", ' class="action-item" style="display:', '">\n        <div>\n          ', "\n        </div>\n        <span>", '</span>\n    </div>\n    <div class="action-item copied" style="display:', '">\n      ', "\n      <span>", "</span>\n    </div>\n    "], ["\n      <div @click=", ' class="action-item" style="display:', '">\n        <div>\n          ', "\n        </div>\n        <span>", '</span>\n    </div>\n    <div class="action-item copied" style="display:', '">\n      ', "\n      <span>", "</span>\n    </div>\n    "])), this.onCopyClick, this.coping ? "none" : "flex", collab_copy, this.msg.copy, this.coping ? "flex" : "none", collab_check, this.msg.copied);
    };
    CollabShowCodeSnippet1005542.prototype.renderWithAccept = function() {
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(["\n      <div @click=", ' class="action-item" style="display:', '">\n        <div>\n          ', "\n        </div>\n        <span>", '</span>\n    </div>\n    <div class="action-item accepted" style="display:', '">\n      ', "\n      <span>", "Accepted</span>\n    </div>\n    "], ["\n      <div @click=", ' class="action-item" style="display:', '">\n        <div>\n          ', "\n        </div>\n        <span>", '</span>\n    </div>\n    <div class="action-item accepted" style="display:', '">\n      ', "\n      <span>", "Accepted</span>\n    </div>\n    "])), this.onAcceptClick, this.accepting ? "none" : "flex", collab_check, this.msg.accept, this.accepting ? "flex" : "none", collab_double_check, this.msg.accepted);
    };
    var _a;
    CollabShowCodeSnippet1005542.styles = css(templateObject_4 || (templateObject_4 = __makeTemplateObject(["\n    pre code.hljs {\n        display: block;\n        overflow-x: auto;\n        padding: 1em\n      }\n      code.hljs {\n        padding: 3px 5px\n      }\n      /*\n      * Visual Studio 2015 dark style\n      * Author: Nicolas LLOBERA <nllobera@gmail.com>\n      */\n      .hljs {\n        background: #1E1E1E;\n        color: #DCDCDC\n      }\n      .hljs-keyword,\n      .hljs-literal,\n      .hljs-symbol,\n      .hljs-name {\n        color: #569CD6\n      }\n      .hljs-link {\n        color: #569CD6;\n        text-decoration: underline\n      }\n      .hljs-built_in,\n      .hljs-type {\n        color: #4EC9B0\n      }\n      .hljs-number,\n      .hljs-class {\n        color: #B8D7A3\n      }\n      .hljs-string,\n      .hljs-meta .hljs-string {\n        color: #D69D85\n      }\n      .hljs-regexp,\n      .hljs-template-tag {\n        color: #9A5334\n      }\n      .hljs-subst,\n      .hljs-function,\n      .hljs-title,\n      .hljs-params,\n      .hljs-formula {\n        color: #DCDCDC\n      }\n      .hljs-comment,\n      .hljs-quote {\n        color: #57A64A;\n        font-style: italic\n      }\n      .hljs-doctag {\n        color: #608B4E\n      }\n      .hljs-meta,\n      .hljs-meta .hljs-keyword,\n      .hljs-tag {\n        color: #9B9B9B\n      }\n      .hljs-variable,\n      .hljs-template-variable {\n        color: #BD63C5\n      }\n      .hljs-attr,\n      .hljs-attribute {\n        color: #9CDCFE\n      }\n      .hljs-section {\n        color: gold\n      }\n      .hljs-emphasis {\n        font-style: italic\n      }\n      .hljs-strong {\n        font-weight: bold\n      }\n      /*.hljs-code {\n        font-family:'Monospace';\n      }*/\n      .hljs-bullet,\n      .hljs-selector-tag,\n      .hljs-selector-id,\n      .hljs-selector-class,\n      .hljs-selector-attr,\n      .hljs-selector-pseudo {\n        color: #D7BA7D\n      }\n      .hljs-addition {\n        background-color: #144212;\n        display: inline-block;\n        width: 100%\n      }\n      .hljs-deletion {\n        background-color: #600;\n        display: inline-block;\n        width: 100%\n      }\n      pre {\n        margin: 0;\n      }\n\n      .actions{\n        height:30px; \n        background: #b4b4b4; \n        display:flex; \n        align-items:center;\n        padding:0 1rem; \n        color:#fff;\n        .actions-list{\n          display:flex;\n          gap:1rem;\n        }\n      }\n      .language {\n        flex:1;\n      }\n      \n      .action-item{\n        display:flex; \n        align-items:center;\n        justify-content: center;\n        cursor:pointer;\n        min-width: 70px;\n      }\n      .accepted{\n        cursor:default;\n\n      }\n      .copied {\n        cursor:default;\n      }\n    "], ["\n    pre code.hljs {\n        display: block;\n        overflow-x: auto;\n        padding: 1em\n      }\n      code.hljs {\n        padding: 3px 5px\n      }\n      /*\n      * Visual Studio 2015 dark style\n      * Author: Nicolas LLOBERA <nllobera@gmail.com>\n      */\n      .hljs {\n        background: #1E1E1E;\n        color: #DCDCDC\n      }\n      .hljs-keyword,\n      .hljs-literal,\n      .hljs-symbol,\n      .hljs-name {\n        color: #569CD6\n      }\n      .hljs-link {\n        color: #569CD6;\n        text-decoration: underline\n      }\n      .hljs-built_in,\n      .hljs-type {\n        color: #4EC9B0\n      }\n      .hljs-number,\n      .hljs-class {\n        color: #B8D7A3\n      }\n      .hljs-string,\n      .hljs-meta .hljs-string {\n        color: #D69D85\n      }\n      .hljs-regexp,\n      .hljs-template-tag {\n        color: #9A5334\n      }\n      .hljs-subst,\n      .hljs-function,\n      .hljs-title,\n      .hljs-params,\n      .hljs-formula {\n        color: #DCDCDC\n      }\n      .hljs-comment,\n      .hljs-quote {\n        color: #57A64A;\n        font-style: italic\n      }\n      .hljs-doctag {\n        color: #608B4E\n      }\n      .hljs-meta,\n      .hljs-meta .hljs-keyword,\n      .hljs-tag {\n        color: #9B9B9B\n      }\n      .hljs-variable,\n      .hljs-template-variable {\n        color: #BD63C5\n      }\n      .hljs-attr,\n      .hljs-attribute {\n        color: #9CDCFE\n      }\n      .hljs-section {\n        color: gold\n      }\n      .hljs-emphasis {\n        font-style: italic\n      }\n      .hljs-strong {\n        font-weight: bold\n      }\n      /*.hljs-code {\n        font-family:'Monospace';\n      }*/\n      .hljs-bullet,\n      .hljs-selector-tag,\n      .hljs-selector-id,\n      .hljs-selector-class,\n      .hljs-selector-attr,\n      .hljs-selector-pseudo {\n        color: #D7BA7D\n      }\n      .hljs-addition {\n        background-color: #144212;\n        display: inline-block;\n        width: 100%\n      }\n      .hljs-deletion {\n        background-color: #600;\n        display: inline-block;\n        width: 100%\n      }\n      pre {\n        margin: 0;\n      }\n\n      .actions{\n        height:30px; \n        background: #b4b4b4; \n        display:flex; \n        align-items:center;\n        padding:0 1rem; \n        color:#fff;\n        .actions-list{\n          display:flex;\n          gap:1rem;\n        }\n      }\n      .language {\n        flex:1;\n      }\n      \n      .action-item{\n        display:flex; \n        align-items:center;\n        justify-content: center;\n        cursor:pointer;\n        min-width: 70px;\n      }\n      .accepted{\n        cursor:default;\n\n      }\n      .copied {\n        cursor:default;\n      }\n    "])));
    __decorate([
      property({ type: String, reflect: true }),
      __metadata("design:type", Object)
    ], CollabShowCodeSnippet1005542.prototype, "language", void 0);
    __decorate([
      property({ type: Boolean, reflect: true }),
      __metadata("design:type", Object)
    ], CollabShowCodeSnippet1005542.prototype, "withCopy", void 0);
    __decorate([
      property({ type: Boolean, reflect: true }),
      __metadata("design:type", Object)
    ], CollabShowCodeSnippet1005542.prototype, "withAccept", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Object)
    ], CollabShowCodeSnippet1005542.prototype, "coping", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Object)
    ], CollabShowCodeSnippet1005542.prototype, "accepting", void 0);
    __decorate([
      query(".code"),
      __metadata("design:type", typeof (_a = typeof HTMLElement !== "undefined" && HTMLElement) === "function" ? _a : Object)
    ], CollabShowCodeSnippet1005542.prototype, "codeBlock", void 0);
    CollabShowCodeSnippet1005542 = __decorate([
      customElement("collab-show-code-snippet-100554")
    ], CollabShowCodeSnippet1005542);
    return CollabShowCodeSnippet1005542;
  }(CollabLitElement)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4;
export {
  CollabShowCodeSnippet100554,
  initCollabShowCodeSnippet100554
};
