import { AttributePart, BooleanAttributePart, ChildPart, ElementPart, EventPart, Part, PropertyPart } from "./_100554_litHtml";
var PartType = {
  ATTRIBUTE: 1,
  CHILD: 2,
  PROPERTY: 3,
  BOOLEAN_ATTRIBUTE: 4,
  EVENT: 5,
  ELEMENT: 6
};
var directive = function(c) {
  return function() {
    var _a;
    var values = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      values[_i] = arguments[_i];
    }
    return _a = {}, // This property needs to remain unminified.
    _a["_$litDirective$"] = c, _a.values = values, _a;
  };
};
var Directive = (
  /** @class */
  function() {
    function Directive2(_partInfo) {
    }
    Object.defineProperty(Directive2.prototype, "_$isConnected", {
      // See comment in Disconnectable interface for why this is a getter
      get: function() {
        return this._$parent._$isConnected;
      },
      enumerable: false,
      configurable: true
    });
    Directive2.prototype._$initialize = function(part, parent, attributeIndex) {
      this.__part = part;
      this._$parent = parent;
      this.__attributeIndex = attributeIndex;
    };
    Directive2.prototype._$resolve = function(part, props) {
      return this.update(part, props);
    };
    Directive2.prototype.update = function(_part, props) {
      return this.render.apply(this, props);
    };
    return Directive2;
  }()
);
export {
  AttributePart,
  BooleanAttributePart,
  ChildPart,
  Directive,
  ElementPart,
  EventPart,
  Part,
  PartType,
  PropertyPart,
  directive
};
