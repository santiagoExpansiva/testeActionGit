var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html } from "lit";
import { customElement, query, property } from "lit/decorators.js";
import { tasks, updateTaskOnServer } from "./_100554_aimHelper";
import { AimActionBase } from "./_100554_aimActionBase";
import { getInfoMyService } from "./_100554_aimHelper";
import { getFormComponentsPrompt, getAttributeDefinitions } from "./_100554_icaBaseDescription";
import { initIcaSelectGroup, IcaSelectGroup } from "./_100554_icaSelectGroup";
var myName = "_100554_aimActionAddIca";
var message_pt = {
  prompt_ts_title_1: "Usando Typescript e Lit 3.O. Criar o render de um webcomponent, usando o source fornecido abaixo.",
  prompt_ts_output_1: "Um component Lit com sua implementa\uFFFD\uFFFDo de renderiza\uFFFD\uFFFDo completa, seguindo todas as especifica\uFFFD\uFFFDes do usuario e utilizando as propriedades fornecidas.",
  prompt_ts_output_2: "N\uFFFDo remover a primeira linha /// <mls",
  prompt_ts_output_3: "Nao alterar defini\uFFFD\uFFFDo da classe",
  prompt_ts_output_4: "Nao alterar extends da classe",
  prompt_ts_output_5: "N\uFFFDo alterar imports",
  prompt_ts_output_6: "Nao altere as propriedades iniciais",
  prompt_ts_output_7: "N\uFFFDo implementar nenhum styles css.",
  prompt_ts_output_8: "As fun\uFFFD\uFFFDes n\uFFFDo implementadas devem ser declaradas com um corpo vazio, e dentro da fun\uFFFD\uFFFDo deve adicionar um coment\uFFFDrios // **implement_here**' e coment\uFFFDrios sobre o que o m\uFFFDtodo deve fazer. Segue exemplo:",
  prompt_ts_output_9: "Retornar o c\uFFFDdigo em um \uFFFDnico bloco  ```typescript.",
  prompt_html_title: "Usando Typescript e Lit 3.O analisar o source do web component abaixo e gerar um html de use cases. N\uFFFDo \uFFFD necessario declarar as tags html, body, head. Somente uma se\uFFFD\uFFFDo com o use cases.",
  prompt_html_output: "Remover os coment\uFFFDrios nas fun\uFFFD\uFFFDes quando implementadas.",
  prompt_fc_title_1: "Usando Typescript e Lit 3.O. Criar a fun\uFFFD\uFFFDo especificada pelo usuario, utilizando o source abaixo",
  prompt_fc_output_1: "O component Lit com a implementa\uFFFD\uFFFDo da fun\uFFFD\uFFFDo completa e altera\uFFFD\uFFFDes solicitadas, seguindo todas as especifica\uFFFD\uFFFDes do usuario.",
  prompt_fc_output_2: "Remover os coment\uFFFDrios nas fun\uFFFD\uFFFDes quando implementadas.",
  template_title: "Ir\uFFFD verificar o grupo selecionado e criar um novo componente Lit",
  textarea_placelholder: "Entre com o prompt aqui",
  btn_cancel: "Cancelar",
  btn_confirm: "Confirmar",
  error_prompt: "Por favor, ajuste o prompt para suas necessidades"
};
var message_en = {
  prompt_ts_title_1: "Using Typescript and Lit 3.0. Create the rendering of a web component, using the provided source below.",
  prompt_ts_output_1: "A Lit component with its complete rendering implementation, following all user specifications and using the provided properties.",
  prompt_ts_output_2: "Do not remove the first line /// <mls",
  prompt_ts_output_3: "Do not change the class definition",
  prompt_ts_output_4: "Do not change the class extends",
  prompt_ts_output_5: "Do not change imports",
  prompt_ts_output_6: "Do not change initial properties",
  prompt_ts_output_7: "Do not implement any CSS styles.",
  prompt_ts_output_8: "Unimplemented functions should be declared with an empty body, and within the function add a comment // implement_here' and comments about what the method should do. Example follows:",
  prompt_ts_output_9: "Return the code in a single block ```typescript.",
  prompt_html_title: "Using Typescript and Lit 3.0, analyze the source of the web component below and generate an HTML of use cases. It is not necessary to declare the html, body, head tags. Only one section with the use cases.",
  prompt_html_output: "Remove comments in functions when implemented.",
  prompt_fc_title_1: "Using Typescript and Lit 3.0. Create the function specified by the user, using the source below",
  prompt_fc_output_1: "The Lit component with the complete function implementation and requested changes, following all user specifications.",
  prompt_fc_output_2: "Remove comments in functions when implemented.",
  template_title: "Will check the selected group and create a new Lit component",
  textarea_placelholder: "Enter your prompt here",
  btn_cancel: "Cancel",
  btn_confirm: "Confirm",
  error_prompt: "Please adjust the prompt to your needs"
};
var messages = {
  "en-us": message_en,
  "pt-br": message_pt
};
var AimActionAddIca = (
  /** @class */
  function(_super) {
    __extends(AimActionAddIca2, _super);
    function AimActionAddIca2() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en-us"];
      _this.assistant = "gpt3_typescript";
      _this.title = "New Component";
      _this.showPrompt = false;
      _this.actualSuggest = "";
      _this.validPrompt = true;
      _this.actualAttributes = [];
      _this.actualGroups = [];
      _this.language = "english";
      initIcaSelectGroup();
      return _this;
    }
    AimActionAddIca2.prototype.getRules = function() {
      return {
        levels: [2],
        tags: ["*serviceSource*"]
      };
    };
    AimActionAddIca2.prototype.handleCancel = function() {
      var _a2;
      this.clear();
      (_a2 = this.selectGroup) === null || _a2 === void 0 ? void 0 : _a2.clear();
      this.dispatchEvent(new CustomEvent("add-task", {
        detail: { cancel: "true" },
        bubbles: true,
        composed: true
      }));
    };
    AimActionAddIca2.prototype.handleAdd = function() {
      this.validPrompt = true;
      var txtAreaValue = "";
      if (!this.textarea)
        return;
      txtAreaValue = this.textarea.value;
      if (txtAreaValue.trim() === this.actualSuggest.trim()) {
        this.validPrompt = false;
        this.requestUpdate();
        return;
      }
      var args = {
        prompt: this.textarea.value,
        group: this.actualGroups,
        attr: this.actualAttributes
      };
      this.taskRoot = {
        mode: "initializing",
        title: "verify group and create new component",
        widget: myName,
        children: [],
        args: JSON.stringify(args),
        trace: [(/* @__PURE__ */ new Date()).toISOString() + ": trask created at "]
      };
      tasks.unshift(this.taskRoot);
      this.prepareCheckTask1(this.taskRoot);
      this.dispatchEvent(new CustomEvent("finished-add-task-root", {
        detail: this.taskRoot,
        bubbles: true,
        composed: true
      }));
    };
    AimActionAddIca2.prototype.onGroupChanged = function(e) {
      var groups = e.detail.selection;
      if (groups.length === 3) {
        var root = groups[0], subgroup = groups[1], finalgroup = groups[2];
        this.showPrompt = true;
        this.actualSuggest = getFormComponentsPrompt(root, subgroup, finalgroup);
        this.actualAttributes = getAttributeDefinitions(root, subgroup, finalgroup);
        this.actualGroups = groups;
      } else {
        this.clear();
      }
    };
    AimActionAddIca2.prototype.clear = function() {
      this.showPrompt = false;
      this.actualSuggest = "";
      this.actualAttributes = [];
      this.actualGroups = [];
    };
    AimActionAddIca2.prototype.renderAdd = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_4 || (templateObject_4 = __makeTemplateObject(["\n        <p> ", "</p>\n        <ica-select-group-100554 @selection-changed=", " ></ica-select-group-100554>\n\n        ", '\n        <div class="buttonGroup">\n            <button @click="', '">', "</button>\n            ", "\n        </div>\n        ", "\n\n            "], ["\n        <p> ", "</p>\n        <ica-select-group-100554 @selection-changed=", " ></ica-select-group-100554>\n\n        ", '\n        <div class="buttonGroup">\n            <button @click="', '">', "</button>\n            ", "\n        </div>\n        ", "\n\n            "])), this.msg.template_title, this.onGroupChanged, this.showPrompt ? html(templateObject_1 || (templateObject_1 = __makeTemplateObject([" \n            <div>\n                <label><b>Prompt:</b></label>\n                <textarea .value=", ' rows="5" placeholder=', ' style="width:100%"></textarea>\n            </div>\n\n        '], [" \n            <div>\n                <label><b>Prompt:</b></label>\n                <textarea .value=", ' rows="5" placeholder=', ' style="width:100%"></textarea>\n            </div>\n\n        '])), this.actualSuggest, this.msg.textarea_placelholder) : "", this.handleCancel, this.msg.btn_cancel, this.showPrompt ? html(templateObject_2 || (templateObject_2 = __makeTemplateObject(['<button @click="', '">', "</button>"], ['<button @click="', '">', "</button>"])), this.handleAdd, this.msg.btn_confirm) : "", !this.validPrompt ? html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['<div style="color:red;"> ', "</div>"], ['<div style="color:red;"> ', "</div>"])), this.msg.error_prompt) : "");
    };
    AimActionAddIca2.prototype.prepareCheckTask1 = function(taskRoot) {
      this.mode = taskRoot.mode = "in progress";
      if (!taskRoot.args) {
        this.mode = taskRoot.mode = "error";
        taskRoot.trace.push("invalid taskroot args");
        return;
      }
      var args = JSON.parse(taskRoot.args);
      this.addTaskAndWaitForCompletion(taskRoot, {
        mode: "initializing",
        title: "verify prompt",
        widget: "_100554_aimTaskExecLLM",
        agent: this.assistant,
        ref: "testeRef",
        prompt: this.getPromptCheckPrompt(args.prompt),
        trace: [],
        nextStep: this.prepareCheckTask2.name
        // danger, loop
      });
      this.requestUpdate();
    };
    AimActionAddIca2.prototype.prepareCheckTask2 = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      var result = child.result || "";
      if (taskFinishResult.status === "error" || !result) {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        return;
      }
      child.mode = "processed";
      this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
        mode: "initializing",
        title: "improve prompt",
        widget: "_100554_aimTaskResultAddIcaPrompt",
        result: child.result,
        trace: [],
        nextStep: this.prepareTask1.name
        // danger, loop
      });
      this.requestUpdate();
    };
    AimActionAddIca2.prototype.prepareTask1 = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      if (taskFinishResult.status === "error") {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        return;
      }
      if (!taskFinishResult.taskRoot.args) {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        child.trace.push("invalid taskroot args");
        return;
      }
      var args = JSON.parse(taskFinishResult.taskRoot.args);
      if (taskFinishResult.status === "userEvent" && taskFinishResult.newPrompt) {
        args.prompt = taskFinishResult.newPrompt;
      }
      child.mode = "processed";
      this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
        mode: "initializing",
        title: "prepare source",
        widget: "_100554_aimTaskPrepareIcaSource",
        prompt: JSON.stringify(args),
        trace: [],
        nextStep: this.prepareTask2.name
        // danger, loop
      });
    };
    AimActionAddIca2.prototype.prepareTask2 = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      if (taskFinishResult.status === "error") {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        return;
      }
      var source = taskFinishResult.result;
      if (!source) {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        child.trace.push("invalid finish , must be notify finish with result field");
        this.requestUpdate();
        return;
      }
      if (!taskFinishResult.taskRoot.args) {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        child.trace.push("invalid taskroot args");
        return;
      }
      var args = JSON.parse(taskFinishResult.taskRoot.args);
      child.mode = "processed";
      this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
        mode: "initializing",
        title: "exec prompt",
        widget: "_100554_aimTaskExecLLM",
        ref: child.ref,
        agent: this.assistant,
        prompt: this.getPrompt(source, args.prompt),
        trace: [],
        nextStep: this.prepareTask3.name
        // danger, loop
      });
      this.requestUpdate();
    };
    AimActionAddIca2.prototype.prepareTask3 = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      var result = child.result || "";
      if (taskFinishResult.status === "error" || !result) {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        return;
      }
      child.mode = "processed";
      this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
        mode: "initializing",
        title: "result",
        widget: "_100554_aimTaskResultAddIca",
        ref: child.ref,
        trace: [],
        result,
        nextStep: this.prepareTask4.name
        // danger, loop
      });
      this.requestUpdate();
    };
    AimActionAddIca2.prototype.prepareTask4 = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      if (taskFinishResult.status === "ok" || taskFinishResult.status === "error" || taskFinishResult.status === "rejected") {
        return this.endTasks(taskFinishResult);
      }
      if (taskFinishResult.status !== "userEvent")
        throw new Error("Event not prepared");
      if (taskFinishResult.taskRoot.children.length > 20)
        throw new Error("Maximum task exceted");
      if (!taskFinishResult.newPrompt)
        throw new Error("Prompt invalid");
      var source = taskFinishResult.result;
      if (!source) {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        child.trace.push("invalid finish , must be notify finish with result field");
        this.requestUpdate();
        return;
      }
      if (taskFinishResult.newPrompt === "[html]") {
        child.mode = "processed";
        this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
          mode: "initializing",
          title: "exec prompt",
          widget: "_100554_aimTaskExecLLM",
          ref: child.ref,
          agent: this.assistant,
          prompt: this.getPromptHTML(source),
          trace: [],
          result: source,
          nextStep: this.endTasks.name
          // looping exec prompt
        });
        return;
      }
      child.mode = "processed";
      this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
        mode: "initializing",
        title: "exec prompt",
        widget: "_100554_aimTaskExecLLM",
        ref: child.ref,
        agent: this.assistant,
        prompt: this.getPrompt2(source, taskFinishResult.newPrompt),
        trace: [],
        nextStep: this.prepareTask3.name
        // looping exec prompt
      });
    };
    AimActionAddIca2.prototype.endTasks = function(taskFinishResult) {
      var taskChild = taskFinishResult.taskChild, taskRoot = taskFinishResult.taskRoot, status = taskFinishResult.status, result = taskFinishResult.result;
      if (status === "error")
        taskChild.mode = "error";
      else if (status === "rejected")
        taskChild.mode = "processed";
      else if (status === "ok") {
        taskChild.mode = "processed";
        if (taskChild.widget === "_100554_aimTaskExecLLM") {
          var res = taskRoot.children.filter(function(ch) {
            return ch.widget === "_100554_aimTaskResultAddIca";
          });
          var lastRes = res.pop();
          var result_1 = lastRes ? lastRes.result : "";
          if (!result_1)
            return;
          this.setResultInEditor(this.extractTS(result_1), this.extractHTML(taskChild.result || ""));
        } else
          this.setResultInEditor(result);
      }
      this.mode = taskFinishResult.taskRoot.mode = taskChild.mode;
      this.requestUpdate();
      updateTaskOnServer(taskFinishResult.taskIndex);
    };
    AimActionAddIca2.prototype.setResultInEditor = function(value, valueHTML) {
      var activeOpService = getActiveOpServiceIfIsValid(this);
      if (!activeOpService) {
        window.collabMessages.add("The service in the opposite position does not refer to this action", "error");
        return false;
      }
      ;
      if (value)
        activeOpService.setEditorValue(value.trim());
      if (valueHTML)
        activeOpService.setEditorHTMLValue(valueHTML.trim());
      return true;
    };
    AimActionAddIca2.prototype.extractHTML = function(src) {
      var regex = /```html([\s\S]+?)```/g;
      var matches = src.match(regex);
      var contents = [];
      var ret = src;
      if (matches) {
        for (var _i = 0, matches_1 = matches; _i < matches_1.length; _i++) {
          var m = matches_1[_i];
          var conteudo = m.replace(/```html|```/g, "").trim();
          contents.push(conteudo);
        }
        ret = contents[0];
      }
      return ret;
    };
    AimActionAddIca2.prototype.extractTS = function(src) {
      var regex = /```typescript([\s\S]+?)```/g;
      var matches = src.match(regex);
      var contents = [];
      var ret = src;
      if (matches) {
        for (var _i = 0, matches_2 = matches; _i < matches_2.length; _i++) {
          var m = matches_2[_i];
          var conteudo = m.replace(/```typescript|```/g, "").trim();
          contents.push(conteudo);
        }
        ret = contents[0];
      }
      return ret;
    };
    AimActionAddIca2.prototype.getPrompt = function(source, user) {
      var promptInitial = "\n### system ###: \n\n".concat(this.msg.prompt_ts_title_1, "\n-Saida esperada: \n1. ").concat(this.msg.prompt_ts_output_1, "\n2. ").concat(this.msg.prompt_ts_output_2, "\n3. ").concat(this.msg.prompt_ts_output_3, "\n4. ").concat(this.msg.prompt_ts_output_4, "\n5. ").concat(this.msg.prompt_ts_output_5, "\n6. ").concat(this.msg.prompt_ts_output_6, "\n7. ").concat(this.msg.prompt_ts_output_7, "\n8. ").concat(this.msg.prompt_ts_output_8, "\nminhaFun\uFFFDao(){\n    // **implement_here**\n}\n\n9. ").concat(this.msg.prompt_ts_output_9, "\n\n### user ###:\n\n").concat(user, "\n\n-Source: ").concat(source, "\n");
      return promptInitial;
    };
    AimActionAddIca2.prototype.getPrompt2 = function(source, user) {
      var promptInitial = "\n### system ###: \n".concat(this.msg.prompt_fc_title_1, "\n\n-Saida esperada: \n1. ").concat(this.msg.prompt_fc_output_1, "\n2. ").concat(this.msg.prompt_ts_output_2, "\n3. ").concat(this.msg.prompt_ts_output_3, "\n4. ").concat(this.msg.prompt_ts_output_4, "\n5. ").concat(this.msg.prompt_ts_output_5, "\n6. ").concat(this.msg.prompt_ts_output_6, "\n7. ").concat(this.msg.prompt_ts_output_7, "\n9. ").concat(this.msg.prompt_ts_output_9, "\n10. ").concat(this.msg.prompt_fc_output_2, "\n\n### user ###:\n").concat(user, "\n\n-Source: ").concat(source, "\n");
      return promptInitial;
    };
    AimActionAddIca2.prototype.getPromptHTML = function(source) {
      var prompt = "\n### system ###: \n".concat(this.msg.prompt_html_title, "\n\n-Saida esperada: \n").concat(this.msg.prompt_html_output, "\n\n-Source: ").concat(source, "\n .");
      return prompt;
    };
    AimActionAddIca2.prototype.getPromptCheckPrompt = function(promptUser) {
      var prompt = "\n        ### system ### \nAnalise o prompt do usu\uFFFDrio e retorne:\n\n- 'sim' se o prompt estiver dentro do contexto, e for suficiente para a pr\uFFFDxima etapa.\n- 'n\uFFFDo' se o prompt for para qualquer outra coisa que n\uFFFDo for a gera\uFFFD\uFFFDo de um web component.\n- 'forne\uFFFDa mais informa\uFFFD\uFFFDes' se o prompt estiver dentro do contexto e precisar de mais informa\uFFFD\uFFFDes importantes neste primeiro passo.\n\ncontexto: Todos os web components devem ser desenvolvidos utilizando TypeScript e Lit 3. Os componentes ser\uFFFDo usados em navegadores modernos, e nesta etapa focaremos apenas no corpo principal do TypeScript, sem CSS.\n\ncondi\uFFFD\uFFFDo especial: Ap\uFFFDs retornar 'forne\uFFFDa mais informa\uFFFD\uFFFDes', gere uma lista de 1 a 3 itens das informa\uFFFD\uFFFDes necess\uFFFDrias para o contexto.\n\nAo adotar esta descri\uFFFD\uFFFDo de contexto, qualquer usu\uFFFDrio que interaja com o sistema j\uFFFD estar\uFFFD ciente de que o desenvolvimento deve ser feito usando TypeScript e Lit 3, e poder\uFFFD se concentrar em especificar outros aspectos do web component que est\uFFFD sendo proposto. Isso simplifica a intera\uFFFD\uFFFDo do usu\uFFFDrio com o sistema e permite um foco maior nos detalhes funcionais e t\uFFFDcnicos espec\uFFFDficos de cada componente.\nN\uFFFDo retorne explica\uFFFD\uFFFDes ou coment\uFFFDrios , somente 'sim' ou 'n\uFFFDo' ou 'forne\uFFFDa mais informa\uFFFD\uFFFDes' (com uma lista complementar) \n\n### user ###\n".concat(promptUser, "\n ");
      return prompt;
    };
    var _a, _b;
    __decorate([
      query("textarea"),
      __metadata("design:type", typeof (_a = typeof HTMLTextAreaElement !== "undefined" && HTMLTextAreaElement) === "function" ? _a : Object)
    ], AimActionAddIca2.prototype, "textarea", void 0);
    __decorate([
      query("ica-select-group-100554"),
      __metadata("design:type", typeof (_b = typeof IcaSelectGroup !== "undefined" && IcaSelectGroup) === "function" ? _b : Object)
    ], AimActionAddIca2.prototype, "selectGroup", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Boolean)
    ], AimActionAddIca2.prototype, "showPrompt", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], AimActionAddIca2.prototype, "actualSuggest", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", Boolean)
    ], AimActionAddIca2.prototype, "validPrompt", void 0);
    __decorate([
      property({ type: Array }),
      __metadata("design:type", Array)
    ], AimActionAddIca2.prototype, "actualAttributes", void 0);
    AimActionAddIca2 = __decorate([
      customElement("aim-action-add-ica-100554"),
      __metadata("design:paramtypes", [])
    ], AimActionAddIca2);
    return AimActionAddIca2;
  }(AimActionBase)
);
function isValidRef(taskRoot, activeOpService) {
  var actualRef = activeOpService.getActualRef();
  var taskWithRef = taskRoot.children.find(function(task) {
    return task.widget === "aimTaskPrepareIcaSource";
  });
  if (!taskWithRef)
    return false;
  return taskWithRef.ref === actualRef;
}
function getActiveOpServiceIfIsValid(el) {
  var info = getInfoMyService(el);
  if (!info)
    return void 0;
  var activeServiceOp = info.actServiceOp;
  if (activeServiceOp.tagName !== "SERVICE-SOURCE-100554")
    return void 0;
  return activeServiceOp;
}
var templateObject_1, templateObject_2, templateObject_3, templateObject_4;
export {
  AimActionAddIca,
  getActiveOpServiceIfIsValid,
  isValidRef
};
