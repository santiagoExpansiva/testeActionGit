var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var __asyncValues = function(o) {
  if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
  var m = o[Symbol.asyncIterator], i;
  return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
    return this;
  }, i);
  function verb(n) {
    i[n] = o[n] && function(v) {
      return new Promise(function(resolve, reject) {
        v = o[n](v), settle(resolve, reject, v.done, v.value);
      });
    };
  }
  function settle(resolve, reject, d, v) {
    Promise.resolve(v).then(function(v2) {
      resolve({ value: v2, done: d });
    }, reject);
  }
};
function readAllProjectAndCompile(project_1, shortName_1) {
  return __awaiter(this, arguments, Promise, function(project, shortName, needCompile) {
    if (needCompile === void 0) {
      needCompile = true;
    }
    return __generator(this, function(_a) {
      return [2, _readAllProjectAndCompile(project, shortName, needCompile)];
    });
  });
}
function getStorFile(file) {
  return _getStorFile(file);
}
function createModel(storFile, compile) {
  return __awaiter(this, void 0, Promise, function() {
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          return [4, _createModel(storFile, compile)];
        case 1:
          return [2, _a.sent()];
      }
    });
  });
}
function createNewFileWithModel(src, file) {
  return __awaiter(this, void 0, Promise, function() {
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          return [4, _createNewFileWithModel(src, file)];
        case 1:
          return [2, _a.sent()];
      }
    });
  });
}
function deleteFileWithModel(file) {
  return __awaiter(this, void 0, Promise, function() {
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          return [4, _deleteFileWithModel(file)];
        case 1:
          return [2, _a.sent()];
      }
    });
  });
}
function undoFileWithModel(file) {
  return __awaiter(this, void 0, Promise, function() {
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          return [4, _undoFileWithModel(file)];
        case 1:
          return [2, _a.sent()];
      }
    });
  });
}
function renameFileWithModel(file) {
  return __awaiter(this, void 0, Promise, function() {
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          return [4, _renameFileWithModel(file)];
        case 1:
          return [2, _a.sent()];
      }
    });
  });
}
function cloneFileWithModel(file) {
  return __awaiter(this, void 0, Promise, function() {
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          return [4, _cloneFileWithModel(file)];
        case 1:
          return [2, _a.sent()];
      }
    });
  });
}
function getUri(shortFN, ftype) {
  return monaco.Uri.parse("file://server/".concat(shortFN).concat(ftype));
}
function _readAllFileExtensionAndCompile(project_1, extension_1) {
  return __awaiter(this, arguments, Promise, function(project, extension, needCompile) {
    var keys, _a, keys_1, keys_1_1, key, storFile, e_1, e_2_1;
    var _b, e_2, _c, _d;
    if (needCompile === void 0) {
      needCompile = true;
    }
    return __generator(this, function(_e) {
      switch (_e.label) {
        case 0:
          if (mls.istrace)
            console.log("loading files from project " + project);
          keys = Object.keys(mls.stor.files);
          _e.label = 1;
        case 1:
          _e.trys.push([1, 9, 10, 15]);
          _a = true, keys_1 = __asyncValues(keys);
          _e.label = 2;
        case 2:
          return [4, keys_1.next()];
        case 3:
          if (!(keys_1_1 = _e.sent(), _b = keys_1_1.done, !_b)) return [3, 8];
          _d = keys_1_1.value;
          _a = false;
          key = _d;
          _e.label = 4;
        case 4:
          _e.trys.push([4, 6, , 7]);
          storFile = mls.stor.files[key];
          if (storFile.project === project && storFile.level === 2 && storFile.extension !== extension)
            return [3, 7];
          return [4, _createModel(storFile, false)];
        case 5:
          _e.sent();
          return [3, 7];
        case 6:
          e_1 = _e.sent();
          console.info("Error readAllFileExtensionAndCompile:" + key);
          return [3, 7];
        case 7:
          _a = true;
          return [3, 2];
        case 8:
          return [3, 15];
        case 9:
          e_2_1 = _e.sent();
          e_2 = { error: e_2_1 };
          return [3, 15];
        case 10:
          _e.trys.push([10, , 13, 14]);
          if (!(!_a && !_b && (_c = keys_1.return))) return [3, 12];
          return [4, _c.call(keys_1)];
        case 11:
          _e.sent();
          _e.label = 12;
        case 12:
          return [3, 14];
        case 13:
          if (e_2) throw e_2.error;
          return [
            7
            /*endfinally*/
          ];
        case 14:
          return [
            7
            /*endfinally*/
          ];
        case 15:
          if (!needCompile) return [3, 17];
          return [4, mls.l2.editor.compileAllProjectIfNeed(project, true)];
        case 16:
          _e.sent();
          _e.label = 17;
        case 17:
          return [
            2
            /*return*/
          ];
      }
    });
  });
}
var projectsLoaded = [];
function _readAllProjectAndCompile(project_1, shortName_1) {
  return __awaiter(this, arguments, Promise, function(project, shortName, needCompile) {
    var promises, keys, _i, keys_2, key, storFile;
    if (needCompile === void 0) {
      needCompile = true;
    }
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          if (projectsLoaded.includes(project))
            return [
              2
              /*return*/
            ];
          if (mls.istrace)
            console.log("loading files from project " + project);
          projectsLoaded.push(project);
          promises = [];
          keys = Object.keys(mls.stor.files);
          for (_i = 0, keys_2 = keys; _i < keys_2.length; _i++) {
            key = keys_2[_i];
            storFile = mls.stor.files[key];
            if (storFile.project === project && storFile.level === 2 && storFile.shortName !== shortName) {
              promises.push(_createModel(storFile, false));
            }
          }
          return [4, Promise.all(promises)];
        case 1:
          _a.sent();
          if (!needCompile) return [3, 3];
          return [4, mls.l2.editor.compileAllProjectIfNeed(project, true)];
        case 2:
          _a.sent();
          _a.label = 3;
        case 3:
          return [
            2
            /*return*/
          ];
      }
    });
  });
}
var code = {
  ".ts": "typescript",
  ".html": "html"
};
var baseSrc = {
  ".ts": '/// <mls shortName="[shortName]" project="[project]" enhancement="[enhancement]" />\n				\n// typescript new file\n',
  ".html": "<fca-text>Edit this.</fca-text>"
};
function _getStorFile(file) {
  var keyFiles = mls.stor.getKeyToFiles(file.project, file.level, file.shortName, file.folder, file.extension);
  var storFile = mls.stor.files[keyFiles];
  if (!storFile)
    throw new Error("Error on getStorFile, mls.stor.files dont exists, key:" + keyFiles);
  return storFile;
}
;
function _createNewFileWithModel(src, file) {
  return __awaiter(this, void 0, Promise, function() {
    var newSource, model;
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          newSource = src;
          if (!newSource && file.extension === ".ts") {
            newSource = baseSrc[file.extension].replace("[shortName]", file.shortName).replace("[project]", file.project.toString()).replace("[enhancement]", file.enhancement);
          } else if (!newSource) {
            newSource = baseSrc[file.extension];
          }
          return [4, createFileAndModel(newSource, file)];
        case 1:
          model = _a.sent();
          return [2, model];
      }
    });
  });
}
;
function _deleteFileWithModel(file) {
  return __awaiter(this, void 0, Promise, function() {
    var storFile;
    return __generator(this, function(_a) {
      storFile = _getStorFile(file);
      if (storFile.status === "new") {
        fcDeleteFile(storFile);
      } else
        storFile.status = "deleted";
      return [
        2
        /*return*/
      ];
    });
  });
}
;
function _undoFileWithModel(file) {
  return __awaiter(this, void 0, Promise, function() {
    var storFile, keyFiles;
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          storFile = _getStorFile(file);
          if (storFile.status === "deleted") {
            storFile.status = "changed";
            return [
              2
              /*return*/
            ];
          }
          if (storFile.status === "renamed") {
            throw new Error("not implemented");
          }
          mls.l2.editor.remove(storFile);
          removeEventsModel(storFile);
          keyFiles = mls.stor.getKeyToFiles(file.project, file.level, file.shortName, file.folder, file.extension);
          return [4, mls.stor.localStor.setContent(storFile, { contentType: "string", content: null })];
        case 1:
          _a.sent();
          if (storFile.status === "new") {
            delete mls.stor.files[keyFiles];
            return [
              2
              /*return*/
            ];
          }
          if (storFile.status === "changed") {
            storFile.status = "nochange";
            if (storFile.isLocalVersionOutdated && storFile.newVersionRefIfOutdated) {
              storFile.versionRef = storFile.newVersionRefIfOutdated;
              storFile.isLocalVersionOutdated = false;
              storFile.newVersionRefIfOutdated = void 0;
            }
          } else {
            storFile.status = "changed";
          }
          return [4, createModel(storFile, true)];
        case 2:
          _a.sent();
          return [
            2
            /*return*/
          ];
      }
    });
  });
}
;
function _renameFileWithModel(file) {
  return __awaiter(this, void 0, Promise, function() {
    var storFile, aux, model1;
    return __generator(this, function(_a) {
      storFile = _getStorFile(file);
      aux = storFile.extension === ".ts" ? "" : storFile.extension;
      model1 = mls.l2.editor.get({ project: storFile.project, shortName: storFile.shortName + aux });
      if (!model1)
        throw new Error("Error renameFile: not found mfile");
      renameFileWithModel2(model1, storFile, file.newProject, file.newShortName);
      return [
        2
        /*return*/
      ];
    });
  });
}
;
function _cloneFileWithModel(file) {
  return __awaiter(this, void 0, Promise, function() {
    var storFile, aux, model1, src, newFile;
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          storFile = _getStorFile(file);
          aux = storFile.extension === ".ts" ? "" : storFile.extension;
          model1 = mls.l2.editor.get({ project: storFile.project, shortName: storFile.shortName + aux });
          if (!model1)
            throw new Error("Error cloneFile, not found mfile");
          src = model1.model.getValue();
          newFile = {
            project: file.newProject,
            shortName: file.newShortName,
            enhancement: file.enhancement,
            extension: file.extension,
            level: file.level,
            folder: file.folder
          };
          return [4, _createNewFileWithModel(src, newFile)];
        case 1:
          model1 = _a.sent();
          mls.common.tripleslash.changeVariable(model1, "shortName", file.newShortName);
          mls.common.tripleslash.changeVariable(model1, "project", file.newProject.toString());
          return [
            2
            /*return*/
          ];
      }
    });
  });
}
;
function renameFileWithModel2(model1, storFile, newProject, newShortName) {
  if (storFile.hasError)
    throw new Error("Error on rename, clear errors before rename");
  if (!isNewNameValid(newShortName))
    throw new Error("Error on rename, new shortName is a invalid name");
  var newFile = { shortName: newShortName, project: newProject };
  if (!mls.l2.editor.rename(model1, newFile))
    throw new Error("Error on rename mls.l2.editor.mfiles");
  if (!mls.stor.renameFile(storFile, newFile))
    throw new Error("Error on rename mls.stor.files");
  mls.common.tripleslash.changeVariable(model1, "shortName", newShortName);
  mls.common.tripleslash.changeVariable(model1, "project", newProject.toString());
  if (storFile.status === "new")
    return;
  storFile.status = "renamed";
}
function createFileAndModel(src, file) {
  return __awaiter(this, void 0, Promise, function() {
    var level, key, storFile, aux, model1, srcModel, _a, ftype, uri, model;
    return __generator(this, function(_b) {
      switch (_b.label) {
        case 0:
          level = 2;
          if (!(file.project > 1)) return [3, 2];
          return [4, mls.stor.server.loadProjectInfoIfNeeded(file.project)];
        case 1:
          _b.sent();
          _b.label = 2;
        case 2:
          key = mls.stor.getKeyToFiles(file.project, level, file.shortName, "", file.extension);
          storFile = mls.stor.files[key];
          if (storFile && file.project !== 0)
            throw new Error("Error on createFileAndModel, model already exists: " + key);
          if (!!storFile) return [3, 4];
          return [4, mls.stor.addOrUpdateFile({ project: file.project, level, shortName: file.shortName, extension: file.extension, versionRef: (/* @__PURE__ */ new Date()).toISOString(), folder: "" })];
        case 3:
          storFile = _b.sent();
          storFile.status = "new";
          _b.label = 4;
        case 4:
          aux = file.extension === ".ts" ? "" : file.extension;
          model1 = mls.l2.editor.get({ project: file.project, shortName: file.shortName + aux });
          if (!!model1) return [3, 8];
          if (!storFile) return [3, 6];
          return [4, storFile.getContent(src)];
        case 5:
          _a = _b.sent() || src;
          return [3, 7];
        case 6:
          _a = src;
          _b.label = 7;
        case 7:
          srcModel = _a;
          ftype = srcModel.split("\n")[0].indexOf(' type="definition"') > 0 ? ".d.ts" : file.extension;
          uri = getUri("_".concat(file.project, "_").concat(file.shortName), ftype);
          model1 = mls.l2.editor.get({ project: file.project, shortName: file.shortName + aux });
          if (model1)
            return [2, model1];
          model = monaco.editor.createModel(src, code[storFile.extension], uri);
          model1 = {
            changed: true,
            error: false,
            project: file.project,
            shortName: file.shortName + aux,
            extension: file.extension,
            model,
            storFile,
            codeLens: []
          };
          mls.l2.editor.add(model1);
          addEventsModel(storFile, model1);
          _b.label = 8;
        case 8:
          if (!(storFile.extension === ".ts")) return [3, 10];
          return [4, updateModelStatus(model1, false)];
        case 9:
          _b.sent();
          _b.label = 10;
        case 10:
          return [2, model1];
      }
    });
  });
}
function _createModel(storFile, compile) {
  return __awaiter(this, void 0, Promise, function() {
    var project, shortName, extension, aux, model1, info, _a, haveInfo, src, _b, originalCRC, originalProject, originalShortName, ftype, uri, model;
    return __generator(this, function(_c) {
      switch (_c.label) {
        case 0:
          project = storFile.project, shortName = storFile.shortName, extension = storFile.extension;
          aux = storFile.extension === ".ts" ? "" : storFile.extension;
          model1 = mls.l2.editor.get({ project: storFile.project, shortName: storFile.shortName + aux });
          if (model1)
            return [2, model1];
          if (!storFile.getValueInfo) return [3, 2];
          return [4, storFile.getValueInfo()];
        case 1:
          _a = _c.sent();
          return [3, 3];
        case 2:
          _a = null;
          _c.label = 3;
        case 3:
          info = _a;
          haveInfo = info && !!info.content || info !== null && !!info.content;
          if (!(haveInfo && info !== null)) return [3, 4];
          _b = info.content;
          return [3, 6];
        case 4:
          return [4, storFile.getContent()];
        case 5:
          _b = _c.sent();
          _c.label = 6;
        case 6:
          src = _b;
          if (src instanceof Blob || src === null)
            throw new Error("ts file must be string");
          originalCRC = haveInfo && info !== null ? info.originalCRC : mls.common.crc.crc32(src).toString(16);
          originalProject = haveInfo && info !== null ? info.originalProject : void 0;
          originalShortName = haveInfo && info !== null ? info.originalShortName : void 0;
          ftype = src.split("\n")[0].indexOf(' type="definition"') > 0 ? ".d.ts" : storFile.extension;
          uri = getUri("_".concat(project, "_").concat(shortName), ftype);
          model = monaco.editor.createModel(src, code[storFile.extension], uri);
          model1 = {
            changed: false,
            // not changed in this section, but storFile.changed is about all sections
            error: false,
            project,
            shortName: shortName + aux,
            extension,
            model,
            storFile,
            originalCRC,
            originalProject,
            originalShortName,
            codeLens: []
          };
          mls.l2.editor.add(model1);
          addEventsModel(storFile, model1);
          if (!(compile && storFile.extension === ".ts")) return [3, 8];
          return [4, updateModelStatus(model1, false)];
        case 7:
          _c.sent();
          _c.label = 8;
        case 8:
          return [2, model1];
      }
    });
  });
}
function addEventsModel(storFile, model1) {
  storFile.onAction = function(action) {
    return afterUpdate(storFile);
  };
  storFile.getValueInfo = function() {
    return getValueInfo(model1);
  };
  model1.model.onDidChangeContent(function(e) {
    return onModelChange(e, model1, storFile);
  });
}
function isNewNameValid(newShortName) {
  if (newShortName.length === 0 || newShortName.length > 255)
    return false;
  var invalidCharacters = /[_\/{}\t\[\]\*$@#=\-+!|?,<>=.;^~��""''``�������������������������������]/;
  return !invalidCharacters.test(newShortName);
}
function afterUpdate(storFile) {
  return __awaiter(this, void 0, void 0, function() {
    var project, shortName, aux, mmodel;
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          project = storFile.project, shortName = storFile.shortName;
          shortName = storFile.extension !== ".ts" ? shortName + storFile.extension : shortName;
          if (!project || !shortName)
            return [
              2
              /*return*/
            ];
          aux = storFile.extension === ".ts" ? "" : storFile.extension;
          mmodel = mls.l2.editor.get({ project: storFile.project, shortName: storFile.shortName + aux });
          if (!mmodel)
            return [
              2
              /*return*/
            ];
          if (storFile.status === "deleted") {
            fcDeleteFile(storFile);
            return [
              2
              /*return*/
            ];
          }
          if (storFile.status === "renamed") {
            mmodel.originalProject = void 0;
            mmodel.originalShortName = void 0;
            mmodel.originalCRC = mls.common.crc.crc32(mmodel.model.getValue()).toString(16);
          }
          return [4, mls.stor.localStor.setContent(storFile, { contentType: "string", content: null })];
        case 1:
          _a.sent();
          storFile.status = "nochange";
          return [
            2
            /*return*/
          ];
      }
    });
  });
}
function getValueInfo(activeModel) {
  return __awaiter(this, void 0, Promise, function() {
    var rc;
    return __generator(this, function(_a) {
      rc = {
        content: activeModel.model.getValue(),
        contentType: "string",
        originalShortName: activeModel.originalShortName,
        originalProject: activeModel.originalProject,
        originalCRC: activeModel.originalCRC
      };
      return [2, rc];
    });
  });
}
var _onChangedContent = -1;
function onModelChange(e, activeModel, storFile) {
  var _this = this;
  clearTimeout(_onChangedContent);
  _onChangedContent = window.setTimeout(function() {
    return __awaiter(_this, void 0, void 0, function() {
      var ignoreChanges;
      return __generator(this, function(_a) {
        switch (_a.label) {
          case 0:
            if (!(storFile.extension === ".ts")) return [3, 2];
            return [4, updateModelStatus(activeModel, true)];
          case 1:
            _a.sent();
            ignoreChanges = e.changes.length === 1 && e.changes[0].range.startLineNumber === 1 && e.changes[0].range.endLineNumber === 1 && e.changes[0].range.endColumn <= 2;
            if (ignoreChanges)
              return [
                2
                /*return*/
              ];
            return [3, 4];
          case 2:
            return [4, changeStatusFile(activeModel, storFile, {}, false)];
          case 3:
            _a.sent();
            _a.label = 4;
          case 4:
            return [
              2
              /*return*/
            ];
        }
      });
    });
  }, 400);
}
;
function updateModelStatus(model1, changed) {
  return __awaiter(this, void 0, Promise, function() {
    var cr, hasError, key, storFile, enhancementInstance;
    var _a;
    return __generator(this, function(_b) {
      switch (_b.label) {
        case 0:
          if (model1.project === 0)
            changed = true;
          model1.changed = changed;
          return [4, mls.l2.editor.getCompilerResultTS({ project: model1.project, shortName: model1.shortName }, true)];
        case 1:
          cr = _b.sent();
          hasError = cr.errors.length > 0;
          model1.error = hasError;
          key = mls.stor.getKeyToFiles(model1.project, model1.storFile.level, model1.shortName, "", model1.extension);
          storFile = mls.stor.files[key];
          if (!!hasError) return [3, 5];
          return [4, mls.l2.enhancement.getEnhancementInstance(model1).catch(function(e) {
            return void 0;
          })];
        case 2:
          enhancementInstance = _b.sent();
          if (!enhancementInstance) return [3, 4];
          return [4, enhancementInstance.onAfterChange(model1)];
        case 3:
          _b.sent();
          _b.label = 4;
        case 4:
          hasError = storFile.hasError;
          _b.label = 5;
        case 5:
          return [4, changeStatusFile(model1, storFile, (_a = cr.tripleSlashMLS) === null || _a === void 0 ? void 0 : _a.variables, hasError)];
        case 6:
          _b.sent();
          return [
            2
            /*return*/
          ];
      }
    });
  });
}
function changeStatusFile(model1, storFile, variables, hasError) {
  return __awaiter(this, void 0, Promise, function() {
    var oldStatus, sameContent, _a, _b, _c;
    return __generator(this, function(_d) {
      switch (_d.label) {
        case 0:
          if (!storFile)
            return [
              2
              /*return*/
            ];
          oldStatus = storFile.status;
          storFile.hasError = hasError;
          sameContent = model1.originalCRC === mls.common.crc.crc32(model1.model.getValue()).toString(16);
          if (!sameContent) return [3, 2];
          if (storFile.status !== "new")
            storFile.status = "nochange";
          return [4, mls.stor.localStor.setContent(storFile, { content: null })];
        case 1:
          _d.sent();
          return [3, 5];
        case 2:
          if (storFile.status !== "renamed" && storFile.status !== "new")
            storFile.status = "changed";
          _b = (_a = mls.stor.localStor).setContent;
          _c = [storFile];
          return [4, getValueInfo(model1)];
        case 3:
          return [4, _b.apply(_a, _c.concat([_d.sent()]))];
        case 4:
          _d.sent();
          _d.label = 5;
        case 5:
          if (oldStatus !== storFile.status) {
            mls.events.fireFileAction("statusOrErrorChanged", storFile, "left");
            mls.events.fireFileAction("statusOrErrorChanged", storFile, "right");
          }
          return [
            2
            /*return*/
          ];
      }
    });
  });
}
function fcDeleteFile(storFile) {
  return __awaiter(this, void 0, void 0, function() {
    var aux, key, keyFiles;
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          return [4, mls.stor.localStor.setContent(storFile, { contentType: "string", content: null })];
        case 1:
          _a.sent();
          aux = storFile.extension === ".ts" ? "" : storFile.extension;
          key = "_".concat(storFile.project, "_").concat(storFile.shortName + aux);
          if (mls.l2.editor.mfiles[key]) {
            if (mls.l2.editor.mfiles[key].model)
              mls.l2.editor.mfiles[key].model.dispose();
            delete mls.l2.editor.mfiles[key];
          }
          removeEventsModel(storFile);
          keyFiles = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, storFile.extension);
          delete mls.stor.files[keyFiles];
          return [
            2
            /*return*/
          ];
      }
    });
  });
}
function removeEventsModel(storFile) {
  storFile.onAction = void 0;
  storFile.getValueInfo = void 0;
}
export {
  cloneFileWithModel,
  createModel,
  createNewFileWithModel,
  deleteFileWithModel,
  getStorFile,
  readAllProjectAndCompile,
  renameFileWithModel,
  undoFileWithModel
};
