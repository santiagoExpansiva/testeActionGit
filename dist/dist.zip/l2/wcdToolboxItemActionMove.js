var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement } from "lit";
import { customElement } from "lit/decorators.js";
var WCDToolboxItemActionMove = (
  /** @class */
  function(_super) {
    __extends(WCDToolboxItemActionMove2, _super);
    function WCDToolboxItemActionMove2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    WCDToolboxItemActionMove2.prototype.createRenderRoot = function() {
      return this;
    };
    WCDToolboxItemActionMove2.prototype.render = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject([""], [""])));
    };
    WCDToolboxItemActionMove2.prototype.updated = function(changedProperties) {
      var _this = this;
      _super.prototype.updated.call(this, changedProperties);
      this.onclick = function(event) {
        _this.initClick(event);
      };
    };
    WCDToolboxItemActionMove2.prototype.beforeRemove = function() {
      var _this = this;
      if (!this.myElements)
        return;
      document.body.onmouseup = function() {
      };
      this.myElements.forEach(function(i) {
        _this.changeStateDrop(i);
      });
    };
    WCDToolboxItemActionMove2.prototype.clearDrag = function() {
      var _this = this;
      if (!this.myElements)
        return;
      this.myElements.forEach(function(i) {
        _this.changeStateDrop(i);
      });
    };
    WCDToolboxItemActionMove2.prototype.stopDragging = function(e) {
      var _this = this;
      try {
        e.stopPropagation();
        if (!this.myParent || !this.elFCA)
          return;
        var myGrandFather = this.myParent.parentElement;
        document.body.style.cursor = "";
        var aux = this.getAux(e.target);
        if (!aux || !aux.elBase) {
          this.clearDrag();
          return;
        }
        var elBase = aux.elBase;
        var oldParent = myGrandFather.getIcaParent(this.elFCA);
        var newParent = myGrandFather.getIcaParent(elBase);
        var father = elBase.parentElement;
        father = father ? father : document.body;
        var move = aux.tagName.toLocaleLowerCase();
        var newEl_1 = this.elFCA.cloneNode(true);
        switch (move) {
          case "wcd-dragdrop-aux-before":
            father.insertBefore(newEl_1, elBase);
            this.elFCA.remove();
            break;
          case "wcd-dragdrop-aux-after":
            father.insertBefore(newEl_1, elBase.nextSibling);
            this.elFCA.remove();
            break;
          case "wcd-dragdrop-aux-in":
            var elIn = elBase.querySelector(elBase.widget);
            if (elIn)
              elIn.appendChild(this.elFCA);
            break;
          default:
            "";
        }
        newEl_1.setAttribute("rendertype", "edit");
        setTimeout(function() {
          newEl_1.click();
        }, 100);
        setTimeout(function() {
          if (_this.myParent)
            mls.events.fire(+_this.myParent.level, "WCDEventChange", '{"op":"Navigation"}');
        }, 500);
        this.clearDrag();
      } catch (err) {
        this.clearDrag();
      }
    };
    WCDToolboxItemActionMove2.prototype.getAux = function(el) {
      if (el.tagName.toLocaleLowerCase().startsWith("wcd-dragdrop-aux-")) {
        return el;
      }
      var parent = el.parentElement;
      if (!parent)
        return;
      var tag = parent.tagName.toLowerCase();
      if (tag.startsWith("wcd-dragdrop-aux-")) {
        return parent;
      }
      return this.getAux(parent);
    };
    WCDToolboxItemActionMove2.prototype.initClick = function(e) {
      var _this = this;
      if (!this.elMain || !this.elFCA || !this.myParent || !document.defaultView)
        return;
      var myGrandFather = this.myParent.parentElement;
      var scope = myGrandFather.getMyScope();
      if (!scope)
        return;
      this.myElements = myGrandFather.getICAComponents(scope);
      this.myElements = this.onlyNeedAddTag(this.myElements);
      this.myElements.forEach(function(i) {
        _this.changeStateDrag(i, scope, myGrandFather);
      });
      if (!this.myParent.shadowRoot)
        return;
      Array.from(this.myParent.shadowRoot.children).forEach(function(i) {
        var tag = i.tagName.toLocaleLowerCase();
        if (tag !== "wcd-toolbox-item-action-move-100554")
          i.remove();
      });
    };
    WCDToolboxItemActionMove2.prototype.onlyNeedAddTag = function(array) {
      var a = [];
      for (var i = 0; i <= array.length; i++) {
        var elBase = array[i];
        var next = array[i + 1];
        if (!next) {
          a.push(elBase);
          continue;
        }
        var parent = next.getIcaParent(next);
        if (!parent && (!next.parentElement || next.parentElement.tagName !== "BODY"))
          continue;
        if (next.parentElement && next.parentElement.tagName === "BODY")
          a.push(elBase);
        else if (parent !== elBase)
          a.push(elBase);
      }
      return a;
    };
    WCDToolboxItemActionMove2.prototype.changeStateDrag = function(elBase, elScope, elMove) {
      var _this = this;
      if (!elBase)
        return;
      if (elBase.getAttribute("renderType") === "editactive" || !this.myParent)
        return;
      var valid = elBase.allowCommand("move", elScope, elMove);
      if (!valid.before && !valid.after && !valid.inside)
        return;
      var content = document.createElement("wcd-dragdrop-aux");
      content.style.position = "absolute";
      content.style.display = "flex";
      content.style.gap = "1rem";
      content.style.justifyContent = "center";
      content.style.alignItems = "center";
      content.style.background = "#0c66e461";
      var before = document.createElement("wcd-dragdrop-aux-before");
      var after = document.createElement("wcd-dragdrop-aux-after");
      var inn = document.createElement("wcd-dragdrop-aux-in");
      before.onclick = function(e) {
        return _this.stopDragging(e);
      };
      after.onclick = function(e) {
        return _this.stopDragging(e);
      };
      inn.onclick = function(e) {
        return _this.stopDragging(e);
      };
      before.elBase = elBase;
      after.elBase = elBase;
      inn.elBase = elBase;
      var cssItens = "width:18px; height:18px; border-radius:50%;box-shadow: 0 0 4px 1px rgba(57,76,96,.15), 0 0 0 1px rgba(43,59,74,.3); background:#fff; display:flex;justify-content:center; align-items: center; cursor:pointer ";
      before.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 384 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M214.6 41.4c-12.5-12.5-32.8-12.5-45.3 0l-160 160c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L160 141.2V448c0 17.7 14.3 32 32 32s32-14.3 32-32V141.2L329.4 246.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3l-160-160z"/></svg>';
      before.title = "Before";
      before.style.cssText = cssItens;
      after.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 384 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M169.4 470.6c12.5 12.5 32.8 12.5 45.3 0l160-160c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 370.8 224 64c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 306.7L54.6 265.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l160 160z"/></svg>';
      after.title = "after";
      after.style.cssText = cssItens;
      inn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 384 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M32 64C14.3 64 0 49.7 0 32S14.3 0 32 0l96 0c53 0 96 43 96 96l0 306.7 73.4-73.4c12.5-12.5 32.8-12.5 45.3 0s12.5 32.8 0 45.3l-128 128c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 402.7 160 96c0-17.7-14.3-32-32-32L32 64z"/></svg>';
      inn.title = "in";
      inn.style.cssText = cssItens;
      if (valid.before)
        content.appendChild(before);
      if (valid.after)
        content.appendChild(after);
      if (valid.inside)
        content.appendChild(inn);
      elBase.style.position = "relative";
      this.myParent.updateSize(elBase, content, true);
      elBase.appendChild(content);
    };
    WCDToolboxItemActionMove2.prototype.changeStateDrop = function(elBase) {
      if (!elBase)
        return;
      if (elBase.getAttribute("renderType") === "editactive")
        return;
      elBase.style.position = "";
      var content = elBase.querySelector(":scope > wcd-dragdrop-aux");
      if (!content)
        return;
      content.remove();
    };
    WCDToolboxItemActionMove2 = __decorate([
      customElement("wcd-toolbox-item-action-move-100554")
    ], WCDToolboxItemActionMove2);
    return WCDToolboxItemActionMove2;
  }(LitElement)
);
var getTemplate = function(mode, position) {
  if (mode === void 0) {
    mode = "";
  }
  if (position === void 0) {
    position = "";
  }
  var ret = templateActionMove.move;
  if (position !== "")
    ret.position = position;
  return ret;
};
var templateActionMove = {
  move: {
    position: "p-m2",
    tp: "action",
    format: "",
    title: "Move",
    iconSvg: '<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 512 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M278.6 9.4c-12.5-12.5-32.8-12.5-45.3 0l-64 64c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l9.4-9.4V224H109.3l9.4-9.4c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-64 64c-12.5 12.5-12.5 32.8 0 45.3l64 64c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3l-9.4-9.4H224V402.7l-9.4-9.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l64 64c12.5 12.5 32.8 12.5 45.3 0l64-64c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-9.4 9.4V288H402.7l-9.4 9.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l64-64c12.5-12.5 12.5-32.8 0-45.3l-64-64c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l9.4 9.4H288V109.3l9.4 9.4c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3l-64-64z"/></svg>',
    onclick: void 0,
    menuItens: [],
    menuSubItens: [],
    widget: "wcd-toolbox-item-action-move-100554",
    cursor: "pointer",
    attrs: void 0,
    isDblClick: false
  }
};
var templateObject_1;
export {
  WCDToolboxItemActionMove,
  getTemplate
};
