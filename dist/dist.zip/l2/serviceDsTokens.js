var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var __spreadArray = function(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};
import { html, css } from "lit";
import { customElement, query, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
var message_pt = {};
var message_en = {};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceDsTokens100554 = (
  /** @class */
  function(_super) {
    __extends(ServiceDsTokens1005542, _super);
    function ServiceDsTokens1005542() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.msize = "";
      _this.details = {
        icon: "&#xf0ae",
        state: "foreground",
        tooltip: "Tokens",
        visible: true,
        position: "left",
        tags: ["ds_tokens"],
        widget: "_100554_serviceDsTokens",
        level: [3]
      };
      _this.onClickLink = function(op) {
        if (op === "opTypography")
          return _this.showTypography();
        if (op === "opCustom")
          return _this.showCustom();
        if (op === "opColors")
          return _this.showColors();
        if (op === "opColors2")
          return _this.showColors2();
        if (op === "opEditor")
          return _this.showResume();
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.menu = {
        title: "Tokens",
        actions: {
          opColors: "Colors",
          opTypography: "Typography",
          opCustom: "Custom"
        },
        icons: {},
        actionDefault: "opColors2",
        // call after close icon clicked
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        getLastMode: void 0,
        updateTitle: void 0
      };
      _this.timeoutChangesEditorColor = 0;
      _this.timeoutChangesEditorTypography = 0;
      _this.timeoutChangesEditorCustom = 0;
      _this.models = {
        resume: {},
        color: {},
        custom: {},
        typography: {}
      };
      _this.lastLine = {
        resume: void 0,
        color: void 0,
        custom: void 0,
        typography: void 0
      };
      _this.tokensColors = [];
      _this.tokensTypo = [];
      _this.tokensCustom = [];
      _this.actualTypeTokens = "color";
      _this.lastLineColor = void 0;
      _this.isRightChange = false;
      _this.setEvents();
      return _this;
    }
    ServiceDsTokens100554_1 = ServiceDsTokens1005542;
    ServiceDsTokens1005542.prototype.createRenderRoot = function() {
      return this;
    };
    ServiceDsTokens1005542.prototype.onServiceClick = function(visible, reinit, el) {
      this._onServiceClick(visible, reinit, el);
    };
    ServiceDsTokens1005542.prototype._onServiceClick = function(visible, reinit, el) {
      return __awaiter(this, void 0, void 0, function() {
        var params, params;
        return __generator(this, function(_a2) {
          if (visible) {
            params = { isComponent: false, service: ["_100529_service_styles_preview"] };
            mls.events.fire([3], ["DSTokenSelected"], JSON.stringify(params), 1e3);
            if (el && typeof el.layout === "function")
              el.layout();
          } else {
            params = { isComponent: false, service: [] };
            mls.events.fire([3], ["DSTokenUnSelected"], JSON.stringify(params), 0);
          }
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServiceDsTokens1005542.prototype.firstUpdated = function(changedProperties) {
      _super.prototype.firstUpdated.call(this, changedProperties);
      this.createEditor();
    };
    ServiceDsTokens1005542.prototype.getActualRef = function() {
      return "_100554_serviceDsTokens_".concat(this.actualTypeTokens);
    };
    ServiceDsTokens1005542.prototype.setEditorSource = function(tokens, tokensType) {
      return __awaiter(this, void 0, void 0, function() {
        var model, fullRange, lines, operations;
        return __generator(this, function(_a2) {
          if (!this.models[tokensType])
            return [
              2
              /*return*/
            ];
          model = this.models[tokensType];
          fullRange = model.getFullModelRange();
          lines = tokens.trim().split("\n");
          operations = [{
            range: fullRange,
            text: "",
            forceMoveMarkers: true
          }, {
            range: { startLineNumber: 1, startColumn: 1 },
            text: lines.join("\n"),
            forceMoveMarkers: true
          }];
          model.pushEditOperations([], operations, function() {
            return [];
          });
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServiceDsTokens1005542.prototype.getEditorSource = function() {
      var _a2;
      var model = (_a2 = this._ed1) === null || _a2 === void 0 ? void 0 : _a2.getModel();
      var val = (model === null || model === void 0 ? void 0 : model.getValue()) || "";
      return val;
    };
    ServiceDsTokens1005542.prototype.setTokens = function() {
      return __awaiter(this, void 0, void 0, function() {
        var _a2, resumeTokens, tokensColors, tokensCustom, tokensTypo;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              return [4, this.getTokens()];
            case 1:
              _a2 = _b.sent(), resumeTokens = _a2.resumeTokens, tokensColors = _a2.tokensColors, tokensCustom = _a2.tokensCustom, tokensTypo = _a2.tokensTypo;
              this.setInitialModels(resumeTokens, "resume");
              this.setInitialModels(tokensColors, "color");
              this.setInitialModels(tokensCustom, "custom");
              this.setInitialModels(tokensTypo, "typography");
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsTokens1005542.prototype.getTokens = function() {
      return __awaiter(this, void 0, void 0, function() {
        var project, mode, dss, dsInfo, list, tokens, strColors, strTypo, strCustom, resumeTokens;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              project = mls.actual[5].project;
              mode = mls.actual[3].mode;
              if (project === void 0 || mode === void 0)
                throw new Error("No project or design system selected");
              dss = mls.l5.ds.list(project);
              dsInfo = dss[mode];
              if (!dsInfo)
                return [2, { tokensColors: "", tokensTypo: "", tokensCustom: "", resumeTokens: "" }];
              this.dsInstance = mls.l3.getDSInstance(project, mode);
              return [4, this.dsInstance.init()];
            case 1:
              _a2.sent();
              list = this.dsInstance.tokens.list;
              tokens = [];
              Object.keys(list).forEach(function(tok) {
                tokens.push(list[tok]);
              });
              this.tokensColors = tokens.filter(function(tok) {
                return tok.category === "color";
              });
              this.tokensTypo = tokens.filter(function(tok) {
                return tok.category === "typography";
              });
              this.tokensCustom = tokens.filter(function(tok) {
                return tok.category === "custom";
              });
              strColors = this.tokensColors.map(function(item) {
                return "@".concat(item.key, ": ").concat(item.value, ";");
              }).join("\n");
              strTypo = this.tokensTypo.map(function(item) {
                return "@".concat(item.key, ": ").concat(item.value, ";");
              }).join("\n");
              strCustom = this.tokensCustom.map(function(item) {
                return "@".concat(item.key, ": ").concat(item.value, ";");
              }).join("\n");
              resumeTokens = ["// Tokens Colors", strColors, "// Tokens Typography", strTypo, "//Tokens Custom", strCustom].join("\n");
              return [2, {
                tokensColors: strColors,
                tokensTypo: strTypo,
                tokensCustom: strCustom,
                resumeTokens
              }];
          }
        });
      });
    };
    ServiceDsTokens1005542.prototype.createEditor = function() {
      if (this.c2)
        this._ed1 = monaco.editor.create(this.c2, mls.editor.conf["tokens"]);
      this.c2["mlsEditor"] = this._ed1;
      if (this.serviceContent) {
        this.serviceContent.layout();
        this.setMsizeEditor();
      }
    };
    ServiceDsTokens1005542.prototype.getUri = function(shortFN) {
      ServiceDsTokens100554_1.modelCount = ServiceDsTokens100554_1.modelCount + 1 || 1;
      return monaco.Uri.parse("file://server/".concat(shortFN, "_").concat(ServiceDsTokens100554_1.modelCount, ".ts"));
    };
    ServiceDsTokens1005542.prototype.setInitialModels = function(src, model) {
      var uri = this.getUri("l3_tokens");
      this.models[model] = monaco.editor.getModel(uri);
      if (this.models[model])
        this.models[model].setValue(src);
      else
        this.models[model] = monaco.editor.createModel(src, "less", uri);
    };
    ServiceDsTokens1005542.prototype.showResume = function() {
      this.menu.title = "Tokens - Resume";
      if (this.menu.updateTitle)
        this.menu.updateTitle();
      this.showResume2();
      return true;
    };
    ServiceDsTokens1005542.prototype.showResume2 = function() {
      return __awaiter(this, void 0, void 0, function() {
        var resumeTokens;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              this.actualTypeTokens = "resume";
              return [4, this.getTokens()];
            case 1:
              resumeTokens = _a2.sent().resumeTokens;
              this.setInitialModels(resumeTokens, "resume");
              if (!this._ed1)
                return [2, true];
              this._ed1.setModel(this.models["resume"]);
              this._ed1.updateOptions({ readOnly: true });
              return [2, true];
          }
        });
      });
    };
    ServiceDsTokens1005542.prototype.showCustom = function() {
      var _this = this;
      var _a2;
      this.actualTypeTokens = "custom";
      if (this.menu.setMode)
        this.menu.setMode("editor");
      if (!this._ed1)
        return true;
      this._ed1.setModel(this.models["custom"]);
      this._ed1.updateOptions({ readOnly: false });
      mls.events.fire([this.level], ["DSCustomClicked"], "Custom Clicked");
      (_a2 = this._ed1.getModel()) === null || _a2 === void 0 ? void 0 : _a2.onDidChangeContent(function(event) {
        _this.timeoutChangesEditorCustom = setTimeout(function() {
          if (_this.timeoutChangesEditorCustom)
            clearTimeout(_this.timeoutChangesEditorCustom);
          _this.onEditorCustomChange(event.changes);
        }, 1e3);
      });
      return true;
    };
    ServiceDsTokens1005542.prototype.showTypography = function() {
      var _this = this;
      var _a2;
      this.actualTypeTokens = "typography";
      if (this.menu.setMode)
        this.menu.setMode("editor");
      if (!this._ed1)
        return true;
      this._ed1.setModel(this.models["typography"]);
      this._ed1.updateOptions({ readOnly: false });
      (_a2 = this._ed1.getModel()) === null || _a2 === void 0 ? void 0 : _a2.onDidChangeContent(function(event) {
        _this.timeoutChangesEditorTypography = setTimeout(function() {
          if (_this.timeoutChangesEditorTypography)
            clearTimeout(_this.timeoutChangesEditorTypography);
          _this.onEditorTypoChange(event.changes);
        }, 1e3);
      });
      return true;
    };
    ServiceDsTokens1005542.prototype.showColors = function() {
      if (this.menu.setMode)
        this.menu.setMode("initial");
      return this.showColors2();
    };
    ServiceDsTokens1005542.prototype.showColors2 = function() {
      var _this = this;
      this.actualTypeTokens = "color";
      this.setTokens().then(function() {
        var _a2;
        if (!_this._ed1)
          return true;
        _this._ed1.setModel(_this.models["color"]);
        _this._ed1.updateOptions({ readOnly: false });
        var rc = _this.getEditorJsonKeyValue("color");
        var params = {
          emitter: "left",
          value: "".concat(JSON.stringify(rc), ";").concat("", ";").concat(_this.isRightChange ? "refresh" : "editor")
        };
        mls.events.fire([_this.level], ["DSColorChanged"], JSON.stringify(params), 1e3);
        (_a2 = _this._ed1.getModel()) === null || _a2 === void 0 ? void 0 : _a2.onDidChangeContent(function(event) {
          _this.timeoutChangesEditorColor = setTimeout(function() {
            if (_this.timeoutChangesEditorColor)
              clearTimeout(_this.timeoutChangesEditorColor);
            _this.onEditorColorChange(event.changes);
          }, 500);
        });
        _this._ed1.onDidChangeCursorPosition(function(event) {
          _this.onEditorColorLineChange(event.position.lineNumber);
        });
      });
      return true;
    };
    ServiceDsTokens1005542.prototype.onEditorColorLineChange = function(line) {
      if (this.isRightChange) {
        this.isRightChange = false;
        return;
      }
      if (this.lastLine && this.lastLineColor !== line) {
        this.lastLineColor = line;
        if (!this._ed1)
          return;
        var model = this._ed1.getModel();
        if (!model)
          return;
        var lineKeyValue = this.convertTokenLineEditorToKeyValue(model.getLineContent(line));
        var params = {
          emitter: "left",
          value: "".concat(lineKeyValue.key, ";").concat("", ";line")
        };
        mls.events.fire([this.level], ["DSColorChanged"], JSON.stringify(params), 0);
      }
    };
    ServiceDsTokens1005542.prototype.onEditorColorChange = function(changes) {
      var _a2;
      var change = changes[0];
      if (!change)
        return;
      var lineChange = change.range.startLineNumber;
      if (!this._ed1)
        return;
      var model = this._ed1.getModel();
      if (!model)
        return;
      var lineKeyValue = this.convertTokenLineEditorToKeyValue(model.getLineContent(lineChange));
      var tokens = this.getEditorsTokens();
      var colorsTokens = tokens.filter(function(item) {
        return item.category === "color";
      });
      ((_a2 = this.dsInstance) === null || _a2 === void 0 ? void 0 : _a2.tokens)["setTokenList"](tokens);
      var params;
      if (this.isRightChange) {
        this.isRightChange = false;
        params = {
          emitter: "left",
          value: "".concat(JSON.stringify(colorsTokens), ";").concat("", ";refresh")
        };
      } else {
        params = {
          emitter: "left",
          value: "".concat(lineKeyValue.key || JSON.stringify(colorsTokens), ";").concat("", ";editor")
        };
      }
      mls.events.fire([this.level], ["DSColorChanged"], JSON.stringify(params));
    };
    ServiceDsTokens1005542.prototype.onEditorTypoChange = function(changes) {
      var _a2;
      var change = changes[0];
      if (!change)
        return;
      var tokens = this.getEditorsTokens();
      var typoTokens = tokens.filter(function(item) {
        return item.category === "typography";
      });
      ((_a2 = this.dsInstance) === null || _a2 === void 0 ? void 0 : _a2.tokens)["setTokenList"](tokens);
      var rc = this.getEditorJsonKeyValue("typography");
      var params = {
        emitter: "left",
        value: "".concat(JSON.stringify(rc), ";").concat("", ";").concat("editor")
      };
      mls.events.fire([this.level], ["DSTYPOChanged"], JSON.stringify(params), 1e3);
    };
    ServiceDsTokens1005542.prototype.onEditorCustomChange = function(changes) {
      var _a2;
      var change = changes[0];
      if (!change)
        return;
      var tokens = this.getEditorsTokens();
      var customTokens = tokens.filter(function(item) {
        return item.category === "custom";
      });
      ((_a2 = this.dsInstance) === null || _a2 === void 0 ? void 0 : _a2.tokens)["setTokenList"](tokens);
      var rc = this.getEditorJsonKeyValue("custom");
      var params = {
        emitter: "left",
        value: "".concat(JSON.stringify(rc), ";").concat("", ";").concat("editor")
      };
      mls.events.fire([this.level], ["DSCustomChanged"], JSON.stringify(params), 1e3);
    };
    ServiceDsTokens1005542.prototype.getEditorsTokens = function() {
      var rcT = this.getEditorJsonKeyValue("typography");
      var rcC = this.getEditorJsonKeyValue("color");
      var rcCustom = this.getEditorJsonKeyValue("custom");
      return __spreadArray(__spreadArray(__spreadArray([], rcC, true), rcT, true), rcCustom, true);
    };
    ServiceDsTokens1005542.prototype.editEditorByDSColorChanged = function(desc) {
      return __awaiter(this, void 0, void 0, function() {
        var params, _a2, key, value, mode, colorModel, allTokensColors, allTokens, tokensColors, line, _b, startLineNumber, startColumn, endLineNumber, lineLength, range, text;
        var _c, _d, _e;
        return __generator(this, function(_f) {
          switch (_f.label) {
            case 0:
              params = JSON.parse(desc);
              if (params.emitter !== "right")
                return [
                  2
                  /*return*/
                ];
              if (!this._ed1 || !this.dsInstance)
                return [
                  2
                  /*return*/
                ];
              _a2 = params.value.split(";"), key = _a2[0], value = _a2[1], mode = _a2[2];
              if (mode !== "helper" && mode !== "line")
                return [
                  2
                  /*return*/
                ];
              this.isRightChange = true;
              colorModel = this.models["color"];
              if (!key.startsWith("[")) return [3, 3];
              allTokensColors = JSON.parse(key);
              this.tokensColors = allTokensColors;
              allTokens = __spreadArray(__spreadArray(__spreadArray([], this.tokensColors, true), this.tokensTypo, true), this.tokensCustom, true);
              return [4, ((_c = this.dsInstance) === null || _c === void 0 ? void 0 : _c.tokens)["setTokenList"](allTokens)];
            case 1:
              _f.sent();
              return [4, this.getTokens()];
            case 2:
              tokensColors = _f.sent().tokensColors;
              colorModel.setValue(tokensColors);
              return [
                2
                /*return*/
              ];
            case 3:
              if (!(mode === "helper" && ((_d = this._ed1.getModel()) === null || _d === void 0 ? void 0 : _d.id) !== colorModel.id)) return [3, 5];
              return [4, this.dsInstance.tokens.update(key, value)];
            case 4:
              _f.sent();
              return [
                2
                /*return*/
              ];
            case 5:
              line = (_e = this._ed1.getModel()) === null || _e === void 0 ? void 0 : _e.findMatches("@".concat(key, ":"), true, false, false, null, true);
              if (!line || line.length === 0)
                return [
                  2
                  /*return*/
                ];
              _b = line[0].range, startLineNumber = _b.startLineNumber, startColumn = _b.startColumn, endLineNumber = _b.endLineNumber;
              lineLength = colorModel.getLineContent(startLineNumber).length + 1;
              range = new monaco.Range(startLineNumber, startColumn, endLineNumber, lineLength);
              text = value ? "@".concat(key, ": ").concat(value, ";") : null;
              if (mode === "helper" && !text) {
                this._ed1.executeEdits("", [{ range: new monaco.Range(range.startLineNumber, 1, range.startLineNumber + 1, 1), text }]);
                return [
                  2
                  /*return*/
                ];
              }
              if (mode === "helper")
                this._ed1.executeEdits("color", [{ range, text }]);
              if (this.lastLine["color"] === startLineNumber)
                return [
                  2
                  /*return*/
                ];
              this.lastLine["color"] = startLineNumber;
              this._ed1.setSelection(new monaco.Selection(range.startLineNumber, 0, range.startLineNumber, lineLength));
              this._ed1.revealLineInCenter(startLineNumber);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsTokens1005542.prototype.getEditorJsonKeyValue = function(model) {
      var _this = this;
      var editorValue = this.models[model].getValue().trim().split("\n");
      var rc = editorValue.map(function(line) {
        var obj = {};
        var _a2 = _this.convertTokenLineEditorToKeyValue(line), key = _a2.key, value = _a2.value;
        obj.key = key;
        obj.value = value;
        obj.category = model;
        return obj;
      }).filter(function(item) {
        return item.key !== void 0;
      });
      var filteredRc = rc.reduce(function(acc, current) {
        var x = acc.find(function(item) {
          return item.key === current.key;
        });
        return !x || !x.key || !x.value ? acc.concat([current]) : acc;
      }, []);
      return filteredRc;
    };
    ServiceDsTokens1005542.prototype.convertTokenLineEditorToKeyValue = function(content) {
      var rc = {};
      if (!content.startsWith("@") || !content.endsWith(";"))
        return rc;
      var _a2 = content.substring(1, content.length - 1).split(":"), key = _a2[0], value = _a2[1];
      rc.key = key.trim();
      rc.value = value.trim();
      return rc;
    };
    ServiceDsTokens1005542.prototype.setMsizeEditor = function() {
      var _a2;
      if (!this.visible)
        return;
      (_a2 = this.c2) === null || _a2 === void 0 ? void 0 : _a2.setAttribute("msize", this.msize);
    };
    ServiceDsTokens1005542.prototype.setEvents = function() {
      var _this = this;
      mls.events.addEventListener([3], ["DSColorChanged"], function(ev) {
        if (ev.desc)
          _this.editEditorByDSColorChanged(ev.desc);
      });
      mls.events.addEventListener([this.level], ["DSTYPOClicked"], function(ev) {
        if (ev.desc !== "right")
          return;
        _this.onClickLink("opTypography");
      });
      mls.events.addEventListener([this.level], ["DSColorClicked"], function(ev) {
        if (ev.desc !== "right")
          return;
        _this.onClickLink("opColors");
      });
    };
    ServiceDsTokens1005542.prototype.updated = function(changedProperties) {
      if (changedProperties.has("msize")) {
        if (!this.visible)
          return;
        this.setMsizeEditor();
      }
    };
    ServiceDsTokens1005542.prototype.render = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['<mls-editor-100529 ismls2="true"></mls-editor-100529>'], ['<mls-editor-100529 ismls2="true"></mls-editor-100529>'])));
    };
    var ServiceDsTokens100554_1;
    var _a;
    ServiceDsTokens1005542.styles = css(templateObject_2 || (templateObject_2 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property({ type: String }),
      __metadata("design:type", Object)
    ], ServiceDsTokens1005542.prototype, "msize", void 0);
    __decorate([
      query("mls-editor-100529"),
      __metadata("design:type", typeof (_a = typeof HTMLElement !== "undefined" && HTMLElement) === "function" ? _a : Object)
    ], ServiceDsTokens1005542.prototype, "c2", void 0);
    ServiceDsTokens1005542 = ServiceDsTokens100554_1 = __decorate([
      customElement("service-ds-tokens-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceDsTokens1005542);
    return ServiceDsTokens1005542;
  }(ServiceBase)
);
var templateObject_1, templateObject_2;
export {
  ServiceDsTokens100554
};
