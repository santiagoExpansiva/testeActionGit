var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { html, css } from "lit";
import { customElement, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
import { initServiceSelectDsAdd } from "./_100554_serviceSelectDsAdd";
import { collab_file, collab_undo, collab_location_dot, collab_unbalanced } from "./_100554_collabIcons";
var message_pt = {
  noDesignSystem: "Nenhum sistema de design neste projeto, por favor clique em adicionar para come\uFFFDar a criar um novo sistema de design.",
  addNew: "Adicionar novo sistema de design"
};
var message_en = {
  noDesignSystem: "No design system in this project, please click add to start a create a new design system.",
  addNew: "Add new design system "
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceSelectDs100554 = (
  /** @class */
  function(_super) {
    __extends(ServiceSelectDs1005542, _super);
    function ServiceSelectDs1005542() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.details = {
        icon: "&#xf15b",
        state: "foreground",
        tooltip: "Select Ds",
        visible: true,
        position: "left",
        widget: "_100554_serviceSelectDs",
        level: [3]
      };
      _this.onClickLink = function(op) {
        if (op === "opSelect")
          return _this.showHelper();
        if (op === "opAdd")
          return _this.showAdd();
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.menu = {
        title: "Select Design System",
        actions: {
          opAdd: "Add"
        },
        icons: {},
        actionDefault: "opSelect",
        // call after close icon clicked
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        getLastMode: void 0,
        updateTitle: void 0
      };
      _this.state = { history: [], actualProject: void 0, ds: [], dsSelected: void 0 };
      initServiceSelectDsAdd();
      _this.setEvents();
      return _this;
    }
    ServiceSelectDs1005542.prototype.onServiceClick = function(visible, reinit, el) {
      this._onServiceClick(visible, reinit, el);
    };
    ServiceSelectDs1005542.prototype._onServiceClick = function(visible, reinit, el) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServiceSelectDs1005542.prototype.showHelper = function() {
      return true;
    };
    ServiceSelectDs1005542.prototype.showAdd = function() {
      var sectionAdd = document.createElement("service-select-ds-add-100554");
      sectionAdd["service"] = this;
      if (this.menu.setMode)
        this.menu.setMode("page", sectionAdd);
      return true;
    };
    ServiceSelectDs1005542.prototype.setEvents = function() {
      var _this = this;
      mls.events.addEventListener([3], ["DSChanged"], function(ev) {
        _this.toogleBadge(true, "_100554_serviceSave");
      });
      mls.events.addEventListener([5], ["ProjectSelected"], function(ev) {
        if (!ev.desc)
          return;
        var data = JSON.parse(ev.desc);
        if (data.value) {
          _this.state.actualProject = data.value;
          _this.requestUpdate();
          setTimeout(function() {
            _this.fireOpenDetails();
          }, 1e3);
        }
      });
    };
    ServiceSelectDs1005542.prototype.init = function() {
      this.clearState();
      this.setProjectActual();
      if (!this.state.actualProject)
        return;
      this.getDs();
    };
    ServiceSelectDs1005542.prototype.clearState = function() {
      this.state.history = [];
      this.state.ds = [];
      this.state.actualProject = void 0;
      this.state.dsSelected = void 0;
    };
    ServiceSelectDs1005542.prototype.setProjectActual = function() {
      this.state.actualProject = mls.actual[5].project;
    };
    ServiceSelectDs1005542.prototype.checkIsALocalStorageChanges = function() {
      var haschangesLocal = false;
      Object.entries(mls.stor.files).forEach(function(entry) {
        var key = entry[0], item = entry[1];
        if (item.level === 3 && item.inLocalStorage)
          haschangesLocal = true;
      });
      return haschangesLocal;
    };
    ServiceSelectDs1005542.prototype.initDsSelected = function(dsindex) {
      return __awaiter(this, void 0, void 0, function() {
        var project, dsInstance;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              project = mls.actual[5].project;
              if (!project)
                return [
                  2
                  /*return*/
                ];
              dsInstance = mls.l3.getDSInstance(project, dsindex);
              return [4, dsInstance.init()];
            case 1:
              _a.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSelectDs1005542.prototype.getLastDsSelectedList = function() {
      var str = localStorage.getItem("collab-last-ds-selected");
      if (!str)
        return {};
      var obj = JSON.parse(str);
      return obj;
    };
    ServiceSelectDs1005542.prototype.getLastDsSelectedByProject = function(project) {
      if (!project)
        return void 0;
      var list = this.getLastDsSelectedList();
      return list[project] || void 0;
    };
    ServiceSelectDs1005542.prototype.setLastDsSelected = function(dsindex, project) {
      if (!dsindex || !project)
        return;
      var list = this.getLastDsSelectedList();
      list[project] = dsindex;
      localStorage.setItem("collab-last-ds-selected", JSON.stringify(list));
    };
    ServiceSelectDs1005542.prototype.getDs = function() {
      var _this = this;
      var project = mls.actual[5].project;
      if (!project)
        throw new Error("Please, select a project");
      var dsList = mls.l5.ds.list(project);
      dsList.forEach(function(ds) {
        var filesInDs = Object.entries(mls.stor.files).map(function(entry) {
          var key = entry[0], value = entry[1];
          if (key.startsWith("".concat(project, "_3_ds_").concat(ds.dsName)))
            return value;
        }).filter(function(value) {
          return value !== void 0;
        });
        var inLc = filesInDs.find(function(file) {
          return file.inLocalStorage === true;
        });
        var outdated = filesInDs.find(function(file) {
          return file.isLocalVersionOutdated === true && file.status !== "new";
        });
        var obj = {
          dsInfo: ds,
          inLocalStorage: !!inLc,
          outdated: !!outdated,
          files: filesInDs
        };
        _this.state.ds.push(obj);
      });
      this.state = this.state;
    };
    ServiceSelectDs1005542.prototype._fireEventDsSelected = function(dsindex) {
      var params = {
        emitter: "left",
        value: dsindex
      };
      mls.actual[3].mode = dsindex;
      mls.events.fire(3, ["DSSelected"], JSON.stringify(params), 500);
    };
    ServiceSelectDs1005542.prototype.openAdd = function() {
      if (this.menu.setMenuActive)
        this.menu.setMenuActive("opAdd");
    };
    ServiceSelectDs1005542.prototype.onItemClick = function(item) {
      return __awaiter(this, void 0, void 0, function() {
        var err_1;
        var _a;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              this.loading = true;
              (_a = this.serviceContent) === null || _a === void 0 ? void 0 : _a.setAttribute("error", "");
              _b.label = 1;
            case 1:
              _b.trys.push([1, 3, 4, 5]);
              return [4, this.initDsSelected(item.dsIndex)];
            case 2:
              _b.sent();
              this._fireEventDsSelected(item.dsIndex);
              if (this.state.actualProject)
                this.setLastDsSelected(item.dsIndex, this.state.actualProject);
              this.state.dsSelected = item.dsIndex;
              return [3, 5];
            case 3:
              err_1 = _b.sent();
              this.setError(err_1.message);
              return [3, 5];
            case 4:
              this.loading = false;
              return [
                7
                /*endfinally*/
              ];
            case 5:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSelectDs1005542.prototype.restoreDs = function(item) {
      return __awaiter(this, void 0, void 0, function() {
        var ds, err_2;
        var _this = this;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (!this.state.actualProject)
                return [
                  2
                  /*return*/
                ];
              ds = mls.l3.getDSInstance(this.state.actualProject, item.dsIndex);
              this.loading = true;
              this.setError("");
              _a.label = 1;
            case 1:
              _a.trys.push([1, 4, 5, 6]);
              return [4, ds.init()];
            case 2:
              _a.sent();
              return [4, ds.dispose()];
            case 3:
              _a.sent();
              this.init();
              this.onItemClick(item);
              this.toogleBadge(this.checkIsALocalStorageChanges(), "_100554_serviceSave");
              return [3, 6];
            case 4:
              err_2 = _a.sent();
              this.setError(err_2.message);
              return [3, 6];
            case 5:
              setTimeout(function() {
                _this.loading = false;
              }, 100);
              return [
                7
                /*endfinally*/
              ];
            case 6:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSelectDs1005542.prototype.fireOpenDetails = function() {
      if (!this.state.actualProject || !this.state.dsSelected)
        return;
      var dss = mls.l5.ds.list(this.state.actualProject);
      var dsInfo = dss[this.state.dsSelected];
      if (!dsInfo)
        return;
      this.onItemClick(dsInfo);
    };
    ServiceSelectDs1005542.prototype.firstUpdated = function(changedProperties) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              return [4, _super.prototype.firstUpdated.call(this, changedProperties)];
            case 1:
              _a.sent();
              this.fireOpenDetails();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSelectDs1005542.prototype.restoreFile = function(storFile) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (storFile.status === "changed") {
                storFile.status = "nochange";
                if (storFile.isLocalVersionOutdated && storFile.newVersionRefIfOutdated) {
                  storFile.versionRef = storFile.newVersionRefIfOutdated;
                  storFile.isLocalVersionOutdated = false;
                  storFile.newVersionRefIfOutdated = void 0;
                }
              }
              return [4, mls.stor.localStor.setContent(storFile, { contentType: "string", content: null })];
            case 1:
              _a.sent();
              this.requestUpdate();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSelectDs1005542.prototype.render = function() {
      var _this = this;
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      this.init();
      if (this.state.actualProject) {
        var lastDsIndex = this.getLastDsSelectedByProject(this.state.actualProject);
        if (!lastDsIndex)
          lastDsIndex = 0;
        this.state.dsSelected = lastDsIndex;
      }
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['\n        <div class="l5-ds-list">\n            <div class="filter-container">\n                <input type="text" placeholder="Filter">\n            </div>\n            <div class="serviceListDs">\n                <span style="display:', '">', '</span>\n                <ul class="serviceListList">\n                    ', '\n                    \n                </ul>\n            </div>\n            <div class="serviceListAddDs">\n                <a href="#" @click=', "> ", "</a>\n            </div>\n        </div>"], ['\n        <div class="l5-ds-list">\n            <div class="filter-container">\n                <input type="text" placeholder="Filter">\n            </div>\n            <div class="serviceListDs">\n                <span style="display:', '">', '</span>\n                <ul class="serviceListList">\n                    ', '\n                    \n                </ul>\n            </div>\n            <div class="serviceListAddDs">\n                <a href="#" @click=', "> ", "</a>\n            </div>\n        </div>"])), this.state.ds.length > 0 ? "none" : "block", this.msg.noDesignSystem, this.state.ds.map(function(ds) {
        var _a;
        return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(['\n                        <li>\n                            <details>\n                                <summary\n                                class= "', '"\n                                @click=', ">\n                                    <span>", '</span>\n                                    <span style="display:inline-flex;gap:.6rem; align-items:center;">\n                                        <span\n                                            title="in local storage" \n                                            style="display:', '">\n                                        ', '\n                                        </span>\n                                        <span\n                                            title="need conciliation"\n                                            style="display:', '">\n                                        ', '\n                                        </span>\n                                        <span\n                                            title="undo all"\n                                            style="margin-left:.5rem;display:', '"\n                                            @click=', "\n                                        >", "</span>\n                                    </span>\n\n                                </summary>\n                                <div>\n                                    <ul>\n                                        ", "\n                                    \n\n                                    </ul>\n                                <div>\n                                \n                            </details>\n                        \n                        </li>\n                    "], ['\n                        <li>\n                            <details>\n                                <summary\n                                class= "', '"\n                                @click=', ">\n                                    <span>", '</span>\n                                    <span style="display:inline-flex;gap:.6rem; align-items:center;">\n                                        <span\n                                            title="in local storage" \n                                            style="display:', '">\n                                        ', '\n                                        </span>\n                                        <span\n                                            title="need conciliation"\n                                            style="display:', '">\n                                        ', '\n                                        </span>\n                                        <span\n                                            title="undo all"\n                                            style="margin-left:.5rem;display:', '"\n                                            @click=', "\n                                        >", "</span>\n                                    </span>\n\n                                </summary>\n                                <div>\n                                    <ul>\n                                        ", "\n                                    \n\n                                    </ul>\n                                <div>\n                                \n                            </details>\n                        \n                        </li>\n                    "])), ds.dsInfo.dsIndex === ((_a = _this.state) === null || _a === void 0 ? void 0 : _a.dsSelected) ? "selected" : "", function(e) {
          _this.onItemClick(ds.dsInfo);
        }, ds.dsInfo.dsName + " (" + ds.dsInfo.dsIndex.toString() + ")", ds.inLocalStorage ? "block" : "none", collab_location_dot, ds.outdated ? "block" : "none", collab_unbalanced, ds.inLocalStorage ? "block" : "none", function(e) {
          e.preventDefault();
          _this.restoreDs(ds.dsInfo);
        }, collab_undo, ds.files.filter(function(f) {
          return f.inLocalStorage;
        }).map(function(file) {
          return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n                                        <li>\n                                            <span>", " ", '</span>\n                                            <span>\n                                                <span title="in local storage"> ', '</span>\n                                                <span title="need conciliation" style="display:', '">\n                                                    ', '\n                                                </span>\n                                                <span\n                                                    title="undo"\n                                                    style="margin-left:.5rem; display:', '"\n                                                    @click=', "\n                                                > ", "</span>\n                                            </span>\n                                                    \n                                        \n                                        </li>\n\n\n                                        "], ["\n                                        <li>\n                                            <span>", " ", '</span>\n                                            <span>\n                                                <span title="in local storage"> ', '</span>\n                                                <span title="need conciliation" style="display:', '">\n                                                    ', '\n                                                </span>\n                                                <span\n                                                    title="undo"\n                                                    style="margin-left:.5rem; display:', '"\n                                                    @click=', "\n                                                > ", "</span>\n                                            </span>\n                                                    \n                                        \n                                        </li>\n\n\n                                        "])), collab_file, file.folder.replace("ds/".concat(ds.dsInfo.dsName), "...") + "/" + file.shortName + file.extension, collab_location_dot, file.isLocalVersionOutdated && file.status !== "new" ? "inline-block" : "none", collab_unbalanced, (file.extension === ".less" || file.extension === ".txt") && file.status !== "new" ? "inline-block" : "none", function(e) {
            e.preventDefault();
            _this.restoreFile(file);
          }, collab_undo);
        }));
      }), function(e) {
        e.preventDefault();
        _this.openAdd();
      }, this.msg.addNew);
    };
    ServiceSelectDs1005542.styles = css(templateObject_4 || (templateObject_4 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", Object)
    ], ServiceSelectDs1005542.prototype, "state", void 0);
    ServiceSelectDs1005542 = __decorate([
      customElement("service-select-ds-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceSelectDs1005542);
    return ServiceSelectDs1005542;
  }(ServiceBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4;
export {
  ServiceSelectDs100554
};
