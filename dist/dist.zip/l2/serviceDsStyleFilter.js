var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css, repeat } from "lit";
import { customElement, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
import { initCollabDSInputRange } from "./_100554_collabDsInputRange";
var message_pt = {
  loading: "Carregando...",
  grayscale: "Tons de cinza",
  blur: "Desfoque",
  sepia: "Sepia",
  saturate: "Saturar",
  opacity: "Opacidade",
  brightness: "Brilho",
  contrast: "Contraste",
  hueRotate: "Rota\uFFFD\uFFFDo de matiz",
  invert: "Inverter"
};
var message_en = {
  loading: "Loading...",
  grayscale: "Grayscale",
  blur: "Blur",
  sepia: "Sepia",
  saturate: "Saturate",
  opacity: "Opacity",
  brightness: "Brightness",
  contrast: "Contrast",
  hueRotate: "Hue-rotate",
  invert: "Invert"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceDsStyleFilter = (
  /** @class */
  function(_super) {
    __extends(ServiceDsStyleFilter2, _super);
    function ServiceDsStyleFilter2() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.filter = {
        grayscale: "",
        blur: "",
        sepia: "",
        saturate: "",
        opacity: "",
        brightness: "",
        contrast: "",
        huerotate: "",
        invert: ""
      };
      _this.myUpp = false;
      _this.opened = false;
      _this.error = "";
      _this.helper = "_100554_serviceDsStyleFilter";
      _this.details = {
        icon: "&#xf0b0",
        state: "foreground",
        position: "right",
        tooltip: "Filter",
        visible: false,
        tags: ["ds_styles"],
        widget: "_100554_serviceDsStyleFilter",
        level: [3]
      };
      _this.onClickLink = function(op) {
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.onClickIcon = function(op) {
      };
      _this.menu = {
        title: "Filter",
        actions: {},
        icons: {},
        actionDefault: "",
        // call after close icon clicked
        iconDefault: "",
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        onClickIcon: _this.onClickIcon
      };
      _this.timeonChangeProp = -1;
      _this.timeLoader = -1;
      _this.arrayGallery = [
        "",
        "filter: brightness(20%) sepia(1) hue-rotate(180deg) saturate(5);",
        "filter: brightness(20%) sepia(1) hue-rotate(310deg) saturate(5);",
        "filter: brightness(70%) sepia(1) hue-rotate(360deg) saturate(6);",
        "filter: brightness(70%) sepia(1) hue-rotate(206deg) saturate(6);",
        "filter: brightness(40%) sepia(1) hue-rotate(-42deg) saturate(6);",
        "filter: brightness(40%) sepia(1) hue-rotate(-40deg);",
        "filter: blur(2px);",
        "filter: invert(100%) sepia(2);",
        "filter: brightness(40%) sepia(1) hue-rotate(-40deg);"
      ];
      initCollabDSInputRange();
      _this.setEvents();
      return _this;
    }
    ServiceDsStyleFilter2.prototype.onServiceClick = function(visible, reinit) {
      if (visible || reinit) {
        if (this.opened === false)
          this.opened = true;
        this.fireEventAboutMe();
      }
    };
    ServiceDsStyleFilter2.prototype.setEvents = function() {
      var _this = this;
      mls.events.addEventListener([3], ["DSStyleChanged"], function(ev) {
        _this.onstylechanged(ev.desc);
      });
      mls.events.addEventListener([3], ["DSStyleSelected"], function(ev) {
        _this.onDSStyleSelected(ev);
      });
      mls.events.addEventListener([3], ["DSStyleUnSelected"], function(ev) {
        _this.onDSStyleUnSelected(ev);
      });
      mls.events.addEventListener([3], ["DSStyleCursorChanged"], function(ev) {
        _this.onDSStyleCursorChanged(ev);
      });
    };
    ServiceDsStyleFilter2.prototype.onstylechanged = function(desc) {
      var obj = JSON.parse(desc);
      if (obj.emitter === "left" && this.visible === "true" && obj.value.length > 0) {
        this.setValues(obj.value);
      }
    };
    ServiceDsStyleFilter2.prototype.onDSStyleSelected = function(ev) {
      var params = ev.desc ? JSON.parse(ev.desc) : [];
      if (params.service.length > 0 && !params.service.includes(this.helper) || !this.serviceItemNav)
        return;
      this.serviceItemNav.setAttribute("mode", "A");
      if (this.showNav2Item)
        this.showNav2Item(true);
    };
    ServiceDsStyleFilter2.prototype.onDSStyleUnSelected = function(ev) {
      var params = ev.desc ? JSON.parse(ev.desc) : [];
      if (params.service.includes(this.helper) || !this.serviceItemNav)
        return;
      this.serviceItemNav.setAttribute("mode", "H");
      if (this.showNav2Item)
        this.showNav2Item(false);
    };
    ServiceDsStyleFilter2.prototype.onDSStyleCursorChanged = function(ev) {
      var rc = JSON.parse(ev.desc);
      if (rc.helper === this.helper) {
        if (this.visible === "true" || !this.serviceItemNav)
          return;
        this.serviceItemNav.click();
      }
    };
    ServiceDsStyleFilter2.prototype.connectedCallback = function() {
      _super.prototype.connectedCallback.call(this);
    };
    ServiceDsStyleFilter2.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject([" ", " \n        "], [" ", " \n        "])), this.opened ? html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["", "", ""], ["", "", ""])), this.renderFilter(), this.renderGallery()) : html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["", ""], ["", ""])), this.msg.loading));
    };
    ServiceDsStyleFilter2.prototype.renderFilter = function() {
      var _this = this;
      return html(templateObject_4 || (templateObject_4 = __makeTemplateObject(['\n            <div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="grayscale" value="0px" useSelect="false" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="blur" value="0px" useSelect="false" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="sepia" value="0px" useSelect="false" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="saturate" value="0px" useSelect="false" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="opacity" value="0px" useSelect="false" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="brightness" value="0px" useSelect="false" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="contrast" value="0px" useSelect="false" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="huerotate" value="0px" useSelect="false" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="invert" value="0px" useSelect="false" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n            </div>\n        '], ['\n            <div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="grayscale" value="0px" useSelect="false" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="blur" value="0px" useSelect="false" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="sepia" value="0px" useSelect="false" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="saturate" value="0px" useSelect="false" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="opacity" value="0px" useSelect="false" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="brightness" value="0px" useSelect="false" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="contrast" value="0px" useSelect="false" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="huerotate" value="0px" useSelect="false" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="invert" value="0px" useSelect="false" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n            </div>\n        '])), this.msg.grayscale, function(e) {
        return _this.onChangeProp(e.detail);
      }, this.msg.blur, function(e) {
        return _this.onChangeProp(e.detail);
      }, this.msg.sepia, function(e) {
        return _this.onChangeProp(e.detail);
      }, this.msg.saturate, function(e) {
        return _this.onChangeProp(e.detail);
      }, this.msg.opacity, function(e) {
        return _this.onChangeProp(e.detail);
      }, this.msg.brightness, function(e) {
        return _this.onChangeProp(e.detail);
      }, this.msg.contrast, function(e) {
        return _this.onChangeProp(e.detail);
      }, this.msg.hueRotate, function(e) {
        return _this.onChangeProp(e.detail);
      }, this.msg.invert, function(e) {
        return _this.onChangeProp(e.detail);
      });
    };
    ServiceDsStyleFilter2.prototype.renderGallery = function() {
      var _this = this;
      return html(templateObject_6 || (templateObject_6 = __makeTemplateObject(['\n            <div style="display: flex; justify-content: center; align-items: center; gap: 1rem; padding: 1rem; flex-wrap: wrap; cursor:pointer">\n                ', "\n            </div>\n        \n        "], ['\n            <div style="display: flex; justify-content: center; align-items: center; gap: 1rem; padding: 1rem; flex-wrap: wrap; cursor:pointer">\n                ', "\n            </div>\n        \n        "])), repeat(this.arrayGallery, function(key) {
        return key;
      }, function(css2, index) {
        return html(templateObject_5 || (templateObject_5 = __makeTemplateObject(['\n                                <img style="width:60px;', '" @click="', '" .gallery=', ' src="https://angrytools.com/css-generator/img/rose.jpg" />\n                            '], ['\n                                <img style="width:60px;', '" @click="', '" .gallery=', ' src="https://angrytools.com/css-generator/img/rose.jpg" />\n                            '])), css2, _this.clickGallery, css2);
      }));
    };
    ServiceDsStyleFilter2.prototype.onChangeProp = function(obj) {
      var _this = this;
      clearTimeout(this.timeonChangeProp);
      this.timeonChangeProp = setTimeout(function() {
        _this.mountValue();
      }, 500);
    };
    ServiceDsStyleFilter2.prototype.fireEventAboutMe = function() {
      var rc = {
        emitter: "right-get"
      };
      mls.events.fire([3], ["DSStyleChanged"], JSON.stringify(rc), 500);
    };
    ServiceDsStyleFilter2.prototype.emitEvent = function(obj) {
      if (this.myUpp)
        return;
      var rc = {
        emitter: this.position,
        value: [obj],
        helper: this.helper
      };
      if (typeof mls !== "object")
        return;
      mls.events.fire([3], ["DSStyleChanged"], JSON.stringify(rc));
    };
    ServiceDsStyleFilter2.prototype.showLoader = function(loader) {
      var _this = this;
      clearTimeout(this.timeLoader);
      this.timeLoader = setTimeout(function() {
        _this.loading = loader;
      }, 200);
    };
    ServiceDsStyleFilter2.prototype.mountValue = function() {
      if (!this.shadowRoot)
        return;
      var value = "";
      var elG = this.shadowRoot.querySelector('*[prop="grayscale"]');
      var elB = this.shadowRoot.querySelector('*[prop="blur"]');
      var elS = this.shadowRoot.querySelector('*[prop="sepia"]');
      var elSt = this.shadowRoot.querySelector('*[prop="saturate"]');
      var elO = this.shadowRoot.querySelector('*[prop="opacity"]');
      var elBr = this.shadowRoot.querySelector('*[prop="brightness"]');
      var elC = this.shadowRoot.querySelector('*[prop="contrast"]');
      var elH = this.shadowRoot.querySelector('*[prop="huerotate"]');
      var elI = this.shadowRoot.querySelector('*[prop="invert"]');
      value += elG.value ? "grayscale(" + elG.value + "%)" : "";
      value += elB.value ? " blur(" + elB.value + "px)" : "";
      value += elS.value ? " sepia(" + elS.value + ")" : "";
      value += elSt.value ? " saturate(" + elSt.value + ")" : "";
      value += elO.value ? " opacity(" + elO.value + ")" : "";
      value += elBr.value ? " brightness(" + elBr.value + "%)" : "";
      value += elC.value ? " contrast(" + elC.value + "%)" : "";
      value += elH.value ? " hue-rotate(" + elH.value + "deg)" : "";
      value += elI.value ? " invert(" + elI.value + "%)" : "";
      var change = {
        key: "filter",
        value
      };
      this.emitEvent(change);
    };
    ServiceDsStyleFilter2.prototype.setValues = function(block) {
      if (!this.shadowRoot)
        return;
      var myFilter = this.filter;
      Object.keys(myFilter).forEach(function(item) {
        myFilter[item] = "";
      });
      var textFilter = block.find(function(item) {
        return item.key === "filter";
      });
      if (!textFilter)
        return;
      this.myUpp = true;
      var value = textFilter.value;
      var filter = value.split(" ");
      filter.forEach(function(item) {
        var _a;
        var prop = item.substr(0, item.indexOf("(")).replace("-", "");
        item = item.substr(item.indexOf("("), item.length);
        var num = (_a = item.match(/[\.-\d]/g)) === null || _a === void 0 ? void 0 : _a.join("");
        if (myFilter[prop] !== void 0)
          myFilter[prop] = num;
      });
      var elG = this.shadowRoot.querySelector('*[prop="grayscale"]');
      var elB = this.shadowRoot.querySelector('*[prop="blur"]');
      var elS = this.shadowRoot.querySelector('*[prop="sepia"]');
      var elSt = this.shadowRoot.querySelector('*[prop="saturate"]');
      var elO = this.shadowRoot.querySelector('*[prop="opacity"]');
      var elBr = this.shadowRoot.querySelector('*[prop="brightness"]');
      var elC = this.shadowRoot.querySelector('*[prop="contrast"]');
      var elH = this.shadowRoot.querySelector('*[prop="huerotate"]');
      var elI = this.shadowRoot.querySelector('*[prop="invert"]');
      if (elG)
        elG.value = this.filter.grayscale;
      if (elB)
        elB.value = this.filter.blur;
      if (elS)
        elS.value = this.filter.sepia;
      if (elSt)
        elSt.value = this.filter.saturate;
      if (elO)
        elO.value = this.filter.opacity;
      if (elBr)
        elBr.value = this.filter.brightness;
      if (elC)
        elC.value = this.filter.contrast;
      if (elH)
        elH.value = this.filter.huerotate;
      if (elI)
        elI.value = this.filter.invert;
      this.myUpp = false;
    };
    ServiceDsStyleFilter2.prototype.clickGallery = function(e) {
      var el = e.target;
      if (!el)
        return;
      var css2 = el.gallery;
      var commands = css2.split(";");
      var changes = [];
      commands.forEach(function(item) {
        var _a = item.split(":"), key = _a[0], value = _a[1];
        if (!key)
          return;
        changes.push({
          key: key.trim(),
          value: value.trim()
        });
      });
      if (changes.length <= 0)
        changes.push({ key: "filter", value: "" });
      this.setValues(changes);
      var rc = {
        emitter: "right",
        value: changes,
        helper: this.helper
      };
      mls.events.fire([3], ["DSStyleChanged"], JSON.stringify(rc));
    };
    ServiceDsStyleFilter2.styles = css(templateObject_7 || (templateObject_7 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", Object)
    ], ServiceDsStyleFilter2.prototype, "opened", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceDsStyleFilter2.prototype, "error", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceDsStyleFilter2.prototype, "helper", void 0);
    ServiceDsStyleFilter2 = __decorate([
      customElement("service-ds-style-filter-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceDsStyleFilter2);
    return ServiceDsStyleFilter2;
  }(ServiceBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6, templateObject_7;
export {
  ServiceDsStyleFilter
};
