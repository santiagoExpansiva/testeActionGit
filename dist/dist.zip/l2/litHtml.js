var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d2, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d3, b2) {
      d3.__proto__ = b2;
    } || function(d3, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d3[p] = b2[p];
    };
    return extendStatics(d2, b);
  };
  return function(d2, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d2, b);
    function __() {
      this.constructor = d2;
    }
    d2.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var _a, _b, _c, _d;
var PartType = {
  ATTRIBUTE: 1,
  CHILD: 2,
  PROPERTY: 3,
  BOOLEAN_ATTRIBUTE: 4,
  EVENT: 5,
  ELEMENT: 6
};
var Directive = (
  /** @class */
  function() {
    function Directive2(_partInfo) {
    }
    Object.defineProperty(Directive2.prototype, "_$isConnected", {
      // See comment in Disconnectable interface for why this is a getter
      get: function() {
        return this._$parent._$isConnected;
      },
      enumerable: false,
      configurable: true
    });
    Directive2.prototype._$initialize = function(part, parent, attributeIndex) {
      this.__part = part;
      this._$parent = parent;
      this.__attributeIndex = attributeIndex;
    };
    Directive2.prototype._$resolve = function(part, props) {
      return this.update(part, props);
    };
    Directive2.prototype.update = function(_part, props) {
      return this.render.apply(this, props);
    };
    return Directive2;
  }()
);
var DEV_MODE = true;
var ENABLE_EXTRA_SECURITY_HOOKS = true;
var ENABLE_SHADYDOM_NOPATCH = true;
var NODE_MODE = false;
var global = NODE_MODE ? globalThis : window;
var debugLogEvent = DEV_MODE ? function(event) {
  var shouldEmit = global.emitLitDebugLogEvents;
  if (!shouldEmit) {
    return;
  }
  global.dispatchEvent(new CustomEvent("lit-debug", {
    detail: event
  }));
} : void 0;
var debugLogRenderId = 0;
var issueWarning;
if (DEV_MODE) {
  (_a = global.litIssuedWarnings) !== null && _a !== void 0 ? _a : global.litIssuedWarnings = /* @__PURE__ */ new Set();
  issueWarning = function(code, warning) {
    warning += code ? " See https://lit.dev/msg/".concat(code, " for more information.") : "";
    if (!global.litIssuedWarnings.has(warning)) {
      console.warn(warning);
      global.litIssuedWarnings.add(warning);
    }
  };
  issueWarning("dev-mode", "Lit is in dev mode. Not recommended for production!");
}
var wrap = ENABLE_SHADYDOM_NOPATCH && ((_b = global.ShadyDOM) === null || _b === void 0 ? void 0 : _b.inUse) && ((_c = global.ShadyDOM) === null || _c === void 0 ? void 0 : _c.noPatch) === true ? global.ShadyDOM.wrap : function(node) {
  return node;
};
var trustedTypes = global.trustedTypes;
var policy = trustedTypes ? trustedTypes.createPolicy("lit-html", {
  createHTML: function(s) {
    return s;
  }
}) : void 0;
var identityFunction = function(value) {
  return value;
};
var noopSanitizer = function(_node, _name, _type) {
  return identityFunction;
};
var setSanitizer = function(newSanitizer) {
  if (!ENABLE_EXTRA_SECURITY_HOOKS) {
    return;
  }
  if (sanitizerFactoryInternal !== noopSanitizer) {
    throw new Error("Attempted to overwrite existing lit-html security policy. setSanitizeDOMValueFactory should be called at most once.");
  }
  sanitizerFactoryInternal = newSanitizer;
};
var _testOnlyClearSanitizerFactoryDoNotCallOrElse = function() {
  sanitizerFactoryInternal = noopSanitizer;
};
var createSanitizer = function(node, name, type) {
  return sanitizerFactoryInternal(node, name, type);
};
var boundAttributeSuffix = "$lit$";
var marker = "lit$".concat(String(Math.random()).slice(9), "$");
var markerMatch = "?" + marker;
var nodeMarker = "<".concat(markerMatch, ">");
var d = NODE_MODE && global.document === void 0 ? {
  createTreeWalker: function() {
    return {};
  }
} : document;
var createMarker = function() {
  return d.createComment("");
};
var isPrimitive = function(value) {
  return value === null || typeof value != "object" && typeof value != "function";
};
var isArray = Array.isArray;
var isIterable = function(value) {
  return isArray(value) || // eslint-disable-next-line @typescript-eslint/no-explicit-any
  typeof (value === null || value === void 0 ? void 0 : value[Symbol.iterator]) === "function";
};
var SPACE_CHAR = "[ 	\n\f\r]";
var ATTR_VALUE_CHAR = "[^ 	\n\f\r\"'`<>=]";
var NAME_CHAR = `[^\\s"'>=/]`;
var textEndRegex = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g;
var COMMENT_START = 1;
var TAG_NAME = 2;
var DYNAMIC_TAG_NAME = 3;
var commentEndRegex = /-->/g;
var comment2EndRegex = />/g;
var tagEndRegex = new RegExp(">|".concat(SPACE_CHAR, "(?:(").concat(NAME_CHAR, "+)(").concat(SPACE_CHAR, "*=").concat(SPACE_CHAR, "*(?:").concat(ATTR_VALUE_CHAR, `|("|')|))|$)`), "g");
var ENTIRE_MATCH = 0;
var ATTRIBUTE_NAME = 1;
var SPACES_AND_EQUALS = 2;
var QUOTE_CHAR = 3;
var singleQuoteAttrEndRegex = /'/g;
var doubleQuoteAttrEndRegex = /"/g;
var rawTextElement = /^(?:script|style|textarea|title)$/i;
var HTML_RESULT = 1;
var SVG_RESULT = 2;
var ATTRIBUTE_PART = 1;
var CHILD_PART = 2;
var PROPERTY_PART = 3;
var BOOLEAN_ATTRIBUTE_PART = 4;
var EVENT_PART = 5;
var ELEMENT_PART = 6;
var COMMENT_PART = 7;
var tag = function(type) {
  return function(strings) {
    var _a2;
    var values = [];
    for (var _i = 1; _i < arguments.length; _i++) {
      values[_i - 1] = arguments[_i];
    }
    if (DEV_MODE && strings.some(function(s) {
      return s === void 0;
    })) {
      console.warn("Some template strings are undefined.\nThis is probably caused by illegal octal escape sequences.");
    }
    return _a2 = {}, // This property needs to remain unminified.
    _a2["_$litType$"] = type, _a2.strings = strings, _a2.values = values, _a2;
  };
};
var html = tag(HTML_RESULT);
var svg = tag(SVG_RESULT);
var noChange = Symbol.for("lit-noChange");
var nothing = Symbol.for("lit-nothing");
var templateCache = /* @__PURE__ */ new WeakMap();
var walker = d.createTreeWalker(d, 129, null);
var sanitizerFactoryInternal = noopSanitizer;
var unsafeHTML = function(strings) {
};
var getTemplateHtml = function(strings, type) {
  var l = strings.length - 1;
  var attrNames = [];
  var html2 = type === SVG_RESULT ? "<svg>" : "";
  var rawTextEndRegex;
  var regex = textEndRegex;
  for (var i = 0; i < l; i++) {
    var s = strings[i];
    var attrNameEndIndex = -1;
    var attrName = void 0;
    var lastIndex = 0;
    var match = void 0;
    while (lastIndex < s.length) {
      regex.lastIndex = lastIndex;
      match = regex.exec(s);
      if (match === null) {
        break;
      }
      lastIndex = regex.lastIndex;
      if (regex === textEndRegex) {
        if (match[COMMENT_START] === "!--") {
          regex = commentEndRegex;
        } else if (match[COMMENT_START] !== void 0) {
          regex = comment2EndRegex;
        } else if (match[TAG_NAME] !== void 0) {
          if (rawTextElement.test(match[TAG_NAME])) {
            rawTextEndRegex = new RegExp("</".concat(match[TAG_NAME]), "g");
          }
          regex = tagEndRegex;
        } else if (match[DYNAMIC_TAG_NAME] !== void 0) {
          if (DEV_MODE) {
            throw new Error("Bindings in tag names are not supported. Please use static templates instead. See https://lit.dev/docs/templates/expressions/#static-expressions");
          }
          regex = tagEndRegex;
        }
      } else if (regex === tagEndRegex) {
        if (match[ENTIRE_MATCH] === ">") {
          regex = rawTextEndRegex !== null && rawTextEndRegex !== void 0 ? rawTextEndRegex : textEndRegex;
          attrNameEndIndex = -1;
        } else if (match[ATTRIBUTE_NAME] === void 0) {
          attrNameEndIndex = -2;
        } else {
          attrNameEndIndex = regex.lastIndex - match[SPACES_AND_EQUALS].length;
          attrName = match[ATTRIBUTE_NAME];
          regex = match[QUOTE_CHAR] === void 0 ? tagEndRegex : match[QUOTE_CHAR] === '"' ? doubleQuoteAttrEndRegex : singleQuoteAttrEndRegex;
        }
      } else if (regex === doubleQuoteAttrEndRegex || regex === singleQuoteAttrEndRegex) {
        regex = tagEndRegex;
      } else if (regex === commentEndRegex || regex === comment2EndRegex) {
        regex = textEndRegex;
      } else {
        regex = tagEndRegex;
        rawTextEndRegex = void 0;
      }
    }
    if (DEV_MODE) {
      console.assert(attrNameEndIndex === -1 || regex === tagEndRegex || regex === singleQuoteAttrEndRegex || regex === doubleQuoteAttrEndRegex, "unexpected parse state B");
    }
    var end = regex === tagEndRegex && strings[i + 1].startsWith("/>") ? " " : "";
    html2 += regex === textEndRegex ? s + nodeMarker : attrNameEndIndex >= 0 ? (attrNames.push(attrName), s.slice(0, attrNameEndIndex) + boundAttributeSuffix + s.slice(attrNameEndIndex)) + marker + end : s + marker + (attrNameEndIndex === -2 ? (attrNames.push(void 0), i) : end);
  }
  var htmlResult = html2 + (strings[l] || "<?>") + (type === SVG_RESULT ? "</svg>" : "");
  if (!Array.isArray(strings) || !strings.hasOwnProperty("raw")) {
    var message = "invalid template strings array";
    if (DEV_MODE) {
      message = "\n          Internal Error: expected template strings to be an array\n          with a 'raw' field. Faking a template strings array by\n          calling html or svg like an ordinary function is effectively\n          the same as calling unsafeHtml and can lead to major security\n          issues, e.g. opening your code up to XSS attacks.\n\n          If you're using the html or svg tagged template functions normally\n          and still seeing this error, please file a bug at\n          https://github.com/lit/lit/issues/new?template=bug_report.md\n          and include information about your build tooling, if any.\n        ".trim().replace(/\n */g, "\n");
    }
    throw new Error(message);
  }
  return [
    policy !== void 0 ? policy.createHTML(htmlResult) : htmlResult,
    attrNames
  ];
};
var Template = (
  /** @class */
  function() {
    function Template2(_a2, options) {
      var strings = _a2.strings, type = _a2["_$litType$"];
      this.parts = [];
      var node;
      var nodeIndex = 0;
      var attrNameIndex = 0;
      var partCount = strings.length - 1;
      var parts = this.parts;
      var _b2 = getTemplateHtml(strings, type), html2 = _b2[0], attrNames = _b2[1];
      this.el = Template2.createElement(html2, options);
      walker.currentNode = this.el.content;
      if (type === SVG_RESULT) {
        var content = this.el.content;
        var svgElement = content.firstChild;
        svgElement.remove();
        content.append.apply(content, svgElement.childNodes);
      }
      while ((node = walker.nextNode()) !== null && parts.length < partCount) {
        if (node.nodeType === 1) {
          if (DEV_MODE) {
            var tag_1 = node.localName;
            if (/^(?:textarea|template)$/i.test(tag_1) && node.innerHTML.includes(marker)) {
              var m = "Expressions are not supported inside `".concat(tag_1, "` ") + "elements. See https://lit.dev/msg/expression-in-".concat(tag_1, " for more ") + "information.";
              if (tag_1 === "template") {
                throw new Error(m);
              } else
                issueWarning("", m);
            }
          }
          if (node.hasAttributes()) {
            var attrsToRemove = [];
            for (var _i = 0, _c2 = node.getAttributeNames(); _i < _c2.length; _i++) {
              var name = _c2[_i];
              if (name.endsWith(boundAttributeSuffix) || name.startsWith(marker)) {
                var realName = attrNames[attrNameIndex++];
                attrsToRemove.push(name);
                if (realName !== void 0) {
                  var value = node.getAttribute(realName.toLowerCase() + boundAttributeSuffix);
                  var statics = value.split(marker);
                  var m = /([.?@])?(.*)/.exec(realName);
                  parts.push({
                    type: ATTRIBUTE_PART,
                    index: nodeIndex,
                    name: m[2],
                    strings: statics,
                    ctor: m[1] === "." ? PropertyPart : m[1] === "?" ? BooleanAttributePart : m[1] === "@" ? EventPart : AttributePart
                  });
                } else {
                  parts.push({
                    type: ELEMENT_PART,
                    index: nodeIndex
                  });
                }
              }
            }
            for (var _d2 = 0, attrsToRemove_1 = attrsToRemove; _d2 < attrsToRemove_1.length; _d2++) {
              var name = attrsToRemove_1[_d2];
              node.removeAttribute(name);
            }
          }
          if (rawTextElement.test(node.tagName)) {
            var strings_1 = node.textContent.split(marker);
            var lastIndex = strings_1.length - 1;
            if (lastIndex > 0) {
              node.textContent = trustedTypes ? trustedTypes.emptyScript : "";
              for (var i = 0; i < lastIndex; i++) {
                node.append(strings_1[i], createMarker());
                walker.nextNode();
                parts.push({ type: CHILD_PART, index: ++nodeIndex });
              }
              node.append(strings_1[lastIndex], createMarker());
            }
          }
        } else if (node.nodeType === 8) {
          var data = node.data;
          if (data === markerMatch) {
            parts.push({ type: CHILD_PART, index: nodeIndex });
          } else {
            var i = -1;
            while ((i = node.data.indexOf(marker, i + 1)) !== -1) {
              parts.push({ type: COMMENT_PART, index: nodeIndex });
              i += marker.length - 1;
            }
          }
        }
        nodeIndex++;
      }
      debugLogEvent === null || debugLogEvent === void 0 ? void 0 : debugLogEvent({
        kind: "template prep",
        template: this,
        clonableTemplate: this.el,
        parts: this.parts,
        strings
      });
    }
    Template2.createElement = function(html2, _options) {
      var el = d.createElement("template");
      el.innerHTML = html2;
      return el;
    };
    return Template2;
  }()
);
function resolveDirective(part, value, parent, attributeIndex) {
  var _a2, _b2, _c2;
  var _d2;
  if (parent === void 0) {
    parent = part;
  }
  if (value === noChange) {
    return value;
  }
  var currentDirective = attributeIndex !== void 0 ? (_a2 = parent.__directives) === null || _a2 === void 0 ? void 0 : _a2[attributeIndex] : parent.__directive;
  var nextDirectiveConstructor = isPrimitive(value) ? void 0 : (
    // This property needs to remain unminified.
    value["_$litDirective$"]
  );
  if ((currentDirective === null || currentDirective === void 0 ? void 0 : currentDirective.constructor) !== nextDirectiveConstructor) {
    (_b2 = currentDirective === null || currentDirective === void 0 ? void 0 : currentDirective["_$notifyDirectiveConnectionChanged"]) === null || _b2 === void 0 ? void 0 : _b2.call(currentDirective, false);
    if (nextDirectiveConstructor === void 0) {
      currentDirective = void 0;
    } else {
      currentDirective = new nextDirectiveConstructor(part);
      currentDirective._$initialize(part, parent, attributeIndex);
    }
    if (attributeIndex !== void 0) {
      ((_c2 = (_d2 = parent).__directives) !== null && _c2 !== void 0 ? _c2 : _d2.__directives = [])[attributeIndex] = currentDirective;
    } else {
      parent.__directive = currentDirective;
    }
  }
  if (currentDirective !== void 0) {
    value = resolveDirective(part, currentDirective._$resolve(part, value.values), currentDirective, attributeIndex);
  }
  return value;
}
var TemplateInstance = (
  /** @class */
  function() {
    function TemplateInstance2(template, parent) {
      this._$parts = [];
      this._$disconnectableChildren = void 0;
      this._$template = template;
      this._$parent = parent;
    }
    Object.defineProperty(TemplateInstance2.prototype, "parentNode", {
      // Called by ChildPart parentNode getter
      get: function() {
        return this._$parent.parentNode;
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(TemplateInstance2.prototype, "_$isConnected", {
      // See comment in Disconnectable interface for why this is a getter
      get: function() {
        return this._$parent._$isConnected;
      },
      enumerable: false,
      configurable: true
    });
    TemplateInstance2.prototype._clone = function(options) {
      var _a2;
      var _b2 = this._$template, content = _b2.el.content, parts = _b2.parts;
      var fragment = ((_a2 = options === null || options === void 0 ? void 0 : options.creationScope) !== null && _a2 !== void 0 ? _a2 : d).importNode(content, true);
      walker.currentNode = fragment;
      var node = walker.nextNode();
      var nodeIndex = 0;
      var partIndex = 0;
      var templatePart = parts[0];
      while (templatePart !== void 0) {
        if (nodeIndex === templatePart.index) {
          var part = void 0;
          if (templatePart.type === CHILD_PART) {
            part = new ChildPart(node, node.nextSibling, this, options);
          } else if (templatePart.type === ATTRIBUTE_PART) {
            part = new templatePart.ctor(node, templatePart.name, templatePart.strings, this, options);
          } else if (templatePart.type === ELEMENT_PART) {
            part = new ElementPart(node, this, options);
          }
          this._$parts.push(part);
          templatePart = parts[++partIndex];
        }
        if (nodeIndex !== (templatePart === null || templatePart === void 0 ? void 0 : templatePart.index)) {
          node = walker.nextNode();
          nodeIndex++;
        }
      }
      walker.currentNode = d;
      return fragment;
    };
    TemplateInstance2.prototype._update = function(values) {
      var i = 0;
      for (var _i = 0, _a2 = this._$parts; _i < _a2.length; _i++) {
        var part = _a2[_i];
        if (part !== void 0) {
          debugLogEvent === null || debugLogEvent === void 0 ? void 0 : debugLogEvent({
            kind: "set part",
            part,
            value: values[i],
            valueIndex: i,
            values,
            templateInstance: this
          });
          if (part.strings !== void 0) {
            part._$setValue(values, part, i);
            i += part.strings.length - 2;
          } else {
            part._$setValue(values[i]);
          }
        }
        i++;
      }
    };
    return TemplateInstance2;
  }()
);
var ChildPart = (
  /** @class */
  function() {
    function ChildPart2(startNode, endNode, parent, options) {
      var _a2;
      this.type = CHILD_PART;
      this._$committedValue = nothing;
      this._$disconnectableChildren = void 0;
      this._$startNode = startNode;
      this._$endNode = endNode;
      this._$parent = parent;
      this.options = options;
      this.__isConnected = (_a2 = options === null || options === void 0 ? void 0 : options.isConnected) !== null && _a2 !== void 0 ? _a2 : true;
      if (ENABLE_EXTRA_SECURITY_HOOKS) {
        this._textSanitizer = void 0;
      }
    }
    Object.defineProperty(ChildPart2.prototype, "_$isConnected", {
      // See comment in Disconnectable interface for why this is a getter
      get: function() {
        var _a2, _b2;
        return (_b2 = (_a2 = this._$parent) === null || _a2 === void 0 ? void 0 : _a2._$isConnected) !== null && _b2 !== void 0 ? _b2 : this.__isConnected;
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(ChildPart2.prototype, "parentNode", {
      /**
       * The parent node into which the part renders its content.
       *
       * A ChildPart's content consists of a range of adjacent child nodes of
       * `.parentNode`, possibly bordered by 'marker nodes' (`.startNode` and
       * `.endNode`).
       *
       * - If both `.startNode` and `.endNode` are non-null, then the part's content
       * consists of all siblings between `.startNode` and `.endNode`, exclusively.
       *
       * - If `.startNode` is non-null but `.endNode` is null, then the part's
       * content consists of all siblings following `.startNode`, up to and
       * including the last child of `.parentNode`. If `.endNode` is non-null, then
       * `.startNode` will always be non-null.
       *
       * - If both `.endNode` and `.startNode` are null, then the part's content
       * consists of all child nodes of `.parentNode`.
       */
      get: function() {
        var parentNode = wrap(this._$startNode).parentNode;
        var parent = this._$parent;
        if (parent !== void 0 && (parentNode === null || parentNode === void 0 ? void 0 : parentNode.nodeType) === 11) {
          parentNode = parent.parentNode;
        }
        return parentNode;
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(ChildPart2.prototype, "startNode", {
      /**
       * The part's leading marker node, if any. See `.parentNode` for more
       * information.
       */
      get: function() {
        return this._$startNode;
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(ChildPart2.prototype, "endNode", {
      /**
       * The part's trailing marker node, if any. See `.parentNode` for more
       * information.
       */
      get: function() {
        return this._$endNode;
      },
      enumerable: false,
      configurable: true
    });
    ChildPart2.prototype._$setValue = function(value, directiveParent) {
      var _a2;
      if (directiveParent === void 0) {
        directiveParent = this;
      }
      if (DEV_MODE && this.parentNode === null) {
        throw new Error("This `ChildPart` has no `parentNode` and therefore cannot accept a value. This likely means the element containing the part was manipulated in an unsupported way outside of Lit's control such that the part's marker nodes were ejected from DOM. For example, setting the element's `innerHTML` or `textContent` can do this.");
      }
      value = resolveDirective(this, value, directiveParent);
      if (isPrimitive(value)) {
        if (value === nothing || value == null || value === "") {
          if (this._$committedValue !== nothing) {
            debugLogEvent === null || debugLogEvent === void 0 ? void 0 : debugLogEvent({
              kind: "commit nothing to child",
              start: this._$startNode,
              end: this._$endNode,
              parent: this._$parent,
              options: this.options
            });
            this._$clear();
          }
          this._$committedValue = nothing;
        } else if (value !== this._$committedValue && value !== noChange) {
          this._commitText(value);
        }
      } else if (value["_$litType$"] !== void 0) {
        this._commitTemplateResult(value);
      } else if (value.nodeType !== void 0) {
        if (DEV_MODE && ((_a2 = this.options) === null || _a2 === void 0 ? void 0 : _a2.host) === value) {
          this._commitText("[probable mistake: rendered a template's host in itself (commonly caused by writing ${this} in a template]");
          console.warn("Attempted to render the template host", value, "inside itself. This is almost always a mistake, and in dev mode ", "we render some warning text. In production however, we'll ", "render it, which will usually result in an error, and sometimes ", "in the element disappearing from the DOM.");
          return;
        }
        this._commitNode(value);
      } else if (isIterable(value)) {
        this._commitIterable(value);
      } else {
        this._commitText(value);
      }
    };
    ChildPart2.prototype._insert = function(node) {
      return wrap(wrap(this._$startNode).parentNode).insertBefore(node, this._$endNode);
    };
    ChildPart2.prototype._commitNode = function(value) {
      var _a2;
      if (this._$committedValue !== value) {
        this._$clear();
        if (ENABLE_EXTRA_SECURITY_HOOKS && sanitizerFactoryInternal !== noopSanitizer) {
          var parentNodeName = (_a2 = this._$startNode.parentNode) === null || _a2 === void 0 ? void 0 : _a2.nodeName;
          if (parentNodeName === "STYLE" || parentNodeName === "SCRIPT") {
            var message = "Forbidden";
            if (DEV_MODE) {
              if (parentNodeName === "STYLE") {
                message = "Lit does not support binding inside style nodes. This is a security risk, as style injection attacks can exfiltrate data and spoof UIs. Consider instead using css`...` literals to compose styles, and make do dynamic styling with css custom properties, ::parts, <slot>s, and by mutating the DOM rather than stylesheets.";
              } else {
                message = "Lit does not support binding inside script nodes. This is a security risk, as it could allow arbitrary code execution.";
              }
            }
            throw new Error(message);
          }
        }
        debugLogEvent === null || debugLogEvent === void 0 ? void 0 : debugLogEvent({
          kind: "commit node",
          start: this._$startNode,
          parent: this._$parent,
          value,
          options: this.options
        });
        this._$committedValue = this._insert(value);
      }
    };
    ChildPart2.prototype._commitText = function(value) {
      if (this._$committedValue !== nothing && isPrimitive(this._$committedValue)) {
        var node = wrap(this._$startNode).nextSibling;
        if (ENABLE_EXTRA_SECURITY_HOOKS) {
          if (this._textSanitizer === void 0) {
            this._textSanitizer = createSanitizer(node, "data", "property");
          }
          value = this._textSanitizer(value);
        }
        debugLogEvent === null || debugLogEvent === void 0 ? void 0 : debugLogEvent({
          kind: "commit text",
          node,
          value,
          options: this.options
        });
        node.data = value;
      } else {
        if (ENABLE_EXTRA_SECURITY_HOOKS) {
          var textNode = d.createTextNode("");
          this._commitNode(textNode);
          if (this._textSanitizer === void 0) {
            this._textSanitizer = createSanitizer(textNode, "data", "property");
          }
          value = this._textSanitizer(value);
          debugLogEvent === null || debugLogEvent === void 0 ? void 0 : debugLogEvent({
            kind: "commit text",
            node: textNode,
            value,
            options: this.options
          });
          textNode.data = value;
        } else {
          this._commitNode(d.createTextNode(value));
          debugLogEvent === null || debugLogEvent === void 0 ? void 0 : debugLogEvent({
            kind: "commit text",
            node: wrap(this._$startNode).nextSibling,
            value,
            options: this.options
          });
        }
      }
      this._$committedValue = value;
    };
    ChildPart2.prototype._commitTemplateResult = function(result) {
      var _a2;
      var values = result.values, type = result["_$litType$"];
      var template = typeof type === "number" ? this._$getTemplate(result) : (type.el === void 0 && (type.el = Template.createElement(type.h, this.options)), type);
      if (((_a2 = this._$committedValue) === null || _a2 === void 0 ? void 0 : _a2._$template) === template) {
        debugLogEvent === null || debugLogEvent === void 0 ? void 0 : debugLogEvent({
          kind: "template updating",
          template,
          instance: this._$committedValue,
          parts: this._$committedValue._$parts,
          options: this.options,
          values
        });
        this._$committedValue._update(values);
      } else {
        var instance = new TemplateInstance(template, this);
        var fragment = instance._clone(this.options);
        debugLogEvent === null || debugLogEvent === void 0 ? void 0 : debugLogEvent({
          kind: "template instantiated",
          template,
          instance,
          parts: instance._$parts,
          options: this.options,
          fragment,
          values
        });
        instance._update(values);
        debugLogEvent === null || debugLogEvent === void 0 ? void 0 : debugLogEvent({
          kind: "template instantiated and updated",
          template,
          instance,
          parts: instance._$parts,
          options: this.options,
          fragment,
          values
        });
        this._commitNode(fragment);
        this._$committedValue = instance;
      }
    };
    ChildPart2.prototype._$getTemplate = function(result) {
      var template = templateCache.get(result.strings);
      if (template === void 0) {
        templateCache.set(result.strings, template = new Template(result));
      }
      return template;
    };
    ChildPart2.prototype._commitIterable = function(value) {
      if (!isArray(this._$committedValue)) {
        this._$committedValue = [];
        this._$clear();
      }
      var itemParts = this._$committedValue;
      var partIndex = 0;
      var itemPart;
      for (var _i = 0, value_1 = value; _i < value_1.length; _i++) {
        var item = value_1[_i];
        if (partIndex === itemParts.length) {
          itemParts.push(itemPart = new ChildPart2(this._insert(createMarker()), this._insert(createMarker()), this, this.options));
        } else {
          itemPart = itemParts[partIndex];
        }
        itemPart._$setValue(item);
        partIndex++;
      }
      if (partIndex < itemParts.length) {
        this._$clear(itemPart && wrap(itemPart._$endNode).nextSibling, partIndex);
        itemParts.length = partIndex;
      }
    };
    ChildPart2.prototype._$clear = function(start, from) {
      var _a2;
      if (start === void 0) {
        start = wrap(this._$startNode).nextSibling;
      }
      (_a2 = this._$notifyConnectionChanged) === null || _a2 === void 0 ? void 0 : _a2.call(this, false, true, from);
      while (start && start !== this._$endNode) {
        var n = wrap(start).nextSibling;
        wrap(start).remove();
        start = n;
      }
    };
    ChildPart2.prototype.setConnected = function(isConnected) {
      var _a2;
      if (this._$parent === void 0) {
        this.__isConnected = isConnected;
        (_a2 = this._$notifyConnectionChanged) === null || _a2 === void 0 ? void 0 : _a2.call(this, isConnected);
      } else if (DEV_MODE) {
        throw new Error("part.setConnected() may only be called on a RootPart returned from render().");
      }
    };
    return ChildPart2;
  }()
);
var AttributePart = (
  /** @class */
  function() {
    function AttributePart2(element, name, strings, parent, options) {
      this.type = ATTRIBUTE_PART;
      this._$committedValue = nothing;
      this._$disconnectableChildren = void 0;
      this.element = element;
      this.name = name;
      this._$parent = parent;
      this.options = options;
      if (strings.length > 2 || strings[0] !== "" || strings[1] !== "") {
        this._$committedValue = new Array(strings.length - 1).fill(new String());
        this.strings = strings;
      } else {
        this._$committedValue = nothing;
      }
      if (ENABLE_EXTRA_SECURITY_HOOKS) {
        this._sanitizer = void 0;
      }
    }
    Object.defineProperty(AttributePart2.prototype, "tagName", {
      get: function() {
        return this.element.tagName;
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(AttributePart2.prototype, "_$isConnected", {
      // See comment in Disconnectable interface for why this is a getter
      get: function() {
        return this._$parent._$isConnected;
      },
      enumerable: false,
      configurable: true
    });
    AttributePart2.prototype._$setValue = function(value, directiveParent, valueIndex, noCommit) {
      if (directiveParent === void 0) {
        directiveParent = this;
      }
      var strings = this.strings;
      var change = false;
      if (strings === void 0) {
        value = resolveDirective(this, value, directiveParent, 0);
        change = !isPrimitive(value) || value !== this._$committedValue && value !== noChange;
        if (change) {
          this._$committedValue = value;
        }
      } else {
        var values = value;
        value = strings[0];
        var i = void 0, v = void 0;
        for (i = 0; i < strings.length - 1; i++) {
          v = resolveDirective(this, values[valueIndex + i], directiveParent, i);
          if (v === noChange) {
            v = this._$committedValue[i];
          }
          change || (change = !isPrimitive(v) || v !== this._$committedValue[i]);
          if (v === nothing) {
            value = nothing;
          } else if (value !== nothing) {
            value += (v !== null && v !== void 0 ? v : "") + strings[i + 1];
          }
          this._$committedValue[i] = v;
        }
      }
      if (change && !noCommit) {
        this._commitValue(value);
      }
    };
    AttributePart2.prototype._commitValue = function(value) {
      if (value === nothing) {
        wrap(this.element).removeAttribute(this.name);
      } else {
        if (ENABLE_EXTRA_SECURITY_HOOKS) {
          if (this._sanitizer === void 0) {
            this._sanitizer = sanitizerFactoryInternal(this.element, this.name, "attribute");
          }
          value = this._sanitizer(value !== null && value !== void 0 ? value : "");
        }
        debugLogEvent === null || debugLogEvent === void 0 ? void 0 : debugLogEvent({
          kind: "commit attribute",
          element: this.element,
          name: this.name,
          value,
          options: this.options
        });
        wrap(this.element).setAttribute(this.name, value !== null && value !== void 0 ? value : "");
      }
    };
    return AttributePart2;
  }()
);
var PropertyPart = (
  /** @class */
  function(_super) {
    __extends(PropertyPart2, _super);
    function PropertyPart2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.type = PROPERTY_PART;
      return _this;
    }
    PropertyPart2.prototype._commitValue = function(value) {
      if (ENABLE_EXTRA_SECURITY_HOOKS) {
        if (this._sanitizer === void 0) {
          this._sanitizer = sanitizerFactoryInternal(this.element, this.name, "property");
        }
        value = this._sanitizer(value);
      }
      debugLogEvent === null || debugLogEvent === void 0 ? void 0 : debugLogEvent({
        kind: "commit property",
        element: this.element,
        name: this.name,
        value,
        options: this.options
      });
      this.element[this.name] = value === nothing ? void 0 : value;
    };
    return PropertyPart2;
  }(AttributePart)
);
var emptyStringForBooleanAttribute = trustedTypes ? trustedTypes.emptyScript : "";
var BooleanAttributePart = (
  /** @class */
  function(_super) {
    __extends(BooleanAttributePart2, _super);
    function BooleanAttributePart2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.type = BOOLEAN_ATTRIBUTE_PART;
      return _this;
    }
    BooleanAttributePart2.prototype._commitValue = function(value) {
      debugLogEvent === null || debugLogEvent === void 0 ? void 0 : debugLogEvent({
        kind: "commit boolean attribute",
        element: this.element,
        name: this.name,
        value: !!(value && value !== nothing),
        options: this.options
      });
      if (value && value !== nothing) {
        wrap(this.element).setAttribute(this.name, emptyStringForBooleanAttribute);
      } else {
        wrap(this.element).removeAttribute(this.name);
      }
    };
    return BooleanAttributePart2;
  }(AttributePart)
);
var EventPart = (
  /** @class */
  function(_super) {
    __extends(EventPart2, _super);
    function EventPart2(element, name, strings, parent, options) {
      var _this = _super.call(this, element, name, strings, parent, options) || this;
      _this.type = EVENT_PART;
      if (DEV_MODE && _this.strings !== void 0) {
        throw new Error("A `<".concat(element.localName, ">` has a `@").concat(name, "=...` listener with ") + "invalid content. Event listeners in templates must have exactly one expression and no surrounding text.");
      }
      return _this;
    }
    EventPart2.prototype._$setValue = function(newListener, directiveParent) {
      var _a2;
      if (directiveParent === void 0) {
        directiveParent = this;
      }
      newListener = (_a2 = resolveDirective(this, newListener, directiveParent, 0)) !== null && _a2 !== void 0 ? _a2 : nothing;
      if (newListener === noChange) {
        return;
      }
      var oldListener = this._$committedValue;
      var shouldRemoveListener = newListener === nothing && oldListener !== nothing || newListener.capture !== oldListener.capture || newListener.once !== oldListener.once || newListener.passive !== oldListener.passive;
      var shouldAddListener = newListener !== nothing && (oldListener === nothing || shouldRemoveListener);
      debugLogEvent === null || debugLogEvent === void 0 ? void 0 : debugLogEvent({
        kind: "commit event listener",
        element: this.element,
        name: this.name,
        value: newListener,
        options: this.options,
        removeListener: shouldRemoveListener,
        addListener: shouldAddListener,
        oldListener
      });
      if (shouldRemoveListener) {
        this.element.removeEventListener(this.name, this, oldListener);
      }
      if (shouldAddListener) {
        this.element.addEventListener(this.name, this, newListener);
      }
      this._$committedValue = newListener;
    };
    EventPart2.prototype.handleEvent = function(event) {
      var _a2, _b2;
      if (typeof this._$committedValue === "function") {
        this._$committedValue.call((_b2 = (_a2 = this.options) === null || _a2 === void 0 ? void 0 : _a2.host) !== null && _b2 !== void 0 ? _b2 : this.element, event);
      } else {
        this._$committedValue.handleEvent(event);
      }
    };
    return EventPart2;
  }(AttributePart)
);
var ElementPart = (
  /** @class */
  function() {
    function ElementPart2(element, parent, options) {
      this.element = element;
      this.type = ELEMENT_PART;
      this._$disconnectableChildren = void 0;
      this._$parent = parent;
      this.options = options;
    }
    Object.defineProperty(ElementPart2.prototype, "_$isConnected", {
      // See comment in Disconnectable interface for why this is a getter
      get: function() {
        return this._$parent._$isConnected;
      },
      enumerable: false,
      configurable: true
    });
    ElementPart2.prototype._$setValue = function(value) {
      debugLogEvent === null || debugLogEvent === void 0 ? void 0 : debugLogEvent({
        kind: "commit to element binding",
        element: this.element,
        value,
        options: this.options
      });
      resolveDirective(this, value);
    };
    return ElementPart2;
  }()
);
var _$LH = {
  // Used in lit-ssr
  _boundAttributeSuffix: boundAttributeSuffix,
  _marker: marker,
  _markerMatch: markerMatch,
  _HTML_RESULT: HTML_RESULT,
  _getTemplateHtml: getTemplateHtml,
  // Used in tests and private-ssr-support
  _TemplateInstance: TemplateInstance,
  _isIterable: isIterable,
  _resolveDirective: resolveDirective,
  _ChildPart: ChildPart,
  _AttributePart: AttributePart,
  _BooleanAttributePart: BooleanAttributePart,
  _EventPart: EventPart,
  _PropertyPart: PropertyPart,
  _ElementPart: ElementPart
};
var polyfillSupport = DEV_MODE ? global.litHtmlPolyfillSupportDevMode : global.litHtmlPolyfillSupport;
polyfillSupport === null || polyfillSupport === void 0 ? void 0 : polyfillSupport(Template, ChildPart);
((_d = global.litHtmlVersions) !== null && _d !== void 0 ? _d : global.litHtmlVersions = []).push("2.7.4");
if (DEV_MODE && global.litHtmlVersions.length > 1) {
  issueWarning("multiple-versions", "Multiple versions of Lit loaded. Loading multiple versions is not recommended.");
}
var render = function(value, container, options) {
  var _a2, _b2;
  if (DEV_MODE && container == null) {
    throw new TypeError("The container to render into may not be ".concat(container));
  }
  var renderId = DEV_MODE ? debugLogRenderId++ : 0;
  var partOwnerNode = (_a2 = options === null || options === void 0 ? void 0 : options.renderBefore) !== null && _a2 !== void 0 ? _a2 : container;
  var part = partOwnerNode["_$litPart$"];
  debugLogEvent === null || debugLogEvent === void 0 ? void 0 : debugLogEvent({
    kind: "begin render",
    id: renderId,
    value,
    container,
    options,
    part
  });
  if (part === void 0) {
    var endNode = (_b2 = options === null || options === void 0 ? void 0 : options.renderBefore) !== null && _b2 !== void 0 ? _b2 : null;
    partOwnerNode["_$litPart$"] = part = new ChildPart(container.insertBefore(createMarker(), endNode), endNode, void 0, options !== null && options !== void 0 ? options : {});
  }
  part._$setValue(value);
  debugLogEvent === null || debugLogEvent === void 0 ? void 0 : debugLogEvent({
    kind: "end render",
    id: renderId,
    value,
    container,
    options,
    part
  });
  return part;
};
if (ENABLE_EXTRA_SECURITY_HOOKS) {
  render.setSanitizer = setSanitizer;
  render.createSanitizer = createSanitizer;
  if (DEV_MODE) {
    render._testOnlyClearSanitizerFactoryDoNotCallOrElse = _testOnlyClearSanitizerFactoryDoNotCallOrElse;
  }
}
export {
  Directive,
  PartType,
  _$LH,
  html,
  noChange,
  nothing,
  render,
  svg,
  unsafeHTML
};
