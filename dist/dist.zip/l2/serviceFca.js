var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css } from "lit";
import { customElement, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
import { initCollabFCATree } from "./_100554_collabFcaTree";
var message_pt = {};
var message_en = {};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceFca100554 = (
  /** @class */
  function(_super) {
    __extends(ServiceFca1005542, _super);
    function ServiceFca1005542() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.activeTab = "AboutFCA";
      _this.details = {
        icon: "&#xf2db",
        state: "background",
        position: "left",
        tooltip: "Service FCA",
        visible: true,
        widget: "_100554_serviceFca",
        level: [4]
      };
      _this.onClickIcon = function(op) {
        _this.activeTab = op;
      };
      _this.menu = {
        title: "",
        actions: {},
        icons: {
          AboutFCA: "About FCA;3f",
          Navigation: "Navigation;f041",
          Properties: "Properties;f0ce",
          Styles: "Styles;f5ad",
          Animation: "Animation;f5ae"
        },
        actionDefault: "",
        // call after close icon clicked
        iconDefault: "AboutFCA",
        setMode: void 0,
        // child will set this
        onClickIcon: _this.onClickIcon,
        getLastMode: void 0,
        updateTitle: void 0
      };
      initCollabFCATree;
      _this.setEvents();
      return _this;
    }
    ServiceFca1005542.prototype.onServiceClick = function(visible, reinit, el) {
      if (visible && reinit) {
        if (this.activeTab !== "Navigation")
          return;
        var elTree = this.querySelector("collab-fca-tree-100554");
        if (elTree && elTree.forceUpdate)
          elTree.forceUpdate();
      }
    };
    ServiceFca1005542.prototype.createRenderRoot = function() {
      return this;
    };
    ServiceFca1005542.prototype.render = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n            ", "\n        "], ["\n            ", "\n        "])), this.renderContent());
    };
    ServiceFca1005542.prototype.renderContent = function() {
      switch (this.activeTab) {
        case "Navigation":
          return this.renderNavigation();
        case "Properties":
          return this.renderProperties();
        case "Styles":
          return this.renderStyles();
        case "Animation":
          return this.renderAnimation();
        case "AboutFCA":
          return this.renderAboutFCA();
        default:
          return html(templateObject_2 || (templateObject_2 = __makeTemplateObject([""], [""])));
      }
    };
    ServiceFca1005542.prototype.renderNavigation = function() {
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(["<collab-fca-tree-100554 .myParent=", "></collab-fca-tree-100554>"], ["<collab-fca-tree-100554 .myParent=", "></collab-fca-tree-100554>"])), this);
    };
    ServiceFca1005542.prototype.renderProperties = function() {
      return html(templateObject_4 || (templateObject_4 = __makeTemplateObject(["<div>In development: Properties</div>"], ["<div>In development: Properties</div>"])));
    };
    ServiceFca1005542.prototype.renderStyles = function() {
      return html(templateObject_5 || (templateObject_5 = __makeTemplateObject(["<div></div>"], ["<div></div>"])));
    };
    ServiceFca1005542.prototype.renderAnimation = function() {
      return html(templateObject_6 || (templateObject_6 = __makeTemplateObject(["<div>In development: Animation</div>"], ["<div>In development: Animation</div>"])));
    };
    ServiceFca1005542.prototype.renderAboutFCA = function() {
      return html(templateObject_7 || (templateObject_7 = __makeTemplateObject(["<div>In develpoment: AboutFCA</div>"], ["<div>In develpoment: AboutFCA</div>"])));
    };
    ServiceFca1005542.prototype.setEvents = function() {
      var _this = this;
      mls.events.addListener(4, "WCDEvent", function(ev) {
        return _this.onWCDEvent(ev);
      });
      mls.events.addListener(4, "WCDEventChange", function(ev) {
        return _this.onWCDEventChange(ev);
      });
    };
    ServiceFca1005542.prototype.onWCDEvent = function(ev) {
      if (!ev.desc)
        return;
      var data = JSON.parse(ev.desc);
      if (this.menu.setIconActive) {
        this.openMe();
        this.menu.setIconActive(data.op);
      }
    };
    ServiceFca1005542.prototype.onWCDEventChange = function(ev) {
      if (this.activeTab !== "Navigation")
        return;
      var elTree = this.querySelector("collab-fca-tree-100554");
      if (elTree && elTree.forceUpdate)
        elTree.forceUpdate();
    };
    ServiceFca1005542.styles = css(templateObject_8 || (templateObject_8 = __makeTemplateObject([""], [""])));
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceFca1005542.prototype, "activeTab", void 0);
    ServiceFca1005542 = __decorate([
      customElement("service-fca-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceFca1005542);
    return ServiceFca1005542;
  }(ServiceBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6, templateObject_7, templateObject_8;
export {
  ServiceFca100554
};
