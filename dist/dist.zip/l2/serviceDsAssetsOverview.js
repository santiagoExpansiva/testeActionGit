var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { html, css } from "lit";
import { customElement } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
import { initCollabInputTag } from "./_100554_collabInputTag";
var message_pt = {
  folder: "Pastas",
  inLocalStorage: "Em local",
  description: "Descri\uFFFD\uFFFDo",
  tags: "Tags",
  deleteFile: "Deletar Arquivo"
};
var message_en = {
  folder: "Folder",
  inLocalStorage: "In local storage",
  description: "Description",
  tags: "Tags",
  deleteFile: "Delete file"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceDsAssetsOverview100554 = (
  /** @class */
  function(_super) {
    __extends(ServiceDsAssetsOverview1005542, _super);
    function ServiceDsAssetsOverview1005542() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.details = {
        icon: "&#xf229",
        state: "foreground",
        tooltip: "Assets Overview",
        visible: false,
        position: "right",
        tags: ["ds_assets"],
        widget: "_100554_serviceDsAssetsOverview",
        level: [3]
      };
      _this.onClickLink = function(op) {
        if (op === "opHelper")
          return _this.showInitial();
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.menu = {
        title: "Assets Overview",
        actions: {
          opHelper: "Assets Overview"
        },
        icons: {},
        actionDefault: "opHelper",
        // call after close icon clicked
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        getLastMode: void 0,
        updateTitle: void 0
      };
      _this.state = {
        multiple: false,
        text: "",
        folder: "",
        inLocalStorage: "",
        readOnly: true,
        description: "",
        tags: "",
        actualFileInfo: void 0,
        actualAssetsItem: null
      };
      _this.setEvents();
      initCollabInputTag();
      return _this;
    }
    ServiceDsAssetsOverview1005542.prototype.onServiceClick = function(visible, reinit, el) {
      this._onServiceClick(visible, reinit, el);
    };
    ServiceDsAssetsOverview1005542.prototype._onServiceClick = function(visible, reinit, el) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          if (visible) {
            this.setData();
            if (el && typeof el.layout === "function")
              el.layout();
          }
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServiceDsAssetsOverview1005542.prototype.setEvents = function() {
      var _this = this;
      mls.events.addEventListener([this.level], ["DSAssetsUnSelected"], function(ev) {
        _this.onDsAssetsUnSelected(ev);
      });
      mls.events.addEventListener([this.level], ["DSAssetsChanged"], function(ev) {
        _this.onDsAssetsChanged(ev);
      });
    };
    ServiceDsAssetsOverview1005542.prototype.onDsAssetsUnSelected = function(ev) {
      if (!ev.desc)
        return;
      var params = JSON.parse(ev.desc);
      if (params.service.includes("_100554_serviceDsAssetsOverview"))
        return;
      this.showNav2Item(false);
    };
    ServiceDsAssetsOverview1005542.prototype.onDsAssetsChanged = function(ev) {
      if (!ev.desc)
        return;
      var params = JSON.parse(ev.desc);
      if (params.position === "right")
        return;
      if (params.info.helper.includes("_100554_serviceDsAssetsOverview")) {
        this.data = params;
        this.showNav2Item(true);
        this.openMe();
        this.setData();
      } else
        this.showNav2Item(false);
    };
    ServiceDsAssetsOverview1005542.prototype.showInitial = function() {
      this.menu.title = "Assets Image";
      this.setData();
      return true;
    };
    ServiceDsAssetsOverview1005542.prototype.setData = function() {
      return __awaiter(this, void 0, void 0, function() {
        var file;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (!this.data)
                return [
                  2
                  /*return*/
                ];
              if (!this.data.info.filesSelectedArr)
                return [2, void 0];
              if (!(this.data.info.filesSelectedArr.length === 0)) return [3, 1];
              this.state.text = "No file selected.";
              this.state.multiple = true;
              this.state.folder = "";
              this.state.inLocalStorage = "";
              return [3, 4];
            case 1:
              if (!(this.data.info.filesSelectedArr.length > 1)) return [3, 2];
              this.state.multiple = true;
              this.state.inLocalStorage = "";
              this.state.text = "".concat(this.data.info.filesSelectedArr.length, " files selected.");
              return [3, 4];
            case 2:
              file = this.data.info.filesSelectedArr[0];
              this.state.actualFileInfo = file;
              this.state.multiple = this.data.info.readOnly;
              this.state.text = file.shortName + file.extension;
              this.state.folder = file.folder;
              this.state.inLocalStorage = file.inLocalStorage.toString();
              return [4, this.prepareStateFile(file)];
            case 3:
              _a.sent();
              _a.label = 4;
            case 4:
              this.state.readOnly = this.data.info.readOnly;
              this.requestUpdate();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsAssetsOverview1005542.prototype.initDs = function() {
      return __awaiter(this, void 0, void 0, function() {
        var project, mode;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              project = mls.actual[5].project;
              mode = mls.actual[3].mode;
              if (project === void 0 || mode === void 0)
                return [
                  2
                  /*return*/
                ];
              this.ds = mls.l3.getDSInstance(project, mode);
              return [4, this.ds.init()];
            case 1:
              _a.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsAssetsOverview1005542.prototype.prepareStateFile = function(file) {
      return __awaiter(this, void 0, void 0, function() {
        var fullname, assetsItem;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              this.state.actualAssetsItem = null;
              this.state.tags = "";
              this.state.description = "";
              return [4, this.initDs()];
            case 1:
              _a.sent();
              if (!this.ds)
                return [
                  2
                  /*return*/
                ];
              fullname = file.shortName + file.extension;
              assetsItem = this.ds.assets.find(file.folder, fullname);
              if (!assetsItem)
                return [
                  2
                  /*return*/
                ];
              this.state.actualAssetsItem = assetsItem;
              this.state.tags = assetsItem.tags ? assetsItem.tags.join(",") : "";
              this.state.description = assetsItem.description;
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsAssetsOverview1005542.prototype.handleKeyUp = function(e) {
      if (!this.ds)
        return;
      var value = e.target.value;
      if (this.state.actualAssetsItem) {
        this.ds.assets.update(this.state.folder, this.state.actualAssetsItem.shortname, this.state.actualAssetsItem.tags, value, this.state.actualAssetsItem.type);
      }
    };
    ServiceDsAssetsOverview1005542.prototype.handleValueChanged = function(value) {
      if (!this.ds)
        return;
      if (this.state.actualAssetsItem) {
        this.ds.assets.update(this.state.folder, this.state.actualAssetsItem.shortname, value.split(","), this.state.actualAssetsItem.description, this.state.actualAssetsItem.type);
      }
    };
    ServiceDsAssetsOverview1005542.prototype.handleDelete = function() {
      return __awaiter(this, void 0, void 0, function() {
        var deletedFile, params;
        var _a;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              if (!this.ds)
                return [
                  2
                  /*return*/
                ];
              if (!(this.state.actualAssetsItem && this.state.actualFileInfo)) return [3, 2];
              deletedFile = this.state.actualFileInfo;
              params = {
                action: "delete",
                info: (_a = this.data) === null || _a === void 0 ? void 0 : _a.info,
                position: "right"
              };
              return [4, this.ds.assets.remove(this.state.folder, this.state.actualAssetsItem.shortname)];
            case 1:
              _b.sent();
              mls.events.fire(3, "DSAssetsChanged", JSON.stringify(params), 0);
              _b.label = 2;
            case 2:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsAssetsOverview1005542.prototype.render = function() {
      var _this = this;
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['\n        <div class="service_assets_overview" >\n            <details open="open" >\n                <summary>', '</summary>\n                <ul >\n                    <li >\n                        <i class="fa-solid fa-folder" ></i>\n                        <span >', ":</span>\n                        <span>", '</span>\n                    </li>\n                    <li ">\n                        <i class="fa-solid fa-database" "></i>\n                        <span ">', ":</span>\n                        <span>", '</span>\n                    </li>\n                </ul>\n                <div class="ds_assets_ds_container" style="display:', '" >\n                    <label>', ':</label>\n                    <textarea rows="5" @input=', ' .value="', '"></textarea>\n                    <label>', ":</label>\n                    <collab-input-tag-100554 .value=", " .onValueChanged=", ' ></collab-input-tag-100554>\n                    <div class="actions">\n                        <button @click=', ">", "</button>\n                    </div>\n                </div>\n            </details>\n        </div>"], ['\n        <div class="service_assets_overview" >\n            <details open="open" >\n                <summary>', '</summary>\n                <ul >\n                    <li >\n                        <i class="fa-solid fa-folder" ></i>\n                        <span >', ":</span>\n                        <span>", '</span>\n                    </li>\n                    <li ">\n                        <i class="fa-solid fa-database" "></i>\n                        <span ">', ":</span>\n                        <span>", '</span>\n                    </li>\n                </ul>\n                <div class="ds_assets_ds_container" style="display:', '" >\n                    <label>', ':</label>\n                    <textarea rows="5" @input=', ' .value="', '"></textarea>\n                    <label>', ":</label>\n                    <collab-input-tag-100554 .value=", " .onValueChanged=", ' ></collab-input-tag-100554>\n                    <div class="actions">\n                        <button @click=', ">", "</button>\n                    </div>\n                </div>\n            </details>\n        </div>"])), this.state.text, this.msg.folder, this.state.folder, this.msg.inLocalStorage, this.state.inLocalStorage, this.state.multiple ? "none;" : "", this.msg.description, function(e) {
        _this.handleKeyUp(e);
      }, this.state.description, this.msg.tags, this.state.tags, function(value) {
        _this.handleValueChanged(value);
      }, function() {
        _this.handleDelete();
      }, this.msg.deleteFile);
    };
    ServiceDsAssetsOverview1005542.styles = css(templateObject_2 || (templateObject_2 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    ServiceDsAssetsOverview1005542 = __decorate([
      customElement("service-ds-assets-overview-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceDsAssetsOverview1005542);
    return ServiceDsAssetsOverview1005542;
  }(ServiceBase)
);
var templateObject_1, templateObject_2;
export {
  ServiceDsAssetsOverview100554
};
