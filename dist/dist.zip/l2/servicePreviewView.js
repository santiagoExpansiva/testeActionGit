var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { html, css, LitElement } from "lit";
import { customElement, property } from "lit/decorators.js";
import { getDependenciesByHtml } from "./_100554_libCompile";
import { convertFileNameToTag } from "./_100554_utilsLit";
var initServicePreviewView = "";
var message_pt = {
  pageNotDefined: "P\uFFFDgina n\uFFFDo definida",
  notFoundStorfile: "Arquivo n\uFFFDo encontrado",
  configure: "Configure seu HTML pela op\uFFFD\uFFFDo do editor!",
  width: "Largura",
  height: "Altura"
};
var message_en = {
  pageNotDefined: "Page not defined",
  notFoundStorfile: "Not found storfile",
  configure: "Configure your html by editor option!",
  width: "Width",
  height: "Height"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServicePreviewView = (
  /** @class */
  function(_super) {
    __extends(ServicePreviewView2, _super);
    function ServicePreviewView2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.msg = messages["en"];
      _this.file = void 0;
      _this.mfile = void 0;
      _this.page = "";
      _this.mode = "d";
      _this.level = "";
      _this.isDsComponent = false;
      _this.watch = true;
      _this.stylechanged = "";
      _this.error = "";
      _this.lastCompiledUrl = "";
      _this.widthP = "300";
      _this.heightP = "600";
      _this.objVariations = {
        0: "en-US",
        1: "pt-BR"
      };
      _this.lastHTML = "";
      _this.timeShow = -1;
      _this.infoDS = {};
      _this.scrollMobile = "\n        .scroll-custom::-webkit-scrollbar {\n            width: 5px;\n        }\n        .scroll-custom::-webkit-scrollbar-track {\n            background: #ddd;\n        }\n        .scroll-custom::-webkit-scrollbar-thumb {\n            background: #666;\n        }\n        .scroll-custom::scrollbar {\n            width: 2px;\n        }\n        .scroll-custom::scrollbar-track {\n            background: #ddd;\n        }\n        .scroll-custom::scrollbar-thumb {\n            background: #666;\n        };\n    ";
      return _this;
    }
    ServicePreviewView2.prototype.connectedCallback = function() {
      _super.prototype.connectedCallback.call(this);
    };
    ServicePreviewView2.prototype.attributeChangedCallback = function(name, oldVal, newVal) {
      if (name === "stylechanged") {
        if (newVal === "true")
          this.addStyles();
        return;
      }
      _super.prototype.attributeChangedCallback.call(this, name, oldVal, newVal);
    };
    ServicePreviewView2.prototype.render = function() {
      var lang = this.father && this.father.getMessageKey ? this.father.getMessageKey(messages) : "en-us";
      this.msg = messages[lang];
      if (this.error !== "")
        return this.renderError();
      else
        return this.renderPreview();
    };
    ServicePreviewView2.prototype.renderError = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['<h3 style="color:red">', "</h3>"], ['<h3 style="color:red">', "</h3>"])), this.error);
    };
    ServicePreviewView2.prototype.renderPreview = function() {
      var _this = this;
      this.watch = this.father.watch;
      this.verifyWC().then(function(res) {
        _this.isDsComponent = res;
      });
      if (this.mode === "m") {
        this.style.cssText = "\n                width:100%;\n                height:100vh;\n                min-height:700px;\n                display: flex!important;\n                flex-direction: column;\n                align-items: center;\n                padding-top:.5rem;\n            ";
        return html(templateObject_2 || (templateObject_2 = __makeTemplateObject([' \n                \n                <div class="groupSetMobile">\n                    <div>\n                        <label>', ':</label>\n                        <input type="number" value="300" @input="', '">\n                    </div>\n                    <div>\n                        <label>', ':</label>\n                        <input type="number" value="700" @input="', '">\n                    </div>\n                    </div> \n                <div class="phone" style="width:', "px; height:", 'px">\n                    <div class="phone_mic"></div>\n                    <div class="phone_screen">\n                        <iframe style="width:100%; height:100%; border:none; display:none"  src="/_100554_servicePreview" @load="', '" ></iframe>\n                    </div>\n                    <div class="phone_button"></div>\n                </div>\n                \n            '], [' \n                \n                <div class="groupSetMobile">\n                    <div>\n                        <label>', ':</label>\n                        <input type="number" value="300" @input="', '">\n                    </div>\n                    <div>\n                        <label>', ':</label>\n                        <input type="number" value="700" @input="', '">\n                    </div>\n                    </div> \n                <div class="phone" style="width:', "px; height:", 'px">\n                    <div class="phone_mic"></div>\n                    <div class="phone_screen">\n                        <iframe style="width:100%; height:100%; border:none; display:none"  src="/_100554_servicePreview" @load="', '" ></iframe>\n                    </div>\n                    <div class="phone_button"></div>\n                </div>\n                \n            '])), this.msg.width, this.changeWidthP, this.msg.height, this.changeHeightP, this.widthP, this.heightP, this.load);
      } else {
        this.style.cssText = "\n                display: block;\n                width: 100%;\n                height: 100%;\n            ";
        return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['\n    \n            <iframe\n                style="width:100%; height:100%; border:none; display:none" src="/_100554_servicePreview"\n                @load="', '" >\n            </iframe>'], ['\n    \n            <iframe\n                style="width:100%; height:100%; border:none; display:none" src="/_100554_servicePreview"\n                @load="', '" >\n            </iframe>'])), this.load);
      }
    };
    ServicePreviewView2.prototype.updated = function(changedProperties) {
      _super.prototype.updated.call(this, changedProperties);
      if (changedProperties.has("level")) {
        var oldLevel = changedProperties.get("level");
        if (!oldLevel)
          return;
        this.fireChangeFCA();
      }
    };
    ServicePreviewView2.prototype.fireChangeFCA = function() {
      if (!this.shadowRoot)
        return;
      var iframe = this.shadowRoot.querySelector("iframe");
      if (!iframe || !iframe.contentDocument)
        return;
      this.changeLevelFca(iframe.contentDocument.body);
    };
    ServicePreviewView2.prototype.changeLevelFca = function(el) {
      var tagEl = el.tagName.toLowerCase();
      if (tagEl.startsWith("fca-")) {
        el.setAttribute("level", this.level);
      }
      for (var _i = 0, _a = el.children; _i < _a.length; _i++) {
        var i = _a[_i];
        this.changeLevelFca(i);
      }
    };
    ServicePreviewView2.prototype.addStyles = function() {
      return __awaiter(this, void 0, void 0, function() {
        var txt, ret, iframe, tag, el, css2, enhacement;
        var _a, _b;
        return __generator(this, function(_c) {
          switch (_c.label) {
            case 0:
              if (!this.mfile)
                return [
                  2
                  /*return*/
                ];
              return [4, this.getFileContent()];
            case 1:
              txt = _c.sent();
              return [4, getDependenciesByHtml(this.mfile, txt, true)];
            case 2:
              ret = _c.sent();
              iframe = (_a = this.shadowRoot) === null || _a === void 0 ? void 0 : _a.querySelector("iframe");
              if (!iframe)
                return [
                  2
                  /*return*/
                ];
              this.mountCSS(ret, iframe);
              this.mountTokens(ret, iframe);
              tag = convertFileNameToTag("_".concat(this.mfile.project, "_").concat(this.mfile.shortName));
              el = (_b = iframe.contentDocument) === null || _b === void 0 ? void 0 : _b.body.querySelector(tag);
              if (!el)
                return [
                  2
                  /*return*/
                ];
              css2 = ret.css.join(" \n");
              return [4, this.getEnhacement()];
            case 3:
              enhacement = _c.sent();
              if (!enhacement)
                return [
                  2
                  /*return*/
                ];
              enhacement.setStylesProcessed(css2, el, tag);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServicePreviewView2.prototype.getEnhacement = function() {
      return __awaiter(this, void 0, void 0, function() {
        var enhacementName, mModule;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (!this.mfile)
                return [
                  2
                  /*return*/
                ];
              enhacementName = this.mfile.compilerResults.tripleSlashMLS.variables.enhancement;
              if (!enhacementName)
                throw new Error("enhacementName not valid");
              return [4, mls.l2.enhancement.getEnhancementInstance(this.mfile)];
            case 1:
              mModule = _a.sent();
              return [2, mModule];
          }
        });
      });
    };
    ServicePreviewView2.prototype.load = function() {
      var _a;
      if (!this.shadowRoot)
        return;
      var iframe = this.shadowRoot.querySelector("iframe");
      var head = (_a = iframe.contentDocument) === null || _a === void 0 ? void 0 : _a.querySelector("head");
      if (head) {
        var base = document.createElement("base");
        base.href = document.baseURI;
        head.appendChild(base);
      }
      this.init(iframe);
    };
    ServicePreviewView2.prototype.init = function(iframe) {
      return __awaiter(this, void 0, void 0, function() {
        var html_1, e_1;
        var _a;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              _b.trys.push([0, 2, , 3]);
              this.setMyFile();
              return [4, this.setHTml(iframe)];
            case 1:
              _b.sent();
              iframe.style.display = "";
              html_1 = (_a = iframe.contentDocument) === null || _a === void 0 ? void 0 : _a.querySelector("html");
              if (html_1)
                html_1.lang = this.objVariations[window.globalVariation] || "en-US";
              this.showLoader(false);
              return [3, 3];
            case 2:
              e_1 = _b.sent();
              this.error = e_1.message;
              this.showLoader(false);
              return [3, 3];
            case 3:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServicePreviewView2.prototype.setMyFile = function() {
      if (!this.page || this.page === "")
        throw new Error(this.msg.pageNotDefined);
      mls.actual[0].setFullName(this.page);
      var info = mls.actual[0];
      var key = mls.stor.getKeyToFiles(info.project, 2, info.path, "", ".html");
      var mkey = mls.l2.editor.getKey({
        project: info.project,
        shortName: info.path
      });
      if (!mls.stor.files[key])
        throw new Error(this.msg.notFoundStorfile + ": " + key);
      if (!mls.l2.editor.mfiles[mkey])
        throw new Error(this.msg.notFoundStorfile + " mfile: " + mkey);
      this.file = mls.stor.files[key];
      this.mfile = mls.l2.editor.mfiles[mkey];
    };
    ServicePreviewView2.prototype.setHTml = function(iframe) {
      return __awaiter(this, void 0, void 0, function() {
        var txt, h, ret;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (!iframe.contentDocument || !this.mfile)
                return [
                  2
                  /*return*/
                ];
              return [4, this.getFileContent()];
            case 1:
              txt = _a.sent();
              if (this.lastHTML === txt) {
                h = this.lastCompiledUrl;
                this.lastCompiledUrl = h;
                return [
                  2
                  /*return*/
                ];
              }
              this.lastHTML = txt;
              iframe.contentDocument.body.innerHTML = txt;
              iframe.contentDocument.body.style.paddingTop = "10px";
              iframe.contentDocument.body["service"] = this.father;
              return [4, getDependenciesByHtml(this.mfile, txt, true)];
            case 2:
              ret = _a.sent();
              this.mountJSImporMap(ret, iframe);
              this.mountJS(ret, iframe);
              this.mountCSS(ret, iframe);
              this.mountTokens(ret, iframe);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServicePreviewView2.prototype.getFileContent = function() {
      return __awaiter(this, void 0, Promise, function() {
        var txt;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              txt = "<h3>" + this.msg.configure + "</h3>";
              if (!(this.file && this.file.getValueInfo)) return [3, 2];
              return [4, this.file.getValueInfo()];
            case 1:
              txt = _a.sent().content;
              _a.label = 2;
            case 2:
              if (!(this.file && txt === null)) return [3, 4];
              return [4, this.file.getContent()];
            case 3:
              txt = _a.sent();
              _a.label = 4;
            case 4:
              return [2, txt];
          }
        });
      });
    };
    ServicePreviewView2.prototype.mountJSImporMap = function(info, ifr) {
      try {
        if (info.importsMap.length <= 0 || !ifr.contentDocument)
          return;
        var js = '{"imports": { ' + info.importsMap.join(",\n") + "} }";
        var script = document.createElement("script");
        script.type = "importmap";
        script.textContent = js;
        ifr.contentDocument.head.appendChild(script);
      } catch (e) {
        console.info("Error mountJSImporMap: " + e.message);
        return;
      }
    };
    ServicePreviewView2.prototype.mountJS = function(info, ifr) {
      var _this = this;
      var _a;
      function loadScripts(scripts) {
        var loadScript = function(src) {
          return new Promise(function(resolve, reject) {
            var _a2;
            var script2 = document.createElement("script");
            script2.type = "module";
            script2.id = src.replace("/", "");
            script2.src = src;
            script2.onload = resolve;
            script2.onerror = reject;
            (_a2 = ifr.contentDocument) === null || _a2 === void 0 ? void 0 : _a2.body.appendChild(script2);
          });
        };
        var nextScript = Promise.resolve();
        var _loop_1 = function(script2) {
          nextScript = nextScript.then(function() {
            return loadScript(script2);
          });
        };
        for (var _i = 0, scripts_1 = scripts; _i < scripts_1.length; _i++) {
          var script = scripts_1[_i];
          _loop_1(script);
        }
        return nextScript;
      }
      try {
        if (info.importsJs.length <= 0 || !ifr.contentDocument)
          return;
        var s = document.createElement("script");
        s.textContent = "\n				window['mls'] = window['mls']  ? window['mls']  : parent.mls ? parent.mls : top['mls'];\n				window['globalVariation'] = window['globalVariation']  ? window['globalVariation']  : parent.globalVariation ? parent.globalVariation : top['globalVariation'];\n				window['latest'] = window['latest']  ? window['latest']  : parent.latest ? parent.latest : top['latest'];\n				window['Quill'] = window['Quill']  ? window['Quill']  : parent.Quill ? parent.Quill : top['Quill'];\n				window['l2_html'] = window['l2_html']  ? window['l2_html']  : parent.l2_html ? parent.l2_html : top['l2_html'];\n                window['monaco'] = window['monaco']  ? window['monaco']  : parent.monaco ? parent.monaco : top['monaco'];\n				window['l2_fieldTypes'] = window['l2_fieldTypes']  ? window['l2_fieldTypes']  : parent.l2_fieldTypes ? parent.l2_fieldTypes : top['l2_fieldTypes'];window['litDisableBundleWarning'] = true; window['collabActualLevel'] = ".concat(this.level, ";\n				");
        (_a = ifr.contentDocument) === null || _a === void 0 ? void 0 : _a.body.appendChild(s);
        loadScripts(info.importsJs).then(function() {
          _this.simulateService(info, ifr);
        });
      } catch (e) {
        console.info("Error mountJS: " + e.message);
      }
    };
    ServicePreviewView2.prototype.simulateService = function(info, ifr) {
      return __awaiter(this, void 0, void 0, function() {
        var txt, tag, instance;
        return __generator(this, function(_a) {
          if (!ifr || !ifr.contentDocument || !ifr.contentWindow)
            return [
              2
              /*return*/
            ];
          if (this.file && this.mfile) {
            txt = this.mfile.model.getValue();
            if (txt.indexOf("extends ServiceBase") === -1)
              return [
                2
                /*return*/
              ];
            tag = convertFileNameToTag("_".concat(this.file.project, "_").concat(this.file.shortName));
            instance = ifr.contentDocument.body.querySelector(tag);
            if (instance) {
              this.addFA(ifr);
              this.addTooltip(ifr);
              this.addNav3(ifr, instance);
            }
          }
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServicePreviewView2.prototype.addTooltip = function(ifr) {
      if (!ifr || !ifr.contentDocument || !ifr.contentWindow)
        return;
      if (!ifr.contentWindow.customElements.get("collab-tooltip")) {
        ifr.contentWindow.customElements.define("collab-tooltip", window["l4_html"].MlsTooltip);
      }
      ifr.contentWindow.customElements.whenDefined("collab-tooltip").then(function() {
        if (!ifr.contentDocument)
          return;
        var collaTbTooltip = document.createElement("collab-tooltip");
        ifr.contentDocument.body.appendChild(collaTbTooltip);
      });
    };
    ServicePreviewView2.prototype.addNav3 = function(ifr, instance) {
      if (!ifr || !ifr.contentDocument || !ifr.contentWindow)
        return;
      if (!ifr.contentWindow.customElements.get("mls-nav3-100529")) {
        ifr.contentWindow.customElements.define("mls-nav3-100529", window["l4_html"]._100529_mls_nav3);
      }
      ifr.contentWindow.customElements.whenDefined("mls-nav3-100529").then(function() {
        if (!ifr.contentDocument)
          return;
        var collabNav = document.createElement("collab-nav");
        collabNav.style.position = "relative";
        collabNav.style.width = "100%";
        collabNav.style.display = "block";
        collabNav["mlsWidget"] = instance;
        var mlsnav3 = document.createElement("mls-nav3-100529");
        mlsnav3.setAttribute("is-mls2", "true");
        collabNav.appendChild(mlsnav3);
        ifr.contentDocument.body.insertBefore(collabNav, instance);
      });
    };
    ServicePreviewView2.prototype.addFA = function(ifr) {
      if (!ifr || !ifr.contentDocument || !ifr.contentWindow)
        return;
      var styleFA = document.createElement("link");
      styleFA.rel = "stylesheet";
      styleFA.href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css";
      styleFA.type = "text/css";
      ifr.contentDocument.head.appendChild(styleFA);
    };
    ServicePreviewView2.prototype.removeOlderStyle = function(ifr) {
      var id = this.getIdStyle();
      if (!ifr.contentDocument || !id)
        return;
      var st = ifr.contentDocument.body.querySelectorAll("#".concat(id));
      st.forEach(function(s) {
        return s.remove();
      });
    };
    ServicePreviewView2.prototype.removeOlderTokens = function(ifr) {
      var id = this.getIdTokens();
      if (!ifr.contentDocument || !id)
        return;
      var st = ifr.contentDocument.body.querySelectorAll("#".concat(id));
      st.forEach(function(s) {
        return s.remove();
      });
    };
    ServicePreviewView2.prototype.mountCSS = function(info, ifr) {
      try {
        if (!ifr.contentDocument)
          return;
        this.removeOlderStyle(ifr);
        var cls = "";
        if (this.mode === "m")
          cls = this.scrollMobile;
        var css_1 = info.css.join(" \n");
        var style = document.createElement("style");
        style.textContent = css_1 + " \n" + cls;
        style.id = this.getIdStyle();
        ifr.contentDocument.body.className = "scroll-custom";
        ifr.contentDocument.body.style.width = "98%";
        ifr.contentDocument.body.appendChild(style);
      } catch (e) {
        console.info("Error mountCSS: " + e.message);
      }
    };
    ServicePreviewView2.prototype.getIdStyle = function() {
      if (!this.mfile)
        return "";
      return "_" + this.mfile.project + "_" + this.mfile.shortName;
    };
    ServicePreviewView2.prototype.getIdTokens = function() {
      if (!this.mfile)
        return "ds_tokens";
      return "_" + this.mfile.project + "_ds_tokens";
    };
    ServicePreviewView2.prototype.mountTokens = function(info, ifr) {
      try {
        if (!ifr.contentDocument)
          return;
        this.removeOlderTokens(ifr);
        var css_2 = info.tokens[0];
        var style = document.createElement("style");
        style.textContent = css_2;
        style.id = this.getIdTokens();
        ifr.contentDocument.body.appendChild(style);
      } catch (e) {
        console.info("Error mountTokens: " + e.message);
      }
    };
    ServicePreviewView2.prototype.changeWidthP = function(e) {
      var el = e.target;
      if (!el)
        return;
      if (el.value === "" || +el.value < 200)
        return;
      this.widthP = el.value;
    };
    ServicePreviewView2.prototype.changeHeightP = function(e) {
      var el = e.target;
      if (!el)
        return;
      if (el.value === "" || +el.value < 250)
        return;
      this.heightP = el.value;
    };
    ServicePreviewView2.prototype.showLoader = function(show) {
      var _this = this;
      clearTimeout(this.timeShow);
      this.timeShow = setTimeout(function() {
        if (!_this.father)
          return;
        _this.father.loading = show;
      }, 200);
    };
    ServicePreviewView2.prototype.verifyWC = function() {
      return __awaiter(this, void 0, void 0, function() {
        var project, comp, info, compName, isAWebComponent;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              project = mls.actual[5].project;
              if (!project)
                throw new Error("No project selected");
              this.infoDS = {
                ds: mls.l3.getDSInstance(project, 0),
                level: +this.level,
                project
              };
              return [4, this.infoDS.ds.init()];
            case 1:
              _a.sent();
              mls.actual[0].setFullName(this.page);
              info = mls.actual[0];
              compName = "_".concat(info.project, "_").concat(info.path);
              if (this.infoDS.ds && this.infoDS.ds.components)
                comp = this.infoDS.ds.components.find(compName);
              if (comp)
                return [2, true];
              return [4, this.checkIfIsAWebComponent(compName)];
            case 2:
              isAWebComponent = _a.sent();
              if (!isAWebComponent)
                return [2, false];
              return [4, this.addComponent(compName, this.infoDS.ds)];
            case 3:
              _a.sent();
              return [2, !!comp];
          }
        });
      });
    };
    ServicePreviewView2.prototype.checkIfIsAWebComponent = function(widget) {
      return __awaiter(this, void 0, Promise, function() {
        var _a, project, path, model, file, content, regex;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              mls.actual[0].setFullName(widget);
              _a = mls.actual[0], project = _a.project, path = _a.path;
              if (!project || !path)
                return [2, false];
              if (path === "servicePreviewView")
                return [2, false];
              model = mls.l2.editor.get({ project, shortName: path });
              if (!model)
                return [2, false];
              file = model.storFile;
              if (!file)
                return [2, false];
              return [4, file.getContent()];
            case 1:
              content = _b.sent();
              if (typeof content !== "string")
                return [2, false];
              regex = /css\`\[\[mls_getDefaultDesignSystem\]\]\`/;
              if (regex.test(content))
                return [2, true];
              return [2, false];
          }
        });
      });
    };
    ServicePreviewView2.prototype.getGroup = function(widget) {
      return __awaiter(this, void 0, Promise, function() {
        var defaultGroup, model, variables, groupName;
        return __generator(this, function(_a) {
          defaultGroup = "other";
          mls.actual[0].setFullName(widget);
          model = mls.l2.editor.get({ project: mls.actual[0].project, shortName: mls.actual[0].path });
          if (!model || !model.compilerResults)
            return [2, defaultGroup];
          variables = model.compilerResults.tripleSlashMLS.variables;
          if (!variables)
            return [2, defaultGroup];
          groupName = variables.groupName;
          if (!groupName)
            return [2, defaultGroup];
          return [2, groupName];
        });
      });
    };
    ServicePreviewView2.prototype.addComponent = function(name, ds) {
      return __awaiter(this, void 0, void 0, function() {
        var group, componentName, widget, err_1, msg;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (!name || !ds)
                return [
                  2
                  /*return*/
                ];
              return [4, this.getGroup(name)];
            case 1:
              group = _a.sent();
              componentName = name;
              widget = {
                docPath: "",
                examples: [],
                group,
                l4MarketingRef: "",
                name: componentName,
                reference: void 0,
                styles: [],
                tags: [],
                widgetExampleRef: {
                  path: "",
                  tagname: ""
                }
              };
              _a.label = 2;
            case 2:
              _a.trys.push([2, 4, , 5]);
              return [4, ds.components.add(widget)];
            case 3:
              _a.sent();
              return [3, 5];
            case 4:
              err_1 = _a.sent();
              msg = "Error on add component in design system";
              this.error = msg;
              throw new Error("Error on add component in design system");
            case 5:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServicePreviewView2.styles = css(templateObject_4 || (templateObject_4 = __makeTemplateObject(["\n        :host{\n            position:relative;\n        }\n\n        .watchDesktop{\n            position: absolute;\n            background: white;\n            box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 2px 2px;\n            top: 3px;\n            right: 46px;\n            border-radius: 50%;\n            width: 30px;\n            height: 30px;\n            display: flex;\n            justify-content: center;\n            align-items: center;\n            cursor: pointer;\n        }\n\n        .groupSetMobile{\n            display:flex;\n            width:300px;\n            gap:.8rem;\n            justify-content: center;\n            align-items: center;\n            margin-bottom:1rem;\n        }\n\n        .groupSetMobile div{\n            display:flex;\n            flex-direction: column;\n            \n        }\n\n        .groupSetMobile label{\n            font-size:.8rem;\n            font-weight:bold;\n        }\n\n        .groupSetMobile input{\n            border:1px solid #cac7c7;\n            outline:none;\n            width:100px;\n            height:20px;\n            border-radius:5px;\n        }\n\n        .phone {\n            z-index: 1;\n            padding: 0 0.5rem;\n            border: 0.25rem solid #404040;\n            border-radius: 1rem;\n            display: flex;\n            flex-direction: column;\n            //box-shadow: 0.5rem 0.5rem rgba(0, 0, 0, 0.3);\n            box-shadow:0px 5px 3px 3px rgba(0, 0, 0, 0.3);\n            background:white;\n        }\n\n        .phone_mic {\n            height: 0.25rem;\n            width: 4rem;\n            margin: 1rem auto;\n            border-radius: 999rem;\n            background-color: #505050;\n        }\n\n        .phone_screen {\n            position: relative;\n            flex: 1 0 auto;\n            border: 1px solid #505050;\n            border-radius:5px;\n        }\n\n        .phone_screen iframe{\n            border-radius:5px;\n        }\n        \n        .phone_button {\n            width: 1.5rem;\n            height: 1.5rem;\n            border: 2px solid #505050;\n            border-radius: 50%;\n            margin: 1rem auto;\n        }\n    \n    "], ["\n        :host{\n            position:relative;\n        }\n\n        .watchDesktop{\n            position: absolute;\n            background: white;\n            box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 2px 2px;\n            top: 3px;\n            right: 46px;\n            border-radius: 50%;\n            width: 30px;\n            height: 30px;\n            display: flex;\n            justify-content: center;\n            align-items: center;\n            cursor: pointer;\n        }\n\n        .groupSetMobile{\n            display:flex;\n            width:300px;\n            gap:.8rem;\n            justify-content: center;\n            align-items: center;\n            margin-bottom:1rem;\n        }\n\n        .groupSetMobile div{\n            display:flex;\n            flex-direction: column;\n            \n        }\n\n        .groupSetMobile label{\n            font-size:.8rem;\n            font-weight:bold;\n        }\n\n        .groupSetMobile input{\n            border:1px solid #cac7c7;\n            outline:none;\n            width:100px;\n            height:20px;\n            border-radius:5px;\n        }\n\n        .phone {\n            z-index: 1;\n            padding: 0 0.5rem;\n            border: 0.25rem solid #404040;\n            border-radius: 1rem;\n            display: flex;\n            flex-direction: column;\n            //box-shadow: 0.5rem 0.5rem rgba(0, 0, 0, 0.3);\n            box-shadow:0px 5px 3px 3px rgba(0, 0, 0, 0.3);\n            background:white;\n        }\n\n        .phone_mic {\n            height: 0.25rem;\n            width: 4rem;\n            margin: 1rem auto;\n            border-radius: 999rem;\n            background-color: #505050;\n        }\n\n        .phone_screen {\n            position: relative;\n            flex: 1 0 auto;\n            border: 1px solid #505050;\n            border-radius:5px;\n        }\n\n        .phone_screen iframe{\n            border-radius:5px;\n        }\n        \n        .phone_button {\n            width: 1.5rem;\n            height: 1.5rem;\n            border: 2px solid #505050;\n            border-radius: 50%;\n            margin: 1rem auto;\n        }\n    \n    "])));
    __decorate([
      property(),
      __metadata("design:type", Object)
    ], ServicePreviewView2.prototype, "father", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServicePreviewView2.prototype, "page", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServicePreviewView2.prototype, "mode", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServicePreviewView2.prototype, "level", void 0);
    __decorate([
      property(),
      __metadata("design:type", Boolean)
    ], ServicePreviewView2.prototype, "isDsComponent", void 0);
    __decorate([
      property(),
      __metadata("design:type", Boolean)
    ], ServicePreviewView2.prototype, "watch", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServicePreviewView2.prototype, "stylechanged", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServicePreviewView2.prototype, "error", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServicePreviewView2.prototype, "lastCompiledUrl", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServicePreviewView2.prototype, "widthP", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServicePreviewView2.prototype, "heightP", void 0);
    ServicePreviewView2 = __decorate([
      customElement("service-preview-view-100554")
    ], ServicePreviewView2);
    return ServicePreviewView2;
  }(LitElement)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4;
export {
  ServicePreviewView,
  initServicePreviewView
};
