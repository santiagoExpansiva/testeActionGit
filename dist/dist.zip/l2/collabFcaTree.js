var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, repeat } from "lit";
import { customElement } from "lit/decorators.js";
import { convertTagToFileName } from "./_100554_utilsLit";
import { CollabLitElement } from "./_100554_collabLitElement";
var initCollabFCATree = "";
var message_pt = {
  noItens: "Nenhum item ICA foi encontrado!"
};
var message_en = {
  noItens: "No ICA items were found!"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var CollabFCATree = (
  /** @class */
  function(_super) {
    __extends(CollabFCATree2, _super);
    function CollabFCATree2() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.idLastClick = "";
      _this.myCss = `
        collab-fca-tree-100554{
            padding: 1rem;
            display:block;
        }
        collab-fca-tree-100554 ul {
            list-style: none;
            padding: 0px 0rem 0rem .5rem;
            border-left: 1px solid #d4d4d4;
        }

        collab-fca-tree-100554 ul li {
            position: relative;
            user-select:none;

        }

        collab-fca-tree-100554 ul li .header {
            padding: .4rem;
            cursor: pointer;
        }

        collab-fca-tree-100554 ul li .header:hover {
            border: 1px solid #d4d4d4;

        }

        collab-fca-tree-100554 ul li .header .dragDropcontainer {
            display:none;
            gap:0.5rem;
        }

        collab-fca-tree-100554 ul li .header.overdragdrop {
            display: flex!important;
            justify-content: space-between;
        }

        collab-fca-tree-100554 ul li .header.overdragdrop .dragDropcontainer {
            display:flex;
            gap:0.5rem;
        }

        collab-fca-tree-100554 ul li .header .dragDropcontainer span {
            display: none;
            justify-content: center;
            align-items: center;
            width:20px;
            heigth:20px;
        }

        collab-fca-tree-100554 ul li .header .dragDropcontainer.b .dbefore {
            display: flex!important;
        }

        collab-fca-tree-100554 ul li .header .dragDropcontainer.i .din {
            display: flex!important;
        }

        collab-fca-tree-100554 ul li .header .dragDropcontainer.a .dAfter {
            display: flex!important;
        }

        collab-fca-tree-100554 ul li div.activeBranch{
            border: 1px solid #d4d4d4;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 5px;
            background: #f8f8f8;
        }

        collab-fca-tree-100554 ul li:before {
            content: ' ';
            position: absolute;
            width: 7px;
            height: 1px;
            background: #d4d4d4;
            top: 1.2rem;
            left: -8px;
        }

        collab-fca-tree-100554 .groupHiddenList {
            border-radius: 4px;
            padding: .3rem;
            transition: all 0.5s;
            cursor: pointer;
            display: none; //flex!important;
            z-index: 9;
            height: .7rem;
            
        }

        collab-fca-tree-100554 ul li div.activeBranch .groupHiddenList{
            display: flex;
            align-items: center;
            position: relative;
        }

        collab-fca-tree-100554 .groupHiddenList::after {
            content: ' ';
            width: 23px;
            height: 19px;
            position: absolute;
            right: -15px;
            background-image:  url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z' fill='rgb(66,65,65,1)'/></svg>");
            background-repeat:no-repeat;
            background-position-y: center;
        }

        collab-fca-tree-100554 .groupHiddenList .mls-gpbtnslider-item {
            display: none;
            transition: 0.5s;
            margin-left: 1rem;
            z-index: 10;
            font-size: 16px;
            line-height: normal;
        }

        collab-fca-tree-100554 .groupHiddenList .mls-gpbtnslider-item:hover {
            color: #1a83ff;
        }
        

        collab-fca-tree-100554 .groupHiddenList.activegpbtnslider {
            padding-right: 24px;
            padding-left: 8px;
        }

        collab-fca-tree-100554 .groupHiddenList.activegpbtnslider .mls-gpbtnslider-item {
            display: inherit;
            text-align: center;
            float: left;
        }
        
    `;
      return _this;
    }
    CollabFCATree2.prototype.createRenderRoot = function() {
      return this;
    };
    CollabFCATree2.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      var ar = this.getFCAComponents();
      if (ar && ar.length > 0)
        return this.createNavigation(ar);
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['<h3 style="padding:1rem">', "<h3>"], ['<h3 style="padding:1rem">', "<h3>"])), this.msg.noItens);
    };
    CollabFCATree2.prototype.createNavigation = function(array) {
      var _this = this;
      var obj = html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n            <ul>\n                ", "\n            </ul><style>", "</style>\n        "], ["\n            <ul>\n                ", "\n            </ul><style>", "</style>\n        "])), repeat(array, function(key, idx) {
        return key.el.tagName + idx;
      }, function(item, index) {
        return _this.renderItemTree(item, index);
      }), this.myCss);
      return obj;
    };
    CollabFCATree2.prototype.renderItemTree = function(item, idx) {
      var _this = this;
      var name = convertTagToFileName(item.el.tagName.toLocaleLowerCase());
      var cls = item.el.renderType === "editactive" ? "activeBranch" : "";
      if (this.idLastClick === name + idx) {
        setTimeout(function() {
          var active = _this.querySelector(".activeBranch");
          if (active)
            active.classList.remove("activeBranch");
          _this.idLastClick = "";
          item.el.click();
        }, 200);
      }
      var mySymbol = "fa-cubes";
      if (item.el.mySymbol)
        mySymbol = item.el.mySymbol;
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['\n            <li>\n                <div id="', '" .info=', ' @mouseover="', '" @mouseleave="', '" class="header ', '" @click="', '">\n                    <info-item><span class="fa ', '" style="margin-right:.5rem"></span>', '</info-item>\n                    <div class="dragDropcontainer">\n                        <span class="dbefore fa fa-arrow-up"></span>\n                        <span class="din fa fa-arrow-turn-down"></span>\n                        <span class="dAfter fa fa-arrow-down"></span>\n                    </div>\n                    <div class="groupHiddenList" .info=', ' @click="', '">\n                        <span class="mls-gpbtnslider-item fa fa-up-down-left-right" title="move" @click="', '"></span>\n                        <span class="mls-gpbtnslider-item fa classLock" @click="', '"></span>\n                        <span class="mls-gpbtnslider-item fa fa-trash" @click="', '" title="remove"></span>\n                    </div>\n                </div>\n                <ul>\n                    ', "\n                </ul>\n            </li>\n        "], ['\n            <li>\n                <div id="', '" .info=', ' @mouseover="', '" @mouseleave="', '" class="header ', '" @click="', '">\n                    <info-item><span class="fa ', '" style="margin-right:.5rem"></span>', '</info-item>\n                    <div class="dragDropcontainer">\n                        <span class="dbefore fa fa-arrow-up"></span>\n                        <span class="din fa fa-arrow-turn-down"></span>\n                        <span class="dAfter fa fa-arrow-down"></span>\n                    </div>\n                    <div class="groupHiddenList" .info=', ' @click="', '">\n                        <span class="mls-gpbtnslider-item fa fa-up-down-left-right" title="move" @click="', '"></span>\n                        <span class="mls-gpbtnslider-item fa classLock" @click="', '"></span>\n                        <span class="mls-gpbtnslider-item fa fa-trash" @click="', '" title="remove"></span>\n                    </div>\n                </div>\n                <ul>\n                    ', "\n                </ul>\n            </li>\n        "])), name + idx, item, this.mouseOver, this.mouseLeave, cls, function(e) {
        return _this.selectItem(e, item);
      }, mySymbol, name, item, this.clickGroupHidden, this.activeMove, this.setLock, this.delEl, repeat(item.children, function(c, idx2) {
        return c.el.tagName + idx2;
      }, function(i, idxI) {
        return _this.renderItemTree(i, idx + "_" + idxI);
      }));
    };
    CollabFCATree2.prototype.forceUpdate = function() {
      this.requestUpdate();
    };
    CollabFCATree2.prototype.setServicePreview = function() {
      if (this.servicePreview || !this.myParent)
        return;
      var nav3 = this.myParent.nav3Service;
      if (!nav3)
        return;
      var wc = nav3.getActiveInstance("right");
      if (!wc)
        return;
      if (wc.tagName.toLowerCase() === "service-preview-100554") {
        this.servicePreview = wc;
      }
    };
    CollabFCATree2.prototype.getFCAComponents = function() {
      var _a;
      this.setServicePreview();
      var ret = [];
      if (!this.servicePreview || !this.servicePreview.parentElement)
        return ret;
      var view = this.servicePreview.parentElement.querySelector("service-preview-view-100554");
      if (!view || !view.shadowRoot)
        return ret;
      var iframe = view.shadowRoot.querySelector("iframe");
      if (!iframe)
        return ret;
      var scope = (_a = iframe.contentDocument) === null || _a === void 0 ? void 0 : _a.body;
      if (!scope)
        return ret;
      var reentrance = function(array, el) {
        var tag = el.tagName.toLowerCase();
        var info;
        if (tag.startsWith("fca-")) {
          info = { el, children: [] };
          array.push(info);
        }
        var isGroup = el.getAttribute("isFCAGroup");
        if (!isGroup || isGroup === "false") {
          Array.from(el.children).forEach(function(i) {
            reentrance(info ? info.children : array, i);
          });
        }
      };
      Array.from(scope.children).forEach(function(i) {
        reentrance(ret, i);
      });
      return ret;
    };
    CollabFCATree2.prototype.selectItem = function(e, item) {
      e.stopPropagation();
      var target = e.target;
      if (target && target.className.indexOf("header") < 0) {
        target = target.closest(".header");
      }
      if (!target)
        return;
      var active = this.querySelector(".activeBranch");
      if (active && active === target)
        return;
      if (active)
        active.classList.remove("activeBranch");
      target.classList.add("activeBranch");
      item.el.style.border = "";
      var father = item.el.closest('*[rendertype="editactive"]');
      if (father) {
        this.idLastClick = target.id;
        item.el.click();
      } else
        item.el.click();
    };
    CollabFCATree2.prototype.clickGroupHidden = function(e) {
      e.stopPropagation();
      var el = e.target;
      if (!el)
        return;
      el.classList.toggle("activegpbtnslider");
      if (!el.info)
        return;
      var lock = "fa-lock-open";
      var isGroup = el.info.el.getAttribute("isFCAGroup");
      if (isGroup || isGroup === "true") {
        lock = "fa-lock";
      }
      var group = el.querySelector(".classLock");
      if (group) {
        group.classList.remove("fa-lock");
        group.classList.remove("fa-lock-open");
        group.title = lock === "fa-lock" ? "lock" : "lock open";
        group.classList.add(lock);
      }
    };
    CollabFCATree2.prototype.setLock = function(e) {
      e.stopPropagation();
      var el = e.target;
      if (!el)
        return;
      var info = el.parentElement.info;
      if (!info)
        return;
      var isGroup = el.className.indexOf("fa-lock-open") < 0;
      info.el.setAttribute("isFCAGroup", (!isGroup).toString());
      var lock = "fa-lock-open";
      if (!isGroup) {
        lock = "fa-lock";
      }
      el.classList.remove("fa-lock");
      el.classList.remove("fa-lock-open");
      el.title = lock === "fa-lock" ? "lock" : "lock open";
      el.classList.add(lock);
      this.requestUpdate();
    };
    CollabFCATree2.prototype.delEl = function(e) {
      e.stopPropagation();
      var el = e.target;
      if (!el)
        return;
      var info = el.parentElement.info;
      if (!info)
        return;
      info.el.remove();
      this.requestUpdate();
    };
    CollabFCATree2.prototype.activeMove = function(e) {
      var _this = this;
      e.stopPropagation();
      var el = e.target;
      if (!el)
        return;
      var info = el.parentElement.info;
      if (!info)
        return;
      var wc = info.el.querySelector("wcd-toolbox-100554");
      if (!wc || !wc.shadowRoot)
        return;
      var move = wc.shadowRoot.querySelector("wcd-toolbox-item-action-move-100554");
      if (move)
        move.click();
      setTimeout(function() {
        _this.setDragDrop(info.el);
      }, 500);
    };
    CollabFCATree2.prototype.setDragDrop = function(active) {
      var _this = this;
      var dragStart = function(e, el) {
        e.stopPropagation();
        if (!el.info)
          return;
        el.style.opacity = "0.4";
      };
      var dragEnter = function(e, el) {
        e.stopPropagation();
        var elLast = _this.querySelector(".overdragdrop");
        if (elLast)
          elLast.classList.remove("overdragdrop");
        el.classList.add("overdragdrop");
      };
      var dragLeave = function(e, el) {
        e.stopPropagation();
      };
      var dragOver = function(e, el) {
        e.stopPropagation();
        e.preventDefault();
        e.dataTransfer.dropEffect = "move";
        return false;
      };
      var dragDrop = function(e, el, mode) {
        e.stopPropagation();
        if (!el.info)
          return;
        mode.click();
        return false;
      };
      var dragEnd = function(e, el) {
        e.stopPropagation();
        try {
          Array.from(listItens).forEach(function(el2) {
            el2.removeAttribute("draggable");
            el2.classList.remove("overdragdrop");
            el2.style.opacity = "";
            el2.ondragstart = function() {
            };
            el2.ondragenter = function() {
            };
            el2.ondragover = function() {
            };
            el2.ondragleave = function() {
            };
            var elbefore = el2.querySelector(".dbefore");
            var elafter = el2.querySelector(".dAfter");
            var elinn = el2.querySelector(".din");
            if (elbefore) {
              elbefore.removeAttribute("draggable");
              elbefore.ondrop = function(e2) {
              };
            }
            if (elafter) {
              elafter.removeAttribute("draggable");
              elafter.ondrop = function(e2) {
              };
            }
            if (elinn) {
              elinn.removeAttribute("draggable");
              elinn.ondrop = function(e2) {
              };
            }
            var cont = el2.querySelector(".dragDropcontainer");
            if (cont) {
              cont.classList.remove("b");
              cont.classList.remove("a");
              cont.classList.remove("i");
            }
            if (el2.info) {
              var elBase = el2.info.el;
              if (!elBase)
                return;
              if (elBase.getAttribute("renderType") === "editactive")
                return;
              elBase.style.position = "";
              var content = elBase.querySelector(":scope > wcd-dragdrop-aux");
              if (!content)
                return;
              content.remove();
            }
          });
        } catch (e2) {
          _this.requestUpdate();
        }
      };
      var addEventsDragAndDrop = function(el) {
        if (!el.info)
          return;
        var rtp = el.info.el.getAttribute("rendertype");
        var wcd = el.info.el.querySelector(":scope > wcd-dragdrop-aux");
        if (!wcd && rtp === "edit")
          return;
        var before = wcd ? wcd.querySelector("wcd-dragdrop-aux-before") : void 0;
        var after = wcd ? wcd.querySelector("wcd-dragdrop-aux-after") : void 0;
        var inn = wcd ? wcd.querySelector("wcd-dragdrop-aux-in") : void 0;
        var elbefore = el.querySelector(".dbefore");
        var elafter = el.querySelector(".dAfter");
        var elinn = el.querySelector(".din");
        var cont = el.querySelector(".dragDropcontainer");
        if (cont && before)
          cont.classList.add("b");
        if (cont && after)
          cont.classList.add("a");
        if (cont && inn)
          cont.classList.add("i");
        if (active === el.info.el) {
          el.ondragstart = function(e) {
            return dragStart(e, el);
          };
        }
        if (active !== el.info.el) {
          el.ondragenter = function(e) {
            return dragEnter(e, el);
          };
          el.ondragover = function(e) {
            return dragOver(e, el);
          };
          el.ondragleave = function(e) {
            return dragLeave(e, el);
          };
          if (before && elbefore) {
            elbefore.setAttribute("draggable", "true");
            elbefore.ondrop = function(e) {
              return dragDrop(e, el, before);
            };
          }
          if (after && elafter) {
            elafter.setAttribute("draggable", "true");
            elafter.ondrop = function(e) {
              return dragDrop(e, el, after);
            };
          }
          if (inn && elinn) {
            elinn.setAttribute("draggable", "true");
            elinn.ondrop = function(e) {
              return dragDrop(e, el, inn);
            };
          }
        }
        el.ondragend = function(e) {
          return dragEnd(e, el);
        };
      };
      var listItens = this.querySelectorAll(".header");
      Array.from(listItens).forEach(function(el) {
        el.setAttribute("draggable", "true");
        addEventsDragAndDrop(el);
      });
    };
    CollabFCATree2.prototype.mouseOver = function(e) {
      e.preventDefault();
      e.stopPropagation();
      var el = e.target;
      if (el && el.className.indexOf("header") < 0) {
        el = el.closest(".header");
      }
      var inOver = el.getAttribute("inOver");
      if (!inOver)
        inOver = "false";
      if (!el || !el.info || inOver === "true" || el.className.indexOf("activeBranch") >= 0)
        return;
      el.info.el.style.border = "1px solid blue";
    };
    CollabFCATree2.prototype.mouseLeave = function(e) {
      e.preventDefault();
      e.stopPropagation();
      var el = e.target;
      if (el && el.className.indexOf("header") < 0) {
        el = el.closest(".header");
      }
      el.removeAttribute("inOver");
      el.info.el.style.border = "";
    };
    CollabFCATree2 = __decorate([
      customElement("collab-fca-tree-100554"),
      __metadata("design:paramtypes", [])
    ], CollabFCATree2);
    return CollabFCATree2;
  }(CollabLitElement)
);
var templateObject_1, templateObject_2, templateObject_3;
export {
  CollabFCATree,
  initCollabFCATree
};
