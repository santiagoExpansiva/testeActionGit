var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { html, css } from "lit";
import { customElement, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
import { convertTagToFileName } from "./_100554_utilsLit";
import { initServicePreviewView } from "./_100554_servicePreviewView";
import { initServicePreviewAddStyle } from "./_100554_servicePreviewAddStyle";
var message_pt = {
  variations: "Varia\uFFFD\uFFFDo",
  editStyle: "Editar estilo",
  pause: "Parar preview"
};
var message_en = {
  variations: "Variation",
  editStyle: "Edit style",
  pause: "Pause preview"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServicePreview100554 = (
  /** @class */
  function(_super) {
    __extends(ServicePreview1005542, _super);
    function ServicePreview1005542() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.itens = void 0;
      _this.error = "";
      _this.watch = true;
      _this.lastMode = "icPreviewD";
      _this.lastLevel = -1;
      _this.elPreview = void 0;
      _this.info = {};
      _this.levels = [1, 2, 3, 4, 5, 6, 7];
      _this.details = {
        icon: "&#xf06e",
        state: "foreground",
        position: "right",
        tooltip: "Preview",
        visible: true,
        widget: "_100554_servicePreview",
        level: [1, 2, 3, 4, 5, 6, 7]
      };
      _this.onClickLink = function(op) {
        if (op === "opAboutTag")
          return _this.opAboutTag();
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.onClickIcon = function(op) {
        _this.lastMode = op;
        if (op === "icPreviewD")
          _this.preview("d");
        if (op === "icPreviewM")
          _this.preview("m");
      };
      _this.onClickButton = function(op, opMenu) {
        if (op === "btWatch")
          return _this.toogleWatch();
        if (op === "btEditStyle")
          return _this.editStyles();
        if (op === "btVariations")
          return _this.onBtVariationsClick(opMenu);
        else
          throw new Error("Invalid option");
      };
      _this.objVariations = {
        0: "en-US",
        1: "pt-BR"
      };
      _this.menu = {
        title: "Preview",
        actions: {},
        icons: {
          icPreviewD: "Desktop;f390",
          icPreviewM: "Mobile;f3cf"
        },
        buttons: {
          btVariations: _this.msg.variations + ";f1ab:menu:0 - Default,1 - Portugues",
          btEditStyle: _this.msg.editStyle + ";f0d0",
          btWatch: _this.msg.pause + ";Update Preview;f04c;f04b"
        },
        actionDefault: "",
        // call after close icon clicked
        iconDefault: "icPreviewD",
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        onClickIcon: _this.onClickIcon,
        onClickButton: _this.onClickButton
      };
      _this.timeEvent = -1;
      _this.htmlAbout = "";
      initServicePreviewView;
      initServicePreviewAddStyle;
      _this.setEvents();
      return _this;
    }
    ServicePreview1005542.prototype.getIframePreviewHTML = function() {
      var _a, _b, _c, _d, _e;
      var htmlEl = (_e = (_d = (_c = (_b = (_a = this.previousElementSibling) === null || _a === void 0 ? void 0 : _a.querySelector("service-preview-view-100554")) === null || _b === void 0 ? void 0 : _b.shadowRoot) === null || _c === void 0 ? void 0 : _c.querySelector("iframe")) === null || _d === void 0 ? void 0 : _d.contentDocument) === null || _e === void 0 ? void 0 : _e.querySelector("html");
      return htmlEl;
    };
    ServicePreview1005542.prototype.onBtVariationsClick = function(opMenu) {
      if (!opMenu)
        return true;
      var htmlEl = this.getIframePreviewHTML();
      var variation = opMenu.substring(0, 1);
      if (htmlEl)
        htmlEl.lang = this.objVariations[variation];
      window.globalVariation = !isNaN(+variation) ? +variation : 0;
      if (window.top)
        window.top.window.globalVariation = !isNaN(+variation) ? +variation : 0;
      this.requestUpdateAllIcaComponentsInPage();
      return true;
    };
    ServicePreview1005542.prototype.toogleWatch = function() {
      this.watch = !this.watch;
      if (this.watch) {
        this.onReloader();
      }
      return this.watch;
    };
    ServicePreview1005542.prototype.editStyles = function() {
      this.openService("_100554_serviceDsStyles", "left", 3);
      return true;
    };
    ServicePreview1005542.prototype.onServiceClick = function(visible, reinit) {
      if (visible && !reinit && this.menu.setIconActive) {
        this.menu.setIconActive(this.lastMode);
      } else if (visible && reinit && this.elPreview && this.menu.setIconActive && this.lastLevel == this.level) {
        this.menu.setIconActive(this.lastMode);
      }
      if (this.elPreview) {
        this.lastLevel = this.level;
        this.elPreview.setAttribute("level", this.level.toString());
      } else {
        this.preview(this.lastMode);
      }
    };
    ServicePreview1005542.prototype.setEvents = function() {
      var _this = this;
      mls.events.addListener(2, "FileAction", this.onMLSFileAction.bind(this));
      mls.events.addEventListener([3], ["DSStyleChanged", "DSColorChanged", "DSCustomChanged", "DSTYPOChanged"], function(ev) {
        return __awaiter(_this, void 0, void 0, function() {
          var rc;
          return __generator(this, function(_a) {
            rc = JSON.parse(ev.desc);
            if (rc.emitter === "right" || rc.emitter === "right-get" || rc.emitter === "left" && rc.helper)
              return [
                2
                /*return*/
              ];
            if (this.watch)
              this.onStyleChanged();
            return [
              2
              /*return*/
            ];
          });
        });
      });
    };
    ServicePreview1005542.prototype.onReloader = function() {
      var _this = this;
      clearTimeout(this.timeEvent);
      this.timeEvent = setTimeout(function() {
        return __awaiter(_this, void 0, void 0, function() {
          return __generator(this, function(_a) {
            this.onServiceClick(true, false);
            mls.events.fire(+this.level, "WCDEventChange", '{"op":"Navigation"}');
            return [
              2
              /*return*/
            ];
          });
        });
      }, 500);
    };
    ServicePreview1005542.prototype.onStyleChanged = function() {
      if (this.elPreview) {
        this.lastLevel = this.level;
        this.elPreview.setAttribute("stylechanged", "true");
      }
    };
    ServicePreview1005542.prototype.onMLSFileAction = function(ev) {
      return __awaiter(this, void 0, Promise, function() {
        var fileAction, eventsValid;
        return __generator(this, function(_a) {
          try {
            if (this.visible === "false" || !this.visible)
              return [
                2
                /*return*/
              ];
            if (ev.level !== +this.level || ev.type !== "FileAction")
              return [
                2
                /*return*/
              ];
            fileAction = JSON.parse(ev.desc);
            eventsValid = ["open", "statusOrErrorChanged", "changed", "new"];
            if (fileAction.position === this.position || !eventsValid.includes(fileAction.action))
              return [
                2
                /*return*/
              ];
            if (this.watch)
              this.onReloader();
          } catch (e) {
            console.info(e);
          }
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServicePreview1005542.prototype.activeMe = function(status, click) {
      if (!this.serviceItemNav)
        return;
      this.serviceItemNav.setAttribute("mode", status);
      if (click)
        this.serviceItemNav.click();
    };
    ServicePreview1005542.prototype.connectedCallback = function() {
      return __awaiter(this, void 0, void 0, function() {
        var dsIndex, ds;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              _super.prototype.connectedCallback.call(this);
              dsIndex = mls.actual[3].mode && +this.level !== 2 ? mls.actual[3].mode : 0;
              ds = mls.l3.getDSInstance(mls.actual[5].project, dsIndex);
              return [4, ds.init()];
            case 1:
              _a.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServicePreview1005542.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject([""], [""])));
    };
    ServicePreview1005542.prototype.setAboutTag = function(tag) {
      return __awaiter(this, void 0, void 0, function() {
        var file;
        return __generator(this, function(_a) {
          try {
            if (!tag)
              return [2, false];
            file = convertTagToFileName(tag.toLocaleLowerCase());
            this.htmlAbout = "  \n                <h3>About this Component</h3>\n                <ul>\n                    <li>Reference: ".concat(file, "</li>\n                    <li>Tag: ").concat(tag, " </li>\n                    <li>Level: 2 </li>                    \n                </ul>");
            if (this.menu.setMenuActive && this.htmlAbout)
              this.menu.setMenuActive("opAboutTag");
          } catch (e) {
            console.info(e);
            return [2, false];
          }
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServicePreview1005542.prototype.opAboutTag = function() {
      var doc = document.createElement("div");
      doc.innerHTML = this.htmlAbout;
      if (this.menu.setMode)
        this.menu.setMode("page", doc);
      return true;
    };
    ServicePreview1005542.prototype.preview = function(mode) {
      return __awaiter(this, void 0, void 0, function() {
        var fullname, doc;
        return __generator(this, function(_a) {
          if (!mls.actual[2].left)
            return [2, true];
          fullname = "_".concat(mls.actual[2].left.project, "_").concat(mls.actual[2].left.shortName);
          this.menu.title = "Preview: " + fullname;
          if (this.menu.updateTitle)
            this.menu.updateTitle();
          doc = document.createElement("service-preview-view-100554");
          doc.setAttribute("page", fullname);
          doc.setAttribute("level", this.level);
          doc.setAttribute("mode", mode);
          doc.father = this;
          this.lastLevel = this.level;
          this.elPreview = doc;
          if (this.menu.setMode)
            this.menu.setMode("page", doc);
          return [2, true];
        });
      });
    };
    ServicePreview1005542.prototype.requestUpdateAllIcaComponentsInPage = function() {
      var _a, _b, _c, _d, _e;
      var elements = (_e = (_d = (_c = (_b = (_a = this.previousElementSibling) === null || _a === void 0 ? void 0 : _a.querySelector("service-preview-view-100554")) === null || _b === void 0 ? void 0 : _b.shadowRoot) === null || _c === void 0 ? void 0 : _c.querySelector("iframe")) === null || _d === void 0 ? void 0 : _d.contentDocument) === null || _e === void 0 ? void 0 : _e.querySelectorAll("*");
      if (!elements)
        return;
      elements.forEach(function(el) {
        if (el.tagName.split("-").length > 1 && el.globalVariation !== void 0) {
          el.globalVariation = window.globalVariation;
        }
      });
    };
    ServicePreview1005542.styles = css(templateObject_2 || (templateObject_2 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", Object)
    ], ServicePreview1005542.prototype, "itens", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServicePreview1005542.prototype, "error", void 0);
    __decorate([
      property(),
      __metadata("design:type", Boolean)
    ], ServicePreview1005542.prototype, "watch", void 0);
    ServicePreview1005542 = __decorate([
      customElement("service-preview-100554"),
      __metadata("design:paramtypes", [])
    ], ServicePreview1005542);
    return ServicePreview1005542;
  }(ServiceBase)
);
var templateObject_1, templateObject_2;
export {
  ServicePreview100554
};
