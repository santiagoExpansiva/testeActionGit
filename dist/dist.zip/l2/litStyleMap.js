var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { noChange } from "./_100554_litHtml";
import { directive, Directive, PartType } from "./_100554_litDirectives";
var important = "important";
var importantFlag = " !" + important;
var flagTrim = 0 - importantFlag.length;
var StyleMapDirective = (
  /** @class */
  function(_super) {
    __extends(StyleMapDirective2, _super);
    function StyleMapDirective2(partInfo) {
      var _a;
      var _this = _super.call(this, partInfo) || this;
      if (partInfo.type !== PartType.ATTRIBUTE || partInfo.name !== "style" || ((_a = partInfo.strings) === null || _a === void 0 ? void 0 : _a.length) > 2) {
        throw new Error("The `styleMap` directive must be used in the `style` attribute and must be the only part in the attribute.");
      }
      return _this;
    }
    StyleMapDirective2.prototype.render = function(styleInfo) {
      return Object.keys(styleInfo).reduce(function(style, prop) {
        var value = styleInfo[prop];
        if (value == null) {
          return style;
        }
        prop = prop.includes("-") ? prop : prop.replace(/(?:^(webkit|moz|ms|o)|)(?=[A-Z])/g, "-$&").toLowerCase();
        return style + "".concat(prop, ":").concat(value, ";");
      }, "");
    };
    StyleMapDirective2.prototype.update = function(part, _a) {
      var _this = this;
      var styleInfo = _a[0];
      var style = part.element.style;
      if (this._previousStyleProperties === void 0) {
        this._previousStyleProperties = /* @__PURE__ */ new Set();
        for (var name in styleInfo) {
          this._previousStyleProperties.add(name);
        }
        return this.render(styleInfo);
      }
      this._previousStyleProperties.forEach(function(name2) {
        if (styleInfo[name2] == null) {
          _this._previousStyleProperties.delete(name2);
          if (name2.includes("-")) {
            style.removeProperty(name2);
          } else {
            style[name2] = "";
          }
        }
      });
      for (var name in styleInfo) {
        var value = styleInfo[name];
        if (value != null) {
          this._previousStyleProperties.add(name);
          var isImportant = typeof value === "string" && value.endsWith(importantFlag);
          if (name.includes("-") || isImportant) {
            style.setProperty(name, isImportant ? value.slice(0, flagTrim) : value, isImportant ? important : "");
          } else {
            style[name] = value;
          }
        }
      }
      return noChange;
    };
    return StyleMapDirective2;
  }(Directive)
);
var styleMap = directive(StyleMapDirective);
export {
  styleMap
};
