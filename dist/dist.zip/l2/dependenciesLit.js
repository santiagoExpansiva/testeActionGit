import { convertTagToFileName } from "./_100554_utilsLit";
import { setErrorOnModel } from "./_100554_validateLit";
function getComponentDependencies(model) {
  var devDoc = model.compilerResults.devDoc;
  if (!devDoc)
    return [];
  var objDocs = JSON.parse(devDoc);
  var tagsInfoString = getJsDocInfoTags(objDocs);
  if (!tagsInfoString)
    return [];
  var regex = /"webComponentDependencies"\s*:\s*(\[.*?\])/;
  var regexVerify = /"webComponentDependencies"\s*:\s*(\[.*?)/;
  var match = tagsInfoString.match(regex);
  var matchVerify = tagsInfoString.match(regexVerify);
  if (matchVerify && !match) {
    model.storFile.hasError = true;
    setErrorOnModel(model.model, 1, 0, 10, "Line breaks are not allowed in webComponentDependencies", monaco.MarkerSeverity.Error);
    mls.events.fireFileAction("statusOrErrorChanged", model.storFile, "left");
    mls.events.fireFileAction("statusOrErrorChanged", model.storFile, "right");
    return [];
  }
  var dependenciesArray = [];
  if (match && match.length === 2) {
    try {
      dependenciesArray = JSON.parse(match[1]);
      dependenciesArray = dependenciesArray.map(function(tag) {
        return convertTagToFileName(tag);
      });
    } catch (error) {
      model.storFile.hasError = true;
      setErrorOnModel(model.model, 1, 0, 10, "Error parsing webComponentDependencies array ", monaco.MarkerSeverity.Error);
      mls.events.fireFileAction("statusOrErrorChanged", model.storFile, "left");
      mls.events.fireFileAction("statusOrErrorChanged", model.storFile, "right");
      dependenciesArray = [];
    }
  }
  return dependenciesArray;
}
function getJsDocInfoTags(objDocs) {
  for (var _i = 0, objDocs_1 = objDocs; _i < objDocs_1.length; _i++) {
    var doc = objDocs_1[_i];
    if (doc.type !== "constructor")
      continue;
    var tagComponentDetails = doc.tags.find(function(tag) {
      return tag.tagName === "mlsComponentDetails";
    });
    if (!tagComponentDetails)
      return "";
    return tagComponentDetails.comment;
  }
}
export {
  getComponentDependencies
};
