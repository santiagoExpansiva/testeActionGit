var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { html, LitElement, unsafeHTML } from "lit";
import { customElement, property } from "lit/decorators.js";
var SimpleGreeting = (
  /** @class */
  function(_super) {
    __extends(SimpleGreeting2, _super);
    function SimpleGreeting2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.project = 100554;
      _this.shortName = "mlsStartL2";
      _this.position = "left";
      _this.folder = "";
      _this.level = 2;
      _this.extension = ".ts";
      _this.loading = true;
      _this.error = "";
      _this.data = [];
      _this.filters = [
        {
          title: "Today",
          maxOffsetDays: 1
        },
        {
          title: "Yesterday",
          maxOffsetDays: 2
        },
        {
          title: "This week",
          maxOffsetWeek: 1
        },
        {
          title: "Last week",
          maxOffsetWeek: 2
        },
        {
          title: "This month",
          maxOffsetMonth: 1
        },
        {
          title: "In {month}",
          maxOffsetMonth: 11
        },
        {
          title: "In {year}"
        }
      ];
      return _this;
    }
    SimpleGreeting2.prototype.connectedCallback = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              _super.prototype.connectedCallback.call(this);
              return [4, this.getListHistory()];
            case 1:
              _a.sent();
              this.loading = false;
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    SimpleGreeting2.prototype.getListHistory = function() {
      return __awaiter(this, void 0, void 0, function() {
        var key, storFile, historie, data, e_1;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              _a.trys.push([0, 2, , 3]);
              key = mls.stor.getKeyToFiles(this.project, this.level, this.shortName, this.folder, this.extension);
              storFile = mls.stor.files[key];
              return [4, storFile.getHistory()];
            case 1:
              historie = _a.sent();
              data = this.createJson(historie);
              this.data = data;
              return [3, 3];
            case 2:
              e_1 = _a.sent();
              this.error = '\n            <div style="width:80%; padding:20px; border:1px solid #eee; border-left-width:5px; border-radius: 3px; margin:10px auto; border-left-color: #d9534f; background-color: rgba(217, 83, 79, 0.1); ">\n                <strong style="color:#d9534f;">Error</strong>- \n                '.concat(e_1, "\n            </div>");
              return [3, 3];
            case 3:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    SimpleGreeting2.prototype.attributeChangedCallback = function(name, oldVal, newVal) {
      _super.prototype.attributeChangedCallback.call(this, name, oldVal, newVal);
      if (name === "msize") {
        var _a = newVal.split(","), width = _a[0], height = _a[1];
        this.style.height = height + "px";
      }
    };
    SimpleGreeting2.prototype.createJson = function(gitObj) {
      var _this = this;
      if (!gitObj)
        return [];
      var today = /* @__PURE__ */ new Date();
      gitObj.forEach(function(item, index) {
        var itemDate = new Date(item.data);
        var yesterday = new Date((/* @__PURE__ */ new Date()).setDate(today.getDate() - 1));
        if (today.toDateString() === itemDate.toDateString())
          item.offsetDay = 0;
        if (yesterday.toDateString() === itemDate.toDateString())
          item.offsetDay = 1;
        if (index === 0)
          item.firstItem = true;
        item.offsetWeek = _this.getWeekOffet(itemDate, today);
        item.offsetMonth = today.getMonth() - itemDate.getMonth();
        item.offsetYear = today.getFullYear() - itemDate.getFullYear();
        item.index = _this.findFirstInFilters(item);
        var filterTitle = _this.filters[item.index].title;
        item.title = filterTitle.replace("{year}", itemDate.getFullYear().toString()).replace("{month}", "".concat(itemDate.getFullYear(), "-").concat(("00" + (itemDate.getMonth() + 1)).slice(-2)));
      });
      return this.createJson2(gitObj);
    };
    SimpleGreeting2.prototype.createJson2 = function(gitObj) {
      var _this = this;
      var ret = [];
      var ret2 = {};
      var objLocal = {};
      objLocal.title = "Local Changes";
      var localAuthor = localStorage.getItem("loginUser") || "unknow";
      var localItem = {
        author: localAuthor,
        authorUrl: "",
        dateAm: "",
        hash: "local",
        time: "",
        type: "item",
        linesDeleted: void 0,
        linesInserted: void 0
      };
      objLocal.type = "title";
      objLocal.itens = [];
      objLocal.itens.push(localItem);
      ret.push(objLocal);
      gitObj.forEach(function(item) {
        if (ret2[item.title])
          ret2[item.title].push(item);
        else
          ret2[item.title] = [item];
      });
      Object.keys(ret2).forEach(function(keys) {
        var obj = {};
        ret.push(obj);
        ret2[keys].forEach(function(item, index) {
          if (index === 0) {
            obj.title = item.title;
            obj.itens = [];
            obj.type = "title";
          }
          var dataItem = new Date(item.data);
          var dataFormat = _this.formatDate(dataItem);
          var objItem = {
            author: item.authorName,
            time: dataFormat,
            dateAm: "",
            hash: item.ref,
            authorUrl: item.authorUrl,
            type: "item",
            linesDeleted: item.deletions,
            linesInserted: item.additions
          };
          obj.itens.push(objItem);
          obj.open = false;
        });
      });
      return ret;
    };
    SimpleGreeting2.prototype.findFirstInFilters = function(item) {
      for (var i = 0; i < this.filters.length; i++) {
        var it = this.filters[i];
        if (it.maxOffsetDays && item.offsetDay < it.maxOffsetDays || it.maxOffsetWeek && item.offsetWeek < it.maxOffsetWeek || it.maxOffsetMonth && item.offsetMonth < it.maxOffsetMonth && item.offsetYear === 0) {
          return i;
        }
      }
      return this.filters.length - 1;
    };
    SimpleGreeting2.prototype.getWeekOffet = function(dateStr, dateEnd) {
      var date1a = dateStr;
      var date2a = dateEnd;
      var dt = new Date(date1a.getFullYear(), 0, 1);
      var w1 = Math.ceil(((date1a - dt) / 864e5 + dt.getDay() + 1) / 7);
      var w2 = Math.ceil(((date2a - dt) / 864e5 + dt.getDay() + 1) / 7);
      return w2 - w1;
    };
    SimpleGreeting2.prototype.formatDate = function(dateValue) {
      var dataFormat = dateValue.getFullYear() + "-" + ("00" + (dateValue.getMonth() + 1)).slice(-2) + "-" + ("00" + dateValue.getDate()).slice(-2) + "  " + ("00" + dateValue.getHours()).slice(-2) + ":" + ("00" + dateValue.getMinutes()).slice(-2) + ":" + ("00" + dateValue.getSeconds()).slice(-2);
      return dataFormat;
    };
    SimpleGreeting2.prototype.createRenderRoot = function() {
      return this;
    };
    SimpleGreeting2.prototype.handleClick = function(a) {
      var target = a.target;
      var li = target.closest("li");
      if (!li)
        return;
      this.querySelectorAll("li").forEach(function(l) {
        return l.classList.remove("active");
      });
      li.classList.add("active");
      var hashModified = li.getAttribute("hash") || "";
      var nextLi = li.nextElementSibling;
      if (!nextLi) {
        var actualUl = li.closest("ul");
        var nextParentUl = actualUl === null || actualUl === void 0 ? void 0 : actualUl.closest("li");
        var nextUlLi = nextParentUl === null || nextParentUl === void 0 ? void 0 : nextParentUl.nextElementSibling;
        var nextUl = nextUlLi === null || nextUlLi === void 0 ? void 0 : nextUlLi.querySelector("ul");
        if (nextUl)
          nextLi = nextUl.children[0];
      }
      var hashOriginal = "";
      if (nextLi)
        hashOriginal = nextLi.getAttribute("hash") || "";
      var obj = {
        project: this.project,
        shortName: this.shortName,
        extension: this.extension,
        position: this.position,
        level: this.level,
        folder: this.folder,
        hashOriginal,
        hashModified
      };
      mls.events.fire([2], "HistoriesSelected", JSON.stringify(obj), 0);
    };
    SimpleGreeting2.prototype.render = function() {
      var _this = this;
      if (this.error !== "") {
        var obj = unsafeHTML(this.error);
        this.error = "";
        return obj;
      }
      return html(templateObject_7 || (templateObject_7 = __makeTemplateObject(["\n      <div>\n        ", "\n      </div>\n    "], ["\n      <div>\n        ", "\n      </div>\n    "])), this.loading ? html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["<p>Loading...</p>"], ["<p>Loading...</p>"]))) : html(templateObject_6 || (templateObject_6 = __makeTemplateObject(["\n        <div>\n          <ul>\n                ", "\n          </ul>\n          \n        </div>\n        "], ["\n        <div>\n          <ul>\n                ", "\n          </ul>\n          \n        </div>\n        "])), this.data.map(function(itemT) {
        return html(templateObject_5 || (templateObject_5 = __makeTemplateObject(['\n                    <li class="historie-title">\n                        <details>\n                            <summary>', "</summary>\n                            <div>\n                                <ul>\n                                    ", "\n                                </ul>\n                            </div>\n                        </details>\n                    </li>\n                "], ['\n                    <li class="historie-title">\n                        <details>\n                            <summary>', "</summary>\n                            <div>\n                                <ul>\n                                    ", "\n                                </ul>\n                            </div>\n                        </details>\n                    </li>\n                "])), itemT.title, itemT.itens.map(function(itemH) {
          return html(templateObject_4 || (templateObject_4 = __makeTemplateObject(['\n                                        <li class="historie-item" hash="', '" @click="', '">\n                                            <svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z"/></svg>\n                                            <span>', '</span>\n                                            <div class="historie-lines" style="', `">
                                                <span class='historie-additions'>+`, "</span>\n                                                <span class='historie-deletions'>-", "</span>\n                                            </div>\n                                            ", " \n                                            <span>", "</span>\n                                        </li>\n                                    "], ['\n                                        <li class="historie-item" hash="', '" @click="', '">\n                                            <svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z"/></svg>\n                                            <span>', '</span>\n                                            <div class="historie-lines" style="', `">
                                                <span class='historie-additions'>+`, "</span>\n                                                <span class='historie-deletions'>-", "</span>\n                                            </div>\n                                            ", " \n                                            <span>", "</span>\n                                        </li>\n                                    "])), itemH.hash, _this.handleClick, itemH.time, itemH.linesInserted === void 0 ? "display:none" : "display:inline-flex", itemH.linesInserted, itemH.linesDeleted, itemH.authorUrl ? html(templateObject_2 || (templateObject_2 = __makeTemplateObject(['<img src="', '" alt="', '"></img>'], ['<img src="', '" alt="', '"></img>'])), itemH.authorUrl, itemH.author) : html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z"/></svg>'], ['<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z"/></svg>']))), itemH.author);
        }));
      })));
    };
    __decorate([
      property({ type: Number }),
      __metadata("design:type", Number)
    ], SimpleGreeting2.prototype, "project", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], SimpleGreeting2.prototype, "shortName", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], SimpleGreeting2.prototype, "position", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], SimpleGreeting2.prototype, "folder", void 0);
    __decorate([
      property({ type: Number }),
      __metadata("design:type", Number)
    ], SimpleGreeting2.prototype, "level", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], SimpleGreeting2.prototype, "extension", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Boolean)
    ], SimpleGreeting2.prototype, "loading", void 0);
    SimpleGreeting2 = __decorate([
      customElement("mls-history-list-100554")
    ], SimpleGreeting2);
    return SimpleGreeting2;
  }(LitElement)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6, templateObject_7;
export {
  SimpleGreeting
};
