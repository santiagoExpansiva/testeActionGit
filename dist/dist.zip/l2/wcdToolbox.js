var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css } from "lit";
import { customElement, property } from "lit/decorators.js";
import { CollabLitElement } from "./_100554_collabLitElement";
import * as states from "./_100554_icaCollabStore";
function initWCDToolbox() {
  return true;
}
var WCDToolbox = (
  /** @class */
  function(_super) {
    __extends(WCDToolbox2, _super);
    function WCDToolbox2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.actions = [];
      return _this;
    }
    Object.defineProperty(WCDToolbox2.prototype, "lastHelper", {
      get: function() {
        if (!this.parentElement)
          return "";
        return this.parentElement["lasthelper"];
      },
      set: function(helper) {
        if (!this.parentElement)
          return;
        this.parentElement["lasthelper"] = helper;
      },
      enumerable: false,
      configurable: true
    });
    WCDToolbox2.prototype.firstUpdated = function() {
      if (this.parentElement) {
        this.parentElement.style.position = "relative";
      }
      if (!this.shadowRoot || !this.parentElement)
        return;
      this.elMain = this.parentElement.querySelector("".concat(this.widget, ":first-child"));
      if (!this.elMain)
        this.elMain = this.parentElement;
      this.renderActions(this.actions);
      this.updateSize(this.elMain, this, true);
      this.setAttribute("title", this.elMain.tagName);
    };
    WCDToolbox2.prototype.updated = function(changedProperties) {
      if (this.parentElement && this.parentElement.renderType === "editactive") {
        this.setIconsWcdToolbox(this.parentElement.actions[this.level]);
      }
    };
    WCDToolbox2.prototype.shouldUpdate = function(changedProperties) {
      if (changedProperties.get("level")) {
        this.lastHelper = "";
      }
      return true;
    };
    WCDToolbox2.prototype.render = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["<wcd-toolbox-aux-background/>"], ["<wcd-toolbox-aux-background/>"])));
    };
    WCDToolbox2.prototype.beforeRemove = function() {
      if (!this.shadowRoot)
        return;
      var allItens = this.shadowRoot.querySelectorAll("*");
      allItens.forEach(function(i) {
        if (i.tagName.toLocaleLowerCase() === "wcd-toolbox-aux-background")
          return;
        if (i.beforeRemove)
          i.beforeRemove();
      });
    };
    WCDToolbox2.prototype.backNavigationScenaryOutdoor = function() {
      if (this.level !== "4")
        return;
      mls.events.fire(4, "WCDEvent", '{"op":"Navigation"}');
    };
    WCDToolbox2.prototype.getAndSetScenaryOutDoor = function(op) {
      var _this = this;
      return new Promise(function(resolve, reject) {
        if (_this.level !== "4")
          resolve(void 0);
        mls.events.fire(4, "WCDEvent", '{"op":"'.concat(op, '"}'));
        setTimeout(function() {
          if (_this.wcServiceFCA) {
            resolve(_this.wcServiceFCA.querySelector("div"));
          } else {
            var nav3 = _this.getNav3();
            if (!nav3 || !_this.elMain)
              resolve(void 0);
            var wc = nav3.getActiveInstance("left");
            if (!wc)
              resolve(void 0);
            if (wc.tagName !== "SERVICE-FCA-100554")
              resolve(void 0);
            else {
              _this.wcServiceFCA = wc;
              resolve(wc.querySelector("div"));
            }
          }
        }, 200);
      });
    };
    WCDToolbox2.prototype.getNav3 = function() {
      if (!this)
        return;
      var bd = this.closest("body");
      if (!bd)
        return;
      var service = bd.service;
      if (!service)
        return;
      var nav3 = service.getNav3Service();
      if (!nav3)
        return;
      return nav3;
    };
    WCDToolbox2.prototype.setIconsWcdToolbox = function(act, useSelf, updataSize) {
      if (useSelf === void 0) {
        useSelf = false;
      }
      if (updataSize === void 0) {
        updataSize = "false";
      }
      if (useSelf)
        this.renderActions(this.actions);
      else
        this.renderActions(act);
      this.updateBackgroundAuxSize();
      if (this.elMain && updataSize === "size")
        this.updateSize(this.elMain, this, true);
      if (this.elMain && updataSize === "padding")
        this.updateBaseNoPadding(this.elMain, this);
    };
    WCDToolbox2.prototype.renderActions = function(arr) {
      var _this = this;
      if (!arr)
        return;
      if (!this.shadowRoot)
        return;
      var lastHelper;
      var allItens = this.shadowRoot.querySelectorAll("*");
      allItens.forEach(function(i) {
        if (i.tagName.toLocaleLowerCase() === "wcd-toolbox-aux-background")
          return;
        i.remove();
      });
      arr.forEach(function(i) {
        switch (i.tp) {
          case "menu":
            _this.addMenu(i);
            break;
          case "button":
            var btnEl = _this.addButton(i);
            if (_this.lastHelper === i.title)
              lastHelper = btnEl;
            break;
          case "back-button":
            _this.addBackButton(i);
            break;
          case "action":
            _this.addAction(i);
            break;
          default:
            "";
        }
      });
      if (lastHelper) {
        lastHelper.click();
      }
    };
    WCDToolbox2.prototype.addMenu = function(item) {
      var _this = this;
      if (!this.elMain || !this.shadowRoot)
        return void 0;
      var menuContainer = document.createElement("wcd-toolbox-menu");
      var container = document.createElement("wcd-toolbox-menu-container");
      var containerItens = document.createElement("wcd-toolbox-itemmenu");
      var iSubItens = document.createElement("a");
      var containerSubItens = document.createElement("wcd-toolbox-submenu");
      menuContainer.className = item.position;
      menuContainer.appendChild(container);
      containerSubItens.onmouseleave = function() {
        containerSubItens.style.display = "none";
      };
      containerSubItens.onclick = function() {
        containerSubItens.style.display = "none";
      };
      item.menuItens.forEach(function(i) {
        if (!i.onclick)
          return;
        var a = document.createElement("a");
        var ic = document.createElement("i");
        ic.title = i.text;
        ic.style.cssText = "width: 18px; background-position: center; height: 18px; background-size: auto; background-repeat: no-repeat;";
        ic.style.backgroundImage = "url('data:image/svg+xml,".concat(i.iconSvg.replace(/\'/g, '"'), "')");
        a.className = "menuItensFcaToolbox";
        a.appendChild(ic);
        containerItens.appendChild(a);
        a.onclick = function(e) {
          e.stopPropagation();
          i.onclick(e, _this);
        };
      });
      if (!item.menuSubItens.find(function(i) {
        return i.text === "About";
      }))
        item.menuSubItens.push(templateAbout);
      container.appendChild(containerItens);
      if (item.menuSubItens.length > 0) {
        iSubItens.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 128 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z"/></svg>';
        iSubItens.onclick = function(e) {
          e.stopPropagation();
          containerSubItens.style.display = containerSubItens.style.display === "" ? "none" : "";
        };
        iSubItens.setAttribute("title", "");
        containerItens.appendChild(iSubItens);
        containerSubItens.style.display = "none";
        container.appendChild(containerSubItens);
      }
      item.menuSubItens.forEach(function(i) {
        if (!i.onclick)
          return;
        var a = document.createElement("a");
        var ic = document.createElement("i");
        var span = document.createElement("span");
        span.innerText = i.text;
        a.title = i.text;
        ic.style.cssText = "width: 18px; background-position: center; height: 18px; background-size: auto; background-repeat: no-repeat;";
        ic.style.backgroundImage = "url('data:image/svg+xml,".concat(i.iconSvg.replace(/\'/g, '"'), "')");
        a.className = "menuSubItensFcaToolbox";
        a.appendChild(ic);
        a.appendChild(span);
        a.onclick = function(e) {
          e.stopPropagation();
          i.onclick(e, _this);
        };
        containerSubItens.appendChild(a);
      });
      this.shadowRoot.appendChild(menuContainer);
      setTimeout(function() {
        var _a;
        if (!_this.isElementVisible(menuContainer)) {
          menuContainer.style.top = "0px";
          var el = (_a = _this.shadowRoot) === null || _a === void 0 ? void 0 : _a.querySelector(".p-m2");
          if (el) {
            menuContainer.style.left = "0px";
            menuContainer.style.transform = "none";
          }
        }
      }, 300);
    };
    WCDToolbox2.prototype.addBackButton = function(item) {
      var _this = this;
      if (!this.shadowRoot || !this.parentElement)
        return;
      var el = document.createElement("wcd-toolbox-item-action-backbutton-100554");
      el.innerHTML = "";
      el.className = "".concat(item.position, " fcaBackButton");
      el.title = item.title;
      el.style.cssText = "width: 18px; background-position: center; height: 18px;\n        background-size: auto; background-repeat: no-repeat; z-index: 9;";
      el.style.backgroundImage = "url('data:image/svg+xml,".concat(item.iconSvg.replace(/\'/g, '"'), "')");
      el.onclick = function(e) {
        e.stopPropagation();
        _this.lastHelper = "";
        if (item.onclick)
          item.onclick(e, _this);
      };
      this.shadowRoot.appendChild(el);
      setTimeout(function() {
        if (!_this.isElementVisible(el)) {
          el.style.top = "0px";
          el.style.right = "0px";
        }
      }, 300);
    };
    WCDToolbox2.prototype.addButton = function(item) {
      var _this = this;
      if (!item.onclick || !this.shadowRoot || !this.parentElement || !["p-r4", "p-m4", "p-l4", "p-l5"].includes(item.position))
        return;
      var el = document.createElement("i");
      el.innerHTML = "";
      el.className = "".concat(item.position, " fcaButtonAction");
      el.title = item.title;
      el.style.cssText = "width: 18px; height: 18px; background: #fff; display:flex; justify-content: center; align-items:center";
      if (item.format === "circle") {
        el.style.cssText += " border-radius:50%; box-shadow: 0 0 4px 1px rgba(57,76,96,.15), 0 0 0 1px rgba(43,59,74,.3);";
      }
      el.innerHTML = item.iconSvg;
      el.onclick = function(e) {
        e.stopPropagation();
        if (item.onclick)
          item.onclick(e, _this);
        _this.lastHelper = item.title;
      };
      this.shadowRoot.appendChild(el);
      setTimeout(function() {
        if (!_this.isElementVisible(el)) {
          el.style.bottom = "0px";
        }
      }, 300);
      return el;
    };
    WCDToolbox2.prototype.addAction = function(act) {
      var _this = this;
      if (!this.elMain || !this.shadowRoot || !act.widget)
        return void 0;
      if (act.isDblClick && act.onclick) {
        this.ondblclick = function(e) {
          if (act.onclick) {
            act.onclick(e, _this, function(vl) {
              _super.prototype.setCollabState.call(_this, states.CHANGESTATE, vl);
            });
          }
        };
        return;
      }
      var el = document.createElement(act.widget);
      el.innerHTML = "";
      if (act.iconSvg && act.iconSvg !== "")
        el.innerHTML = act.iconSvg;
      el.className = "".concat(act.position, " f-").concat(act.format);
      el.myParent = this;
      el.elMain = this.elMain;
      el.elFCA = this.parentElement;
      el.style.cursor = act.cursor;
      if (act.attrs) {
        act.attrs.forEach(function(attr) {
          el.setAttribute(attr.attr, attr.value);
        });
      }
      el.addEventListener("onChange", function(obj) {
        if (!obj || !obj.detail || !obj.detail.valor)
          return;
        _super.prototype.setCollabState.call(_this, states.CHANGESTATE, obj.detail.valor);
      });
      this.shadowRoot.appendChild(el);
    };
    WCDToolbox2.prototype.updateBackgroundAuxSize = function(tp) {
      if (tp === void 0) {
        tp = "hide";
      }
      if (!this.shadowRoot)
        return;
      var elChange = this.shadowRoot.querySelector("wcd-toolbox-aux-background");
      var elBase = this.elMain;
      if (!elBase || !elChange || !this.parentElement)
        return;
      if (tp === "hide") {
        elChange.style.display = "none";
        return;
      }
      var display = elChange.style.display;
      elChange.style.display = "none!important";
      var ad3 = function(n1, s1, s2) {
        return n1 + parseInt(s1, 10) + parseInt(s2, 10);
      };
      var _a = window.getComputedStyle(elBase), marginTop = _a.marginTop, marginBottom = _a.marginBottom, marginLeft = _a.marginLeft, marginRight = _a.marginRight, paddingTop = _a.paddingTop, paddingBottom = _a.paddingBottom, paddingLeft = _a.paddingLeft, paddingRight = _a.paddingRight, fontSize = _a.fontSize;
      var _b = elBase.getBoundingClientRect(), width = _b.width, height = _b.height;
      var heightori = height;
      var left = 0;
      var top = 0;
      left -= parseInt(marginLeft, 10);
      top -= parseInt(marginTop, 10);
      if (top > 0)
        top = 0;
      width = Math.max(ad3(width, marginLeft, marginRight), ad3(0, paddingLeft, paddingRight));
      if (width > elBase.ownerDocument.body.clientWidth)
        width -= 3;
      height = Math.max(ad3(height, marginTop, marginBottom), ad3(0, paddingTop, paddingBottom));
      elChange.style.left = "".concat(left - 1 < 0 ? 0 : left - 1, "px");
      elChange.style.top = "".concat(top - 1, "px");
      elChange.style.width = "".concat(width + 2, "px");
      elChange.style.height = "".concat(height + 2, "px");
      elChange.style.display = display;
      elChange.style.display = this.parentElement.style.display;
      elChange.style.background = "#bdbdbd3d";
      elChange.style.position = "absolute";
      if (elBase.style.height && paddingTop || paddingTop && paddingBottom) {
        elChange.style.top = "-" + (parseInt(paddingTop, 10) + parseInt(fontSize, 10)) + "px";
      } else if (paddingTop !== "0px")
        elChange.style.top = "-" + (heightori - 6) + "px";
      if (paddingLeft !== "0px")
        elChange.style.left = "-" + parseInt(paddingLeft, 10) + "px";
    };
    WCDToolbox2.prototype.updateSize = function(elBase, elChange, changePosition) {
      if (!elBase)
        return;
      setTimeout(function() {
        var display = elChange.style.display;
        elChange.style.display = "none!important";
        var icaBase = elBase.parentElement;
        if (!icaBase)
          return;
        var ad3 = function(n1, s1, s2) {
          return n1 + parseInt(s1, 10) + parseInt(s2, 10);
        };
        var _a = window.getComputedStyle(elBase), marginTop = _a.marginTop, marginBottom = _a.marginBottom, marginLeft = _a.marginLeft, marginRight = _a.marginRight, paddingTop = _a.paddingTop, paddingBottom = _a.paddingBottom, paddingLeft = _a.paddingLeft, paddingRight = _a.paddingRight;
        var _b = elBase.getBoundingClientRect(), width = _b.width, height = _b.height, y = _b.y;
        var topIca = icaBase.getBoundingClientRect().top;
        var left = 0;
        var top = 0;
        left -= parseInt(marginLeft, 10);
        top -= parseInt(marginTop, 10);
        width = Math.max(ad3(width, marginLeft, marginRight), ad3(0, paddingLeft, paddingRight));
        if (width > elBase.ownerDocument.body.clientWidth)
          width -= 3;
        height = Math.max(ad3(height, marginTop, marginBottom), ad3(0, paddingTop, paddingBottom));
        var grandFahter = elBase.parentElement && elBase.parentElement.parentElement ? elBase.parentElement.parentElement : void 0;
        if (grandFahter) {
          var display_1 = window.getComputedStyle(grandFahter).display;
          if (["flex"].includes(display_1) && elBase.parentElement) {
            var fTop = elBase.parentElement.getClientRects()[0].top;
            var bTop = elBase.getClientRects()[0].top;
            top = fTop - bTop;
            top = top < 0 ? top * -1 : top;
          }
        }
        if (changePosition) {
          elChange.style.left = "".concat(left - 1 < 0 ? 0 : left - 1, "px");
          elChange.style.top = "".concat(top - 1, "px");
        }
        elChange.style.width = "".concat(width + 2, "px");
        elChange.style.height = "".concat(height + 2, "px");
        elChange.style.display = display;
      }, 50);
    };
    WCDToolbox2.prototype.updateBaseNoPadding = function(elBase, elChange) {
      var st = elChange.style;
      st.position = "absolute";
      var _a = window.getComputedStyle(elBase), borderTopWidth = _a.borderTopWidth, borderBottomWidth = _a.borderBottomWidth, borderLeftWidth = _a.borderLeftWidth, borderRightWidth = _a.borderRightWidth, paddingTop = _a.paddingTop, paddingBottom = _a.paddingBottom, paddingLeft = _a.paddingLeft, paddingRight = _a.paddingRight;
      var _b = elBase.getBoundingClientRect(), width = _b.width, height = _b.height;
      var cd = function(v1, v2) {
        var rc = parseInt(v1, 10) + parseInt(v2, 10);
        if (rc < 0)
          rc = 0;
        return rc + "px";
      };
      var ci = function(v1, v2) {
        var rc = parseInt(v1, 10) + parseInt(v2, 10);
        if (rc < 0)
          rc = 0;
        return rc;
      };
      var cWidth = ci(paddingLeft, paddingRight);
      var cHeight = ci(paddingTop, paddingBottom);
      if (cWidth > 0 && cWidth < width)
        width = width - cWidth;
      if (cHeight > 0 && cHeight < height)
        height = height - cHeight;
      st.left = cd(paddingLeft, borderLeftWidth);
      st.bottom = cd(paddingBottom, borderBottomWidth);
      st.top = cd(paddingTop, borderTopWidth);
      st.right = cd(paddingRight, borderRightWidth);
      st.width = width + "px";
      st.height = height + "px";
    };
    WCDToolbox2.prototype.isElementVisible = function(element) {
      var rect = element.getBoundingClientRect();
      return rect.top >= 0 && rect.left >= 0 && rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) && rect.right <= (window.innerWidth || document.documentElement.clientWidth);
    };
    WCDToolbox2.styles = css(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n        :host{\n            display:block;\n            border:1px solid #d3cece;\n            position:absolute;\n            user-select:none;\n            z-index:9999;\n            background: #c8c8c8c2; /*#edededc2;*/\n        }\n\n        :host(:hover){\n            border:1px solid purple!important;\n        }\n\n        .itensFcaToolbox:hover{\n            background:purple;\n        }\n\n        .fcaButtonAction{\n            cursor:pointer;\n        }\n\n        .fcaBackButton{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            top:-2rem;\n            right:0px\n        }\n\n        .p-l1{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            top:-6px;\n            left:-6px\n        }\n\n        .p-l2{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            top:50%;\n            left:-6px;\n            transform: translateY(-50%);\n        }\n\n        .p-l3{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            bottom:-6px;\n            left:-6px;\n        }\n\n        .p-l4{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            bottom:-2rem;\n            left:0px;\n        }\n\n        .p-l5{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            top:50%;\n            left:-23px;\n            transform: translateY(-50%);\n        }\n\n        .p-m1{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            top:-6px;\n            left: 50%;\n            transform: translateX(-50%);\n        }\n\n        .p-m2{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            top:50%;\n            left: 50%;\n            transform: translate(-50%, -50%);\n        }\n\n        .p-m3{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            bottom:-6px;\n            left: 50%;\n            transform: translateX(-50%);\n        }\n\n        .p-m4{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            bottom:-2rem;\n            left: 50%;\n            transform: translateX(-50%);\n        }\n\n        .p-r1{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            top:-6px;\n            right:-6px\n        }\n\n        .p-r2{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            top:50%;\n            right:-6px;\n            transform: translateY(-50%);\n        }\n\n        .p-r3{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            bottom:-6px;\n            right:-6px;\n        }\n\n        .p-r4{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            bottom:-2rem;\n            right:-6px;\n        }\n\n        .f-circle{\n            width:10px;\n            height:10px;\n            background:#fff;\n            border-radius:50%;\n            box-shadow: 0 0 4px 1px rgba(57,76,96,.15), 0 0 0 1px rgba(43,59,74,.3);\n        }\n        \n\n        .f-square{\n            width:23px;\n            height:7px;\n            background:#fff;\n            border-radius:3px;\n            box-shadow: 0 0 4px 1px rgba(57,76,96,.15), 0 0 0 1px rgba(43,59,74,.3);\n        }\n\n        .p-l1.f-square{\n            top:-4px;\n            left:-4px\n        }\n\n        .p-l2.f-square{\n            top:50%;\n            left:-4px;\n            width:7px;\n            height:23px;\n        }\n\n        .p-l3.f-square{\n            bottom:-4px;\n            left:-4px;\n        }\n\n        .p-m1.f-square{\n            top:-4px;\n            width:23px;\n            height:7px;\n        }\n\n        .p-m2.f-square{\n            width:23px;\n            height:7px;\n        }\n\n        .p-m3.f-square{\n            bottom:-4px;\n            width:23px;\n            height:7px;\n        }\n\n        .p-r1.f-square{\n            top:-4px;\n            right:-4px\n        }\n\n        .p-r2.f-square{\n            right:-4px;\n            width:7px;\n            height:23px;\n        }\n\n        .p-r3.f-square{\n            bottom:-4px;\n            right:-4px;\n        }\n\n        wcd-toolbox-menu.p-m1{\n            top:-30px\n        }\n\n        wcd-toolbox-menu.p-m3{\n            bottom:-30px\n        }\n\n        wcd-toolbox-menu{\n            display:block;\n            height:17px;\n            border:1px solid #d3cece;\n            padding:.2rem;\n            border-radius:5px;\n            position:relative;\n            background:#fff;\n            \n        }\n\n        wcd-toolbox-menu-container{\n            display:block;\n            position:relative;\n        }\n\n        wcd-toolbox-itemmenu{\n            display:flex;\n            height:20px;\n            gap:.3rem;\n            \n        }\n\n        wcd-toolbox-itemmenu a{\n            display: flex!important;\n            flex-direction: column;\n            align-items: center;\n            justify-content: center;\n            font-size:13px;\n            width:18px;\n            height:18px;\n        }\n\n        wcd-toolbox-itemmenu a:hover{\n            background:#e1e1e1;\n        }\n\n        wcd-toolbox-submenu{\n            position:absolute;\n            top:19px;\n            left:80%;\n            display:flex;\n            flex-direction: column;\n            gap:.3rem;\n            min-width: 150px;\n            min-height: 50px;\n            padding:.5rem;\n            border:1px solid #d3cece;\n            background:#fff;\n            border-bottom-left-radius: 10px;\n            border-bottom-right-radius: 10px;\n            border-top-right-radius: 10px;\n            box-shadow: 0px 1px 4px 1px #e1e1e1;\n        }\n\n        wcd-toolbox-submenu a {\n            font-size:13px;\n            display:flex;\n            gap:.3rem;\n            align-items: center;\n            padding:.1rem;\n        }\n\n        wcd-toolbox-submenu a:hover {\n            background:#e1e1e1;\n        }\n\n\n    "], ["\n        :host{\n            display:block;\n            border:1px solid #d3cece;\n            position:absolute;\n            user-select:none;\n            z-index:9999;\n            background: #c8c8c8c2; /*#edededc2;*/\n        }\n\n        :host(:hover){\n            border:1px solid purple!important;\n        }\n\n        .itensFcaToolbox:hover{\n            background:purple;\n        }\n\n        .fcaButtonAction{\n            cursor:pointer;\n        }\n\n        .fcaBackButton{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            top:-2rem;\n            right:0px\n        }\n\n        .p-l1{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            top:-6px;\n            left:-6px\n        }\n\n        .p-l2{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            top:50%;\n            left:-6px;\n            transform: translateY(-50%);\n        }\n\n        .p-l3{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            bottom:-6px;\n            left:-6px;\n        }\n\n        .p-l4{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            bottom:-2rem;\n            left:0px;\n        }\n\n        .p-l5{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            top:50%;\n            left:-23px;\n            transform: translateY(-50%);\n        }\n\n        .p-m1{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            top:-6px;\n            left: 50%;\n            transform: translateX(-50%);\n        }\n\n        .p-m2{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            top:50%;\n            left: 50%;\n            transform: translate(-50%, -50%);\n        }\n\n        .p-m3{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            bottom:-6px;\n            left: 50%;\n            transform: translateX(-50%);\n        }\n\n        .p-m4{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            bottom:-2rem;\n            left: 50%;\n            transform: translateX(-50%);\n        }\n\n        .p-r1{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            top:-6px;\n            right:-6px\n        }\n\n        .p-r2{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            top:50%;\n            right:-6px;\n            transform: translateY(-50%);\n        }\n\n        .p-r3{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            bottom:-6px;\n            right:-6px;\n        }\n\n        .p-r4{\n            cursor:pointer;\n            display:block;\n            position:absolute;\n            bottom:-2rem;\n            right:-6px;\n        }\n\n        .f-circle{\n            width:10px;\n            height:10px;\n            background:#fff;\n            border-radius:50%;\n            box-shadow: 0 0 4px 1px rgba(57,76,96,.15), 0 0 0 1px rgba(43,59,74,.3);\n        }\n        \n\n        .f-square{\n            width:23px;\n            height:7px;\n            background:#fff;\n            border-radius:3px;\n            box-shadow: 0 0 4px 1px rgba(57,76,96,.15), 0 0 0 1px rgba(43,59,74,.3);\n        }\n\n        .p-l1.f-square{\n            top:-4px;\n            left:-4px\n        }\n\n        .p-l2.f-square{\n            top:50%;\n            left:-4px;\n            width:7px;\n            height:23px;\n        }\n\n        .p-l3.f-square{\n            bottom:-4px;\n            left:-4px;\n        }\n\n        .p-m1.f-square{\n            top:-4px;\n            width:23px;\n            height:7px;\n        }\n\n        .p-m2.f-square{\n            width:23px;\n            height:7px;\n        }\n\n        .p-m3.f-square{\n            bottom:-4px;\n            width:23px;\n            height:7px;\n        }\n\n        .p-r1.f-square{\n            top:-4px;\n            right:-4px\n        }\n\n        .p-r2.f-square{\n            right:-4px;\n            width:7px;\n            height:23px;\n        }\n\n        .p-r3.f-square{\n            bottom:-4px;\n            right:-4px;\n        }\n\n        wcd-toolbox-menu.p-m1{\n            top:-30px\n        }\n\n        wcd-toolbox-menu.p-m3{\n            bottom:-30px\n        }\n\n        wcd-toolbox-menu{\n            display:block;\n            height:17px;\n            border:1px solid #d3cece;\n            padding:.2rem;\n            border-radius:5px;\n            position:relative;\n            background:#fff;\n            \n        }\n\n        wcd-toolbox-menu-container{\n            display:block;\n            position:relative;\n        }\n\n        wcd-toolbox-itemmenu{\n            display:flex;\n            height:20px;\n            gap:.3rem;\n            \n        }\n\n        wcd-toolbox-itemmenu a{\n            display: flex!important;\n            flex-direction: column;\n            align-items: center;\n            justify-content: center;\n            font-size:13px;\n            width:18px;\n            height:18px;\n        }\n\n        wcd-toolbox-itemmenu a:hover{\n            background:#e1e1e1;\n        }\n\n        wcd-toolbox-submenu{\n            position:absolute;\n            top:19px;\n            left:80%;\n            display:flex;\n            flex-direction: column;\n            gap:.3rem;\n            min-width: 150px;\n            min-height: 50px;\n            padding:.5rem;\n            border:1px solid #d3cece;\n            background:#fff;\n            border-bottom-left-radius: 10px;\n            border-bottom-right-radius: 10px;\n            border-top-right-radius: 10px;\n            box-shadow: 0px 1px 4px 1px #e1e1e1;\n        }\n\n        wcd-toolbox-submenu a {\n            font-size:13px;\n            display:flex;\n            gap:.3rem;\n            align-items: center;\n            padding:.1rem;\n        }\n\n        wcd-toolbox-submenu a:hover {\n            background:#e1e1e1;\n        }\n\n\n    "])));
    __decorate([
      property({ type: String, reflect: true }),
      __metadata("design:type", String)
    ], WCDToolbox2.prototype, "level", void 0);
    __decorate([
      property({ type: String, reflect: true }),
      __metadata("design:type", String)
    ], WCDToolbox2.prototype, "widget", void 0);
    WCDToolbox2 = __decorate([
      customElement("wcd-toolbox-100554")
    ], WCDToolbox2);
    return WCDToolbox2;
  }(CollabLitElement)
);
var templateAbout = {
  text: "About",
  iconSvg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M464 256A208 208 0 1 0 48 256a208 208 0 1 0 416 0zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zm169.8-90.7c7.9-22.3 29.1-37.3 52.8-37.3h58.3c34.9 0 63.1 28.3 63.1 63.1c0 22.6-12.1 43.5-31.7 54.8L280 264.4c-.2 13-10.9 23.6-24 23.6c-13.3 0-24-10.7-24-24V250.5c0-8.6 4.6-16.5 12.1-20.8l44.3-25.4c4.7-2.7 7.6-7.7 7.6-13.1c0-8.4-6.8-15.1-15.1-15.1H222.6c-3.4 0-6.4 2.1-7.5 5.3l-.4 1.2c-4.4 12.5-18.2 19-30.6 14.6s-19-18.2-14.6-30.6l.4-1.2zM224 352a32 32 0 1 1 64 0 32 32 0 1 1 -64 0z"/></svg>',
  onclick: function(e, wc) {
    var bd = wc.closest("body");
    if (bd.service && bd.service.setAboutTag)
      bd.service.setAboutTag(wc.title.toLocaleLowerCase());
  }
};
var templateObject_1, templateObject_2;
export {
  WCDToolbox,
  initWCDToolbox
};
