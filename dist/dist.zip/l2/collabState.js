var isTrace = false;
var CollabState = (
  /** @class */
  function() {
    function CollabState2() {
      this.stateMap = /* @__PURE__ */ new Map();
      this.componentMap = /* @__PURE__ */ new Map();
    }
    CollabState2.prototype.setState = function(key, value) {
      var oldValue = this.stateMap.get(key);
      if (isTrace)
        console.info("setState key: " + key + " value=", value, ", oldValue=", oldValue);
      if (oldValue !== value) {
        this.stateMap.set(key, value);
        this.notify(key);
      }
    };
    CollabState2.prototype.getState = function(key) {
      var value = this.stateMap.get(key);
      if (isTrace)
        console.info("getState key: " + key + " value=", value);
      return value;
    };
    CollabState2.prototype.subscribe = function(keyOrKeys, component) {
      var _this = this;
      var keys = Array.isArray(keyOrKeys) ? keyOrKeys : [keyOrKeys];
      keys.forEach(function(key) {
        if (!_this.componentMap.has(key)) {
          _this.componentMap.set(key, /* @__PURE__ */ new Set());
        }
        _this.componentMap.get(key).add(component);
      });
    };
    CollabState2.prototype.unsubscribe = function(keyOrKeys, component) {
      var _this = this;
      var keys = Array.isArray(keyOrKeys) ? keyOrKeys : [keyOrKeys];
      keys.forEach(function(key) {
        var _a;
        (_a = _this.componentMap.get(key)) === null || _a === void 0 ? void 0 : _a.delete(component);
      });
    };
    CollabState2.prototype.notify = function(key) {
      var _this = this;
      var _a;
      (_a = this.componentMap.get(key)) === null || _a === void 0 ? void 0 : _a.forEach(function(component) {
        if ("handleCollabStateChange" in component) {
          component["handleCollabStateChange"](key, _this.getState(key));
        }
      });
    };
    CollabState2.prototype.getStateStatistics = function() {
      var statistics = /* @__PURE__ */ new Map();
      this.componentMap.forEach(function(value, key) {
        statistics.set(key, value.size);
      });
      return statistics;
    };
    return CollabState2;
  }()
);
export {
  CollabState
};
