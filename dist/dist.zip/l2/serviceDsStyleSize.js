var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css } from "lit";
import { customElement, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
import { initCollabDSInputRange } from "./_100554_collabDsInputRange";
var message_pt = {
  width: "Largura",
  maxWidth: "Largura m\uFFFDxima",
  minWidth: "Largura m\uFFFDnima",
  height: "Altura",
  maxHeight: "Altura m\uFFFDxima",
  minHeight: "Altura m\uFFFDnima",
  overflow: "Overflow",
  overflowX: "Overflow-x",
  overflowY: "Overflow-y"
};
var message_en = {
  width: "Width",
  maxWidth: "Max Width",
  minWidth: "Min Width",
  height: "Height",
  maxHeight: "Max Height",
  minHeight: "Min Height",
  overflow: "Overflow",
  overflowX: "Overflow-x",
  overflowY: "Overflow-y"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceDsStyleSize = (
  /** @class */
  function(_super) {
    __extends(ServiceDsStyleSize2, _super);
    function ServiceDsStyleSize2() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.myUpp = false;
      _this.error = "";
      _this.helper = "_100554_serviceDsStyleSize";
      _this.details = {
        icon: "&#xf07e",
        state: "foreground",
        position: "right",
        tooltip: "Size",
        visible: false,
        widget: "_100554_serviceDsStyleSize",
        tags: ["ds_styles"],
        level: [3]
      };
      _this.onClickLink = function(op) {
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.onClickIcon = function(op) {
      };
      _this.menu = {
        title: "Size",
        actions: {},
        icons: {},
        actionDefault: "",
        // call after close icon clicked
        iconDefault: "",
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        onClickIcon: _this.onClickIcon
      };
      _this.tpMeasures = ["px", "em", "rem", "vh", "vw", "vmin", "vmax", "ex", "ch", "auto"];
      _this.timeonChangeProp = -1;
      _this.timeLoader = -1;
      initCollabDSInputRange();
      _this.setEvents();
      return _this;
    }
    ServiceDsStyleSize2.prototype.onServiceClick = function(visible, reinit) {
      if (visible || reinit) {
        this.fireEventAboutMe();
      }
    };
    ServiceDsStyleSize2.prototype.setEvents = function() {
      var _this = this;
      mls.events.addEventListener([3], ["DSStyleChanged"], function(ev) {
        _this.onstylechanged(ev.desc);
      });
      mls.events.addEventListener([3], ["DSStyleSelected"], function(ev) {
        _this.onDSStyleSelected(ev);
      });
      mls.events.addEventListener([3], ["DSStyleUnSelected"], function(ev) {
        _this.onDSStyleUnSelected(ev);
      });
      mls.events.addEventListener([3], ["DSStyleCursorChanged"], function(ev) {
        _this.onDSStyleCursorChanged(ev);
      });
    };
    ServiceDsStyleSize2.prototype.onstylechanged = function(desc) {
      var obj = JSON.parse(desc);
      if (obj.emitter === "left" && this.visible === "true" && obj.value.length > 0) {
        this.setValues(obj.value);
      }
    };
    ServiceDsStyleSize2.prototype.setValues = function(ar) {
      var _this = this;
      this.myUpp = true;
      ar.forEach(function(i) {
        if (!_this.shadowRoot || !i.key)
          return;
        var value = i.value;
        var prop = i.key;
        if (prop === "overflow") {
          var elGroup = _this.shadowRoot.querySelector('*[prop="overflow"]');
          var el = _this.shadowRoot.querySelector('*[prop="overflow-x"]');
          var el2 = _this.shadowRoot.querySelector('*[prop="overflow-y"]');
          if (elGroup)
            elGroup.checked = true;
          if (el)
            el.value = value;
          if (el2)
            el2.value = value;
        } else {
          var el = _this.shadowRoot.querySelector('*[prop="' + prop + '"]');
          if (el)
            el.value = value;
        }
      });
      this.myUpp = false;
    };
    ServiceDsStyleSize2.prototype.onDSStyleSelected = function(ev) {
      var params = ev.desc ? JSON.parse(ev.desc) : [];
      if (params.service.length > 0 && !params.service.includes(this.helper) || !this.serviceItemNav)
        return;
      this.serviceItemNav.setAttribute("mode", "A");
      this.showNav2Item(true);
    };
    ServiceDsStyleSize2.prototype.onDSStyleUnSelected = function(ev) {
      var params = ev.desc ? JSON.parse(ev.desc) : [];
      if (params.service.includes(this.helper) || !this.serviceItemNav)
        return;
      this.serviceItemNav.setAttribute("mode", "H");
      this.showNav2Item(false);
    };
    ServiceDsStyleSize2.prototype.onDSStyleCursorChanged = function(ev) {
      var rc = JSON.parse(ev.desc);
      if (rc.helper === this.helper) {
        if (this.visible === "true" || !this.serviceItemNav)
          return;
        this.serviceItemNav.click();
      }
    };
    ServiceDsStyleSize2.prototype.connectedCallback = function() {
      _super.prototype.connectedCallback.call(this);
    };
    ServiceDsStyleSize2.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      if (this.error)
        return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['<h3 style="color:red">', "</h3>"], ['<h3 style="color:red">', "</h3>"])), this.error);
      return this.renderBody();
    };
    ServiceDsStyleSize2.prototype.renderBody = function() {
      return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n            ", "\n            ", "\n            ", "\n        "], ["\n            ", "\n            ", "\n            ", "\n        "])), this.renderWidth(), this.renderHeight(), this.renderOverflow());
    };
    ServiceDsStyleSize2.prototype.renderWidth = function() {
      var _this = this;
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(["\n            <div>\n                <h5>", '</h5>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="width" value="0px" .arraySelect=', ' @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="max-width" value="0px" .arraySelect=', ' @onchange="', '"></collab-ds-input-range-100554>    \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="min-width" value="0px" .arraySelect=', ' @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n            </div>\n        '], ["\n            <div>\n                <h5>", '</h5>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="width" value="0px" .arraySelect=', ' @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="max-width" value="0px" .arraySelect=', ' @onchange="', '"></collab-ds-input-range-100554>    \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="min-width" value="0px" .arraySelect=', ' @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n            </div>\n        '])), this.msg.width, this.msg.width, this.tpMeasures, function(e) {
        return _this.onChangeProp(e.detail);
      }, this.msg.maxWidth, this.tpMeasures, function(e) {
        return _this.onChangeProp(e.detail);
      }, this.msg.minWidth, this.tpMeasures, function(e) {
        return _this.onChangeProp(e.detail);
      });
    };
    ServiceDsStyleSize2.prototype.renderHeight = function() {
      var _this = this;
      return html(templateObject_4 || (templateObject_4 = __makeTemplateObject(["\n            <div>\n                <h5>", '</h5>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="height" value="0px" .arraySelect=', ' @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="max-height" value="0px" .arraySelect=', ' @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="min-height" value="0px" .arraySelect=', ' @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n            </div>\n        '], ["\n            <div>\n                <h5>", '</h5>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="height" value="0px" .arraySelect=', ' @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="max-height" value="0px" .arraySelect=', ' @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="min-height" value="0px" .arraySelect=', ' @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n            </div>\n        '])), this.msg.height, this.msg.height, this.tpMeasures, function(e) {
        return _this.onChangeProp(e.detail);
      }, this.msg.maxHeight, this.tpMeasures, function(e) {
        return _this.onChangeProp(e.detail);
      }, this.msg.minHeight, this.tpMeasures, function(e) {
        return _this.onChangeProp(e.detail);
      });
    };
    ServiceDsStyleSize2.prototype.renderOverflow = function() {
      var _this = this;
      return html(templateObject_5 || (templateObject_5 = __makeTemplateObject(["\n            <div>\n                <h5>", '</h5>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <input type="checkbox" prop="overflow"></input>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" prop="overflow-x" group="overflow">\n                        <option value="none">none</option>\n                        <option value="auto">auto</option>\n                        <option value="hidden">hidden</option>\n                        <option value="inherit">inherit</option>\n                        <option value="initial">initial</option>\n                        <option value="overlay">overlay</option>\n                        <option value="revert">revert</option>\n                        <option value="scroll">scroll</option>\n                        <option value="unset">unset</option>\n                        <option value="visible">visible</option>\n                    </select>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" prop="overflow-y" group="overflow">\n                        <option value="none">none</option>\n                        <option value="auto">auto</option>\n                        <option value="hidden">hidden</option>\n                        <option value="inherit">inherit</option>\n                        <option value="initial">initial</option>\n                        <option value="overlay">overlay</option>\n                        <option value="revert">revert</option>\n                        <option value="scroll">scroll</option>\n                        <option value="unset">unset</option>\n                        <option value="visible">visible</option>\n                    </select>\n                </div>\n            </div>\n        '], ["\n            <div>\n                <h5>", '</h5>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <input type="checkbox" prop="overflow"></input>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" prop="overflow-x" group="overflow">\n                        <option value="none">none</option>\n                        <option value="auto">auto</option>\n                        <option value="hidden">hidden</option>\n                        <option value="inherit">inherit</option>\n                        <option value="initial">initial</option>\n                        <option value="overlay">overlay</option>\n                        <option value="revert">revert</option>\n                        <option value="scroll">scroll</option>\n                        <option value="unset">unset</option>\n                        <option value="visible">visible</option>\n                    </select>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" prop="overflow-y" group="overflow">\n                        <option value="none">none</option>\n                        <option value="auto">auto</option>\n                        <option value="hidden">hidden</option>\n                        <option value="inherit">inherit</option>\n                        <option value="initial">initial</option>\n                        <option value="overlay">overlay</option>\n                        <option value="revert">revert</option>\n                        <option value="scroll">scroll</option>\n                        <option value="unset">unset</option>\n                        <option value="visible">visible</option>\n                    </select>\n                </div>\n            </div>\n        '])), this.msg.overflow, this.msg.overflow, this.msg.overflowX, function(e) {
        return _this.onChangeProp2("overflow-x");
      }, this.msg.overflowY, this.onChangeProp2);
    };
    ServiceDsStyleSize2.prototype.onChangeProp2 = function(prop) {
      var _this = this;
      clearTimeout(this.timeonChangeProp);
      this.timeonChangeProp = setTimeout(function() {
        if (!_this.shadowRoot)
          return;
        var elGroup = _this.shadowRoot.querySelector('*[prop="overflow"]');
        var isGroup = elGroup && elGroup.checked;
        if (isGroup) {
          var el = _this.shadowRoot.querySelector('*[prop="' + prop + '"]');
          var el2 = _this.shadowRoot.querySelector('*[prop="' + (prop === "overflow-x" ? "overflow-y" : "overflow-x") + '"]');
          if (el2)
            el2.value = el.value;
          _this.emitEvent({ key: "overflow", value: el.value });
        } else {
          var el = _this.shadowRoot.querySelector('*[prop="' + prop + '"]');
          _this.emitEvent({ key: prop, value: el.value });
        }
      }, 500);
    };
    ServiceDsStyleSize2.prototype.onChangeProp = function(obj) {
      var _this = this;
      clearTimeout(this.timeonChangeProp);
      this.timeonChangeProp = setTimeout(function() {
        _this.emitEvent(obj);
      }, 500);
    };
    ServiceDsStyleSize2.prototype.fireEventAboutMe = function() {
      var rc = {
        emitter: "right-get"
      };
      mls.events.fire([3], ["DSStyleChanged"], JSON.stringify(rc), 500);
    };
    ServiceDsStyleSize2.prototype.emitEvent = function(obj) {
      if (this.myUpp)
        return;
      if (obj.target)
        delete obj.target;
      var rc = {
        emitter: this.position,
        value: [obj],
        helper: this.helper
      };
      if (typeof mls !== "object")
        return;
      mls.events.fire([3], ["DSStyleChanged"], JSON.stringify(rc));
    };
    ServiceDsStyleSize2.prototype.showLoader = function(loader) {
      var _this = this;
      clearTimeout(this.timeLoader);
      this.timeLoader = setTimeout(function() {
        _this.loading = loader;
      }, 200);
    };
    ServiceDsStyleSize2.styles = css(templateObject_6 || (templateObject_6 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceDsStyleSize2.prototype, "error", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceDsStyleSize2.prototype, "helper", void 0);
    ServiceDsStyleSize2 = __decorate([
      customElement("service-ds-style-size-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceDsStyleSize2);
    return ServiceDsStyleSize2;
  }(ServiceBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6;
export {
  ServiceDsStyleSize
};
