var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css } from "lit";
import { customElement, property } from "lit/decorators.js";
import { IcaFormsInputSelectOne } from "./_100554_icaFormsInputSelectOne";
import { propertyDataSource, propertyCompositeDataSource } from "./_100554_icaLitElement";
var WcSelectOne = (
  /** @class */
  function(_super) {
    __extends(WcSelectOne2, _super);
    function WcSelectOne2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.required = false;
      _this.disabled = false;
      return _this;
    }
    WcSelectOne2.prototype.render = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n        <label>", '<label>\n        <br>\n        <select\n            class="select_control" \n            ?disabled=', " \n            ?required=", "\n            .value=", " \n            @change=", "\n        >\n            ", "\n        </select>\n        <small> ", "</small>\n    "], ["\n        <label>", '<label>\n        <br>\n        <select\n            class="select_control" \n            ?disabled=', " \n            ?required=", "\n            .value=", " \n            @change=", "\n        >\n            ", "\n        </select>\n        <small> ", "</small>\n    "])), this.label, this.disabled, this.required, this.selectedvalue, this.handleChange, this.renderOpt(), this.hint || "");
    };
    WcSelectOne2.prototype.renderOpt = function() {
      if (this.options) {
        return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(["\n                ", "\n        "], ["\n                ", "\n        "])), this.options.map(function(opt) {
          return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["<option value=", ">", "</option>"], ["<option value=", ">", "</option>"])), opt.key, opt.value);
        }));
      }
    };
    WcSelectOne2.prototype.handleChange = function(event) {
      var selectElement = event.target;
      this.selectedvalue = selectElement.value;
    };
    WcSelectOne2.styles = css(templateObject_4 || (templateObject_4 = __makeTemplateObject(["\n    :host {\n        display: block;\n    }\n\n    .select_control {\n        display: block;\n        width:100%;\n        padding: 0.375rem 0.75rem;\n        font-size: 1rem;\n        font-weight: 400;\n        line-height: 1.5;\n        color: #212529;\n        background-color: #fff;\n        background-clip: padding-box;\n        border: 1px solid #ced4da;\n        border-radius: 0.25rem;\n        transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;\n        outline:none;\n    }\n    "], ["\n    :host {\n        display: block;\n    }\n\n    .select_control {\n        display: block;\n        width:100%;\n        padding: 0.375rem 0.75rem;\n        font-size: 1rem;\n        font-weight: 400;\n        line-height: 1.5;\n        color: #212529;\n        background-color: #fff;\n        background-clip: padding-box;\n        border: 1px solid #ced4da;\n        border-radius: 0.25rem;\n        transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;\n        outline:none;\n    }\n    "])));
    __decorate([
      propertyDataSource({ type: String }),
      __metadata("design:type", String)
    ], WcSelectOne2.prototype, "hint", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Boolean)
    ], WcSelectOne2.prototype, "required", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Boolean)
    ], WcSelectOne2.prototype, "disabled", void 0);
    __decorate([
      propertyCompositeDataSource({ type: String }),
      __metadata("design:type", String)
    ], WcSelectOne2.prototype, "label", void 0);
    __decorate([
      propertyDataSource(),
      __metadata("design:type", Array)
    ], WcSelectOne2.prototype, "options", void 0);
    __decorate([
      propertyDataSource(),
      __metadata("design:type", String)
    ], WcSelectOne2.prototype, "selectedvalue", void 0);
    WcSelectOne2 = __decorate([
      customElement("wc-select-one-100554")
    ], WcSelectOne2);
    return WcSelectOne2;
  }(IcaFormsInputSelectOne)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4;
export {
  WcSelectOne
};
