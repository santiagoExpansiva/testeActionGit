var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { html, css, unsafeHTML, repeat } from "lit";
import { customElement, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
var message_pt = {
  updateChanges: "Atualizar altera\uFFFD\uFFFDes",
  comments: "Coment\uFFFDrios",
  update: "Atualizar",
  fileChanges: "Altera\uFFFD\uFFFDes de arquivos",
  noItemsToSave: "Nenhum item para salvar"
};
var message_en = {
  updateChanges: "Update Changes",
  comments: "Comments",
  update: "Update",
  fileChanges: "File Changes",
  noItemsToSave: "No items to save"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceSave = (
  /** @class */
  function(_super) {
    __extends(ServiceSave2, _super);
    function ServiceSave2() {
      var _this = _super.call(this) || this;
      _this.myMessage = messages["en"];
      _this.itens = void 0;
      _this.error = "";
      _this.details = {
        icon: "&#xf0c7",
        state: "background",
        position: "left",
        tooltip: "Save",
        visible: true,
        widget: "_100554_serviceSave",
        level: [5]
      };
      _this.onClickLink = function(op) {
        if (op === "opSave")
          return _this.showInitial();
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.menu = {
        title: "Save",
        actions: {},
        icons: {},
        actionDefault: "opSave",
        // call after close icon clicked
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink
      };
      _this.onMLSEvents = function(ev) {
        return __awaiter(_this, void 0, Promise, function() {
          var fileAction;
          return __generator(this, function(_a) {
            if (ev.type !== "FileAction")
              return [
                2
                /*return*/
              ];
            fileAction = JSON.parse(ev.desc);
            if (!["changed", "delete", "new", "rename"].includes(fileAction.action))
              return [
                2
                /*return*/
              ];
            if (this.isServiceVisible()) {
              this.init();
            }
            this.toogleBadge(true, "_100554_serviceSave");
            return [
              2
              /*return*/
            ];
          });
        });
      };
      _this.oIcon = {
        nochange: { icon: "fa-file-pen", title: "Edited" },
        changed: { icon: "fa-file-pen", title: "Edited" },
        renamed: { icon: "fa-clone", title: "Renamed" },
        deleted: { icon: "fa-xmark", title: "Deleted" },
        //deleted: { icon: '&#xf1f8', title: 'Deleted' },f068
        //new: { icon: '&#xf006', title: 'New' }2b
        new: { icon: "fa-plus", title: "New" }
      };
      _this.setEvents();
      return _this;
    }
    ServiceSave2.prototype.showInitial = function() {
      return true;
    };
    ServiceSave2.prototype.onServiceClick = function(visible, reinit) {
      if (visible && reinit) {
        this.updateList();
      } else if (visible && !reinit) {
        this.updateList();
      }
    };
    ServiceSave2.prototype.setEvents = function() {
      var _this = this;
      mls.events.addListener(2, "FileAction", this.onMLSEvents.bind(this));
      mls.events.addListener(3, "FileAction", this.onMLSEvents.bind(this));
      mls.events.addListener(5, "ProjectSelected", function(ev) {
        _this.init();
      });
      this.verifyExitFileChanged();
    };
    ServiceSave2.prototype.isServiceVisible = function() {
      return this.visible === "true";
    };
    ServiceSave2.prototype.verifyExitFileChanged = function() {
      if (!mls.stor.files)
        return;
      var array = Object.keys(mls.stor.files);
      var exist = false;
      array.forEach(function(i) {
        var f = mls.stor.files[i];
        if (!f)
          return;
        if (f.project === mls.actual[5].project && f.status !== "nochange")
          exist = true;
      });
      if (!exist)
        return;
      this.toogleBadge(true, "_100554_serviceSave");
    };
    ServiceSave2.prototype.connectedCallback = function() {
      _super.prototype.connectedCallback.call(this);
      this.init();
    };
    ServiceSave2.prototype.render = function() {
      var _this = this;
      var lang = this.getMessageKey(messages);
      this.myMessage = messages[lang];
      if (this.error !== "") {
        setTimeout(function() {
          return _this.error = "";
        }, 3e3);
        return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["", ""], ["", ""])), this.error);
      }
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject([" ", "\n            \n        "], [" ", "\n            \n        "])), this.itens ? html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["<sectionsaveheader> ", " </sectionsaveheader>", ""], ["<sectionsaveheader> ", " </sectionsaveheader>", ""])), this.renderHeader(), this.renderItens()) : this.renderNoItens());
    };
    ServiceSave2.prototype.renderHeader = function() {
      return html(templateObject_4 || (templateObject_4 = __makeTemplateObject(['\n            <i class="fa fa-floppy-disk"></i>\n            <span>', "</span>    \n        \n        "], ['\n            <i class="fa fa-floppy-disk"></i>\n            <span>', "</span>    \n        \n        "])), this.myMessage.updateChanges);
    };
    ServiceSave2.prototype.renderNoItens = function() {
      return html(templateObject_5 || (templateObject_5 = __makeTemplateObject(["\n            <sectionnosave>\n                <span>", "</span> \n            </sectionnosave>  \n        \n        "], ["\n            <sectionnosave>\n                <span>", "</span> \n            </sectionnosave>  \n        \n        "])), this.myMessage.noItemsToSave);
    };
    ServiceSave2.prototype.renderItens = function() {
      var _this = this;
      var keys = Object.keys(this.itens);
      return html(templateObject_6 || (templateObject_6 = __makeTemplateObject(['\n            <sectionsave>\n                <div id="Save_menu_action" style="display:flex;">\n                    <div style="width:100%;" >\n                        <h4 class="mt-3">', ':</h4>\n                        <textarea id="commitMessage" class="form-control" style="width:95%;" rows="2" maxlength="50"></textarea>\n                    </div>\n                    <div id="div_btn_save" class="text-right" style="width:79px; display: flex; align-items: self-end;">\n                        <button id="btn_save" class="btnSave btn-sm btnSave-primary" @click="', '">', '</button>\n                    </div>\n                </div>\n                <h4 class="mt-3" data-mlsline="23">', "</h4>\n                <ul>\n                    ", "\n                </ul>\n            </sectionsave>  \n        \n        "], ['\n            <sectionsave>\n                <div id="Save_menu_action" style="display:flex;">\n                    <div style="width:100%;" >\n                        <h4 class="mt-3">', ':</h4>\n                        <textarea id="commitMessage" class="form-control" style="width:95%;" rows="2" maxlength="50"></textarea>\n                    </div>\n                    <div id="div_btn_save" class="text-right" style="width:79px; display: flex; align-items: self-end;">\n                        <button id="btn_save" class="btnSave btn-sm btnSave-primary" @click="', '">', '</button>\n                    </div>\n                </div>\n                <h4 class="mt-3" data-mlsline="23">', "</h4>\n                <ul>\n                    ", "\n                </ul>\n            </sectionsave>  \n        \n        "])), this.myMessage.comments, this.onSave, this.myMessage.update, this.myMessage.fileChanges, repeat(keys, function(key) {
        return key;
      }, function(k, index) {
        return _this.renderProject(k, index);
      }));
    };
    ServiceSave2.prototype.renderProject = function(project, index) {
      var _this = this;
      var keys = Object.keys(this.itens[project]);
      return html(templateObject_7 || (templateObject_7 = __makeTemplateObject(['\n        <li>\n            <div>\n                <span class="fatv fa-caret-righttv" @click="', '"></span>\n                <input type="checkbox" id="l0-', '" @click="', '">\n                <label for="l0-', '">', "</label>\n            </div>\n            <ul>\n                ", "\n            </ul>\n        </li>\n        "], ['\n        <li>\n            <div>\n                <span class="fatv fa-caret-righttv" @click="', '"></span>\n                <input type="checkbox" id="l0-', '" @click="', '">\n                <label for="l0-', '">', "</label>\n            </div>\n            <ul>\n                ", "\n            </ul>\n        </li>\n        "])), this.openMeList, index, this.clickSetValueAllChilds, index, project, repeat(keys, function(key) {
        return key;
      }, function(k, indexl) {
        return _this.renderLevels(k, project, index, indexl);
      }));
    };
    ServiceSave2.prototype.renderLevels = function(level, project, indexP, index) {
      if (level === "3") {
        return this.renderLevel3(level, project, indexP, index);
      } else {
        return this.renderLevelsDefault(level, project, indexP, index);
      }
    };
    ServiceSave2.prototype.renderLevel3 = function(level, project, indexP, index) {
      var _this = this;
      var objP = this.itens[project];
      var keys = Object.keys(objP[level]);
      return html(templateObject_9 || (templateObject_9 = __makeTemplateObject(['\n        <li>\n            <div>\n                <span class="fatv fa-caret-righttv" @click="', '"></span>\n                <input type="checkbox" id="l0-', "-", '" @click="', '">\n                <label for="l0-', "-", '">l', "</label>\n            </div>\n            <ul>\n                ", "\n            </ul>\n        </li>\n        "], ['\n        <li>\n            <div>\n                <span class="fatv fa-caret-righttv" @click="', '"></span>\n                <input type="checkbox" id="l0-', "-", '" @click="', '">\n                <label for="l0-', "-", '">l', "</label>\n            </div>\n            <ul>\n                ", "\n            </ul>\n        </li>\n        "])), this.openMeList, project, index, this.clickSetValueAllChilds, project, index, level, repeat(keys, function(key) {
        return key;
      }, function(k, index3) {
        var objL = objP[level];
        var objDS = objL[k];
        var itens = objDS ? objDS : [];
        return html(templateObject_8 || (templateObject_8 = __makeTemplateObject(['\n                                <li>\n                                    <div>\n                                        <span class="fatv fa-caret-righttv" @click="', '"></span>\n                                        <input type="checkbox" id="l0-', "-", "-", '" @click="', '">\n                                        <label for="l0-', "-", "-", '">', "</label>\n                                    </div>\n                                    <ul>                        \n                                        ", "\n                                    </ul>\n                                </li>\n                            "], ['\n                                <li>\n                                    <div>\n                                        <span class="fatv fa-caret-righttv" @click="', '"></span>\n                                        <input type="checkbox" id="l0-', "-", "-", '" @click="', '">\n                                        <label for="l0-', "-", "-", '">', "</label>\n                                    </div>\n                                    <ul>                        \n                                        ", "\n                                    </ul>\n                                </li>\n                            "])), _this.openMeList, project, index, index3, _this.clickSetValueAllChilds, project, index, index3, k, repeat(itens, function(item) {
          return item;
        }, function(i, indexI) {
          return _this.renderItem(i, indexP, index, indexI);
        }));
      }));
    };
    ServiceSave2.prototype.renderLevelsDefault = function(level, project, indexP, index) {
      var _this = this;
      var objP = this.itens[project];
      var itens = objP[+level];
      return html(templateObject_10 || (templateObject_10 = __makeTemplateObject(['\n        <li>\n            <div>\n                <span class="fatv fa-caret-righttv" @click="', '"></span>\n                <input type="checkbox" id="l0-', "-", '" @click="', '">\n                <label for="l0-', "-", '">l', "</label>\n            </div>\n            <ul>\n                ", "\n            </ul>\n        </li>\n        "], ['\n        <li>\n            <div>\n                <span class="fatv fa-caret-righttv" @click="', '"></span>\n                <input type="checkbox" id="l0-', "-", '" @click="', '">\n                <label for="l0-', "-", '">l', "</label>\n            </div>\n            <ul>\n                ", "\n            </ul>\n        </li>\n        "])), this.openMeList, project, index, this.clickSetValueAllChilds, project, index, level, repeat(itens, function(item) {
        return item;
      }, function(i, indexI) {
        return _this.renderItem(i, indexP, index, indexI);
      }));
    };
    ServiceSave2.prototype.renderItem = function(item, indexP, indexL, index) {
      return html(templateObject_13 || (templateObject_13 = __makeTemplateObject(['\n        <li style="padding-left: 1.1rem;" > \n            <div>\n                ', '\n                \n                <label for="l0-', "-", "-", '">\n                \n                    ', "\n                    ", "\n                \n                </label>\n            </div>\n        </li>\n        "], ['\n        <li style="padding-left: 1.1rem;" > \n            <div>\n                ', '\n                \n                <label for="l0-', "-", "-", '">\n                \n                    ', "\n                    ", "\n                \n                </label>\n            </div>\n        </li>\n        "])), item.disabled || item.onlyFather ? html(templateObject_11 || (templateObject_11 = __makeTemplateObject(['<input type="checkbox" id="l0-', "-", "-", '" disabled onlyStatusFather="', '" @click="', '" .instance=', ">"], ['<input type="checkbox" id="l0-', "-", "-", '" disabled onlyStatusFather="', '" @click="', '" .instance=', ">"])), indexP, indexL, index, item.onlyFather, this.clickVerifyStatusFather, item.file) : html(templateObject_12 || (templateObject_12 = __makeTemplateObject(['<input type="checkbox" id="l0-', "-", "-", '" onlyStatusFather="', '" @click="', '" .instance=', ">"], ['<input type="checkbox" id="l0-', "-", "-", '" onlyStatusFather="', '" @click="', '" .instance=', ">"])), indexP, indexL, index, item.onlyFather, this.clickVerifyStatusFather, item.file), indexP, indexL, index, item.text, unsafeHTML(item.span));
    };
    ServiceSave2.prototype.init = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              this.showLoader(true);
              return [4, this.setInfos()];
            case 1:
              _a.sent();
              this.showLoader(false);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSave2.prototype.showLoader = function(loader) {
      this.loading = loader;
    };
    ServiceSave2.prototype.setInfos = function() {
      return __awaiter(this, void 0, void 0, function() {
        var objProjects, filesKeys, _i, filesKeys_1, fKey, file, pj, level, obj, nNivel, _a, _b, _c, _d, _e, nNivel, obj3, _f, _g, _h, _j, _k;
        var _l;
        return __generator(this, function(_m) {
          switch (_m.label) {
            case 0:
              _m.trys.push([0, 13, , 14]);
              objProjects = {};
              filesKeys = Object.keys(mls.stor.files);
              _i = 0, filesKeys_1 = filesKeys;
              _m.label = 1;
            case 1:
              if (!(_i < filesKeys_1.length)) return [3, 12];
              fKey = filesKeys_1[_i];
              file = mls.stor.files[fKey];
              if (
                /*(!file.inLocalStorage && file.status === 'nochange') ||
                file.status === 'nochange' ||*/
                !file.inLocalStorage && file.status !== "deleted" || file.project === 0 || file.project !== mls.actual[5].project
              )
                return [3, 11];
              pj = file.project;
              level = file.level;
              if (!objProjects[pj])
                objProjects[pj] = {};
              obj = objProjects[pj];
              if (!(!obj[level] && level === 3)) return [3, 4];
              nNivel = file.folder.split("/");
              if (!(nNivel.length >= 2)) return [3, 3];
              _a = obj;
              _b = level;
              _l = {};
              _c = nNivel[1];
              return [4, this.configItem(file)];
            case 2:
              _a[_b] = (_l[_c] = [_m.sent()], _l);
              _m.label = 3;
            case 3:
              return [3, 11];
            case 4:
              if (!!obj[level]) return [3, 6];
              _d = obj;
              _e = level;
              return [4, this.configItem(file)];
            case 5:
              _d[_e] = [_m.sent()];
              return [3, 11];
            case 6:
              if (!(obj[level] && level === 3)) return [3, 9];
              nNivel = file.folder.split("/");
              obj3 = obj[level];
              if (!(nNivel.length >= 2 && obj3[nNivel[1]])) return [3, 8];
              _g = (_f = obj3[nNivel[1]]).push;
              return [4, this.configItem(file)];
            case 7:
              _g.apply(_f, [_m.sent()]);
              _m.label = 8;
            case 8:
              return [3, 11];
            case 9:
              _j = (_h = obj[level]).push;
              return [4, this.configItem(file)];
            case 10:
              _j.apply(_h, [_m.sent()]);
              _m.label = 11;
            case 11:
              _i++;
              return [3, 1];
            case 12:
              if (Object.keys(objProjects).length > 0) {
                this.itens = objProjects;
              } else {
                this.itens = void 0;
                this.toogleBadge(false, "_100554_serviceSave");
              }
              return [3, 14];
            case 13:
              _k = _m.sent();
              this.itens = void 0;
              return [3, 14];
            case 14:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSave2.prototype.configItem = function(item) {
      return __awaiter(this, void 0, void 0, function() {
        var mountText, disabled, span, itemNew;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              mountText = item.shortName + item.extension;
              disabled = false;
              span = '<span style="font-size: 12px; color: #7678a6; margin-left: 5px;" class="fa '.concat(this.oIcon[item.status].icon, '" title="').concat(this.oIcon[item.status].title, '"></span>');
              if (item.hasError && item.status !== "deleted") {
                span = '<span style="font-size: 12px; color: #ff0000; margin-left: 5px; height: 16px;" class="fa fa-bug" title="Error"></span>';
                disabled = true;
              }
              if (item.isLocalVersionOutdated) {
                span = '<span style="font-size: 12px; color: #ff0000; margin-left: 5px;" class="fa fa-unbalanced" title="Version block"></span>';
                disabled = true;
              }
              if (!(item.status === "renamed" && item.getValueInfo)) return [3, 2];
              return [4, item.getValueInfo()];
            case 1:
              itemNew = _a.sent();
              mountText = "".concat(itemNew.originalShortName + item.extension, " to ").concat(mountText, " ");
              _a.label = 2;
            case 2:
              return [2, {
                file: item,
                text: mountText,
                span,
                onlyFather: item.level === 3,
                disabled
              }];
          }
        });
      });
    };
    ServiceSave2.prototype.openMeList = function(e) {
      e.stopPropagation();
      var el = e.target;
      if (!el)
        return;
      var li = el.closest("li");
      if (!li)
        return;
      li.classList.toggle("open");
    };
    ServiceSave2.prototype.clickSetValueAllChilds = function(e) {
      e.stopPropagation();
      var el = e.target;
      if (!el)
        return;
      this.setValueAllChilds(el);
    };
    ServiceSave2.prototype.setValueAllChilds = function(el) {
      var father = el.closest("li");
      if (!father)
        return;
      var subList = father.querySelector("ul");
      if (!subList)
        return;
      var all = subList.querySelectorAll("input");
      all.forEach(function(i) {
        var onlyStatusFather = i.getAttribute("onlyStatusFather") === "true";
        if (i.disabled && !onlyStatusFather)
          return;
        i.checked = el.checked;
      });
      if (all.length === 1 && all[0].disabled)
        el.checked = false;
    };
    ServiceSave2.prototype.clickVerifyStatusFather = function(e) {
      e.stopPropagation();
      var el = e.target;
      if (!el)
        return;
      this.verifyStatusFather(el);
    };
    ServiceSave2.prototype.verifyStatusFather = function(el) {
      var father = el.closest("ul");
      if (!father)
        return;
      var grandfather = father.closest("li");
      if (!grandfather)
        return;
      var inpMain = grandfather.querySelector("input");
      if (!inpMain)
        return;
      if (el.checked) {
        inpMain.checked = true;
        return;
      }
      var needDisable = true;
      var all = father.querySelectorAll("input");
      all.forEach(function(i) {
        if (i.checked)
          needDisable = false;
      });
      if (needDisable)
        inpMain.checked = false;
    };
    ServiceSave2.prototype.updateList = function() {
      return __awaiter(this, void 0, void 0, function() {
        var e_1;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              _a.trys.push([0, 2, , 3]);
              this.showLoader(true);
              return [4, this.setInfos()];
            case 1:
              _a.sent();
              this.showLoader(false);
              return [3, 3];
            case 2:
              e_1 = _a.sent();
              this.error = e_1.message;
              this.showLoader(false);
              return [3, 3];
            case 3:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSave2.prototype.createArrayInfoVersion = function(array) {
      var ret = [];
      array.forEach(function(i) {
        ret.push({
          name: "l".concat(i.level, "/").concat(i.folder ? i.folder + "/" : "").concat(i.shortName).concat(i.extension),
          version: i.versionRef,
          file: i
        });
      });
      return ret;
    };
    ServiceSave2.prototype.uppVersionAfterSave = function(array) {
      return __awaiter(this, void 0, void 0, function() {
        var driver, retArray, arrayVersion;
        var _this = this;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              driver = mls.stor.others.getDefaultDriver(mls.actual[5].project);
              return [4, driver.loadFilesInfo(mls.actual[5].project)];
            case 1:
              retArray = _a.sent();
              arrayVersion = this.createArrayInfoVersion(array);
              retArray.forEach(function(i) {
                return __awaiter(_this, void 0, void 0, function() {
                  var file;
                  return __generator(this, function(_a2) {
                    switch (_a2.label) {
                      case 0:
                        file = arrayVersion.filter(function(f) {
                          return f.name === i.ShortPath;
                        });
                        if (!file || file.length <= 0 || file && file.length >= 1 && file[0].version === i.versionRef)
                          return [
                            2
                            /*return*/
                          ];
                        if (!(file[0].version !== i.versionRef)) return [3, 2];
                        file[0].file.versionRef = i.versionRef;
                        file[0].file.isLocalVersionOutdated = false;
                        file[0].file.newVersionRefIfOutdated = void 0;
                        return [4, mls.stor.localStor.setContent(file[0].file, { contentType: "string", content: null })];
                      case 1:
                        _a2.sent();
                        _a2.label = 2;
                      case 2:
                        return [
                          2
                          /*return*/
                        ];
                    }
                  });
                });
              });
              mls.stor.localDB.savePrjInfo(mls.actual[5].project, retArray);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSave2.prototype.verifyVersionBlock = function(array) {
      return __awaiter(this, void 0, void 0, function() {
        var ret, e_2;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              _a.trys.push([0, 2, , 3]);
              if (array.length <= 0)
                return [
                  2
                  /*return*/
                ];
              return [4, mls.stor.server.loadProjectInfoIfNeeded(mls.actual[5].project, true)];
            case 1:
              ret = _a.sent();
              return [3, 3];
            case 2:
              e_2 = _a.sent();
              console.info("Error save verifyVersionBlock:" + e_2.message);
              return [3, 3];
            case 3:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSave2.prototype.onSave = function(e) {
      return __awaiter(this, void 0, void 0, function() {
        var el, father, txt, array_1, msg_1;
        var _this = this;
        return __generator(this, function(_a) {
          try {
            e.stopPropagation();
            el = e.target;
            if (!el)
              return [
                2
                /*return*/
              ];
            father = el.closest("sectionsave");
            if (!father)
              return [
                2
                /*return*/
              ];
            this.showLoader(true);
            txt = father.querySelector("textarea");
            array_1 = this.getAllFileToSave(father);
            msg_1 = txt ? txt.value : "";
            setTimeout(function() {
              return __awaiter(_this, void 0, void 0, function() {
                var e_3;
                return __generator(this, function(_a2) {
                  switch (_a2.label) {
                    case 0:
                      _a2.trys.push([0, 4, , 5]);
                      return [4, this.verifyVersionBlock(array_1)];
                    case 1:
                      _a2.sent();
                      return [4, this.onSavenew(array_1, msg_1)];
                    case 2:
                      _a2.sent();
                      return [4, this.setInfos()];
                    case 3:
                      _a2.sent();
                      this.fireEvents();
                      this.showLoader(false);
                      return [3, 5];
                    case 4:
                      e_3 = _a2.sent();
                      this.error = e_3.message;
                      this.showLoader(false);
                      return [3, 5];
                    case 5:
                      return [
                        2
                        /*return*/
                      ];
                  }
                });
              });
            }, 500);
          } catch (e2) {
            console.info("Error onSave");
          }
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServiceSave2.prototype.getAllFileToSave = function(father) {
      var ar = [];
      var els = father.querySelectorAll('input[type="checkbox"][onlyStatusFather]:checked');
      els.forEach(function(el) {
        if (el.instance) {
          ar.push(el.instance);
          var info = el.instance;
          if (info.extension === ".ts" && info.status === "deleted") {
            var key = mls.stor.getKeyToFiles(info.project, info.level, info.shortName, info.folder, ".html");
            var fl = mls.stor.files[key];
            if (!fl || fl.status === "new")
              return;
            fl.status = "deleted";
            ar.push(fl);
          }
        }
      });
      return ar;
    };
    ServiceSave2.prototype.onSavenew = function(ar, msg) {
      return __awaiter(this, void 0, void 0, function() {
        var versionBLock_1, arrSet_1, e_4;
        var _this = this;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (ar.length <= 0)
                return [
                  2
                  /*return*/
                ];
              _a.label = 1;
            case 1:
              _a.trys.push([1, 5, , 6]);
              versionBLock_1 = 0;
              arrSet_1 = [];
              ar.forEach(function(i) {
                if (i.isLocalVersionOutdated && !["new", "deleted"].includes(i.status)) {
                  versionBLock_1++;
                  return;
                }
                i.inLocalStorage = false;
                if (!i.onAction)
                  i.onAction = function(action) {
                    return _this.afterUpdate(i);
                  };
                arrSet_1.push(i);
              });
              if (!(arrSet_1.length > 0)) return [3, 4];
              return [4, mls.stor.setContents(arrSet_1, msg)];
            case 2:
              _a.sent();
              return [4, this.uppVersionAfterSave(arrSet_1)];
            case 3:
              _a.sent();
              this.fireEvents(800);
              _a.label = 4;
            case 4:
              if (versionBLock_1 > 0) {
                window.collabMessages.add("File ".concat(versionBLock_1, " was changed in server, file was not save"), "information");
              }
              return [
                2
                /*return*/
              ];
            case 5:
              e_4 = _a.sent();
              this.error = e_4.message;
              return [3, 6];
            case 6:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSave2.prototype.afterUpdate = function(storFile) {
      return __awaiter(this, void 0, void 0, function() {
        var mmodel;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              mmodel = mls.l2.editor.get(storFile);
              if (storFile.status === "deleted") {
                this.deleteFile(storFile);
                return [
                  2
                  /*return*/
                ];
              }
              if (storFile.status === "renamed" && mmodel) {
                mmodel.originalProject = void 0;
                mmodel.originalShortName = void 0;
                mmodel.originalCRC = mls.common.crc.crc32(mmodel.model.getValue()).toString(16);
              }
              return [4, mls.stor.localStor.setContent(storFile, { contentType: "string", content: null })];
            case 1:
              _a.sent();
              storFile.status = "nochange";
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSave2.prototype.deleteFile = function(storFile) {
      return __awaiter(this, void 0, void 0, function() {
        var keyFiles;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              return [4, mls.stor.localStor.setContent(storFile, { contentType: "string", content: null })];
            case 1:
              _a.sent();
              mls.l2.editor.remove(storFile);
              keyFiles = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, storFile.extension);
              delete mls.stor.files[keyFiles];
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSave2.prototype.fireEvents = function(time) {
      if (time === void 0) {
        time = 0;
      }
      var params = {};
      params.action = "projectListChanged";
      params.level = 5;
      params.project = mls.actual[5].project;
      params.position = this.position;
      mls.events.fire([5], ["FileAction"], JSON.stringify(params), time);
    };
    ServiceSave2.styles = css(templateObject_14 || (templateObject_14 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", Object)
    ], ServiceSave2.prototype, "itens", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceSave2.prototype, "error", void 0);
    ServiceSave2 = __decorate([
      customElement("service-save-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceSave2);
    return ServiceSave2;
  }(ServiceBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6, templateObject_7, templateObject_8, templateObject_9, templateObject_10, templateObject_11, templateObject_12, templateObject_13, templateObject_14;
export {
  ServiceSave
};
