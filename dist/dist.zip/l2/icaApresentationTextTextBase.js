import { IcaLitElement } from "./_100554_icaLitElement";
class IcaApresentationTextTextBase extends IcaLitElement {
}
export {
  IcaApresentationTextTextBase
};
