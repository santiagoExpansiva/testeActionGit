var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { setErrorOnModel } from "./_100554_validateLit";
function setCodeLens(mfile) {
  clearCodeLens(mfile);
  var model = mfile.model, compilerResults = mfile.compilerResults;
  var decorators = compilerResults.decorators;
  if (mfile.shortName === "enhancementLit" && mfile.project === 100554)
    return;
  setCodeLensDecoratorClass(model, decorators);
  setCodeLensMlsComponents(model, mfile);
  setCodeLensServiceDetails(model, mfile);
}
function clearCodeLens(mfile) {
  for (var slineNr in mfile.codeLens) {
    var codeLen = mfile.codeLens[slineNr];
    if (codeLen[0].id === "helpAssistant") {
      mls.l2.codeLens.removeCodeLen(mfile.model, Number.parseInt(slineNr));
    }
  }
}
function setCodeLensDecoratorClass(model, decorators) {
  var objDecorators = JSON.parse(decorators);
  Object.entries(objDecorators).forEach(function(entrie) {
    var decoratorInfo = entrie[1];
    if (!decoratorInfo || decoratorInfo.type !== "ClassDeclaration")
      return;
    decoratorInfo.decorators.forEach(function(_decorator) {
      if (_decorator.text.startsWith("customElement(")) {
        mls.l2.codeLens.addCodeLen(model, _decorator.line + 1, { id: "helpAssistant", title: "customElement", jsComm: "", refs: "codelens-custom-element-100554" });
      }
    });
  });
}
function setCodeLensServiceDetails(model, mfile) {
  return __awaiter(this, void 0, void 0, function() {
    var lines;
    return __generator(this, function(_a) {
      lines = findLinesByText(model, "public details: IService");
      lines.forEach(function(line) {
        mls.l2.codeLens.addCodeLen(model, line, { id: "helpAssistant", title: "serviceDetails", jsComm: "", refs: "codelens-service-details-100554" });
      });
      return [
        2
        /*return*/
      ];
    });
  });
}
function setCodeLensMlsComponents(model, mfile) {
  return __awaiter(this, void 0, void 0, function() {
    var errorInfo, lines, mModule, obj, hasError, _i, _a, i, text;
    return __generator(this, function(_b) {
      switch (_b.label) {
        case 0:
          errorInfo = {
            line: 0,
            start: 0,
            end: 0
          };
          lines = findLinesByText(model, "@mlsComponentDetails");
          lines.forEach(function(line) {
            errorInfo.line = line;
            mls.l2.codeLens.addCodeLen(model, line, { id: "helpAssistant", title: "mlsComponentDetails", jsComm: "", refs: "codelens-component-details-100554" });
          });
          return [4, mls.l2.enhancement.getEnhancementInstance(mfile)];
        case 1:
          mModule = _b.sent();
          if (!mModule)
            return [
              2
              /*return*/
            ];
          return [4, mModule.getDesignDetails(mfile)];
        case 2:
          obj = _b.sent();
          hasError = lines.length > 1 ? "only one dependency declaration is valid." : "";
          if (!hasError) {
            for (_i = 0, _a = obj.webComponentDependencies; _i < _a.length; _i++) {
              i = _a[_i];
              if (!mls.l2.editor.mfiles[i]) {
                hasError = i;
                break;
              }
            }
          }
          if (hasError) {
            mfile.storFile.hasError = true;
            text = model.getLineContent(errorInfo.line);
            errorInfo.end = text.length;
            setErrorOnModel(model, errorInfo.line, errorInfo.start, errorInfo.end, hasError.startsWith("onl") ? hasError : "Not found dependence: ".concat(hasError), monaco.MarkerSeverity.Error);
            mls.events.fireFileAction("statusOrErrorChanged", mfile.storFile, "left");
            mls.events.fireFileAction("statusOrErrorChanged", mfile.storFile, "right");
          }
          return [
            2
            /*return*/
          ];
      }
    });
  });
}
function findLinesByText(model, textToFind) {
  var lines = [];
  if (!model)
    return lines;
  var lineCount = model.getLineCount();
  for (var lineNumber = 1; lineNumber <= lineCount; lineNumber++) {
    var lineText = model.getLineContent(lineNumber);
    if (lineText.includes(textToFind)) {
      lines.push(lineNumber);
    }
  }
  return lines;
}
export {
  setCodeLens
};
