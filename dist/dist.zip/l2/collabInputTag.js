var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css, LitElement } from "lit";
import { customElement, property, query } from "lit/decorators.js";
function initCollabInputTag() {
  return true;
}
var CollabInputTag = (
  /** @class */
  function(_super) {
    __extends(CollabInputTag2, _super);
    function CollabInputTag2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.tags = [];
      _this.allowDelete = false;
      return _this;
    }
    Object.defineProperty(CollabInputTag2.prototype, "value", {
      get: function() {
        return this.tags.join(",");
      },
      set: function(val) {
        if (!val) {
          this.empty();
          return;
        }
        var arrTags = val.split(",");
        this.tags = arrTags;
      },
      enumerable: false,
      configurable: true
    });
    CollabInputTag2.prototype.addTag = function(tag) {
      return this._addTag(tag);
    };
    CollabInputTag2.prototype.deleteTag = function(index) {
      return this._deleteTag(index);
    };
    CollabInputTag2.prototype.empty = function() {
      return this._empty();
    };
    CollabInputTag2.prototype._addTag = function(tag) {
      var _a2;
      if (!tag)
        return;
      tag = tag.toLowerCase();
      if (this.tags.indexOf(tag) === -1) {
        this.tags.push(tag);
        if (this.input)
          this.input.value = "";
        this.requestUpdate();
      } else {
        var element_1 = (_a2 = this.shadowRoot) === null || _a2 === void 0 ? void 0 : _a2.querySelector('[data-index="' + this.tags.indexOf(tag) + '"]');
        element_1.classList.add("duplicate");
        setTimeout(function() {
          element_1.classList.remove("duplicate");
        }, 500);
      }
    };
    CollabInputTag2.prototype._deleteTag = function(index) {
      var newTags = [];
      this.tags.forEach(function(tag, idx) {
        if (idx !== index) {
          newTags.push(tag);
        }
      });
      this.tags = newTags;
      this.requestUpdate();
    };
    CollabInputTag2.prototype._empty = function() {
      this.tags = [];
      this.requestUpdate();
    };
    CollabInputTag2.prototype.onInputKeyDown = function(event) {
      if (!this.input)
        return;
      var value = this.input.value;
      if (event.keyCode === 13) {
        this._addTag(value);
        if (this.onValueChanged)
          this.onValueChanged(this.value);
      } else if (event.keyCode === 188) {
        event.preventDefault();
        this._addTag(value);
        if (this.onValueChanged)
          this.onValueChanged(this.value);
      } else if (event.keyCode === 8 && value.length === 0) {
        if (this.allowDelete) {
          this._deleteTag(this.tags.length - 1);
          if (this.onValueChanged)
            this.onValueChanged(this.value);
          this.allowDelete = false;
        } else {
          this.allowDelete = true;
        }
      }
    };
    CollabInputTag2.prototype.render = function() {
      var _this = this;
      return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(['<div class="collab-tag-input">\n                <input id="tag-input" @keydown=', "></input>\n                ", "\n        </div>"], ['<div class="collab-tag-input">\n                <input id="tag-input" @keydown=', "></input>\n                ", "\n        </div>"])), function(ev) {
        _this.onInputKeyDown(ev);
      }, this.tags.map(function(tag, index) {
        return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n                        <div data-index=", ' class="tag">\n                            <div class="remove">x</div>\n                            ', "\n                        </div>\n                    "], ["\n                        <div data-index=", ' class="tag">\n                            <div class="remove">x</div>\n                            ', "\n                        </div>\n                    "])), index, tag);
      }));
    };
    var _a;
    CollabInputTag2.styles = css(templateObject_3 || (templateObject_3 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", Array)
    ], CollabInputTag2.prototype, "tags", void 0);
    __decorate([
      query("#tag-input"),
      __metadata("design:type", typeof (_a = typeof HTMLInputElement !== "undefined" && HTMLInputElement) === "function" ? _a : Object)
    ], CollabInputTag2.prototype, "input", void 0);
    CollabInputTag2 = __decorate([
      customElement("collab-input-tag-100554")
    ], CollabInputTag2);
    return CollabInputTag2;
  }(LitElement)
);
var templateObject_1, templateObject_2, templateObject_3;
export {
  CollabInputTag,
  initCollabInputTag
};
