var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var __asyncValues = function(o) {
  if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
  var m = o[Symbol.asyncIterator], i;
  return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
    return this;
  }, i);
  function verb(n) {
    i[n] = o[n] && function(v) {
      return new Promise(function(resolve, reject) {
        v = o[n](v), settle(resolve, reject, v.done, v.value);
      });
    };
  }
  function settle(resolve, reject, d, v) {
    Promise.resolve(v).then(function(v2) {
      resolve({ value: v2, done: d });
    }, reject);
  }
};
import { html, css, unsafeHTML, render, styleMap, repeat } from "lit";
import { customElement, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
import { convertFileNameToTag, convertTagToFileName } from "./_100554_utilsLit";
import { tasks, readTasksFromServer, getUserConfigs, saveUserConfigs } from "./_100554_aimHelper";
import { findActions } from "./_100554_aimActionBase";
var message_pt = {
  loading: "Carregando...",
  selectadd: "por favor selecione abaixo para adicionar",
  allTasksLast: "Todas as tarefas, \uFFFDltimas",
  user: "Usu\uFFFDrio",
  all: "Todos",
  ref: "Ref",
  add: "Adicionar",
  notFoundReference: "Refer\uFFFDncia n\uFFFDo encontrada",
  tasksByReference: "Tarefas por refer\uFFFDncia",
  noActionsToAdd: "Nenhuma a\uFFFD\uFFFDo para adicionar",
  selectColumnsYouWant: "Selecione as colunas que deseja visualizar",
  save: "Salvar",
  cancel: "Cancelar"
};
var message_en = {
  loading: "Loading...",
  selectadd: "please select below to add",
  allTasksLast: "All Tasks, last",
  user: "User",
  all: "All",
  ref: "Ref",
  add: "Add",
  notFoundReference: "Not found reference",
  tasksByReference: "Tasks by reference",
  noActionsToAdd: "No Actions to Add",
  selectColumnsYouWant: "Select the columns you want to view",
  save: "Save",
  cancel: "Cancel"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceAim100554 = (
  /** @class */
  function(_super) {
    __extends(ServiceAim1005542, _super);
    function ServiceAim1005542() {
      var _this = _super.call(this) || this;
      _this.myMessage = messages["en"];
      _this.activeTab = "All";
      _this.useContainerAdd = true;
      _this.actionToOpen = "";
      _this.actualServiceOpName = "";
      _this.isloading = true;
      _this.actualServiceOpLevel = 0;
      _this.details = {
        icon: "&#xf03a",
        state: "foreground",
        position: "all",
        tooltip: "AI",
        visible: true,
        widget: "_100554_serviceAim",
        level: [2, 3]
      };
      _this.onClickLink = function(op) {
        if (op === "opColumns")
          return _this.showConfigColumns();
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.onClickIcon = function(op) {
        if (_this.activeTab === op)
          return;
        _this.activeTab = op;
      };
      _this.menu = {
        title: "AI",
        actions: {
          opColumns: "Columns"
        },
        icons: {
          All: "".concat(_this.myMessage.all, ";f560"),
          User: "".concat(_this.myMessage.user, ";f007"),
          Ref: "".concat(_this.myMessage.ref, ";f15b"),
          Add: "".concat(_this.myMessage.add, ";2b")
        },
        actionDefault: "",
        // call after close icon clicked
        iconDefault: "All",
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        onClickIcon: _this.onClickIcon,
        getLastMode: void 0,
        updateTitle: void 0
      };
      _this.actions = [];
      _this.setEvents();
      return _this;
    }
    ServiceAim1005542.prototype.render = function() {
      var _this = this;
      var lang = this.getMessageKey(messages);
      this.myMessage = messages[lang];
      if (this.menu.setIconActive)
        this.menu.setIconActive(this.activeTab);
      if (this.actionToOpen)
        this.activeTab = "Add";
      switch (this.activeTab) {
        case "All":
          return this.renderAll();
        case "User":
          return this.renderUser();
        case "Ref":
          return this.renderRef();
        case "Add":
          var renderAddResult = this.renderAdd();
          Promise.resolve().then(function() {
            _this.checkIfHasActionToOpen();
          });
          return renderAddResult;
        default:
          return html(templateObject_1 || (templateObject_1 = __makeTemplateObject([""], [""])));
      }
    };
    Object.defineProperty(ServiceAim1005542.prototype, "invertedPosition", {
      get: function() {
        return this.position === "left" ? "right" : "left";
      },
      enumerable: false,
      configurable: true
    });
    ;
    ServiceAim1005542.prototype.onServiceClick = function(visible, reinit, el) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (!visible || !reinit)
                return [
                  2
                  /*return*/
                ];
              return [4, this.setActions()];
            case 1:
              _a.sent();
              this.requestUpdate();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceAim1005542.prototype.setEvents = function() {
      var _this = this;
      mls.events.addEventListener([1, 2, 3, 4, 5, 6, 7], ["ToolBarSelected"], function(ev) {
        return _this.onToolbarSelectChange(ev);
      });
      this.addEventListener("refresh-request", this.handleRefreshRequest);
    };
    ServiceAim1005542.prototype.onToolbarSelectChange = function(ev) {
      if (mls.istrace)
        console.log("serviceAim, toolbarSelected", ev);
      if (this.activeTab !== "Add")
        return;
      if (!ev.desc)
        return;
      var data = JSON.parse(ev.desc);
      if (mls.istrace)
        console.log("serviceAim, ".concat(data.position, ", ").concat(this.position));
      if (data.position === this.position || data.level !== this.level)
        return;
      this.actualServiceOpLevel = data.level;
      this.actualServiceOpName = data.to;
      if (this.visible === "true")
        this.requestUpdate();
    };
    ServiceAim1005542.prototype.sortKey = function(arr) {
      function getKey(key) {
        if (!key)
          return -1;
        var parts = key.split("/");
        if (parts.length !== 3)
          return -1;
        var index = Number.parseInt(parts[2]);
        return Number.isNaN(index) ? -1 : index;
      }
      function sort(a, b) {
        if (a.mode === "in progress" && b.mode !== "in progress") {
          return -1;
        } else if (a.mode !== "in progress" && b.mode === "in progress") {
          return 1;
        } else {
          return getKey(b.key) - getKey(a.key);
        }
      }
      return arr.sort(sort);
    };
    ServiceAim1005542.prototype.renderAll = function() {
      var renderTask = function(taskRoot, index) {
        var actionName = convertFileNameToTag(taskRoot.widget);
        var sHtml = "<".concat(actionName, ' mode="').concat(taskRoot.mode, '" taskIndex="').concat(index, '" />');
        return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["", ""], ["", ""])), unsafeHTML(sHtml));
      };
      var orderned = this.sortKey(tasks);
      if (mls.istrace)
        console.log("serviceAim, renderAll");
      if (this.isloading)
        return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(["<span>", "</span>"], ["<span>", "</span>"])), this.myMessage.loading);
      return html(templateObject_4 || (templateObject_4 = __makeTemplateObject(["\n        <h4 class='title'>", " (", ")</h4>\n            ", "\n        "], ["\n        <h4 class='title'>", " (", ")</h4>\n            ", "\n        "])), this.myMessage.allTasksLast, tasks.length, repeat(orderned, function(task, index) {
        return task.key;
      }, function(task, index) {
        return renderTask(task, index);
      }));
    };
    ServiceAim1005542.prototype.renderUser = function() {
      var userName = localStorage.getItem("loginUser");
      function renderTask(taskRoot, index) {
        if (taskRoot.userName !== userName)
          return;
        var actionName = convertFileNameToTag(taskRoot.widget);
        var sHtml = "<".concat(actionName, ' mode="').concat(taskRoot.mode, '" taskIndex="').concat(index, '"/>');
        return html(templateObject_5 || (templateObject_5 = __makeTemplateObject(["", ""], ["", ""])), unsafeHTML(sHtml));
      }
      var orderned = this.sortKey(tasks);
      return html(templateObject_6 || (templateObject_6 = __makeTemplateObject(["\n        <h4 class='title'>", ": ", " </h4>\n            ", "            \n        "], ["\n        <h4 class='title'>", ": ", " </h4>\n            ", "            \n        "])), this.myMessage.user, userName, repeat(orderned, function(task, index) {
        return index;
      }, function(task, index) {
        return renderTask(task, index);
      }));
    };
    ServiceAim1005542.prototype.renderRef = function() {
      var refOpr = "";
      if (this.nav3Service) {
        var pos = this.position === "left" ? "right" : "left";
        var op = this.nav3Service.getActiveInstance(pos);
        if (op && op.getActualRef)
          refOpr = op.getActualRef();
      }
      function renderTask(taskRoot, index) {
        var hasRef = taskRoot.children.filter(function(c) {
          return c.ref === refOpr;
        });
        if (!hasRef || hasRef.length <= 0)
          return;
        var actionName = convertFileNameToTag(taskRoot.widget);
        var sHtml = "<".concat(actionName, ' mode="').concat(taskRoot.mode, '" taskIndex="').concat(index, '"/>');
        return html(templateObject_7 || (templateObject_7 = __makeTemplateObject(["", ""], ["", ""])), unsafeHTML(sHtml));
      }
      var orderned = this.sortKey(tasks);
      if (refOpr.length <= 0)
        refOpr = "***notFoundService---";
      var verifyOrderned = orderned.filter(function(i) {
        var hasRef = i.children.filter(function(c) {
          return c.ref === refOpr;
        });
        if (!hasRef || hasRef.length <= 0)
          return false;
        return true;
      });
      return html(templateObject_9 || (templateObject_9 = __makeTemplateObject(["\n            <h4 class='title'>", " </h4>\n                ", "\n        "], ["\n            <h4 class='title'>", " </h4>\n                ", "\n        "])), this.myMessage.tasksByReference, verifyOrderned.length > 0 ? repeat(orderned, function(task, index) {
        return index;
      }, function(task, index) {
        return renderTask(task, index);
      }) : html(templateObject_8 || (templateObject_8 = __makeTemplateObject(["<h4>", "</h4>"], ["<h4>", "</h4>"])), this.myMessage.notFoundReference));
    };
    ServiceAim1005542.prototype.updated = function(changedProperties) {
      var _this = this;
      _super.prototype.update.call(this, changedProperties);
      if (!changedProperties.has("activeTab"))
        return;
      switch (this.activeTab) {
        case "All":
          return;
        case "User":
          return;
        case "Ref":
          return;
        case "Add":
          this.setActions().then(function() {
            return _this.sendRefreshRequest();
          });
          return;
        case "Loading":
          return;
        default:
          console.error("invalid activeTab:", this.activeTab);
      }
    };
    ServiceAim1005542.prototype.sendRefreshRequest = function() {
      var event = new CustomEvent("refresh-request", { bubbles: true, composed: true });
      this.dispatchEvent(event);
    };
    ServiceAim1005542.prototype.handleRefreshRequest = function() {
      this.requestUpdate();
    };
    ServiceAim1005542.prototype.connectedCallback = function() {
      return __awaiter(this, void 0, void 0, function() {
        var _this = this;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              _super.prototype.connectedCallback.call(this);
              if (!this.nav3Service) {
                this.actualServiceOpName = "_100554_ServiceSource";
                this.actualServiceOpLevel = 2;
              }
              return [4, readTasksFromServer("all", "").then(function() {
                return __awaiter(_this, void 0, void 0, function() {
                  var widgetsDistincts, arrayWidgets, _a2, arrayWidgets_1, arrayWidgets_1_1, widget, e_1_1;
                  var _b, e_1, _c, _d;
                  return __generator(this, function(_e) {
                    switch (_e.label) {
                      case 0:
                        return [4, this.setActions()];
                      case 1:
                        _e.sent();
                        widgetsDistincts = /* @__PURE__ */ new Set();
                        tasks.forEach(function(task) {
                          widgetsDistincts.add(task.widget);
                        });
                        arrayWidgets = Array.from(widgetsDistincts);
                        _e.label = 2;
                      case 2:
                        _e.trys.push([2, 8, 9, 14]);
                        _a2 = true, arrayWidgets_1 = __asyncValues(arrayWidgets);
                        _e.label = 3;
                      case 3:
                        return [4, arrayWidgets_1.next()];
                      case 4:
                        if (!(arrayWidgets_1_1 = _e.sent(), _b = arrayWidgets_1_1.done, !_b)) return [3, 7];
                        _d = arrayWidgets_1_1.value;
                        _a2 = false;
                        widget = _d;
                        return [4, this.loadComponentModule(widget)];
                      case 5:
                        _e.sent();
                        _e.label = 6;
                      case 6:
                        _a2 = true;
                        return [3, 3];
                      case 7:
                        return [3, 14];
                      case 8:
                        e_1_1 = _e.sent();
                        e_1 = { error: e_1_1 };
                        return [3, 14];
                      case 9:
                        _e.trys.push([9, , 12, 13]);
                        if (!(!_a2 && !_b && (_c = arrayWidgets_1.return))) return [3, 11];
                        return [4, _c.call(arrayWidgets_1)];
                      case 10:
                        _e.sent();
                        _e.label = 11;
                      case 11:
                        return [3, 13];
                      case 12:
                        if (e_1) throw e_1.error;
                        return [
                          7
                          /*endfinally*/
                        ];
                      case 13:
                        return [
                          7
                          /*endfinally*/
                        ];
                      case 14:
                        this.isloading = false;
                        this.requestUpdate();
                        return [
                          2
                          /*return*/
                        ];
                    }
                  });
                });
              })];
            case 1:
              _a.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceAim1005542.prototype.attributeChangedCallback = function(prop, oldValue, newValue) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              _super.prototype.attributeChangedCallback.call(this, prop, oldValue, newValue);
              if (!(prop === "actualserviceopname" && oldValue !== newValue)) return [3, 2];
              return [4, this.setActions()];
            case 1:
              _a.sent();
              this.requestUpdate();
              _a.label = 2;
            case 2:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceAim1005542.prototype.setActions = function() {
      return __awaiter(this, void 0, void 0, function() {
        var _a;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              _a = this;
              return [4, this.getActionsByContext()];
            case 1:
              _a.actions = _b.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceAim1005542.prototype.getActionsByContext = function() {
      return __awaiter(this, void 0, Promise, function() {
        var activeInstance, tag, fileName, act;
        var _a;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              if (!this.actualServiceOpName || this.actualServiceOpLevel !== this.level) {
                activeInstance = (_a = this.nav3Service) === null || _a === void 0 ? void 0 : _a.getActiveInstance(this.invertedPosition);
                if (!activeInstance || !(activeInstance instanceof ServiceBase)) {
                  return [2, []];
                }
                tag = activeInstance.tagName;
                fileName = convertTagToFileName(tag.toLowerCase());
                this.actualServiceOpLevel = activeInstance.level;
                this.actualServiceOpName = fileName;
              }
              return [4, findActions([this.level], [this.actualServiceOpName])];
            case 1:
              act = _b.sent();
              return [2, act];
          }
        });
      });
    };
    ServiceAim1005542.prototype.renderAdd = function() {
      var _this = this;
      var filteredActions = [];
      if (!this.nav3Service)
        filteredActions = this.actions;
      else
        filteredActions = this.actions.filter(function(item) {
          return item.tagsValid === true && item.levelsValid;
        });
      var renderItems = function() {
        return filteredActions.map(function(action, index) {
          var dataAction = "_".concat(action.project, "_").concat(action.shortName);
          return html(templateObject_10 || (templateObject_10 = __makeTemplateObject(["\n                <div data-action=", ' class="ActionItem" @click=', ">\n                    <div>", "</div>\n                    <div>", " - ", "</div>\n                </div>\n            "], ["\n                <div data-action=", ' class="ActionItem" @click=', ">\n                    <div>", "</div>\n                    <div>", " - ", "</div>\n                </div>\n            "])), dataAction, function() {
            return _this.onAddTask(action, index);
          }, action.title, action.project, action.shortName);
        });
      };
      var showListStyle = { display: !this.useContainerAdd ? "none" : "grid" };
      var showContainerStyle = { display: !this.useContainerAdd ? "block" : "none" };
      return html(templateObject_12 || (templateObject_12 = __makeTemplateObject(["\n        <div class='addTab' >\n          <h4 class='title'>", " : ", "</h4>\n          <div class='ActionItemContainer'  style=", ">\n            ", "\n          </div>\n          <div\n            id='componentContainer'\n            class='addContainer'\n            style=", " \n            @add-task=", "\n            @finished-add-task-root=", "\n          >\n          </div> \n        </div>\n        "], ["\n        <div class='addTab' >\n          <h4 class='title'>", " : ", "</h4>\n          <div class='ActionItemContainer'  style=", ">\n            ", "\n          </div>\n          <div\n            id='componentContainer'\n            class='addContainer'\n            style=", " \n            @add-task=", "\n            @finished-add-task-root=", "\n          >\n          </div> \n        </div>\n        "])), this.myMessage.selectadd, this.actualServiceOpName, styleMap(showListStyle), filteredActions.length === 0 ? html(templateObject_11 || (templateObject_11 = __makeTemplateObject(['<div class="no-actions" style="color: #fff;">', "</div>"], ['<div class="no-actions" style="color: #fff;">', "</div>"])), this.myMessage.noActionsToAdd) : renderItems(), styleMap(showContainerStyle), this.finishedAddTaskRoot, this.finishedAddTaskRoot);
    };
    ServiceAim1005542.prototype.onAddTask = function(action, index) {
      var _a;
      var webComponentAddHandle = "_".concat(action.project, "_").concat(action.shortName);
      var container = (_a = this.shadowRoot) === null || _a === void 0 ? void 0 : _a.getElementById("componentContainer");
      this.loadAndRenderComponent(webComponentAddHandle, container);
    };
    ServiceAim1005542.prototype.finishedAddTaskRoot = function(e) {
      if (e.detail.cancel) {
        this.useContainerAdd = true;
        return;
      }
      this.activeTab = "All";
      this.useContainerAdd = true;
    };
    ServiceAim1005542.prototype.loadAndRenderComponent = function(widget, container) {
      return __awaiter(this, void 0, Promise, function() {
        var componentModule, tagName, newTabIndex, modeInit, newMode, error_1;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (!widget || !container) {
                console.error("invalid call on loadAndRenderComponent: ", !!widget, !!container);
                return [
                  2
                  /*return*/
                ];
              }
              _a.label = 1;
            case 1:
              _a.trys.push([1, 3, , 4]);
              return [4, this.loadComponentModule(widget)];
            case 2:
              componentModule = _a.sent();
              if (!componentModule) {
                console.error("widget not exists or invalid:" + widget);
                return [
                  2
                  /*return*/
                ];
              }
              tagName = convertFileNameToTag(widget);
              newTabIndex = ' tabIndex="-1" ';
              modeInit = "add";
              newMode = ' mode="' + modeInit + '"';
              render(html(templateObject_13 || (templateObject_13 = __makeTemplateObject(["", ""], ["", ""])), unsafeHTML("<" + tagName + newTabIndex + newMode + "/> ")), container);
              this.useContainerAdd = false;
              return [3, 4];
            case 3:
              error_1 = _a.sent();
              console.error("Erro ao carregar o componente:" + widget + ", error: ", error_1);
              this.useContainerAdd = true;
              return [3, 4];
            case 4:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceAim1005542.prototype.loadComponentModule = function(widget) {
      return __awaiter(this, void 0, void 0, function() {
        var componentModule;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              return [4, import("./" + widget)];
            case 1:
              componentModule = _a.sent();
              return [2, componentModule];
          }
        });
      });
    };
    ServiceAim1005542.prototype.renderColums = function() {
      var _this = this;
      this.stateColumns = getUserConfigs();
      var keys = Object.keys(this.stateColumns);
      return html(templateObject_15 || (templateObject_15 = __makeTemplateObject(["\n            ", '\n            <div style="padding:0 1rem;">\n                ', '\n                <div style="margin-top:1rem;">\n                    <button @click=', ">", "</button>\n                    <button @click=", ">", "</button>\n                </div>\n            \n            </div>\n        "], ["\n            ", '\n            <div style="padding:0 1rem;">\n                ', '\n                <div style="margin-top:1rem;">\n                    <button @click=', ">", "</button>\n                    <button @click=", ">", "</button>\n                </div>\n            \n            </div>\n        "])), this.myMessage.selectColumnsYouWant, keys.map(function(key) {
        var isChecked = _this.stateColumns[key] === true;
        var isDisabled = key === "status";
        return html(templateObject_14 || (templateObject_14 = __makeTemplateObject(['\n                        <div style="display:flex; align-items:center;">\n                            <input\n                                id="', '" \n                                type="checkbox"\n                                ?checked=', " \n                                ?disabled=", " \n                                @change=", '\n                            ></input>\n                            <label style="cursor:pointer;" for=', ">", "</label>\n                        </div>\n                    "], ['\n                        <div style="display:flex; align-items:center;">\n                            <input\n                                id="', '" \n                                type="checkbox"\n                                ?checked=', " \n                                ?disabled=", " \n                                @change=", '\n                            ></input>\n                            <label style="cursor:pointer;" for=', ">", "</label>\n                        </div>\n                    "])), key, isChecked, isDisabled, function(event) {
          return _this.handleInputChange(event, key);
        }, key, key);
      }), this.handleSaveColumnClick.bind(this), this.myMessage.save, this.handleCancelColumnClick.bind(this), this.myMessage.cancel);
    };
    ServiceAim1005542.prototype.handleInputChange = function(event, key) {
      var target = event.target;
      var checked = target.checked;
      if (key === "status")
        return;
      this.stateColumns[key] = checked;
    };
    ServiceAim1005542.prototype.handleCancelColumnClick = function() {
      if (this.menu.closeMenu)
        this.menu.closeMenu();
    };
    ServiceAim1005542.prototype.handleSaveColumnClick = function() {
      var _this = this;
      if (this.stateColumns) {
        saveUserConfigs(this.stateColumns);
        this.activeTab = "Loading";
        setTimeout(function() {
          _this.activeTab = "All";
          if (_this.menu.closeMenu)
            _this.menu.closeMenu();
        }, 50);
      }
    };
    ServiceAim1005542.prototype.showConfigColumns = function() {
      var div1 = document.createElement("div");
      div1.style.padding = "1rem";
      render(this.renderColums(), div1);
      if (this.menu.setMode)
        this.menu.setMode("page", div1);
      return true;
    };
    ServiceAim1005542.prototype.checkIfHasActionToOpen = function() {
      var _this = this;
      if (!this.actionToOpen)
        return;
      setTimeout(function() {
        var _a;
        var action = (_a = _this.shadowRoot) === null || _a === void 0 ? void 0 : _a.querySelector('.ActionItem[data-action="'.concat(_this.actionToOpen, '"]'));
        if (action)
          action.click();
        _this.actionToOpen = "";
      }, 100);
    };
    ServiceAim1005542.styles = css(templateObject_16 || (templateObject_16 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceAim1005542.prototype, "activeTab", void 0);
    __decorate([
      property({ reflect: true }),
      __metadata("design:type", Object)
    ], ServiceAim1005542.prototype, "useContainerAdd", void 0);
    __decorate([
      property({ reflect: true }),
      __metadata("design:type", String)
    ], ServiceAim1005542.prototype, "actionToOpen", void 0);
    __decorate([
      property({ reflect: true }),
      __metadata("design:type", String)
    ], ServiceAim1005542.prototype, "actualServiceOpName", void 0);
    __decorate([
      property(),
      __metadata("design:type", Boolean)
    ], ServiceAim1005542.prototype, "isloading", void 0);
    ServiceAim1005542 = __decorate([
      customElement("service-aim-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceAim1005542);
    return ServiceAim1005542;
  }(ServiceBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6, templateObject_7, templateObject_8, templateObject_9, templateObject_10, templateObject_11, templateObject_12, templateObject_13, templateObject_14, templateObject_15, templateObject_16;
export {
  ServiceAim100554
};
