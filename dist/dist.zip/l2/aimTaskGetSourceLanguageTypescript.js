var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { customElement } from "lit/decorators.js";
import { AimTaskBase } from "./_100554_aimTaskBase";
var AimTaskGetSourceLanguageTypescript = (
  /** @class */
  function(_super) {
    __extends(AimTaskGetSourceLanguageTypescript2, _super);
    function AimTaskGetSourceLanguageTypescript2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    AimTaskGetSourceLanguageTypescript2.prototype.onInitializing = function() {
      this.getSource();
    };
    AimTaskGetSourceLanguageTypescript2.prototype.getSource = function() {
      var _this = this;
      if (!this.taskRoot.args) {
        this.notifyCompleteByStatus("error", "Invalid Args");
        return;
      }
      var data = JSON.parse(this.taskRoot.args);
      var shortName = data.fileName;
      this._getSource(shortName).then(function(ret) {
        var result = ret;
        _this.notifyCompleteByStatus("ok", JSON.stringify(result));
      }).catch(function(e) {
        _this.notifyCompleteByStatus("error", e);
      });
    };
    AimTaskGetSourceLanguageTypescript2.prototype._getSource = function(shortName) {
      var _this = this;
      return new Promise(function(resolve, reject) {
        return __awaiter(_this, void 0, void 0, function() {
          var mfile, value, data;
          return __generator(this, function(_a) {
            mfile = mls.l2.editor.mfiles[shortName];
            if (!mfile)
              reject("No mfile find for file: ".concat(shortName));
            value = mfile.model.getValue();
            data = this.getDataInternalization(value);
            resolve(data);
            return [
              2
              /*return*/
            ];
          });
        });
      });
    };
    AimTaskGetSourceLanguageTypescript2.prototype.getDataInternalization = function(sourceComplete) {
      var _a;
      var regex = /\/\/\/ **collab_i18n_start*([\s\S]+?)\/\/\/ **collab_i18n_end**/;
      var match = sourceComplete.match(regex);
      var internalization = void 0;
      var source = "";
      if (match && match.index) {
        var internationalizationText = match[1].trim();
        var languages = Object.keys(((_a = internationalizationText.match(/message_[a-z]{2}/g)) === null || _a === void 0 ? void 0 : _a.reduce(function(acc, curr) {
          var language = curr.split("_")[1];
          acc[language] = true;
          return acc;
        }, {})) || {});
        var startIndex = sourceComplete.substring(0, match.index).split("\n").length;
        var blankLinesBefore = sourceComplete.substring(0, match.index).match(/\n\s*\n/g);
        var blankLinesBeforeCount = blankLinesBefore ? blankLinesBefore.length : 0;
        var endIndex = startIndex + internationalizationText.split("\n").length + blankLinesBeforeCount;
        var beforeMatch = sourceComplete.substring(0, match.index).trim();
        var afterMatch = sourceComplete.substring(match.index + match[0].length).trim();
        internalization = {
          endLine: endIndex,
          source: internationalizationText,
          startLine: startIndex,
          languages
        };
        source = beforeMatch + "\n" + afterMatch;
      }
      return { internalization, source, sourceComplete };
    };
    AimTaskGetSourceLanguageTypescript2 = __decorate([
      customElement("aim-task-get-source-language-typescript-100554")
    ], AimTaskGetSourceLanguageTypescript2);
    return AimTaskGetSourceLanguageTypescript2;
  }(AimTaskBase)
);
export {
  AimTaskGetSourceLanguageTypescript
};
