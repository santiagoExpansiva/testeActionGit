var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css, LitElement, repeat } from "lit";
import { customElement, property } from "lit/decorators.js";
function initCollabDsInputSelectColor() {
}
;
var CollabDsInputSelectColor = (
  /** @class */
  function(_super) {
    __extends(CollabDsInputSelectColor2, _super);
    function CollabDsInputSelectColor2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.arrayInputSelect = [];
      _this.arraySelect = [];
      _this.valueInput = "";
      _this.valueSelect = "";
      _this.valueColor = "";
      _this.prop = "";
      _this.useInput = "true";
      _this.useSelect = "true";
      _this.useColor = "true";
      return _this;
    }
    Object.defineProperty(CollabDsInputSelectColor2.prototype, "value", {
      get: function() {
        return this.configGetValue();
      },
      set: function(str) {
        this.configSetValue(str);
      },
      enumerable: false,
      configurable: true
    });
    ;
    ;
    CollabDsInputSelectColor2.prototype.render = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["    \n            ", "\n            ", "\n            ", "\n        "], ["    \n            ", "\n            ", "\n            ", "\n        "])), this.useInput === "true" ? this.renderInput() : "", this.useSelect === "true" ? this.renderSelect() : "", this.useColor === "true" ? this.renderColor() : "");
    };
    CollabDsInputSelectColor2.prototype.renderInput = function() {
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['\n            <div>\n                <input type="search" .value="', '" @input="', '">\n                <select @change="', '" .value="px">\n                    ', "\n                </select>\n            </div>\n        "], ['\n            <div>\n                <input type="search" .value="', '" @input="', '">\n                <select @change="', '" .value="px">\n                    ', "\n                </select>\n            </div>\n        "])), this.onlyNumber(this.valueInput), this.allChange, this.allChange, repeat(this.arrayInputSelect, function(key) {
        return key;
      }, function(k, index) {
        return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(['<option value="', '">', "</option>"], ['<option value="', '">', "</option>"])), k, k);
      }));
    };
    CollabDsInputSelectColor2.prototype.renderSelect = function() {
      return html(templateObject_5 || (templateObject_5 = __makeTemplateObject(['\n            <select @change="', '" .value="px" prop="', '">\n                    ', "\n            </select>\n        "], ['\n            <select @change="', '" .value="px" prop="', '">\n                    ', "\n            </select>\n        "])), this.allChange, this.prop, repeat(this.arraySelect, function(key) {
        return key;
      }, function(k, index) {
        return html(templateObject_4 || (templateObject_4 = __makeTemplateObject(['<option value="', '">', "</option>"], ['<option value="', '">', "</option>"])), k, k);
      }));
    };
    CollabDsInputSelectColor2.prototype.renderColor = function() {
      return html(templateObject_6 || (templateObject_6 = __makeTemplateObject(['\n            <input type="color" .value="', '" @input="', '">\n        '], ['\n            <input type="color" .value="', '" @input="', '">\n        '])), this.valueColor, this.allChange);
    };
    CollabDsInputSelectColor2.prototype.updated = function() {
      if (!this.shadowRoot)
        return;
      var sel = this.shadowRoot.querySelector("div select");
      if (sel)
        sel.value = this.onlyTxt(this.valueInput);
      var sel2 = this.shadowRoot.querySelector("select[prop]");
      if (sel2)
        sel2.value = this.onlyTxt(this.valueSelect);
    };
    CollabDsInputSelectColor2.prototype.configGetValue = function() {
      var ret = "";
      if (this.useInput === "true" && this.valueInput)
        ret = this.valueInput;
      else if (this.useInput === "true")
        ret = "0px";
      if (this.useSelect === "true" && this.valueSelect)
        ret += " " + this.valueSelect;
      else if (this.useSelect === "true")
        ret = " none";
      if (this.useColor === "true" && this.valueColor)
        ret += " " + this.valueColor;
      else if (this.useColor === "true")
        ret = " #ffffff";
      return ret.trim();
    };
    CollabDsInputSelectColor2.prototype.configSetValue = function(str) {
      if (!str)
        return;
      var array = str.split(" ");
      if (this.useInput === "true" && array.length >= 1) {
        this.valueInput = array[0];
        array.splice(0, 1);
      }
      if (this.useSelect === "true" && array.length >= 1) {
        this.valueSelect = array[0];
        array.splice(0, 1);
      }
      if (this.useColor === "true" && array.length >= 1) {
        this.valueColor = array[0];
        array.splice(0, 1);
      }
    };
    CollabDsInputSelectColor2.prototype.onlyNumber = function(str) {
      var regexNum = /\d+/;
      var res = str.match(regexNum);
      return res && res[0] ? res[0] : "";
    };
    CollabDsInputSelectColor2.prototype.onlyTxt = function(str) {
      var regexStr = /[a-zA-Z]+/;
      var res = str.match(regexStr);
      return res && res[0] ? res[0] : "";
    };
    CollabDsInputSelectColor2.prototype.allChange = function(e) {
      e.stopPropagation();
      if (!this.shadowRoot)
        return;
      var parent = this.shadowRoot;
      var input = parent.querySelector('input[type="search"]');
      var sel = parent.querySelector("select");
      var sel2 = parent.querySelector("select[prop]");
      var color = parent.querySelector('input[type="color"]');
      var ret = [];
      if (this.useInput) {
        this.valueInput = input.value + sel.value;
        ret.push({ tp: "input", value: input.value + sel.value });
      }
      if (this.useSelect) {
        this.valueSelect = sel2.value;
        ret.push({ tp: "select", value: sel2.value });
      }
      if (this.useColor) {
        this.valueColor = color.value;
        ret.push({ tp: "color", value: color.value });
      }
      this.fireEvents({
        key: this.prop,
        value: ret
      });
    };
    CollabDsInputSelectColor2.prototype.fireEvents = function(obj) {
      obj.target = this;
      var onChangePropEvento = new CustomEvent("onchange", {
        bubbles: true,
        detail: obj
      });
      this.dispatchEvent(onChangePropEvento);
    };
    CollabDsInputSelectColor2.styles = css(templateObject_7 || (templateObject_7 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", String)
    ], CollabDsInputSelectColor2.prototype, "valueInput", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], CollabDsInputSelectColor2.prototype, "valueSelect", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], CollabDsInputSelectColor2.prototype, "valueColor", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], CollabDsInputSelectColor2.prototype, "prop", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], CollabDsInputSelectColor2.prototype, "useInput", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], CollabDsInputSelectColor2.prototype, "useSelect", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], CollabDsInputSelectColor2.prototype, "useColor", void 0);
    CollabDsInputSelectColor2 = __decorate([
      customElement("collab-ds-input-select-color-100554")
    ], CollabDsInputSelectColor2);
    return CollabDsInputSelectColor2;
  }(LitElement)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6, templateObject_7;
export {
  CollabDsInputSelectColor,
  initCollabDsInputSelectColor
};
