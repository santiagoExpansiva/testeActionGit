var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html } from "lit";
import { customElement, query } from "lit/decorators.js";
import { tasks, updateTaskOnServer } from "./_100554_aimHelper";
import { AimActionBase } from "./_100554_aimActionBase";
var myName = "_100554_aimActionUpdateLit";
var message_pt = {
  title: "Permitir atualizar o lit do file selecionado",
  prompt: "Prompt",
  cancel: "Cancelar",
  confirm: "Confirmar"
};
var message_en = {
  title: "Allow updating the lit of the selected file",
  prompt: "Prompt",
  cancel: "Cancel",
  confirm: "Confirm"
};
var messages = {
  "en-us": message_en,
  "pt-br": message_pt
};
var AimActionUpdateLit = (
  /** @class */
  function(_super) {
    __extends(AimActionUpdateLit2, _super);
    function AimActionUpdateLit2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.msg = messages["en-us"];
      _this.assistant = "gpt3_typescript";
      _this.title = "Update Lit";
      _this.language = "english";
      return _this;
    }
    AimActionUpdateLit2.prototype.getRules = function() {
      return {
        levels: [2],
        tags: ["*serviceSource*"]
      };
    };
    AimActionUpdateLit2.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return _super.prototype.render.call(this);
    };
    AimActionUpdateLit2.prototype.handleCancel = function() {
      this.dispatchEvent(new CustomEvent("add-task", {
        detail: { cancel: "true" },
        bubbles: true,
        composed: true
      }));
    };
    AimActionUpdateLit2.prototype.handleAdd = function() {
      var _a2;
      var taskRoot = {
        mode: "initializing",
        title: "update Lit",
        widget: myName,
        children: [],
        args: ((_a2 = this.textarea) === null || _a2 === void 0 ? void 0 : _a2.value) || "",
        trace: [(/* @__PURE__ */ new Date()).toISOString() + ": trask created at "]
      };
      tasks.unshift(taskRoot);
      this.prepareTask1(taskRoot);
      this.dispatchEvent(new CustomEvent("finished-add-task-root", {
        detail: taskRoot,
        bubbles: true,
        composed: true
      }));
    };
    AimActionUpdateLit2.prototype.renderAdd = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['\n        <p style="margin-bottom:0rem">', '</p>\n        <br>\n        <div style="display: flex; flex-direction: column; gap: 0.5rem;">\n          <label>', '</label>\n          <textarea></textarea>\n        </div>\n        <br>\n        <div class="buttonGroup">\n          <button @click="', '">', '</button>\n          <button @click="', '">', "</button>\n        </div>\n    "], ['\n        <p style="margin-bottom:0rem">', '</p>\n        <br>\n        <div style="display: flex; flex-direction: column; gap: 0.5rem;">\n          <label>', '</label>\n          <textarea></textarea>\n        </div>\n        <br>\n        <div class="buttonGroup">\n          <button @click="', '">', '</button>\n          <button @click="', '">', "</button>\n        </div>\n    "])), this.msg.title, this.msg.prompt, this.handleCancel, this.msg.cancel, this.handleAdd, this.msg.confirm);
    };
    AimActionUpdateLit2.prototype.getPrompt = function(source, user) {
      var prompt = " \n        Objective: Usando typescript, lit 3, alterar o c\uFFFDdigo abaixo seguindo as instru\uFFFD\uFFFDes.\n\n\n        System:\n\n        1. Manter a linha 1 (tripe slash) que \uFFFD de controle\n\n        2. Fazer e manter coment\uFFFDrios no c\uFFFDdigo em ingles\n\n\n        User:\n\n        1. ".concat(user, "\n\n\n        Expected Output Format:\n\n            Retornar o novo source inteiro em um unico bloco\n\n\n\n        Source:\n ").concat(source, " \n");
      return prompt;
    };
    AimActionUpdateLit2.prototype.prepareTask1 = function(taskRoot) {
      this.mode = taskRoot.mode = "in progress";
      this.addTaskAndWaitForCompletion(taskRoot, {
        mode: "initializing",
        title: "get typescript source",
        widget: "_100554_aimTaskTSSource",
        trace: [],
        nextStep: this.prepareTask2.name
        // danger, loop
      });
    };
    AimActionUpdateLit2.prototype.prepareTask2 = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      if (taskFinishResult.status === "error") {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        return;
      }
      var source = taskFinishResult.result;
      if (!source) {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        child.trace.push("invalid finish , must be notify finish with result field");
        this.requestUpdate();
        return;
      }
      child.mode = "processed";
      this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
        mode: "initializing",
        title: "exec prompt",
        widget: "_100554_aimTaskExecLLM",
        agent: this.assistant,
        prompt: this.getPrompt(source, taskFinishResult.taskRoot.args || ""),
        trace: [],
        nextStep: this.prepareTask3.name
        // danger, loop
      });
    };
    AimActionUpdateLit2.prototype.prepareTask3 = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      var result = child.result || "";
      if (taskFinishResult.status === "error" || !result) {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        return;
      }
      child.mode = "processed";
      this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
        mode: "initializing",
        title: "result",
        widget: "_100554_aimTaskResultCode",
        trace: [],
        _tempResult: result,
        nextStep: this.endTasks.name
        // danger, loop
      });
      this.requestUpdate();
    };
    AimActionUpdateLit2.prototype.endTasks = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      if (taskFinishResult.status === "error")
        child.mode = "error";
      else
        child.mode = "processed";
      this.mode = taskFinishResult.taskRoot.mode = child.mode;
      this.requestUpdate();
      updateTaskOnServer(taskFinishResult.taskIndex);
    };
    var _a;
    __decorate([
      query("textarea"),
      __metadata("design:type", typeof (_a = typeof HTMLTextAreaElement !== "undefined" && HTMLTextAreaElement) === "function" ? _a : Object)
    ], AimActionUpdateLit2.prototype, "textarea", void 0);
    AimActionUpdateLit2 = __decorate([
      customElement("aim-action-update-lit-100554")
    ], AimActionUpdateLit2);
    return AimActionUpdateLit2;
  }(AimActionBase)
);
var templateObject_1;
export {
  AimActionUpdateLit
};
