var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { CollabLitElement } from "./_100554_collabLitElement";
import { customElement, property, state } from "lit/decorators.js";
var ServiceBase = (
  /** @class */
  function(_super) {
    __extends(ServiceBase2, _super);
    function ServiceBase2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.position = "left";
      _this.visible = "false";
      _this.msize = "";
      _this.loading = false;
      return _this;
    }
    Object.defineProperty(ServiceBase2.prototype, "level", {
      // @property({ type: Number, reflect: true })
      get: function() {
        return +(this.getAttribute("level") || 7);
      },
      enumerable: false,
      configurable: true
    });
    ;
    Object.defineProperty(ServiceBase2.prototype, "serviceContent", {
      get: function() {
        return this.getNav3ServiceContent();
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(ServiceBase2.prototype, "nav3Service", {
      get: function() {
        return this.getNav3Service();
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(ServiceBase2.prototype, "serviceItemNav", {
      get: function() {
        return this.getServiceItemNav();
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(ServiceBase2.prototype, "tooltipEl", {
      get: function() {
        return this.getTooltip();
      },
      enumerable: false,
      configurable: true
    });
    ServiceBase2.prototype.getActualRef = function() {
      var _a;
      return ((_a = this.nav3Service) === null || _a === void 0 ? void 0 : _a.getAttribute("data-service")) || "";
    };
    ServiceBase2.prototype.connectedCallback = function() {
      var _a;
      _super.prototype.connectedCallback.call(this);
      this["mlsWidget"] = this;
      (_a = this.serviceContent) === null || _a === void 0 ? void 0 : _a.addEventListener("focusin", this.checkFocus.bind(this));
    };
    ServiceBase2.prototype.checkFocus = function() {
      if (!this.serviceContent)
        return;
      if (this.serviceContent.contains(document.activeElement)) {
        this.setActualServicePosition();
      }
    };
    ServiceBase2.prototype.checkMouse = function() {
      this.setActualServicePosition();
    };
    ServiceBase2.prototype.setActualServicePosition = function() {
      if (!this.serviceContent || !this.nav3Service)
        return;
      var service = this.serviceContent.getAttribute("data-service") || "";
      var position = this.nav3Service.getAttribute("toolbarposition") || "";
      mls.setActualPosition(position);
      mls.setActualService(service);
    };
    ServiceBase2.prototype.attributeChangedCallback = function(name, oldVal, newVal) {
      if (name === "visible") {
        var visible = newVal === "true";
        var reinit = oldVal !== null && visible !== false;
        if (this.onServiceClick && typeof this.onServiceClick === "function")
          this.onServiceClick(visible, reinit, this.getNav3ServiceContent());
      }
      if (name === "msize") {
        var _a = this.msize.split(","), width = _a[0], height = _a[1], top = _a[2], left = _a[3];
        if (height)
          this.style.height = height + "px";
      }
      _super.prototype.attributeChangedCallback.call(this, name, oldVal, newVal);
    };
    ServiceBase2.prototype.updated = function(changedProperties) {
      _super.prototype.updated.call(this, changedProperties);
      if (changedProperties.has("loading")) {
        var loading = changedProperties.get("loading");
        if (loading !== void 0) {
          var nav3Service = this.getNav3Service();
          if (!nav3Service)
            return;
          nav3Service["serviceBind"] = this.details.widget;
          nav3Service.setAttribute("loading", (!loading).toString());
        }
      }
    };
    ServiceBase2.prototype.setError = function(error) {
      var nav3Service = this.getNav3Service();
      if (!nav3Service)
        return;
      nav3Service["serviceBind"] = this.details.widget;
      nav3Service.setAttribute("error", error);
    };
    ServiceBase2.prototype.toogleBadge = function(show, serviceName) {
      var mlsNav2 = this.getMlsNav2();
      if (!mlsNav2) {
        console.error("Function toogleBadge: mls-nav-2 dont exist");
        return;
      }
      mlsNav2.toogleBadge(show, serviceName);
    };
    ServiceBase2.prototype.openMe = function() {
      var itemService = this.serviceItemNav;
      if (itemService)
        itemService.click();
    };
    ServiceBase2.prototype.showNav2Item = function(show) {
      var itemService = this.serviceItemNav;
      if (itemService && itemService.show)
        itemService.show(show);
    };
    ServiceBase2.prototype.openService = function(service, position, level) {
      var page = this.closest("collab-page");
      if (!page)
        return;
      var toolbar = page.querySelector('collab-nav-2[toolbarposition="'.concat(position, '"]'));
      if (!toolbar)
        return;
      if (this.level !== level) {
        toolbar.state[level][position] = service;
        this.selectLevel(level);
        return;
      }
      var item = toolbar.querySelector('collab-nav-2-item[data-service="'.concat(service, '"]'));
      if (item)
        item.click();
      return;
    };
    ServiceBase2.prototype.selectLevel = function(level) {
      var page = this.closest("collab-page");
      var nav = page === null || page === void 0 ? void 0 : page.querySelector("collab-nav-1");
      var objIndex = {
        0: 7,
        1: 6,
        2: 5,
        3: 4,
        4: 3,
        5: 2,
        6: 1,
        7: 0
      };
      if (!nav)
        return;
      nav.setAttribute("tabindexactive", objIndex[level]);
    };
    ServiceBase2.prototype.getMlsNav2 = function() {
      var _a;
      var mlsNav2 = (_a = this.closest("collab-nav-3")) === null || _a === void 0 ? void 0 : _a.previousElementSibling;
      return mlsNav2;
    };
    ServiceBase2.prototype.getNav3ServiceContent = function() {
      var parentToolbarContent = this.closest("collab-nav-3-service");
      return parentToolbarContent;
    };
    ServiceBase2.prototype.getNav3Service = function() {
      var parentToolbarContent = this.closest("collab-nav-3");
      return parentToolbarContent;
    };
    ServiceBase2.prototype.getTooltip = function() {
      var tooltip = document.querySelector("collab-tooltip");
      return tooltip;
    };
    ServiceBase2.prototype.getServiceItemNav = function() {
      var toolbar = this.getMlsNav2();
      if (!toolbar)
        return null;
      var content = this.getNav3ServiceContent();
      if (!content)
        return null;
      var dataservice = content.getAttribute("data-service");
      var item = toolbar.querySelector('collab-nav-2-item[data-service="'.concat(dataservice, '"]'));
      return item;
    };
    __decorate([
      property({ type: String, reflect: true }),
      __metadata("design:type", String)
    ], ServiceBase2.prototype, "position", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", Object)
    ], ServiceBase2.prototype, "visible", void 0);
    __decorate([
      property({ type: String, noAccessor: true }),
      __metadata("design:type", Object)
    ], ServiceBase2.prototype, "msize", void 0);
    __decorate([
      state(),
      __metadata("design:type", Boolean)
    ], ServiceBase2.prototype, "loading", void 0);
    ServiceBase2 = __decorate([
      customElement("service-base-100554")
    ], ServiceBase2);
    return ServiceBase2;
  }(CollabLitElement)
);
export {
  ServiceBase
};
