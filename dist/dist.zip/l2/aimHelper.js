var __assign = function() {
  __assign = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
        t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var tasks = [];
var lastReadFromServer = void 0;
function executePrompt(taskIndex) {
  return __awaiter(this, void 0, Promise, function() {
    var project, taskRoot, tasksToExecute, _i, _a, child, resp;
    return __generator(this, function(_b) {
      switch (_b.label) {
        case 0:
          if (taskIndex < 0 || taskIndex >= tasks.length)
            throw new Error("invalid task index");
          project = mls.actual[5].project || 0;
          if (project < 1)
            throw new Error("invalid project ".concat(project));
          taskRoot = __assign({}, tasks[taskIndex]);
          tasksToExecute = 0;
          for (_i = 0, _a = taskRoot.children; _i < _a.length; _i++) {
            child = _a[_i];
            if (child.mode === "initializing")
              tasksToExecute++;
            if (child.mode === "in progress")
              child.mode = "error";
            child._tempResult = void 0;
          }
          if (tasksToExecute < 1 || tasksToExecute > 3)
            throw new Error("invalid tasks to execute, tasksToExecute=".concat(tasksToExecute));
          return [4, mls.api.cbeAiTask(project, taskRoot, "execute LLM")];
        case 1:
          resp = _b.sent();
          if (resp.msg !== "ok")
            throw new Error("error on api prompt: " + resp.msg);
          if (resp.task)
            tasks[taskIndex] = __assign(__assign({}, tasks[taskIndex]), resp.task);
          return [2, resp.task];
      }
    });
  });
}
function updateTaskOnServer(taskIndex) {
  return __awaiter(this, void 0, Promise, function() {
    var project, taskRoot, resp;
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          if (taskIndex < 0 || taskIndex >= tasks.length)
            throw new Error("invalid task index");
          project = mls.actual[5].project || 0;
          if (project < 1)
            throw new Error("invalid project ".concat(project));
          taskRoot = __assign({}, tasks[taskIndex]);
          return [4, mls.api.cbeAiTask(project, taskRoot, "update record")];
        case 1:
          resp = _a.sent();
          if (resp.msg !== "ok")
            throw new Error("error on api prompt: " + resp.msg);
          if (resp.task)
            tasks[taskIndex] = __assign(__assign({}, tasks[taskIndex]), resp.task);
          return [2, resp.task];
      }
    });
  });
}
var timeToWait = 5 * 60 * 1e3;
function readTasksFromServer(filtedBy, filter) {
  return __awaiter(this, void 0, void 0, function() {
    var timeSinceLastRead, rc, _i, tasks_1, task;
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          if (lastReadFromServer) {
            timeSinceLastRead = (/* @__PURE__ */ new Date()).getTime() - lastReadFromServer.getTime();
            if (timeSinceLastRead < timeToWait)
              return [
                2
                /*return*/
              ];
          }
          lastReadFromServer = /* @__PURE__ */ new Date();
          return [4, mls.api.cbeAiTaskList(mls.actual[5].project || 0, "all", "")];
        case 1:
          rc = _a.sent();
          if (rc.msg !== "ok") {
            console.error("error on read tasks from server: ", rc);
            return [
              2
              /*return*/
            ];
          }
          tasks = rc.tasks;
          for (_i = 0, tasks_1 = tasks; _i < tasks_1.length; _i++) {
            task = tasks_1[_i];
            if (task.mode !== "error" && task.mode !== "processed" && task.mode !== "waiting for user")
              task.mode = "error";
          }
          return [
            2
            /*return*/
          ];
      }
    });
  });
}
function getInfoMyService(elBase) {
  var ret;
  try {
    var shadowRoot = elBase.getRootNode();
    if (!shadowRoot)
      return ret;
    var service = shadowRoot.host;
    if (!service || service.tagName !== "SERVICE-AIM-100554")
      return ret;
    var op = service.position === "left" ? "right" : "left";
    var servOp = service.nav3Service;
    if (!servOp)
      return ret;
    servOp = servOp.getActiveInstance(op);
    if (!servOp)
      return ret;
    ret = {
      level: service.level,
      position: service.position,
      actServiceOp: servOp
    };
    return ret;
  } catch (e) {
    return ret;
  }
}
function getUserConfigs() {
  var configs = getDefaultColumsConfigs();
  try {
    var str = localStorage.getItem("serviceAIM");
    if (!str)
      return configs;
    var data = JSON.parse(str);
    configs = data;
    return __assign({}, configs);
  } catch (err) {
    throw new Error(err.message);
  }
}
function saveUserConfigs(obj) {
  if (!obj)
    throw new Error("Invalid data");
  try {
    var str = localStorage.setItem("serviceAIM", JSON.stringify(obj));
  } catch (err) {
    throw new Error(err.message);
  }
}
function getDefaultColumsConfigs() {
  return {
    status: true,
    cost: true,
    sequencial: true,
    countChild: true,
    title: true,
    prompt: true,
    user: true,
    reference: false,
    lastUpdateDate: false
  };
}
;
export {
  executePrompt,
  getInfoMyService,
  getUserConfigs,
  readTasksFromServer,
  saveUserConfigs,
  tasks,
  updateTaskOnServer
};
