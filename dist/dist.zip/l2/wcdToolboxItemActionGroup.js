var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement } from "lit";
import { customElement } from "lit/decorators.js";
import * as icaGlobal from "./_100554_icaGlobal";
var WCDToolboxItemActionGroup = (
  /** @class */
  function(_super) {
    __extends(WCDToolboxItemActionGroup2, _super);
    function WCDToolboxItemActionGroup2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    WCDToolboxItemActionGroup2.prototype.createRenderRoot = function() {
      return this;
    };
    WCDToolboxItemActionGroup2.prototype.render = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject([""], [""])));
    };
    WCDToolboxItemActionGroup2.prototype.firstUpdated = function() {
      if (!this.elFCA)
        return;
      var inGroup = this.elFCA.getAttribute(icaGlobal.ATTRGROUP);
      var lock = '<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M144 144v48H304V144c0-44.2-35.8-80-80-80s-80 35.8-80 80zM80 192V144C80 64.5 144.5 0 224 0s144 64.5 144 144v48h16c35.3 0 64 28.7 64 64V448c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V256c0-35.3 28.7-64 64-64H80z"/></svg>';
      var unlock = '<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 576 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M352 144c0-44.2 35.8-80 80-80s80 35.8 80 80v48c0 17.7 14.3 32 32 32s32-14.3 32-32V144C576 64.5 511.5 0 432 0S288 64.5 288 144v48H64c-35.3 0-64 28.7-64 64V448c0 35.3 28.7 64 64 64H384c35.3 0 64-28.7 64-64V256c0-35.3-28.7-64-64-64H352V144z"/></svg>';
      if (inGroup && inGroup === "true") {
        this.innerHTML = lock;
        return;
      } else {
        this.innerHTML = unlock;
      }
    };
    WCDToolboxItemActionGroup2.prototype.updated = function(changedProperties) {
      var _this = this;
      _super.prototype.updated.call(this, changedProperties);
      this.onclick = function(event) {
        _this.initClick(event);
      };
    };
    WCDToolboxItemActionGroup2.prototype.initClick = function(e) {
      if (!this.elMain || !this.elFCA || !this.myParent || !document.defaultView)
        return;
      var inGroup = this.elFCA.getAttribute(icaGlobal.ATTRGROUP);
      var lock = '<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M144 144v48H304V144c0-44.2-35.8-80-80-80s-80 35.8-80 80zM80 192V144C80 64.5 144.5 0 224 0s144 64.5 144 144v48h16c35.3 0 64 28.7 64 64V448c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V256c0-35.3 28.7-64 64-64H80z"/></svg>';
      var unlock = '<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 576 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M352 144c0-44.2 35.8-80 80-80s80 35.8 80 80v48c0 17.7 14.3 32 32 32s32-14.3 32-32V144C576 64.5 511.5 0 432 0S288 64.5 288 144v48H64c-35.3 0-64 28.7-64 64V448c0 35.3 28.7 64 64 64H384c35.3 0 64-28.7 64-64V256c0-35.3-28.7-64-64-64H352V144z"/></svg>';
      if (inGroup && inGroup === "true") {
        this.elFCA.removeAttribute(icaGlobal.ATTRGROUP);
        this.innerHTML = unlock;
        return;
      } else {
        this.innerHTML = lock;
        this.elFCA.setAttribute(icaGlobal.ATTRGROUP, "true");
      }
    };
    WCDToolboxItemActionGroup2 = __decorate([
      customElement("wcd-toolbox-item-action-group-100554")
    ], WCDToolboxItemActionGroup2);
    return WCDToolboxItemActionGroup2;
  }(LitElement)
);
var getTemplate = function(mode, position) {
  if (mode === void 0) {
    mode = "";
  }
  if (position === void 0) {
    position = "";
  }
  var ret = templateActionGroup.group;
  if (position !== "")
    ret.position = position;
  return ret;
};
var templateActionGroup = {
  group: {
    position: "p-r4",
    tp: "action",
    format: "",
    title: "Group",
    iconSvg: '<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512"><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M144 144v48H304V144c0-44.2-35.8-80-80-80s-80 35.8-80 80zM80 192V144C80 64.5 144.5 0 224 0s144 64.5 144 144v48h16c35.3 0 64 28.7 64 64V448c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V256c0-35.3 28.7-64 64-64H80z"/></svg>',
    onclick: void 0,
    menuItens: [],
    menuSubItens: [],
    widget: "wcd-toolbox-item-action-group-100554",
    cursor: "pointer",
    attrs: void 0,
    isDblClick: false
  }
};
var templateObject_1;
export {
  WCDToolboxItemActionGroup,
  getTemplate
};
