var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css } from "lit";
import { customElement, property, query } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
var message_pt = {
  languageLabel: "Linguagens",
  alterarLabel: "Alterar"
};
var message_en = {
  languageLabel: "Languages",
  alterarLabel: "Change"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceUserSettings100554 = (
  /** @class */
  function(_super) {
    __extends(ServiceUserSettings1005542, _super);
    function ServiceUserSettings1005542() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.myMessage = messages["en-us"];
      _this.details = {
        icon: "&#xf4fe",
        state: "foreground",
        position: "right",
        tooltip: "User Settings",
        visible: true,
        widget: "_100554_serviceUserSettings",
        level: [0]
      };
      _this.onClickLink = function(op) {
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.menu = {
        title: "User Settings",
        actions: {},
        icons: {},
        actionDefault: "",
        // call after close icon clicked
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        getLastMode: void 0,
        updateTitle: void 0
      };
      _this.actualLanguage = "pt-BR";
      return _this;
    }
    ServiceUserSettings1005542.prototype.onServiceClick = function(visible, reinit, el) {
      if (visible && reinit) {
        this.requestUpdate();
      }
    };
    ServiceUserSettings1005542.prototype.getUserSettings = function() {
      var userSettings = localStorage.getItem("userSettings");
      if (!userSettings) {
        this.actualLanguage = "default";
        return;
      }
      var data = JSON.parse(userSettings);
      if (!data || !data.language) {
        this.actualLanguage = "default";
        return;
      }
      this.actualLanguage = data.language;
    };
    ServiceUserSettings1005542.prototype.setUserLanguage = function(language) {
      var data = { language: "" };
      var userSettings = localStorage.getItem("userSettings");
      if (userSettings)
        data = JSON.parse(userSettings);
      if (language === "default")
        this.actualLanguage = this.getUserDefault();
      else
        this.actualLanguage = language;
      data.language = language;
      localStorage.setItem("userSettings", JSON.stringify(data));
    };
    ServiceUserSettings1005542.prototype.getNavigatorLanguage = function() {
      var lg = navigator.language ? navigator.language : "";
      return lg;
    };
    ;
    ServiceUserSettings1005542.prototype.getUserDefault = function() {
      var navigatorLanguage = this.getNavigatorLanguage();
      var acceptLanguages = ["en-US", "pt-BR"];
      var defaultLang = acceptLanguages.includes(navigatorLanguage) ? navigatorLanguage : "en-US";
      return defaultLang;
    };
    ServiceUserSettings1005542.prototype.handleChanceLanguageClick = function() {
      if (!this.selectLanguage)
        return;
      var language = this.selectLanguage.value;
      this.setUserLanguage(language);
      location.reload();
    };
    ServiceUserSettings1005542.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.myMessage = messages[lang];
      this.getUserSettings();
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n        <section>\n            <details> \n                <summary>", '</summary>\n                <div>\n                    <select style="width:200px" .value=', ' class="select-language">\n                        <option value="default">Default</option>\n                        <option value="pt-BR">pt-BR</option>\n                        <option value="en-US">en-US</option>\n                    </select>\n                    <button style="margin-top:1rem" @click=', ">", "</button>\n                </div>\n            </details>\n        </section>\n        "], ["\n        <section>\n            <details> \n                <summary>", '</summary>\n                <div>\n                    <select style="width:200px" .value=', ' class="select-language">\n                        <option value="default">Default</option>\n                        <option value="pt-BR">pt-BR</option>\n                        <option value="en-US">en-US</option>\n                    </select>\n                    <button style="margin-top:1rem" @click=', ">", "</button>\n                </div>\n            </details>\n        </section>\n        "])), this.myMessage.languageLabel, this.actualLanguage, this.handleChanceLanguageClick, this.myMessage.alterarLabel);
    };
    var _a;
    ServiceUserSettings1005542.styles = css(templateObject_2 || (templateObject_2 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceUserSettings1005542.prototype, "actualLanguage", void 0);
    __decorate([
      query(".select-language"),
      __metadata("design:type", typeof (_a = typeof HTMLSelectElement !== "undefined" && HTMLSelectElement) === "function" ? _a : Object)
    ], ServiceUserSettings1005542.prototype, "selectLanguage", void 0);
    ServiceUserSettings1005542 = __decorate([
      customElement("service-user-settings-100554")
    ], ServiceUserSettings1005542);
    return ServiceUserSettings1005542;
  }(ServiceBase)
);
var templateObject_1, templateObject_2;
export {
  ServiceUserSettings100554
};
