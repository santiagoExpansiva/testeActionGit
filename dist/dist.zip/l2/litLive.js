var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { noChange, nothing } from "./_100554_litHtml";
import { directive, Directive, PartType } from "./_100554_litDirectives";
import { isSingleExpression, setCommittedValue } from "./_100554_litDirectivesHelper";
var LiveDirective = (
  /** @class */
  function(_super) {
    __extends(LiveDirective2, _super);
    function LiveDirective2(partInfo) {
      var _this = _super.call(this, partInfo) || this;
      if (!(partInfo.type === PartType.PROPERTY || partInfo.type === PartType.ATTRIBUTE || partInfo.type === PartType.BOOLEAN_ATTRIBUTE)) {
        throw new Error("The `live` directive is not allowed on child or event bindings");
      }
      if (!isSingleExpression(partInfo)) {
        throw new Error("`live` bindings can only contain a single expression");
      }
      return _this;
    }
    LiveDirective2.prototype.render = function(value) {
      return value;
    };
    LiveDirective2.prototype.update = function(part, _a) {
      var value = _a[0];
      if (value === noChange || value === nothing) {
        return value;
      }
      var element = part.element;
      var name = part.name;
      if (part.type === PartType.PROPERTY) {
        if (value === element[name]) {
          return noChange;
        }
      } else if (part.type === PartType.BOOLEAN_ATTRIBUTE) {
        if (!!value === element.hasAttribute(name)) {
          return noChange;
        }
      } else if (part.type === PartType.ATTRIBUTE) {
        if (element.getAttribute(name) === String(value)) {
          return noChange;
        }
      }
      setCommittedValue(part);
      return value;
    };
    return LiveDirective2;
  }(Directive)
);
var live = directive(LiveDirective);
export {
  live
};
