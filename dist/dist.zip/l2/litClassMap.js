var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { noChange } from "./_100554_litHtml";
import { directive, Directive, PartType } from "./_100554_litDirectives";
var ClassMapDirective = (
  /** @class */
  function(_super) {
    __extends(ClassMapDirective2, _super);
    function ClassMapDirective2(partInfo) {
      var _a;
      var _this = _super.call(this, partInfo) || this;
      if (partInfo.type !== PartType.ATTRIBUTE || partInfo.name !== "class" || ((_a = partInfo.strings) === null || _a === void 0 ? void 0 : _a.length) > 2) {
        throw new Error("`classMap()` can only be used in the `class` attribute and must be the only part in the attribute.");
      }
      return _this;
    }
    ClassMapDirective2.prototype.render = function(classInfo) {
      return " " + Object.keys(classInfo).filter(function(key) {
        return classInfo[key];
      }).join(" ") + " ";
    };
    ClassMapDirective2.prototype.update = function(part, _a) {
      var _this = this;
      var _b, _c;
      var classInfo = _a[0];
      if (this._previousClasses === void 0) {
        this._previousClasses = /* @__PURE__ */ new Set();
        if (part.strings !== void 0) {
          this._staticClasses = new Set(part.strings.join(" ").split(/\s/).filter(function(s) {
            return s !== "";
          }));
        }
        for (var name in classInfo) {
          if (classInfo[name] && !((_b = this._staticClasses) === null || _b === void 0 ? void 0 : _b.has(name))) {
            this._previousClasses.add(name);
          }
        }
        return this.render(classInfo);
      }
      var classList = part.element.classList;
      this._previousClasses.forEach(function(name2) {
        if (!(name2 in classInfo)) {
          classList.remove(name2);
          _this._previousClasses.delete(name2);
        }
      });
      for (var name in classInfo) {
        var value = !!classInfo[name];
        if (value !== this._previousClasses.has(name) && !((_c = this._staticClasses) === null || _c === void 0 ? void 0 : _c.has(name))) {
          if (value) {
            classList.add(name);
            this._previousClasses.add(name);
          } else {
            classList.remove(name);
            this._previousClasses.delete(name);
          }
        }
      }
      return noChange;
    };
    return ClassMapDirective2;
  }(Directive)
);
var classMap = directive(ClassMapDirective);
export {
  classMap
};
