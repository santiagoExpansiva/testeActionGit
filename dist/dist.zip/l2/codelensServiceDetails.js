var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, unsafeHTML } from "lit";
import { customElement } from "lit/decorators.js";
import { CollabLitElement } from "./_100554_collabLitElement";
function initCodelensServiceDetails() {
  return true;
}
var message_pt = {
  title: "Detalhes do servi\uFFFDo",
  p1: "Para que seu service esteja disponivel para uso, \uFFFD preciso configurar corretamente o service details, assim definindo o nome, icone, posi\uFFFD\uFFFDes, level entre outras defini\uFFFD\uFFFDes.",
  icon: "Icone",
  p2: 'Para definir o icone, voc\uFFFD precisa primeiro escolher um que mais representa ao seu service, no <a href="https://fontawesome.com/icons" target="_blank">FontAwesome </a>. Ap\uFFFDs escolher, copie o seu unicode e preencha na propriedade icon.',
  example: "Exemplo",
  state: "Estado",
  p3: ' \uFFFD possivel escolher entre o state <b>"foreground"</b> e <b>"background"</b>. No caso do foreground, o seu service ser\uFFFD executado somente quando chamado em tela pelo usu\uFFFDrio. No caso do background, seu service \uFFFD instanciado, assim que inicia o level em que ele executa. ',
  exampleCustom: "Exemplo Personalizado por posi\uFFFD\uFFFDo:",
  p4: "Tamb\uFFFDm \uFFFD possivel customizar, determinadas propriedades para cada level/position",
  exampleLevel: "Exemplo Personalizado por n\uFFFDvel:",
  p5: "Tamb\uFFFDm \uFFFD possivel customizar, determinadas propriedades para cada level, nesse caso as configura\uFFFD\uFFFDes ser\uFFFDo aplicadas tanto para a posi\uFFFD\uFFFDo left e right"
};
var message_en = {
  title: "Service Details",
  p1: "For your service to be available for use, it is necessary to properly configure the service details, thus defining the name, icon, positions, level, among other settings.",
  icon: "Icon",
  p2: 'To set the icon, you first need to choose one that best represents your service, on <a href="https://fontawesome.com/icons" target="_blank">FontAwesome</a>. After choosing, copy its unicode and fill in the icon property.',
  example: "Example",
  state: "State",
  p3: 'You can choose between the states <b>"foreground"</b> and <b>"background"</b>. In the case of foreground, your service will only be executed when called on screen by the user. In the case of background, your service is instantiated as soon as the level it executes on starts.',
  exampleCustom: "Custom Example by Position:",
  p4: "It is also possible to customize certain properties for each level/position.",
  exampleLevel: "Custom Example by Level:",
  p5: "It is also possible to customize certain properties for each level; in this case, the settings will be applied to both the left and right positions."
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var CodeLensServiceDetails100554 = (
  /** @class */
  function(_super) {
    __extends(CodeLensServiceDetails1005542, _super);
    function CodeLensServiceDetails1005542() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.msg = messages["en"];
      _this.textExampleIcon = "\n    public details: IService = {\n        <br>\n        &nbsp;&nbsp;icon: '&#x[seu unicode]',\n        <br>\n        &nbsp;&nbsp;...\n        <br>\n    }\n    ";
      _this.textExampleNormal = `
    public details: IService = {
        <br>
        &nbsp;&nbsp;icon:'&#x[seu unicode]',
        <br>
        &nbsp;&nbsp;state: 'background',
        <br>
        &nbsp;&nbsp;tooltip: 'My service',
        <br>
        &nbsp;&nbsp;visible: true,
        <br>
        &nbsp;&nbsp;position: "right",
        <br>
        &nbsp;&nbsp;level: [3]
        <br>
    }
    `;
      _this.textExampleCustom = `
    public details: IService = {
        <br>
        &nbsp;&nbsp;icon:'&#x[seu unicode]',
        <br>
        &nbsp;&nbsp;state: 'background',
        <br>
        &nbsp;&nbsp;tooltip: 'My service',
        <br>
        &nbsp;&nbsp;visible: true,
        <br>
        &nbsp;&nbsp;position: "all",
        <br>
        &nbsp;&nbsp;level: [4,5]
        <br>
        &nbsp;&nbsp;customConfiguration: {
            <br>
            &nbsp;&nbsp&nbsp;&nbsp4: {
                <br>
                &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbspleft: {
                    <br>
                    &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsptooltip: 'My title 1'
                    <br>
                &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp},
                <br>
                &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbspright: {
                    <br>
                    &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbspshow: false
                    <br>
                &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp}
                <br>
            &nbsp;&nbsp&nbsp;&nbsp},
            <br>
            &nbsp;&nbsp&nbsp;&nbsp5: {
                <br>
                &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbspright: {
                    <br>
                    &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsptooltip: 'My title 2',
                    <br>
                    &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbspclassname: 'separator-left'
                    <br>
                &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp}
                <br>
            &nbsp;&nbsp&nbsp;&nbsp}
            <br>
        &nbsp;&nbsp}
        <br>
    }
    `;
      _this.textExampleCustomLevel = `
    public details: IService = {
        <br>
        &nbsp;&nbsp;icon:'&#x[seu unicode]',
        <br>
        &nbsp;&nbsp;state: 'background',
        <br>
        &nbsp;&nbsp;tooltip: 'My service',
        <br>
        &nbsp;&nbsp;visible: true,
        <br>
        &nbsp;&nbsp;position: "all",
        <br>
        &nbsp;&nbsp;level: [3,4,5]
        <br>
        &nbsp;&nbsp;&nbsp;&nbsp;customConfiguration: {
            <br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4: {
                <br>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;tooltip: 'My service title left and right'
                  <br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}
            <br>
        &nbsp;&nbsp;&nbsp;&nbsp;}
        <br>
    }
    `;
      return _this;
    }
    CodeLensServiceDetails1005542.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n        <h1> ", " </h1>\n        <p> ", "\n        </p>\n        <h2>", "</h2>\n        <p> ", " </p>\n        <p>", ':</p>\n        <div style="    border: 1px solid #c3c3c3;padding: 1rem;">\n            <code>', "</code>\n        </div>\n        <h2>", "</h2>\n        <p>", "</p>\n        <h2>", ':</h2>\n        <div style="    border: 1px solid #c3c3c3;padding: 1rem;">\n            <code>', "</code>\n        </div>\n        <h2>", "</h2>\n        <p>", '</p>\n        <div style="    border: 1px solid #c3c3c3;padding: 1rem;">\n            <code>', "</code>\n        </div>\n        <h2>", "</h2>\n        <p>", '</p>\n        <div style="    border: 1px solid #c3c3c3;padding: 1rem;">\n            <code>', "</code>\n        </div>\n    \n        \n        "], ["\n        <h1> ", " </h1>\n        <p> ", "\n        </p>\n        <h2>", "</h2>\n        <p> ", " </p>\n        <p>", ':</p>\n        <div style="    border: 1px solid #c3c3c3;padding: 1rem;">\n            <code>', "</code>\n        </div>\n        <h2>", "</h2>\n        <p>", "</p>\n        <h2>", ':</h2>\n        <div style="    border: 1px solid #c3c3c3;padding: 1rem;">\n            <code>', "</code>\n        </div>\n        <h2>", "</h2>\n        <p>", '</p>\n        <div style="    border: 1px solid #c3c3c3;padding: 1rem;">\n            <code>', "</code>\n        </div>\n        <h2>", "</h2>\n        <p>", '</p>\n        <div style="    border: 1px solid #c3c3c3;padding: 1rem;">\n            <code>', "</code>\n        </div>\n    \n        \n        "])), this.msg.title, this.msg.p1, this.msg.icon, this.msg.p2, this.msg.example, unsafeHTML(this.textExampleIcon), this.msg.state, this.msg.p3, this.msg.example, unsafeHTML(this.textExampleNormal), this.msg.exampleCustom, this.msg.p4, unsafeHTML(this.textExampleCustom), this.msg.exampleLevel, this.msg.p5, unsafeHTML(this.textExampleCustomLevel));
    };
    CodeLensServiceDetails1005542.styles = css(templateObject_2 || (templateObject_2 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    CodeLensServiceDetails1005542 = __decorate([
      customElement("codelens-service-details-100554")
    ], CodeLensServiceDetails1005542);
    return CodeLensServiceDetails1005542;
  }(CollabLitElement)
);
var templateObject_1, templateObject_2;
export {
  CodeLensServiceDetails100554,
  initCodelensServiceDetails
};
