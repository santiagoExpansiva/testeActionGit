var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
import { html } from "lit";
import { customElement, property } from "lit/decorators.js";
import { CollabLitElement, collabState } from "./_100554_collabLitElement";
import * as states from "./_100554_collabStore";
var require_collabStateTestCount2 = __commonJS({
  "l2/collabStateTestCount2.ts"(exports) {
    var __extends = exports && exports.__extends || /* @__PURE__ */ function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
          d2.__proto__ = b2;
        } || function(d2, b2) {
          for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        if (typeof b !== "function" && b !== null)
          throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();
    var __makeTemplateObject = exports && exports.__makeTemplateObject || function(cooked, raw) {
      if (Object.defineProperty) {
        Object.defineProperty(cooked, "raw", { value: raw });
      } else {
        cooked.raw = raw;
      }
      return cooked;
    };
    var __decorate = exports && exports.__decorate || function(decorators, target, key, desc) {
      var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
      else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = exports && exports.__metadata || function(k, v) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var MyComponent = (
      /** @class */
      function(_super) {
        __extends(MyComponent2, _super);
        function MyComponent2() {
          var _this = _super !== null && _super.apply(this, arguments) || this;
          _this.count = 0;
          return _this;
        }
        MyComponent2.prototype.connectedCallback = function() {
          var _this = this;
          _super.prototype.connectedCallback.call(this);
          setTimeout(function() {
            _this.count += 10;
            _super.prototype.setCollabState.call(_this, states.COUNTHITSPAGES, _this.count);
          }, 6e3);
        };
        MyComponent2.prototype.render = function() {
          var _this = this;
          return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n      <button @click=", ">Increment Lit default</button>\n      <button @click=", " style='margin: 2em; background-color: yellow'>\n        Increment CollabState\n      </button>\n      <div>Count: ", "</div>\n    "], ["\n      <button @click=", ">Increment Lit default</button>\n      <button @click=", " style='margin: 2em; background-color: yellow'>\n        Increment CollabState\n      </button>\n      <div>Count: ", "</div>\n    "])), this.increment, function() {
            return _super.prototype.setCollabState.call(_this, states.COUNTHITSPAGES, _this.count + 1);
          }, this.count);
        };
        MyComponent2.prototype.increment = function() {
          this.count++;
          _super.prototype.setCollabState.call(this, states.COUNTHITSPAGES, this.count);
        };
        __decorate([
          property({ type: Number, state: true }),
          collabState(states.COUNTHITSPAGES),
          __metadata("design:type", Object)
        ], MyComponent2.prototype, "count", void 0);
        MyComponent2 = __decorate([
          customElement("collab-state-test-count2-100554")
        ], MyComponent2);
        return MyComponent2;
      }(CollabLitElement)
    );
    var templateObject_1;
  }
});
export default require_collabStateTestCount2();
