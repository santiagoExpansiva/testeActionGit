var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { html, css, classMap } from "lit";
import { customElement, query, property } from "lit/decorators.js";
import { CollabLitElement } from "./_100554_collabLitElement";
var initServiceSelectDsAdd = function() {
  return true;
};
var message_pt = {
  addNew: "Adicionar um novo sistema de design",
  p1: "Aqui voc\uFFFD pode criar um novo sistema de design selecionando um sistema de design padr\uFFFDo vazio ou selecionando um modelo.",
  empty: "Vazio",
  templates: "Modelos",
  next: "Pr\uFFFDximo",
  project: "Projeto",
  resume: "Resumo",
  name: "Nome",
  create: "Criar Sistema de Design"
};
var message_en = {
  addNew: "Add a new design system",
  p1: "Here you can create a new design system selecting empty default design system or select a template.",
  empty: "Empty",
  templates: "Templates",
  next: "Next",
  project: "Project",
  resume: "Resume",
  name: "Name",
  create: "Create Design System"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceSelectDsAdd100554 = (
  /** @class */
  function(_super) {
    __extends(ServiceSelectDsAdd1005542, _super);
    function ServiceSelectDsAdd1005542() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.msg = messages["en"];
      _this.state = {
        dsAvaliables: [],
        copyFrom: {
          name: void 0,
          dsindex: void 0,
          project: void 0,
          widgetIOName: void 0
        },
        name: void 0,
        project: void 0
      };
      _this.currentScenario = "sc1";
      _this.mode = "default";
      return _this;
    }
    ServiceSelectDsAdd1005542.prototype.onBtnNext1Click = function() {
      if (this.mode === "template") {
        this.changeScenario("sc2");
        this.fireEvent(0);
        return;
      }
      this.state.copyFrom.name = "config_ds_default";
      this.state.copyFrom.dsindex = 0;
      this.state.copyFrom.project = 100529;
      this.state.copyFrom.widgetIOName = "_100529_config_ds_default";
      this.changeScenario("sc3");
    };
    ServiceSelectDsAdd1005542.prototype.onBtnNext2Click = function() {
      this.changeScenario("sc3");
    };
    ServiceSelectDsAdd1005542.prototype.onBtnNext3Click = function() {
      this.addDs();
    };
    ServiceSelectDsAdd1005542.prototype.onRadioClick = function(mode) {
      this.mode = mode;
    };
    ServiceSelectDsAdd1005542.prototype.changeScenario = function(scenario) {
      this.currentScenario = scenario;
    };
    ServiceSelectDsAdd1005542.prototype.validateLettersAndNumbers = function(str) {
      var pattern = /^[A-Za-z0-9]+$/;
      return pattern.test(str);
    };
    ServiceSelectDsAdd1005542.prototype.addDs = function() {
      return __awaiter(this, void 0, void 0, function() {
        var isValidName, dsAdded, err_1;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (!this.service || !this.inputName)
                return [
                  2
                  /*return*/
                ];
              this.service.setError("");
              this.service.loading = true;
              isValidName = this.validateLettersAndNumbers(this.inputName.value);
              if (!this.inputName.value || !isValidName) {
                this.service.setError("Name invalid!");
                this.service.loading = false;
                return [
                  2
                  /*return*/
                ];
              }
              if (!this.state.project) {
                this.service.setError("Project invalid!");
                this.service.loading = false;
                return [
                  2
                  /*return*/
                ];
              }
              this.state.name = this.inputName.value;
              _a2.label = 1;
            case 1:
              _a2.trys.push([1, 3, 4, 5]);
              if (!this.state.copyFrom || !this.state.copyFrom.widgetIOName)
                return [
                  2
                  /*return*/
                ];
              return [4, mls.l5.ds.addDesignSystem(this.state.project, this.state.name, this.state.copyFrom.widgetIOName)];
            case 2:
              dsAdded = _a2.sent();
              this.service.setLastDsSelected(dsAdded.dsIndex, this.state.project);
              this.service.loading = true;
              if (this.service.menu.setMenuActive)
                this.service.menu.setMenuActive("opSelect");
              return [3, 5];
            case 3:
              err_1 = _a2.sent();
              this.service.setError(err_1.message);
              return [3, 5];
            case 4:
              this.service.loading = false;
              return [
                7
                /*endfinally*/
              ];
            case 5:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceSelectDsAdd1005542.prototype.getDsAvaliable = function() {
      var projects = this.getProjectsInMemory();
      var rc = [];
      projects.forEach(function(prj) {
        var dsByPrj = mls.l5["getProjectDesingSystems"](prj);
        dsByPrj.forEach(function(info) {
          rc.push({
            dsindex: info.dsIndex,
            name: info.dsName,
            project: prj,
            widgetIOName: info.widgetIOName
          });
        });
      });
      return rc;
    };
    ServiceSelectDsAdd1005542.prototype.getProjectsInMemory = function() {
      var projectInMemory = /* @__PURE__ */ new Set();
      Object.entries(mls.stor.files).forEach(function(item) {
        var key = item[0], value = item[1];
        projectInMemory.add(value.project);
      });
      return Array.from(projectInMemory);
    };
    ServiceSelectDsAdd1005542.prototype.fireEvent = function(index) {
      this.state.copyFrom = this.state.dsAvaliables[index];
      if (!this.state.copyFrom)
        return;
      var params = {
        service: ["_100529_service_styles_preview"],
        isAddShowPreview: true,
        dsInfoAddShowPreview: {
          index: this.state.dsAvaliables[index].dsindex,
          project: this.state.dsAvaliables[index].project
        }
      };
      mls.events.fire([3], ["DSStyleSelected"], JSON.stringify(params), 0);
    };
    ServiceSelectDsAdd1005542.prototype.renderScenario = function() {
      switch (this.currentScenario) {
        case "sc1":
          return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n                    ", "\n                "], ["\n                    ", "\n                "])), this.renderSc1());
        case "sc2":
          return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n                    ", "\n                "], ["\n                    ", "\n                "])), this.renderSc2());
        case "sc3":
          return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(["\n                    ", "\n                "], ["\n                    ", "\n                "])), this.renderSc3());
      }
    };
    ServiceSelectDsAdd1005542.prototype.renderSc1 = function() {
      var _this = this;
      return html(templateObject_4 || (templateObject_4 = __makeTemplateObject(['\n            <section id="service_selectds_section_1">\n                    <h1>', "</h1>\n                    <h4>", '</h4>\n                    <div class="ds-type-select">\n                        <div class="ds-type-select-item ', '">\n                            <input\n                             name="typeGroup"\n                             type="radio"\n                             checked="checked"\n                             value="default"\n                             @click=', '\n                             >\n                            <div>\n                                <svg fill="#000000" height="40px" width="40px" version="1.1" id="XMLID_89_" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24" xml:space="preserve"> \n                                    <g id="template"> 	<g> 		<path d="M8,22H0V2h24v20H8z M2,20h4V7.9H2V20z M8,20h14V8H8V20z M6,6h16V4H2v2H6z"></path> 	\n                                        </g> \n                                    </g> \n                                </svg>\n                            </div>\n                            <span >', '</span>\n                        </div>\n                        <div class="ds-type-select-item ', '" >\n                            <input \n                                name="typeGroup" \n                                type="radio" \n                                value="template" \n                                @click=', '\n                                >\n                            <div >\n                                <svg width="40px" height="40px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"> \n                                    <path d="M20.9983 10C20.9862 7.82497 20.8897 6.64706 20.1213 5.87868C19.2426 5 17.8284 5 15 5H12C9.17157 5 7.75736 5 6.87868 5.87868C6 6.75736 6 8.17157 6 11V16C6 18.8284 6 20.2426 6.87868 21.1213C7.75736 22 9.17157 22 12 22H15C17.8284 22 19.2426 22 20.1213 21.1213C21 20.2426 21 18.8284 21 16V15" stroke="#1C274C" stroke-width="1.5" stroke-linecap="round"></path> \n                                    <path d="M3 10V16C3 17.6569 4.34315 19 6 19M18 5C18 3.34315 16.6569 2 15 2H11C7.22876 2 5.34315 2 4.17157 3.17157C3.51839 3.82475 3.22937 4.69989 3.10149 6" stroke="#1C274C" stroke-width="1.5" stroke-linecap="round"></path> \n                                </svg>\n                            </div>\n                            <span >', '</span>\n                        </div>\n                    </div>\n                    <hr >\n                    <div class="next-action" >\n                        <button @click=', " >", "</button>\n                    </div>\n                </section>"], ['\n            <section id="service_selectds_section_1">\n                    <h1>', "</h1>\n                    <h4>", '</h4>\n                    <div class="ds-type-select">\n                        <div class="ds-type-select-item ', '">\n                            <input\n                             name="typeGroup"\n                             type="radio"\n                             checked="checked"\n                             value="default"\n                             @click=', '\n                             >\n                            <div>\n                                <svg fill="#000000" height="40px" width="40px" version="1.1" id="XMLID_89_" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24" xml:space="preserve"> \n                                    <g id="template"> 	<g> 		<path d="M8,22H0V2h24v20H8z M2,20h4V7.9H2V20z M8,20h14V8H8V20z M6,6h16V4H2v2H6z"></path> 	\n                                        </g> \n                                    </g> \n                                </svg>\n                            </div>\n                            <span >', '</span>\n                        </div>\n                        <div class="ds-type-select-item ', '" >\n                            <input \n                                name="typeGroup" \n                                type="radio" \n                                value="template" \n                                @click=', '\n                                >\n                            <div >\n                                <svg width="40px" height="40px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"> \n                                    <path d="M20.9983 10C20.9862 7.82497 20.8897 6.64706 20.1213 5.87868C19.2426 5 17.8284 5 15 5H12C9.17157 5 7.75736 5 6.87868 5.87868C6 6.75736 6 8.17157 6 11V16C6 18.8284 6 20.2426 6.87868 21.1213C7.75736 22 9.17157 22 12 22H15C17.8284 22 19.2426 22 20.1213 21.1213C21 20.2426 21 18.8284 21 16V15" stroke="#1C274C" stroke-width="1.5" stroke-linecap="round"></path> \n                                    <path d="M3 10V16C3 17.6569 4.34315 19 6 19M18 5C18 3.34315 16.6569 2 15 2H11C7.22876 2 5.34315 2 4.17157 3.17157C3.51839 3.82475 3.22937 4.69989 3.10149 6" stroke="#1C274C" stroke-width="1.5" stroke-linecap="round"></path> \n                                </svg>\n                            </div>\n                            <span >', '</span>\n                        </div>\n                    </div>\n                    <hr >\n                    <div class="next-action" >\n                        <button @click=', " >", "</button>\n                    </div>\n                </section>"])), this.msg.addNew, this.msg.p1, classMap({ active: this.mode === "default" }), function(e) {
        _this.onRadioClick("default");
      }, this.msg.empty, classMap({ active: this.mode === "template" }), function(e) {
        _this.onRadioClick("template");
      }, this.msg.templates, function(e) {
        e.preventDefault();
        _this.onBtnNext1Click();
      }, this.msg.next);
    };
    ServiceSelectDsAdd1005542.prototype.renderSc2 = function() {
      var _this = this;
      return html(templateObject_6 || (templateObject_6 = __makeTemplateObject(["\n            <section>\n                <div >\n                    <label >", ":</label>\n                    <div >\n                        <select @change=", "> \n                            ", "\n                            </select>\n                    </div>\n                </div>\n                <hr >\n                <div >\n                    <button @click=", ">", "</button>\n                </div>\n            </section>\n        "], ["\n            <section>\n                <div >\n                    <label >", ":</label>\n                    <div >\n                        <select @change=", "> \n                            ", "\n                            </select>\n                    </div>\n                </div>\n                <hr >\n                <div >\n                    <button @click=", ">", "</button>\n                </div>\n            </section>\n        "])), this.msg.templates, function(e) {
        _this.fireEvent(+e.target.value);
      }, this.state.dsAvaliables.map(function(ds, index) {
        return html(templateObject_5 || (templateObject_5 = __makeTemplateObject(["\n                                <option value=", ">", ": ", " Name: ", "</option>\n                            "], ["\n                                <option value=", ">", ": ", " Name: ", "</option>\n                            "])), index, _this.msg.project, ds.project, ds.name);
      }), function(e) {
        e.preventDefault();
        _this.onBtnNext2Click();
      }, this.msg.next);
    };
    ServiceSelectDsAdd1005542.prototype.renderSc3 = function() {
      var _this = this;
      return html(templateObject_7 || (templateObject_7 = __makeTemplateObject(["\n            <section >\n                <div>\n                    <label >", ":</label>\n                    <ul >\n                        <li>Project: ", "</li>\n                        <li>Template: ", "</li>\n                    </ul>\n                    <label>", ':</label>\n                    <div>\n                        <input id="l5_ds_add_input_name" >\n                    </div>\n                    <hr >\n                    <div >\n                        <button @click=', ">", " </button>\n                    </div>\n                </div>\n            </section>\n        "], ["\n            <section >\n                <div>\n                    <label >", ":</label>\n                    <ul >\n                        <li>Project: ", "</li>\n                        <li>Template: ", "</li>\n                    </ul>\n                    <label>", ':</label>\n                    <div>\n                        <input id="l5_ds_add_input_name" >\n                    </div>\n                    <hr >\n                    <div >\n                        <button @click=', ">", " </button>\n                    </div>\n                </div>\n            </section>\n        "])), this.msg.resume, this.state.project, this.state.copyFrom.project + "_" + this.state.copyFrom.name, this.msg.name, function(e) {
        e.preventDefault();
        _this.onBtnNext3Click();
      }, this.msg.create);
    };
    ServiceSelectDsAdd1005542.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      this.state.project = mls.actual[5].project;
      this.state.dsAvaliables = this.getDsAvaliable();
      return html(templateObject_8 || (templateObject_8 = __makeTemplateObject(['\n            <section class="service-selectds-add">\n                ', "\n            </section>\n        "], ['\n            <section class="service-selectds-add">\n                ', "\n            </section>\n        "])), this.renderScenario());
    };
    var _a;
    ServiceSelectDsAdd1005542.styles = css(templateObject_9 || (templateObject_9 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", Object)
    ], ServiceSelectDsAdd1005542.prototype, "state", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], ServiceSelectDsAdd1005542.prototype, "currentScenario", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], ServiceSelectDsAdd1005542.prototype, "mode", void 0);
    __decorate([
      query("#l5_ds_add_input_name"),
      __metadata("design:type", typeof (_a = typeof HTMLInputElement !== "undefined" && HTMLInputElement) === "function" ? _a : Object)
    ], ServiceSelectDsAdd1005542.prototype, "inputName", void 0);
    ServiceSelectDsAdd1005542 = __decorate([
      customElement("service-select-ds-add-100554")
    ], ServiceSelectDsAdd1005542);
    return ServiceSelectDsAdd1005542;
  }(CollabLitElement)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6, templateObject_7, templateObject_8, templateObject_9;
export {
  ServiceSelectDsAdd100554,
  initServiceSelectDsAdd
};
