var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { html, css } from "lit";
import { customElement, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
var message_pt = {
  resume: "Resumo",
  name: "Nome",
  createdBy: "Criado por",
  lastUpdated: "\uFFFDltima atualiza\uFFFD\uFFFDo",
  lastUpdatedBy: "\uFFFDltima atualiza\uFFFD\uFFFDo por",
  documentation: "Documenta\uFFFD\uFFFDo",
  tokens: "Tokens",
  assets: "Ativos",
  components: "Componentes",
  style: "Estilo"
};
var message_en = {
  resume: "Resume",
  name: "Name",
  createdBy: "Created By",
  lastUpdated: "Last Updated",
  lastUpdatedBy: "Last updated by",
  documentation: "Documentation",
  tokens: "Tokens",
  assets: "Assets",
  components: "Components",
  style: "Style"
};
var messages = {
  "en-us": message_en,
  "pt-br": message_pt
};
var ServiceDetailsDs100554 = (
  /** @class */
  function(_super) {
    __extends(ServiceDetailsDs1005542, _super);
    function ServiceDetailsDs1005542() {
      var _this = _super.call(this) || this;
      _this.myMessage = messages["en-us"];
      _this.details = {
        icon: "&#xf229",
        state: "background",
        tooltip: "Details Design System",
        visible: true,
        position: "right",
        widget: "_100554_serviceDetailsDs",
        level: [3]
      };
      _this.onClickLink = function(op) {
        if (op === "opOverview")
          return _this.showOverview();
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.menu = {
        title: "Details",
        actions: {
          opOverview: "Resume"
        },
        icons: {},
        actionDefault: "opOverview",
        // call after close icon clicked
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        getLastMode: void 0,
        updateTitle: void 0
      };
      _this.state = { assets: 0, components: 0, createdBy: "", documentation: 0, lastUpdated: "", lastUpdatedBy: "", name: "", style: 0, tokens: 0 };
      _this.setEvents();
      return _this;
    }
    ServiceDetailsDs1005542.prototype.onServiceClick = function(visible, reinit, el) {
      this._onServiceClick(visible, reinit, el);
    };
    ServiceDetailsDs1005542.prototype._onServiceClick = function(visible, reinit, el) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          if (visible && reinit) {
          }
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServiceDetailsDs1005542.prototype.setEvents = function() {
      var _this = this;
      mls.events.addEventListener([3], ["DSSelected"], function(ev) {
        if (!_this.serviceItemNav)
          return;
        _this.serviceItemNav.setAttribute("mode", "A");
        _this.openMe();
      });
    };
    ServiceDetailsDs1005542.prototype.showOverview = function() {
      return true;
    };
    ServiceDetailsDs1005542.prototype.init = function() {
      return __awaiter(this, void 0, void 0, function() {
        var mode, project;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              mode = mls.actual[3].mode;
              project = mls.actual[5].project;
              if (mode === void 0 || project === void 0)
                return [
                  2
                  /*return*/
                ];
              this.ds = mls.l3.getDSInstance(project, mode);
              return [4, this.ds.init()];
            case 1:
              _a.sent();
              this.setResume(project, mode);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDetailsDs1005542.prototype.setResume = function(project, index) {
      return __awaiter(this, void 0, void 0, function() {
        var dsInfo, dsName, _a;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              dsInfo = mls.l5.getProjectDesingSystems(project);
              dsName = dsInfo[index].dsName;
              if (!this.ds)
                return [
                  2
                  /*return*/
                ];
              this.state.name = dsName;
              this.state.createdBy = this.ds.createdBy;
              this.state.lastUpdated = this.getLastModifiedFormated(this.ds.lastUpdated);
              this.state.lastUpdatedBy = this.ds.lastUpdatedBy;
              this.state.components = Object.keys(this.ds.components.list).length;
              this.state.assets = this.getAssetsLenght(project, dsName);
              this.state.documentation = Object.keys(this.ds.docs.list).length;
              this.state.tokens = Object.keys(this.ds.tokens.list).length;
              _a = this.state;
              return [4, this.getStyleLines()];
            case 1:
              _a.style = _b.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDetailsDs1005542.prototype.getStyleLines = function() {
      return __awaiter(this, void 0, Promise, function() {
        var style, lenght;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (!this.ds)
                return [2, 0];
              return [4, this.ds.css.list.definitions.getContent()];
            case 1:
              style = _a.sent();
              lenght = style.split("\n").length;
              return [2, lenght];
          }
        });
      });
    };
    ServiceDetailsDs1005542.prototype.getAssetsLenght = function(project, nameDs) {
      var listFiles = mls.stor.files;
      var onlyProjects = Object.keys(listFiles).filter(function(file) {
        return listFiles[file].project === project;
      });
      var l3files = onlyProjects.filter(function(item) {
        var _a = listFiles[item], level = _a.level, folder = _a.folder;
        return level === 3 && folder.startsWith("ds/".concat(nameDs, "/assets"));
      });
      return l3files.length;
    };
    ServiceDetailsDs1005542.prototype.getLastModifiedFormated = function(dt) {
      var lastUpdated;
      var dateToday = /* @__PURE__ */ new Date();
      var dtLastWrite = new Date(dt);
      var _MS_PER_DAY = 1e3 * 60 * 60 * 24;
      function dateDiffInDays(a, b) {
        var utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
        var utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
        return Math.floor((utc2 - utc1) / _MS_PER_DAY);
      }
      var diffDays = dateDiffInDays(dtLastWrite, dateToday);
      var moreThanTwoDays = diffDays > 1;
      if (diffDays === 0)
        lastUpdated = "today";
      else if (diffDays < 30)
        lastUpdated = "".concat(diffDays, " ").concat(moreThanTwoDays ? "days" : "day", " ago");
      else {
        var lastWriteYear = dtLastWrite.getFullYear();
        var lastWriteMounth = dtLastWrite.getMonth();
        var lastWriteDay = dtLastWrite.getDate();
        var mounthFilter = {
          0: "Jan",
          1: "Feb",
          2: "Mar",
          3: "Apr",
          4: "May",
          5: "June",
          6: "July",
          7: "Aug",
          8: "Sept",
          9: "Oct",
          10: "Nov",
          11: "Dec"
        };
        lastUpdated = "on ".concat(lastWriteYear, ", ").concat(lastWriteDay, " ").concat(mounthFilter[lastWriteMounth], " ");
      }
      return lastUpdated;
    };
    ServiceDetailsDs1005542.prototype.onLinkClick = function(service) {
      this.openService(service, "left", 3);
    };
    ServiceDetailsDs1005542.prototype.render = function() {
      var _this = this;
      var lang = this.getMessageKey(messages);
      this.myMessage = messages[lang];
      this.init();
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['\n            <div class="mls-ds-resume">\n                <details open="open">\n                    <summary>', '</summary>\n                    <ul>\n                        <li>\n                            <i class="fa fa-file-signature"></i>\n                            <span>', ":</span>\n                            <span>", '</span>\n                        </li>\n                        <li>\n                            <i class="fa fa-user"></i>\n                            <span>', ":</span>\n                            <span>", '</span>\n                        </li>\n                        <li>\n                            <i class="fa fa-calendar-days"></i>\n                            <span>', ":</span>\n                            <span>", '</span>\n                        </li>\n                        <li>\n                            <i class="fa fa-regular fa-user"></i>\n                            <span>', ":</span>\n                            <span>", '</span>\n                        </li>\n                        <li>\n                            <i class="fa fa-book"></i>\n                            <span>', ':</span>\n                            <a href="#"  @click=', "> ", ' docs </a>\n                        </li>\n                        <li>\n                            <i class="fa fa-list-check"></i>\n                            <span>', ':</span>\n                            <a href="#" @click=', ">", ' tokens</a>\n                        </li>\n                        <li>\n                            <i class="fa fa-folder-tree"></i>\n                            <span>', ':</span>\n                            <a href="#" @click=', ">", ' assets </a>\n                        </li>\n                        <li>\n                            <i class="fa fa-cubes"></i>\n                            <span>', ':</span>\n                            <a href="#"" @click=', ">", ' components </a>\n                        </li>\n                        <li>\n                            <i class="fa fa-pen-nib"></i>\n                            <span>', ':</span>\n                            <a href="#""  @click=', ">", " lines</a>\n                        </li>\n                    </ul>\n                </details>\n            </div>\n        "], ['\n            <div class="mls-ds-resume">\n                <details open="open">\n                    <summary>', '</summary>\n                    <ul>\n                        <li>\n                            <i class="fa fa-file-signature"></i>\n                            <span>', ":</span>\n                            <span>", '</span>\n                        </li>\n                        <li>\n                            <i class="fa fa-user"></i>\n                            <span>', ":</span>\n                            <span>", '</span>\n                        </li>\n                        <li>\n                            <i class="fa fa-calendar-days"></i>\n                            <span>', ":</span>\n                            <span>", '</span>\n                        </li>\n                        <li>\n                            <i class="fa fa-regular fa-user"></i>\n                            <span>', ":</span>\n                            <span>", '</span>\n                        </li>\n                        <li>\n                            <i class="fa fa-book"></i>\n                            <span>', ':</span>\n                            <a href="#"  @click=', "> ", ' docs </a>\n                        </li>\n                        <li>\n                            <i class="fa fa-list-check"></i>\n                            <span>', ':</span>\n                            <a href="#" @click=', ">", ' tokens</a>\n                        </li>\n                        <li>\n                            <i class="fa fa-folder-tree"></i>\n                            <span>', ':</span>\n                            <a href="#" @click=', ">", ' assets </a>\n                        </li>\n                        <li>\n                            <i class="fa fa-cubes"></i>\n                            <span>', ':</span>\n                            <a href="#"" @click=', ">", ' components </a>\n                        </li>\n                        <li>\n                            <i class="fa fa-pen-nib"></i>\n                            <span>', ':</span>\n                            <a href="#""  @click=', ">", " lines</a>\n                        </li>\n                    </ul>\n                </details>\n            </div>\n        "])), this.myMessage.resume, this.myMessage.name, this.state.name, this.myMessage.createdBy, this.state.createdBy, this.myMessage.lastUpdated, this.state.lastUpdated, this.myMessage.lastUpdatedBy, this.state.lastUpdatedBy, this.myMessage.documentation, function(e) {
        e.preventDefault();
        _this.onLinkClick("_100554_serviceDsDocList");
      }, this.state.documentation, this.myMessage.tokens, function(e) {
        e.preventDefault();
        _this.onLinkClick("_100554_serviceDsTokens");
      }, this.state.tokens, this.myMessage.assets, function(e) {
        e.preventDefault();
        _this.onLinkClick("_100529_service_assets");
      }, this.state.assets, this.myMessage.components, function(e) {
        e.preventDefault();
        _this.onLinkClick("_100554_serviceDsComponentsList");
      }, this.state.components, this.myMessage.style, function(e) {
        e.preventDefault();
        _this.onLinkClick("_100529_service_styles");
      }, this.state.style);
    };
    ServiceDetailsDs1005542.styles = css(templateObject_2 || (templateObject_2 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", Object)
    ], ServiceDetailsDs1005542.prototype, "state", void 0);
    ServiceDetailsDs1005542 = __decorate([
      customElement("service-details-ds-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceDetailsDs1005542);
    return ServiceDetailsDs1005542;
  }(ServiceBase)
);
var templateObject_1, templateObject_2;
export {
  ServiceDetailsDs100554
};
