var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var __spreadArray = function(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};
import { html, repeat, css, LitElement } from "lit";
import { customElement, property } from "lit/decorators.js";
var initServicePreviewAddStyle = "";
var message_pt = {
  groupAndSubgroup: "Grupo e subgrupo",
  tagsForSearch: "Tags para busca",
  exInputList: "ex: entrada, lista",
  addInDesingSystem: "Adicionar no Sistema de Design",
  thisComponentAlreadyHasStyleAdded: "Este componente j\uFFFD tem estilo adicionado",
  notAdded: "Este componente n\uFFFDo \uFFFD adicionado no Design System, adicione abaixo"
};
var message_en = {
  groupAndSubgroup: "Group and subgroup",
  tagsForSearch: "Tags for search",
  exInputList: "ex: input,list",
  addInDesingSystem: "Add in Desing System",
  thisComponentAlreadyHasStyleAdded: "This component already has style added",
  notAdded: "This component is not added in Design System, please add below"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServicePreviewAddStyle = (
  /** @class */
  function(_super) {
    __extends(ServicePreviewAddStyle2, _super);
    function ServicePreviewAddStyle2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.msg = messages["en"];
      _this.father = void 0;
      _this.widget = "";
      _this.level = "";
      _this.tags = [];
      _this.error = "";
      _this.groupName = "";
      _this.styleAlready = false;
      _this.setTimeLoader = -1;
      return _this;
    }
    ServicePreviewAddStyle2.prototype.connectedCallback = function() {
      _super.prototype.connectedCallback.call(this);
      this.init();
    };
    ServicePreviewAddStyle2.prototype.render = function() {
      var lang = this.father.getMessageKey(messages);
      this.msg = lang ? messages[lang] : message_en;
      if (this.styleAlready)
        return this.renderStyleAlreadyr();
      else
        return this.renderAdd();
    };
    ServicePreviewAddStyle2.prototype.renderStyleAlreadyr = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["<h3>", "</h3>"], ["<h3>", "</h3>"])), this.msg.thisComponentAlreadyHasStyleAdded);
    };
    ServicePreviewAddStyle2.prototype.renderAdd = function() {
      var _this = this;
      return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(['\n            <div>\n                <h4 style="text-align:center">', "</h4>\n                <span>", '</span>\n                <input type="text" class="inputGroup" .value="', '"></input>\n            </div>\n            <div style="display:flex; flex-direction: column;">\n                <span>', "</span>\n                <mls-input-tags>\n                    ", '\n                    <input type="text" @keydown="', '"></input>\n                </mls-input-tags>\n                <span style="font-size:.8rem; color: #595959;">', '</span>\n            </div>\n            <div style="display:flex; justify-content:center;">\n                <button @click="', '">', '</button>\n            </div>\n            <h3 style="color:red">', "</h3>\n        "], ['\n            <div>\n                <h4 style="text-align:center">', "</h4>\n                <span>", '</span>\n                <input type="text" class="inputGroup" .value="', '"></input>\n            </div>\n            <div style="display:flex; flex-direction: column;">\n                <span>', "</span>\n                <mls-input-tags>\n                    ", '\n                    <input type="text" @keydown="', '"></input>\n                </mls-input-tags>\n                <span style="font-size:.8rem; color: #595959;">', '</span>\n            </div>\n            <div style="display:flex; justify-content:center;">\n                <button @click="', '">', '</button>\n            </div>\n            <h3 style="color:red">', "</h3>\n        "])), this.msg.notAdded, this.msg.groupAndSubgroup, this.groupName, this.msg.tagsForSearch, repeat(this.tags, function(item) {
        return item;
      }, function(vl, index) {
        return _this.renderItemTag(vl, index);
      }), this.addInputTag, this.msg.exInputList, this.addComponent, this.msg.addInDesingSystem, this.error);
    };
    ServicePreviewAddStyle2.prototype.renderItemTag = function(vl, idx) {
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(["\n            <div>\n                ", '\n                <span .idx="', '" @click="', '">x</span>\n            </div>\n        '], ["\n            <div>\n                ", '\n                <span .idx="', '" @click="', '">x</span>\n            </div>\n        '])), vl, idx, this.deleteItemTag);
    };
    ServicePreviewAddStyle2.prototype.init = function() {
      return __awaiter(this, void 0, void 0, function() {
        var e_1;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              _a.trys.push([0, 3, , 4]);
              this.showLoader(true);
              return [4, this.initds()];
            case 1:
              _a.sent();
              return [4, this.getGroup()];
            case 2:
              _a.sent();
              this.verifyAlready();
              this.showLoader(false);
              return [3, 4];
            case 3:
              e_1 = _a.sent();
              this.error = e_1.message;
              return [3, 4];
            case 4:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServicePreviewAddStyle2.prototype.verifyAlready = function() {
      if (!this.widget || !this.dsInstance)
        return;
      var componentName = this.widget;
      var comp = this.dsInstance.components.find(componentName);
      if (!comp)
        this.styleAlready = false;
    };
    ServicePreviewAddStyle2.prototype.getGroup = function() {
      return __awaiter(this, void 0, void 0, function() {
        var model, variables, groupName;
        return __generator(this, function(_a) {
          mls.actual[0].setFullName(this.widget);
          model = mls.l2.editor.get({ project: mls.actual[0].project, shortName: mls.actual[0].path });
          if (!model || !model.compilerResults)
            return [
              2
              /*return*/
            ];
          variables = model.compilerResults.tripleSlashMLS.variables;
          if (!variables)
            return [
              2
              /*return*/
            ];
          groupName = variables.groupName;
          if (!groupName)
            return [
              2
              /*return*/
            ];
          this.groupName = groupName;
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServicePreviewAddStyle2.prototype.initds = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          this.dsInstance = mls.l3.getDSInstance(mls.actual[5].project, mls.actual[3].mode);
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServicePreviewAddStyle2.prototype.addInputTag = function(e) {
      e.stopPropagation();
      var el = e.target;
      if (!el)
        return;
      var value = el.value;
      if (e.keyCode === 13) {
        this.addTag(value);
        el.value = "";
      } else if (e.keyCode === 188) {
        e.preventDefault();
        this.addTag(value);
        el.value = "";
      } else if (e.keyCode === 8 && value.length === 0) {
        this.deleteTag(this.tags.length - 1);
      }
    };
    ServicePreviewAddStyle2.prototype.addTag = function(vl) {
      if (this.tags.includes(vl))
        return;
      this.tags.push(vl);
      this.tags = __spreadArray([], this.tags, true);
    };
    ServicePreviewAddStyle2.prototype.deleteTag = function(idx) {
      if (idx > this.tags.length || idx < 0)
        return;
      this.tags.splice(idx, 1);
      this.tags = __spreadArray([], this.tags, true);
    };
    ServicePreviewAddStyle2.prototype.deleteItemTag = function(e) {
      e.stopPropagation();
      var el = e.target;
      if (!el)
        return;
      var idx = +el.idx;
      this.deleteTag(idx);
    };
    ServicePreviewAddStyle2.prototype.showLoader = function(show) {
      var _this = this;
      if (!this.father)
        return;
      clearTimeout(this.setTimeLoader);
      this.setTimeLoader = setTimeout(function() {
        _this.father.loading = show;
      }, 200);
    };
    ServicePreviewAddStyle2.prototype.addComponent = function() {
      return __awaiter(this, void 0, void 0, function() {
        var group, componentName, widget, err_1;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (!this.widget || !this.shadowRoot || !this.dsInstance)
                return [
                  2
                  /*return*/
                ];
              group = this.shadowRoot.querySelector(".inputGroup");
              if (!group || !group.value)
                throw new Error("Not found group");
              this.showLoader(true);
              componentName = this.widget;
              widget = {
                docPath: "",
                examples: [],
                group: group.value,
                l4MarketingRef: "",
                name: componentName,
                reference: void 0,
                styles: [],
                tags: this.tags,
                widgetExampleRef: {
                  path: "",
                  tagname: ""
                }
              };
              _a.label = 1;
            case 1:
              _a.trys.push([1, 3, 4, 5]);
              return [4, this.dsInstance.components.add(widget)];
            case 2:
              _a.sent();
              this.styleAlready = true;
              return [3, 5];
            case 3:
              err_1 = _a.sent();
              this.error = err_1.message;
              return [3, 5];
            case 4:
              this.showLoader(false);
              return [
                7
                /*endfinally*/
              ];
            case 5:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServicePreviewAddStyle2.styles = css(templateObject_4 || (templateObject_4 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", Object)
    ], ServicePreviewAddStyle2.prototype, "father", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServicePreviewAddStyle2.prototype, "widget", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServicePreviewAddStyle2.prototype, "level", void 0);
    __decorate([
      property({ type: Array }),
      __metadata("design:type", Array)
    ], ServicePreviewAddStyle2.prototype, "tags", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServicePreviewAddStyle2.prototype, "error", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServicePreviewAddStyle2.prototype, "groupName", void 0);
    __decorate([
      property(),
      __metadata("design:type", Boolean)
    ], ServicePreviewAddStyle2.prototype, "styleAlready", void 0);
    ServicePreviewAddStyle2 = __decorate([
      customElement("service-preview-add-style-100554")
    ], ServicePreviewAddStyle2);
    return ServicePreviewAddStyle2;
  }(LitElement)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4;
export {
  ServicePreviewAddStyle,
  initServicePreviewAddStyle
};
