const message_pt = {
  dForms: "Componentes para cria\xE7\xE3o e manipula\xE7\xE3o de formul\xE1rios, permitindo a entrada de dados pelo usu\xE1rio de forma estruturada.",
  dNavigation: "Componentes projetados para facilitar a movimenta\xE7\xE3o do usu\xE1rio pela aplica\xE7\xE3o, englobando tanto a navega\xE7\xE3o entre diferentes p\xE1ginas quanto a manipula\xE7\xE3o de conte\xFAdo dentro de uma mesma p\xE1gina.",
  dApresentation: "Componentes projetados para apresentar conte\xFAdo est\xE1tico em diferentes formatos, como texto, imagens, v\xEDdeos, sons e gr\xE1ficos.",
  dLayout: "Define a estrutura e a organiza\xE7\xE3o visual dos elementos na interface do usu\xE1rio. Engloba componentes e t\xE9cnicas para arranjar o conte\xFAdo de forma l\xF3gica e esteticamente agrad\xE1vel, melhorando a experi\xEAncia do usu\xE1rio ao navegar e interagir com a aplica\xE7\xE3o.",
  dBlocks: "Agrupa componentes complexos que encapsulam funcionalidades espec\xEDficas e s\xE3o compostos por m\xFAltiplos elementos. Esses blocos s\xE3o projetados para oferecer recursos interativos avan\xE7ados, como calend\xE1rios, visualizadores de documentos e sistemas de agendamento, enriquecendo a experi\xEAncia do usu\xE1rio com funcionalidades integradas e personaliz\xE1veis.",
  // definition sub group 1 (2 itens 'a / b')
  dFInput: "Campos de entrada para coleta de informa\xE7\xF5es do usu\xE1rio, incluindo texto, n\xFAmeros, datas, sele\xE7\xF5es e mais.",
  dFRecords: "Visualizadores de registros para apresentar dados ao usu\xE1rio em diferentes formatos como tabelas, listas, cart\xF5es e mapas geogr\xE1ficos.",
  dFTree: "Componentes para visualiza\xE7\xE3o e edi\xE7\xE3o de dados em estrutura hier\xE1rquica, como \xE1rvores de dados, breadcrumbs adaptados e mapas mentais.",
  dFSubmit: "Componentes focados na finaliza\xE7\xE3o de intera\xE7\xF5es do usu\xE1rio com formul\xE1rios. Inclui bot\xF5es para submeter, cancelar ou limpar formul\xE1rios, bem como mecanismos para enviar dados para sistemas externos. Essencial para facilitar a\xE7\xF5es conclusivas dentro de formul\xE1rios, garantindo uma interface clara e eficiente para coleta de dados e outras a\xE7\xF5es relacionadas. Considera\xE7\xF5es especiais para feedback ao usu\xE1rio e quest\xF5es de seguran\xE7a e privacidade s\xE3o fundamentais neste grupo.",
  dNLinks: "Conjunto de componentes focados na navega\xE7\xE3o entre p\xE1ginas ou recursos, seja dentro da pr\xF3pria aplica\xE7\xE3o ou para sites externos. Inclui menus, bot\xF5es, links diretos e \xE2ncoras para navega\xE7\xE3o interna.",
  dNContent: "Componentes especializados na apresenta\xE7\xE3o e intera\xE7\xE3o com diferentes tipos de conte\xFAdo dentro de uma p\xE1gina, como tabs, accordions e popups, permitindo uma experi\xEAncia de usu\xE1rio mais din\xE2mica e interativa.",
  dAText: "Componentes para apresenta\xE7\xE3o de conte\xFAdo textual, incluindo textos simples, banners, cita\xE7\xF5es e textos ricos.",
  dAImages: "Componentes para apresentar imagens, \xEDcones, avatares, galerias, carross\xE9is, sliders e mapas.",
  dAVideos: "Componentes para incorporar v\xEDdeos, apresentar v\xEDdeos imagem (como GIFs ou v\xEDdeos animados) e listas de reprodu\xE7\xE3o de v\xEDdeo.",
  dASound: "Componentes para reprodu\xE7\xE3o de sons, incluindo players de \xE1udio, efeitos sonoros e players de podcast.",
  dACharts: "Componentes para exibir gr\xE1ficos em 2D ou 3D, facilitando a visualiza\xE7\xE3o de dados.",
  dAAnimations: "Anima\xE7\xF5es para enriquecer a intera\xE7\xE3o do usu\xE1rio, incluindo carregamentos, cliques e anima\xE7\xF5es JavaScript.",
  dAEmbeds: "Componentes para incorporar conte\xFAdos de redes sociais, como posts e feeds.",
  dAMessages: "Componentes destinados a fornecer feedback ao usu\xE1rio atrav\xE9s de mensagens, alertas e notifica\xE7\xF5es. Inclui desde toasts e snackbars, que oferecem feedback breve e direto, at\xE9 alertas modais e notifica\xE7\xF5es mais persistentes. Ideal para informar os usu\xE1rios sobre o resultado de a\xE7\xF5es, avisos importantes, ou novas mensagens recebidas. Esses componentes s\xE3o projetados para serem intuitivos e minimamente intrusivos, garantindo uma comunica\xE7\xE3o eficaz sem prejudicar a experi\xEAncia do usu\xE1rio.",
  dLFlow: "Componentes e t\xE9cnicas focados na disposi\xE7\xE3o sequencial ou estruturada do conte\xFAdo, como se\xE7\xF5es, grupos, linhas, colunas e grades. Inclui abordagens adaptativas e responsivas para garantir uma apresenta\xE7\xE3o \xF3tima em diferentes dispositivos e tamanhos de tela.",
  dLGroup: "Ferramentas e componentes dedicados a agrupar elementos relacionados para destacar informa\xE7\xF5es ou organizar o conte\xFAdo de forma coesa. Inclui tabelas para dados tabulares e cart\xF5es para representa\xE7\xF5es visuais compactas de informa\xE7\xF5es.",
  dBView: "Subgrupo dedicado a componentes para visualiza\xE7\xE3o de conte\xFAdo, como documentos PDF, planilhas, e outros formatos de arquivo. Permite aos usu\xE1rios acessar e interagir com uma variedade de dados diretamente dentro da aplica\xE7\xE3o.",
  dBPlugins: "Inclui componentes de terceiros integr\xE1veis, oferecendo funcionalidades adicionais prontas para uso. Estende as capacidades da aplica\xE7\xE3o com solu\xE7\xF5es especializadas, como mapas, an\xE1lises, e widgets de m\xEDdia social.",
  dBProjects: "Agrupa componentes internos customizados, como p\xE1ginas de pesquisa e visualiza\xE7\xF5es de detalhes espec\xEDficos. Esses blocos s\xE3o projetados para complementar a aplica\xE7\xE3o com funcionalidades espec\xEDficas e vis\xF5es detalhadas de dados ou processos.",
  // definition final group (3 itens 'a / b / c')
  dFINumber: "Permite ao usu\xE1rio inserir valores num\xE9ricos, com suporte a limites m\xEDnimo e m\xE1ximo.",
  dFIString: "Campo para texto livre, podendo configurar valida\xE7\xF5es como tamanho m\xE1ximo e express\xF5es regulares.",
  dFIBoolean: "Componente para escolha bin\xE1ria, como switches ou checkboxes, ideal para configura\xE7\xF5es de sim/n\xE3o.",
  dFIDate: "Seletor de datas, com op\xE7\xF5es de configura\xE7\xE3o para limitar per\xEDodos.",
  dFITime: "Permite ao usu\xE1rio selecionar um hor\xE1rio, com suporte a diferentes formatos de hora.",
  dFIDateRange: "Componente para sele\xE7\xE3o de intervalos de datas, \xFAtil para filtros de per\xEDodos.",
  dFISelectOne: "Seletor para uma \xFAnica op\xE7\xE3o dentre v\xE1rias, podendo ser apresentado como dropdown, combobox, etc.",
  dFIMultSelect: "Permite a sele\xE7\xE3o de m\xFAltiplas op\xE7\xF5es, ideal para filtros ou configura\xE7\xF5es avan\xE7adas.",
  dFIColor: "Seletor de cores, com suporte a diferentes formatos de cor (RGB, HEX, etc.).",
  dFIEditor: "Editor de texto rico, permitindo formata\xE7\xE3o b\xE1sica (negrito, it\xE1lico) e inser\xE7\xE3o de elementos como listas e tabelas.",
  dFIFeedBack: "Para rating, ou joinha (aprova\xE7\xE3o ou n\xE3o aprova\xE7\xE3o), permitindo ao usu\xE1rio expressar opini\xF5es de forma simples.",
  dFIFile: "Para anexar um arquivo, com suporte a arrastar e soltar e visualiza\xE7\xE3o de progresso de upload.",
  dFRTable: "Exibe dados em formato de tabela, com suporte a ordena\xE7\xE3o e filtragem.",
  dFRList: "Lista de itens, customiz\xE1vel para exibir informa\xE7\xF5es resumidas ou detalhadas.",
  dFRTimeline: "Apresenta eventos ou registros em linha do tempo, facilitando a visualiza\xE7\xE3o de sequ\xEAncias ou hist\xF3ricos.",
  dFRCards: "Dados apresentados em cart\xF5es, ideal para resumos visuais com imagens ou \xEDcones.",
  dFRMap: "Exibe informa\xE7\xF5es geogr\xE1ficas em um mapa, suportando marcadores e regi\xF5es personalizadas.",
  dFRPagination: "Tabela de dados com pagina\xE7\xE3o, para gerenciar grandes conjuntos de dados sem sobrecarregar a interface.",
  dFRInfinity: "Tabela que carrega mais dados automaticamente conforme o usu\xE1rio rola a p\xE1gina, para uma navega\xE7\xE3o fluida em grandes conjuntos de dados.",
  dFTView: "Estrutura hier\xE1rquica de dados que permite expans\xE3o e contra\xE7\xE3o de n\xF3s, \xFAtil para categorias ou estruturas organizacionais.",
  dFTBreadcrumbs: "Sequ\xEAncia hier\xE1rquica de links que representam a navega\xE7\xE3o ou localiza\xE7\xE3o atual do usu\xE1rio, aqui adaptada para edi\xE7\xE3o de estruturas hier\xE1rquicas.",
  dFTDropdown: "Dropdowns aninhados que permitem a sele\xE7\xE3o em m\xFAltiplos n\xEDveis de uma hierarquia.",
  dFTAccordions: "Acordions aninhados para organizar conte\xFAdo ou categorias em m\xFAltiplas camadas, facilitando a navega\xE7\xE3o em estruturas complexas.",
  dFTTags: "Conjunto de tags ou palavras-chave que representam frequ\xEAncia ou import\xE2ncia, permitindo edi\xE7\xE3o e organiza\xE7\xE3o din\xE2mica.",
  dFTMap: "Mapa mental para organiza\xE7\xE3o e visualiza\xE7\xE3o de ideias ou conceitos em estrutura radial, facilitando a edi\xE7\xE3o e expans\xE3o de conceitos relacionados.",
  dFSSubmit: "Bot\xE3o para submeter o formul\xE1rio. Ao ser clicado, coleta e envia os dados do formul\xE1rio para o servidor ou manipulador designado. Essencial para finalizar a entrada de dados pelo usu\xE1rio.",
  dFSCancel: "Bot\xE3o para cancelar a opera\xE7\xE3o do formul\xE1rio, permitindo ao usu\xE1rio interromper sua a\xE7\xE3o e, geralmente, voltar ao estado ou tela anterior. Ajuda a garantir uma navega\xE7\xE3o segura sem submiss\xE3o de dados.",
  dFSClear: "Bot\xE3o para limpar todos os campos do formul\xE1rio, removendo as entradas do usu\xE1rio. \xDAtil em formul\xE1rios longos ou complexos onde o rein\xEDcio pode ser necess\xE1rio.",
  dFSSend: "Mecanismo para enviar dados do formul\xE1rio para um sistema ou site externo. Utilizado para integra\xE7\xF5es com APIs de terceiros ou para coletar informa\xE7\xF5es em diferentes plataformas. Deve garantir a seguran\xE7a e a privacidade dos dados do usu\xE1rio.",
  dNLMenus: "Menus que oferecem navega\xE7\xE3o principal atrav\xE9s da aplica\xE7\xE3o ou para sites externos. Suportam estruturas hier\xE1rquicas para organizar as op\xE7\xF5es de navega\xE7\xE3o.",
  dNLButtons: "Bot\xF5es utilizados para a\xE7\xF5es de navega\xE7\xE3o, como submeter formul\xE1rios ou redirecionar para outras p\xE1ginas internas ou externas.",
  dNLLinks: "Links para navega\xE7\xE3o direta entre p\xE1ginas da aplica\xE7\xE3o ou para recursos externos, com suporte a abertura em nova aba dependendo do contexto (target).",
  dNLBreadcrumbs: "Caminhos de navega\xE7\xE3o hier\xE1rquicos que indicam a localiza\xE7\xE3o atual do usu\xE1rio dentro da aplica\xE7\xE3o e facilitam o retorno a n\xEDveis anteriores.",
  dNLAnchors: "\xC2ncoras que permitem a navega\xE7\xE3o interna em uma p\xE1gina, direcionando o usu\xE1rio para se\xE7\xF5es espec\xEDficas sem recarregar a p\xE1gina.",
  dNCTab: "Abas que organizam conte\xFAdo relacionado em se\xE7\xF5es separadas, permitindo a troca entre elas sem recarregar a p\xE1gina.",
  dNCScenary: "Componentes que guiam o usu\xE1rio atrav\xE9s de cen\xE1rios ou passos sequenciais dentro de uma mesma p\xE1gina, ideal para tutoriais ou configura\xE7\xF5es passo a passo.",
  dNCStepper: "Indicadores de passo (steppers) que mostram progresso atrav\xE9s de uma sequ\xEAncia de passos, \xFAteis para processos de m\xFAltiplas etapas como checkouts ou formul\xE1rios longos.",
  dNCToolbar: "Barras de ferramentas que oferecem acesso r\xE1pido a a\xE7\xF5es e ferramentas frequentemente usadas, podendo ser parte da navega\xE7\xE3o de conte\xFAdo ou a\xE7\xE3o.",
  dNCAccordion: "Acorde\xF5es que permitem a expans\xE3o e contra\xE7\xE3o de se\xE7\xF5es de conte\xFAdo, organizando grandes quantidades de informa\xE7\xE3o em um espa\xE7o compacto.",
  dNCPopup: "Popups que fornecem informa\xE7\xF5es adicionais, mensagens ou conte\xFAdo interativo, aparecendo sobre o conte\xFAdo existente sem redirecionar o usu\xE1rio.",
  dNCScrollspy: "Um componente que atualiza links de navega\xE7\xE3o baseados na rolagem, indicando qual se\xE7\xE3o do conte\xFAdo est\xE1 atualmente vis\xEDvel na tela.",
  dATText: "Para apresentar blocos de texto simples.",
  dATBanner: "Para exibir banners promocionais ou informativos.",
  dATQuote: "Para destacar cita\xE7\xF5es ou depoimentos.",
  dATRich: "Para apresentar texto com formata\xE7\xE3o rica.",
  dAIImages: "Para apresentar imagens individuais ou em grupo.",
  dAIIcons: "Para exibir \xEDcones representativos.",
  dAIAvatar: "Para mostrar avatares de usu\xE1rios ou personagens.",
  dAIGallery: "Para exibir cole\xE7\xF5es de imagens em formato de galeria.",
  dAICarousel: "Para apresentar imagens em um carrossel rotativo.",
  dAISliders: "Para mostrar imagens ou banners em um slider.",
  dAIMaps: "Para exibir mapas est\xE1ticos ou interativos.",
  dAVEmbedded: "Para incorporar v\xEDdeos de plataformas externas.",
  dAVImage: "Para mostrar v\xEDdeos em formato de imagem, como GIFs ou v\xEDdeos animados.",
  dAVVideo: "Para listar v\xEDdeos em uma sequ\xEAncia ou cole\xE7\xE3o.",
  dASPlayer: "Para reproduzir arquivos de \xE1udio ou m\xFAsica.",
  dASSound: "Para executar efeitos sonoros em a\xE7\xF5es espec\xEDficas.",
  dASPodcast: "Para reproduzir epis\xF3dios de podcast.",
  dAC2d: "Para exibir gr\xE1ficos bidimensionais.",
  dAC3d: "Para mostrar gr\xE1ficos tridimensionais.",
  dAALoading: "Anima\xE7\xF5es que indicam carregamento de conte\xFAdo.",
  dAAClick: "Anima\xE7\xF5es ativadas por cliques ou intera\xE7\xF5es do usu\xE1rio.",
  dAAJava: "Anima\xE7\xF5es complexas criadas com JavaScript.",
  dAAIndicators: "Componentes projetados para informar o usu\xE1rio sobre o estado ou progresso de uma opera\xE7\xE3o. Inclui barras de progresso, indicadores de carregamento, luzes de status e outros elementos visuais que comunicam informa\xE7\xF5es essenciais de forma clara e concisa. Esses componentes s\xE3o fundamentais para melhorar a experi\xEAncia do usu\xE1rio, fornecendo feedback visual imediato sobre as a\xE7\xF5es em andamento.",
  dAEPost: "Para incorporar posts de redes sociais diretamente na p\xE1gina.",
  dAEFeed: "Para mostrar feeds ao vivo de redes sociais na aplica\xE7\xE3o.",
  dAMToast: "Mensagens breves que aparecem e desaparecem automaticamente, ideais para feedback de a\xE7\xF5es n\xE3o intrusivas.",
  dAMAlert: "Alertas s\xE3o notifica\xE7\xF5es importantes que requerem a aten\xE7\xE3o do usu\xE1rio, podendo ser usadas para erros cr\xEDticos, avisos ou confirma\xE7\xF5es.",
  dAMSneackbar: "Snackbars fornecem mensagens breves com a op\xE7\xE3o de uma a\xE7\xE3o pelo usu\xE1rio, como desfazer uma a\xE7\xE3o ou fechar a mensagem.",
  dAMModal: "Modais s\xE3o janelas que aparecem em cima do conte\xFAdo da p\xE1gina para comunicar mensagens importantes ou exigir uma a\xE7\xE3o do usu\xE1rio antes de prosseguir.",
  dAMNotification: "Notifica\xE7\xF5es s\xE3o mensagens que podem ser enviadas a usu\xE1rios mesmo quando n\xE3o est\xE3o ativamente usando a aplica\xE7\xE3o, \xFAteis para atualiza\xE7\xF5es importantes ou lembretes.",
  dAMBadges: "Badges indicam status ou contam itens, como mensagens n\xE3o lidas ou notifica\xE7\xF5es, geralmente sobrepostos a \xEDcones ou bot\xF5es.",
  dLFSection: "Divide o conte\xFAdo em se\xE7\xF5es l\xF3gicas e distintas, facilitando a organiza\xE7\xE3o e a compreens\xE3o pelo usu\xE1rio.",
  dLFGroup: "Agrupa elementos relacionados, promovendo uma visualiza\xE7\xE3o organizada e coesa do conte\xFAdo.",
  dLFRow: "Organiza itens em uma sequ\xEAncia horizontal, ideal para listar elementos que compartilham um contexto.",
  dLFColumn: "Organiza itens em uma sequ\xEAncia vertical, suportando estruturas hier\xE1rquicas ou listagens ordenadas.",
  dLFGrid: "Apresenta cole\xE7\xF5es de itens em uma estrutura bidimensional, facilitando a compara\xE7\xE3o e visualiza\xE7\xE3o.",
  dLFAdaptive: "Layouts que se ajustam dinamicamente ao tamanho do dispositivo, mantendo a acessibilidade e a usabilidade.",
  dLFSplit: "Divide a tela em \xE1reas distintas para intera\xE7\xE3o simult\xE2nea com diferentes conte\xFAdos.",
  dLGTable: "Apresenta dados em formato tabular, permitindo f\xE1cil an\xE1lise e compara\xE7\xE3o de informa\xE7\xF5es.",
  dLGCards: "Destaca conjuntos de informa\xE7\xF5es ou itens individuais em formato de cart\xF5es, oferecendo uma vis\xE3o geral acess\xEDvel.",
  dBVPdf: "Componente para visualizar documentos PDF dentro da aplica\xE7\xE3o. Permite aos usu\xE1rios ler e interagir com conte\xFAdo PDF diretamente na interface, sem necessidade de downloads ou aplicativos externos.",
  dBVViwer: "Visualizador de planilhas que suporta formatos como Excel. Facilita a visualiza\xE7\xE3o e manipula\xE7\xE3o de dados de planilhas dentro da aplica\xE7\xE3o, permitindo an\xE1lises e revis\xF5es diretas.",
  dBVDocument: "Permite a visualiza\xE7\xE3o de v\xE1rios formatos de documentos, como Word, PowerPoint e PDF, integrando uma vis\xE3o de conte\xFAdo rico sem a necessidade de software adicional.",
  dBPCalendar: "Plugin de calend\xE1rio que oferece visualiza\xE7\xF5es e intera\xE7\xF5es com eventos e agendas. Integra-se com sistemas externos para sincroniza\xE7\xE3o e gerenciamento de eventos.",
  dBPSchedule: "Componente para planejamento e visualiza\xE7\xE3o de agendas pessoais ou profissionais. Permite aos usu\xE1rios organizar e visualizar compromissos, tarefas e eventos em um layout claro e interativo.",
  dBPExternal: "Facilita a integra\xE7\xE3o com APIs externas para buscar ou enviar dados. Ideal para funcionalidades como visualizar condi\xE7\xF5es clim\xE1ticas, cota\xE7\xF5es de a\xE7\xF5es ou atualiza\xE7\xF5es de redes sociais diretamente na aplica\xE7\xE3o.",
  dBPPages: "Permite a incorpora\xE7\xE3o de p\xE1ginas inteiras ou componentes espec\xEDficos dentro da aplica\xE7\xE3o atual. \xDAtil para integrar funcionalidades ou informa\xE7\xF5es adicionais sem a necessidade de navega\xE7\xE3o externa."
};
const message_en = {
  dForms: "Components for creating and manipulating forms, allowing structured data entry by the user.",
  dNavigation: "Components designed to facilitate user movement through the application, encompassing both navigation between different pages and content manipulation within the same page.",
  dApresentation: "Components designed to present static content in different formats, such as text, images, videos, sounds, and graphics.",
  dLayout: "Defines the structure and visual organization of elements in the user interface. It encompasses components and techniques to arrange content in a logical and aesthetically pleasing manner, enhancing the user's experience while navigating and interacting with the application.",
  dBlocks: "Groups complex components that encapsulate specific functionalities and are composed of multiple elements. These blocks are designed to offer advanced interactive features, such as calendars, document viewers, and scheduling systems, enriching the user experience with integrated and customizable functionalities.",
  // definition sub group 1 (2 itens 'a / b')
  dFInput: "Input fields for collecting user information, including text, numbers, dates, selections, and more.",
  dFRecords: "Record viewers to present data to the user in different formats such as tables, lists, cards, and geographic maps.",
  dFTree: "Components for viewing and editing data in a hierarchical structure, such as data trees, adapted breadcrumbs, and mind maps.",
  dFSubmit: "Components focused on finalizing user interactions with forms. Includes buttons to submit, cancel, or clear forms, as well as mechanisms to send data to external systems. Essential for facilitating conclusive actions within forms, ensuring a clear and efficient interface for data collection and related actions. Special considerations for user feedback and security and privacy issues are fundamental in this group.",
  dNLinks: "Set of components focused on navigation between pages or resources, either within the application itself or to external sites. Includes menus, buttons, direct links, and anchors for internal navigation.",
  dNContent: "Components specialized in presenting and interacting with different types of content within a page, such as tabs, accordions, and popups, allowing for a more dynamic and interactive user experience.",
  dAText: "Components for presenting textual content, including plain text, banners, quotes, and rich text.",
  dAImages: "Components for displaying images, icons, avatars, galleries, carousels, sliders, and maps.",
  dAVideos: "Components for embedding videos, displaying image videos (like GIFs or animated videos), and video playlists.",
  dASound: "Components for sound playback, including audio players, sound effects, and podcast players.",
  dACharts: "Components for displaying charts in 2D or 3D, facilitating data visualization.",
  dAAnimations: "Animations to enrich user interaction, including loadings, clicks, and JavaScript animations.",
  dAEmbeds: "Components for embedding social media content, such as posts and feeds.",
  dAMessages: "Components designed to provide user feedback through messages, alerts, and notifications. Includes everything from toasts and snackbars, which offer brief and direct feedback, to modal alerts and more persistent notifications. Ideal for informing users about action results, important warnings, or new messages received. These components are designed to be intuitive and minimally intrusive, ensuring effective communication without compromising the user experience.",
  dLFlow: "Components and techniques focused on the sequential or structured arrangement of content, such as sections, groups, rows, columns, and grids. Includes adaptive and responsive approaches to ensure optimal presentation on different devices and screen sizes.",
  dLGroup: "Tools and components dedicated to grouping related elements to highlight information or organize content cohesively. Includes tables for tabular data and cards for compact visual representations of information.",
  dBView: "Subgroup dedicated to components for content viewing, such as PDF documents, spreadsheets, and other file formats. Allows users to access and interact with a variety of data directly within the application.",
  dBPlugins: "Includes third-party integrable components, offering ready-to-use additional functionalities. Extends the application's capabilities with specialized solutions, such as maps, analytics, and social media widgets.",
  dBProjects: "Groups custom internal components, such as search pages and specific detail views. These blocks are designed to complement the application with specific functionalities and detailed views of data or processes.",
  // definition final group (3 itens 'a / b / c')
  dFINumber: "Allows the user to input numerical values, with support for minimum and maximum limits.",
  dFIString: "Field for free text, with configurable validations such as maximum length and regular expressions.",
  dFIBoolean: "Component for binary choice, like switches or checkboxes, ideal for yes/no settings.",
  dFIDate: "Date selector, with configuration options to limit periods.",
  dFITime: "Allows the user to select a time, with support for different time formats.",
  dFIDateRange: "Component for selecting date ranges, useful for period filters.",
  dFISelectOne: "Selector for a single option among many, which can be presented as a dropdown, combobox, etc.",
  dFIMultSelect: "Allows multiple option selection, ideal for filters or advanced settings.",
  dFIColor: "Color picker, with support for different color formats (RGB, HEX, etc.).",
  dFIEditor: "Rich text editor, allowing basic formatting (bold, italic) and insertion of elements like lists and tables.",
  dFIFeedBack: "For rating or thumbs up/down (approval or disapproval), allowing the user to express opinions simply.",
  dFIFile: "For attaching a file, with support for drag and drop and upload progress visualization.",
  dFRTable: "Displays data in table format, with support for sorting and filtering.",
  dFRList: "List of items, customizable to display summarized or detailed information.",
  dFRTimeline: "Presents events or records in a timeline, facilitating the visualization of sequences or histories.",
  dFRCards: "Data presented in cards, ideal for visual summaries with images or icons.",
  dFRMap: "Displays geographic information on a map, supporting markers and custom regions.",
  dFRPagination: "Data table with pagination, to manage large data sets without overloading the interface.",
  dFRInfinity: "Table that automatically loads more data as the user scrolls the page, for smooth navigation through large data sets.",
  dFTView: "Hierarchical data structure that allows for expansion and contraction of nodes, useful for categories or organizational structures.",
  dFTBreadcrumbs: "Hierarchical sequence of links representing the user's navigation or current location, here adapted for editing hierarchical structures.",
  dFTDropdown: "Nested dropdowns that allow selection at multiple levels of a hierarchy.",
  dFTAccordions: "Nested accordions to organize content or categories into multiple layers, facilitating navigation in complex structures.",
  dFTTags: "Set of tags or keywords representing frequency or importance, allowing dynamic editing and organization.",
  dFTMap: "Mind map for organizing and visualizing ideas or concepts in a radial structure, facilitating editing and expansion of related concepts.",
  dFSSubmit: "Button to submit the form. When clicked, it collects and sends the form data to the server or designated handler. Essential for finalizing user data entry.",
  dFSCancel: "Button to cancel the form operation, allowing the user to abort their action and typically return to the previous state or screen. Helps ensure safe navigation without data submission.",
  dFSClear: "Button to clear all form fields, removing user inputs. Useful in long or complex forms where reset may be necessary.",
  dFSSend: "Mechanism for sending form data to an external system or website. Used for integrations with third-party APIs or for collecting information across different platforms. Must ensure user data security and privacy.",
  dNLMenus: "Menus that provide primary navigation through the application or to external sites. Support hierarchical structures to organize navigation options.",
  dNLButtons: "Buttons used for navigation actions, such as submitting forms or redirecting to other internal or external pages.",
  dNLLinks: "Links for direct navigation between application pages or external resources, with support for opening in a new tab depending on the context (target).",
  dNLBreadcrumbs: "Hierarchical navigation paths that indicate the user's current location within the application and facilitate returning to previous levels.",
  dNLAnchors: "Anchors that allow internal navigation on a page, directing the user to specific sections without reloading the page.",
  dNCTab: "Tabs that organize related content into separate sections, allowing switching between them without reloading the page.",
  dNCScenary: "Components that guide the user through scenarios or sequential steps within the same page, ideal for tutorials or step-by-step configurations.",
  dNCStepper: "Step indicators (steppers) that show progress through a sequence of steps, useful for multi-step processes such as checkouts or long forms.",
  dNCToolbar: "Toolbars that offer quick access to frequently used actions and tools, which can be part of content or action navigation.",
  dNCAccordion: "Accordions that allow expanding and collapsing sections of content, organizing large amounts of information in a compact space.",
  dNCPopup: "Popups that provide additional information, messages, or interactive content, appearing over the existing content without redirecting the user.",
  dNCScrollspy: "A component that updates navigation links based on scrolling, indicating which section of the content is currently visible on the screen.",
  dATText: "To present blocks of simple text.",
  dATBanner: "To display promotional or informational banners.",
  dATQuote: "To highlight quotations or testimonials.",
  dATRich: "To present text with rich formatting.",
  dAIImages: "To present individual or grouped images.",
  dAIIcons: "To display representative icons.",
  dAIAvatar: "To show user or character avatars.",
  dAIGallery: "To display collections of images in gallery format.",
  dAICarousel: "To present images in a rotating carousel.",
  dAISliders: "To display images or banners in a slider.",
  dAIMaps: "To display static or interactive maps.",
  dAVEmbedded: "To embed videos from external platforms.",
  dAVImage: "To display videos in image format, such as GIFs or animated videos.",
  dAVVideo: "To list videos in a sequence or collection.",
  dASPlayer: "To play audio files or music.",
  dASSound: "To play sound effects on specific actions.",
  dASPodcast: "To play podcast episodes.",
  dAC2d: "To display two-dimensional charts.",
  dAC3d: "To show three-dimensional charts.",
  dAALoading: "Animations indicating content loading.",
  dAAClick: "Animations triggered by clicks or user interactions.",
  dAAJava: "Complex animations created with JavaScript.",
  dAAIndicators: "Components designed to inform the user about the state or progress of an operation. Includes progress bars, loading indicators, status lights, and other visual elements that communicate essential information clearly and concisely. These components are essential for improving the user experience by providing immediate visual feedback on ongoing actions.",
  dAEPost: "To embed social media posts directly on the page.",
  dAEFeed: "To display live social media feeds in the application.",
  dAMToast: "Brief messages that appear and disappear automatically, ideal for non-intrusive action feedback.",
  dAMAlert: "Alerts are important notifications that require the user's attention, and can be used for critical errors, warnings, or confirmations.",
  dAMSneackbar: "Snackbars provide brief messages with the option for user action, such as undoing an action or closing the message.",
  dAMModal: "Modals are windows that appear on top of the page content to communicate important messages or require user action before proceeding.",
  dAMNotification: "Notifications are messages that can be sent to users even when they are not actively using the application, useful for important updates or reminders.",
  dAMBadges: "Badges indicate status or count items, such as unread messages or notifications, usually overlaid on icons or buttons.",
  dLFSection: "Divides content into logical and distinct sections, facilitating organization and understanding by the user.",
  dLFGroup: "Groups related elements, promoting an organized and cohesive view of the content.",
  dLFRow: "Organizes items in a horizontal sequence, ideal for listing elements that share a context.",
  dLFColumn: "Organizes items in a vertical sequence, supporting hierarchical structures or ordered listings.",
  dLFGrid: "Presents collections of items in a two-dimensional structure, facilitating comparison and visualization.",
  dLFAdaptive: "Layouts that dynamically adjust to the device size, maintaining accessibility and usability.",
  dLFSplit: "Divides the screen into distinct areas for simultaneous interaction with different content.",
  dLGTable: "Displays data in tabular format, allowing easy analysis and comparison of information.",
  dLGCards: "Highlights sets of information or individual items in card format, providing an accessible overview.",
  dBVPdf: "Component for viewing PDF documents within the application. Allows users to read and interact with PDF content directly in the interface, without the need for downloads or external applications.",
  dBVViwer: "Spreadsheet viewer that supports formats such as Excel. Facilitates the visualization and manipulation of spreadsheet data within the application, allowing for direct analysis and reviews.",
  dBVDocument: "Allows the visualization of various document formats, such as Word, PowerPoint, and PDF, integrating a rich content view without the need for additional software.",
  dBPCalendar: "Calendar plugin that offers views and interactions with events and schedules. Integrates with external systems for event synchronization and management.",
  dBPSchedule: "Component for planning and viewing personal or professional schedules. Allows users to organize and view appointments, tasks, and events in a clear and interactive layout.",
  dBPExternal: "Facilitates integration with external APIs to fetch or send data. Ideal for features such as viewing weather conditions, stock quotes, or social media updates directly in the application.",
  dBPPages: "Allows the embedding of entire pages or specific components within the current application. Useful for integrating additional functionality or information without the need for external navigation."
};
const messages = {
  "en-us": message_en,
  "pt-br": message_pt
};
const getMessageKey = (messages2) => {
  const keys = Object.keys(messages2);
  if (!keys || keys.length < 1) throw new Error("Error Message not valid for international");
  const firstKey = keys[0];
  const lang2 = (document.documentElement.lang || "").toLowerCase();
  if (!lang2) return firstKey;
  if (messages2.hasOwnProperty(lang2)) return lang2;
  const similarLang = keys.find((key) => lang2.substring(0, 2) === key);
  if (similarLang) return similarLang;
  return firstKey;
};
const lang = getMessageKey(messages);
const msg = messages[lang];
const icaDescriptions = [
  // definition principal group 
  { group: "Forms", description: msg.dForms },
  { group: "Navigation", description: msg.dNavigation },
  { group: "Apresentation", description: msg.dApresentation },
  { group: "Layout", description: msg.dLayout },
  { group: "Blocks", description: msg.dBlocks },
  // definition sub group 1 (2 itens 'a / b')
  { group: "Forms / Input", description: msg.dFInput },
  { group: "Forms / Records", description: msg.dFRecords },
  { group: "Forms / Tree", description: msg.dFTree },
  { group: "Forms / Submit", description: msg.dFSubmit },
  { group: "Navigation / Links", description: msg.dNLinks },
  { group: "Navigation / Content", description: msg.dNContent },
  { group: "Apresentation / Text", description: msg.dAText },
  { group: "Apresentation / Images", description: msg.dAImages },
  { group: "Apresentation / Video", description: msg.dAVideos },
  { group: "Apresentation / Sound", description: msg.dASound },
  { group: "Apresentation / Charts", description: msg.dACharts },
  { group: "Apresentation / Animations", description: msg.dAAnimations },
  { group: "Apresentation / Embeds", description: msg.dAEmbeds },
  { group: "Apresentation / Messages", description: msg.dAMessages },
  { group: "Layout / Flow", description: msg.dLFlow },
  { group: "Layout / Group", description: msg.dLGroup },
  { group: "Blocks / Viewer", description: msg.dBView },
  { group: "Blocks / Plugins", description: msg.dBPlugins },
  { group: "Blocks / Projects", description: msg.dBProjects },
  // definition final group (3 itens 'a / b / c')
  // Input
  {
    group: "Forms / Input / Number",
    description: msg.dFINumber,
    prompt: "O componente, um 'Input / Form / Number', deve apresentar uma combina\xE7\xE3o de uma caixa de entrada de texto e um controle deslizante (slider). Ele deve permitir que os usu\xE1rios digitem um n\xFAmero diretamente na caixa de entrada, ajustando o controle deslizante de acordo dentro de um intervalo m\xEDnimo e m\xE1ximo pr\xE9-definido. Se o usu\xE1rio inserir um n\xFAmero inv\xE1lido, uma mensagem de erro vermelha deve aparecer abaixo do componente.",
    attributes: "name,datasource,placeholder,label,pattern,errormessage,maxvalue,minvalue,step,required,disabled,readonly,autofocus,hint,inputmode"
  },
  { group: "Forms / Input / String", description: msg.dFIString, attributes: "name,hint,label,required,disabled,readonly,maxlength,minlength,placeholder,pattern,errormessage,autofocus,autoCapitalize,autocorrect,autocomplete, datasource" },
  { group: "Forms / Input / Boolean", description: msg.dFIBoolean },
  { group: "Forms / Input / Date", description: msg.dFIDate },
  { group: "Forms / Input / Time", description: msg.dFITime },
  { group: "Forms / Input / Date Range", description: msg.dFIDateRange },
  { group: "Forms / Input / Select One", description: msg.dFISelectOne, attributes: "hint,label,required,disabled,options,selectedvalue" },
  { group: "Forms / Input / MultiSelect", description: msg.dFIMultSelect },
  { group: "Forms / Input / Color", description: msg.dFIColor },
  { group: "Forms / Input / Editor", description: msg.dFIEditor },
  { group: "Forms / Input / Feedback", description: msg.dFIFeedBack },
  { group: "Forms / Input / File", description: msg.dFIFile },
  // Records
  { group: "Forms / Records / Table", description: msg.dFRTable },
  { group: "Forms / Records / Table", description: msg.dFRTable },
  { group: "Forms / Records / List", description: msg.dFRList },
  { group: "Forms / Records / Timeline", description: msg.dFRTimeline },
  { group: "Forms / Records / Cards", description: msg.dFRCards },
  { group: "Forms / Records / Map (Geo)", description: msg.dFRMap },
  { group: "Forms / Records / Table with Pagination", description: msg.dFRPagination },
  { group: "Forms / Records / Table with Infinite Scroll", description: msg.dFRInfinity },
  // Tree
  { group: "Forms / Tree / Tree View", description: msg.dFTView },
  { group: "Forms / Tree / Breadcrumbs", description: msg.dFTBreadcrumbs },
  { group: "Forms / Tree / Nested Dropdown", description: msg.dFTDropdown },
  { group: "Forms / Tree / Nested Accordions", description: msg.dFTAccordions },
  { group: "Forms / Tree / Tag Cloud", description: msg.dFTTags },
  { group: "Forms / Tree / Mind Map", description: msg.dFTMap },
  // Submit
  { group: "Forms / Submit / Submit", description: msg.dFSSubmit },
  { group: "Forms / Submit / Cancel", description: msg.dFSCancel },
  { group: "Forms / Submit / Clear", description: msg.dFSClear },
  { group: "Forms / Submit / Send External", description: msg.dFSSend },
  // Links
  { group: "Navigation / Links / Menus", description: msg.dNLMenus },
  { group: "Navigation / Links / Button", description: msg.dNLButtons },
  { group: "Navigation / Links / Links", description: msg.dNLLinks },
  { group: "Navigation / Links / Breadcrumbs", description: msg.dNLBreadcrumbs },
  { group: "Navigation / Links / Anchors", description: msg.dNLAnchors },
  // Content
  { group: "Navigation / Content / Tab", description: msg.dNCTab },
  { group: "Navigation / Content / Scenary", description: msg.dNCScenary },
  { group: "Navigation / Content / Stepper", description: msg.dNCStepper },
  { group: "Navigation / Content / Toolbar", description: msg.dNCToolbar },
  { group: "Navigation / Content / Accordion", description: msg.dNCAccordion },
  { group: "Navigation / Content / Popup", description: msg.dNCPopup },
  { group: "Navigation / Content / Scrollspy", description: msg.dNCScrollspy },
  // Text
  { group: "Apresentation / Text / Text", description: msg.dATText },
  { group: "Apresentation / Text / Banner", description: msg.dATBanner },
  { group: "Apresentation / Text / Quote", description: msg.dATQuote },
  { group: "Apresentation / Text / Rich Text", description: msg.dATRich },
  // Images
  { group: "Apresentation / Images / Images", description: msg.dAIImages },
  { group: "Apresentation / Images / Icons", description: msg.dAIIcons },
  { group: "Apresentation / Images / Avatar", description: msg.dAIAvatar },
  { group: "Apresentation / Images / Gallery", description: msg.dAIGallery },
  { group: "Apresentation / Images / Carousel", description: msg.dAICarousel },
  { group: "Apresentation / Images / Sliders", description: msg.dAISliders },
  { group: "Apresentation / Images / Maps", description: msg.dAIMaps },
  // Video
  { group: "Apresentation / Video / Embedded Video", description: msg.dAVEmbedded },
  { group: "Apresentation / Video / Image Video", description: msg.dAVImage },
  { group: "Apresentation / Video / Video Playlist", description: msg.dAVVideo },
  // Sound
  { group: "Apresentation / Sound / Player", description: msg.dASPlayer },
  { group: "Apresentation / Sound / Sound Effects", description: msg.dASSound },
  { group: "Apresentation / Sound / Podcast Player", description: msg.dASPodcast },
  // Charts
  { group: "Apresentation / Charts / 2D", description: msg.dAC2d },
  { group: "Apresentation / Charts / 3D", description: msg.dAC3d },
  // Animations
  { group: "Apresentation / Animations / Loading", description: msg.dAALoading },
  { group: "Apresentation / Animations / OnClick", description: msg.dAAClick },
  { group: "Apresentation / Animations / JavaScript Animations", description: msg.dAAJava },
  { group: "Apresentation / Indicators", description: msg.dAAIndicators },
  // Embeds
  { group: "Apresentation / Embeds / Social Media Posts", description: msg.dAEPost },
  { group: "Apresentation / Embeds / Social Media Feeds", description: msg.dAEFeed },
  // Messages
  { group: "Apresentation / Messages / Toast", description: msg.dAMToast },
  { group: "Apresentation / Messages / Alert", description: msg.dAMAlert },
  { group: "Apresentation / Messages / Snackbar", description: msg.dAMSneackbar },
  { group: "Apresentation / Messages / Modal", description: msg.dAMModal },
  { group: "Apresentation / Messages / Notification", description: msg.dAMNotification },
  { group: "Apresentation / Messages / Badge", description: msg.dAMBadges },
  // Flow
  { group: "Layout / Flow / Section", description: msg.dLFSection },
  { group: "Layout / Flow / Group", description: msg.dLFGroup },
  { group: "Layout / Flow / Row", description: msg.dLFRow },
  { group: "Layout / Flow / Column", description: msg.dLFColumn },
  { group: "Layout / Flow / Grid", description: msg.dLFGrid },
  { group: "Layout / Flow / Adaptive", description: msg.dLFAdaptive },
  { group: "Layout / Flow / Split", description: msg.dLFSplit },
  // Group
  { group: "Layout / Group / Table", description: msg.dLGTable },
  { group: "Layout / Group / Cards", description: msg.dLGCards },
  // Viewer
  { group: "Blocks / Viewer / PDF Viewer", description: msg.dBVPdf },
  { group: "Blocks / Viewer / Spreadsheet Viewer", description: msg.dBVViwer },
  { group: "Blocks / Viewer / Document Viewer", description: msg.dBVDocument },
  // Plugins
  { group: "Blocks / Plugins / Calendar", description: msg.dBPCalendar },
  { group: "Blocks / Plugins / Schedule", description: msg.dBPSchedule },
  { group: "Blocks / Plugins / External API", description: msg.dBPExternal },
  // Projects
  { group: "Blocks / Projects / Pages", description: msg.dBPPages }
];
const attributeDefinitions = [
  { path: "name", lit: "@property({ type: String }) name: string | undefined;" },
  { path: "hint", lit: "@property({ type: String }) hint: string | undefined; // An optional descriptive hint for the field", variations: true },
  { path: "label", lit: "@property({ type: String }) label: string | undefined; // A label to identify this field", variations: true },
  { path: "required", lit: "@property({ type: Boolean }) required: boolean = false; // Whether the field is required or optional" },
  { path: "disabled", lit: "@property({ type: Boolean }) disabled: boolean = false; // Whether the field is ready for input or disabled" },
  { path: "maxvalue", lit: "@property({ type: Number }) maxvalue: number | undefined = undefined; // Maximum value restriction for the input" },
  { path: "minvalue", lit: "@property({ type: Number }) minvalue: number | undefined = undefined; // Minimum value restriction for the input" },
  { path: "step", lit: "@property({ type: Number }) step: number | undefined = undefined; // The step increment between values" },
  { path: "placeholder", lit: "@property({ type: String }) placeholder: string| undefined; // Placeholder text for the input field", variations: true },
  { path: "pattern", lit: "@property({ type: String }) pattern: string| undefined; // A regular expression that the input's value must match" },
  { path: "errormessage", lit: "@property({ type: String }) errormessage: string| undefined; // Custom error message to display when input validation fails", variations: true },
  { path: "autofocus", lit: "@property({ type: Boolean }) autofocus: boolean = false; // Whether the field should be automatically focused on page load" },
  { path: "maxlength", lit: "@property({ type: Number }) maxlength: number | undefined = undefined; // Maximum length restriction for the input" },
  { path: "minlength", lit: "@property({ type: Number }) minlength: number | undefined = undefined; // Minimum length restriction for the input" },
  { path: "autoCapitalize", lit: "@property({ type: String }) autoCapitalize: 'off' | 'none' | 'on' | 'sentences' | 'words' | 'characters' = undefined; // Controls whether and how text input is automatically capitalized as it is entered by the user." },
  { path: "autocorrect", lit: "@property({ type: String }) autocorrect: 'off' | 'on' = undefined; // Indicates whether the browser's autocorrect feature is on or off." },
  { path: "autocomplete", lit: "@property({ type: String }) autocomplete: string | undefined;" },
  { path: "value", lit: "@property({ type: String }) value: string | undefined;", variations: true },
  { path: "options", lit: "@property() options: OptionItem[] | undefined; // Optional path in the global JSON or a valid JSON for a list of options " },
  { path: "selectedvalue", lit: "@property() selectedvalue: string | undefined;" },
  { path: "inputmode", lit: " @property({ type: String }) inputmode: 'none' | 'text' | 'decimal' | 'numeric' | 'tel' | 'search' | 'email' | 'url' = 'none';" }
];
function getDescriptionsRootGroup() {
  const rootGroups = /* @__PURE__ */ new Set();
  icaDescriptions.forEach((component) => {
    const groupName = component.group.split("/")[0].trim();
    rootGroups.add(groupName);
  });
  return Array.from(rootGroups);
}
function getDescriptionsSubGroup(root) {
  const rc = /* @__PURE__ */ new Set();
  icaDescriptions.forEach((component) => {
    const parts = component.group.split("/");
    if (parts.length > 1 && parts[0].trim() === root) rc.add(parts[1].trim());
  });
  return Array.from(rc);
}
function getDescriptionsFinalGroup(root, subGroup) {
  const rc = /* @__PURE__ */ new Set();
  icaDescriptions.forEach((component) => {
    const parts = component.group.split("/");
    if (parts.length > 2 && parts[0].trim() === root && parts[1].trim() === subGroup) rc.add(parts[2].trim());
  });
  return Array.from(rc);
}
function getFormComponentsDescription(root, subGroup, finalGroup) {
  let len = 3;
  if (subGroup === null) len = 1;
  else if (finalGroup === null) len = 2;
  for (const component of icaDescriptions) {
    const parts = component.group.split("/");
    if (parts.length === len && parts[0].trim() === root && (subGroup === null || parts[1].trim() === subGroup) && (finalGroup === null || parts[2].trim() === finalGroup)) return component.description;
  }
  ;
  return "";
}
function getFormComponentsPrompt(root, subGroup, finalGroup) {
  for (const component of icaDescriptions) {
    const parts = component.group.split("/");
    if (parts.length === 3 && parts[0].trim() === root && parts[1].trim() === subGroup && parts[2].trim() === finalGroup) return component.prompt || "";
  }
  ;
  return "";
}
function getFormComponentsAttributes(root, subGroup, finalGroup) {
  for (const component of icaDescriptions) {
    const parts = component.group.split("/");
    if (parts.length === 3 && parts[0].trim() === root && parts[1].trim() === subGroup && parts[2].trim() === finalGroup) return component.attributes || "";
  }
  ;
  return "";
}
function getAttributeDefinitions(root, subGroup, finalGroup) {
  const rc = /* @__PURE__ */ new Set();
  const atts = getFormComponentsAttributes(root, subGroup, finalGroup);
  if (!atts) return [];
  const obj1 = attributeDefinitions.find((def) => def.path === atts);
  if (obj1) rc.add(obj1.lit);
  else rc.add("// " + atts + " dont exists");
  return Array.from(rc);
}
function getAttributeDefinitionsLit(root, subGroup, finalGroup) {
  const rc = /* @__PURE__ */ new Set();
  const attrs = getFormComponentsAttributes(root, subGroup, finalGroup);
  for (const att of attrs.split(",")) {
    const def = attributeDefinitions.find((item) => item.path === att);
    if (def) rc.add(def.lit);
  }
  ;
  return Array.from(rc);
}
function checkAttributteHasVariation(attribute) {
  const attr = attributeDefinitions.find((attr2) => attr2.path === attribute);
  if (!attr) return false;
  return attr.variations === true;
}
export {
  checkAttributteHasVariation,
  getAttributeDefinitions,
  getAttributeDefinitionsLit,
  getDescriptionsFinalGroup,
  getDescriptionsRootGroup,
  getDescriptionsSubGroup,
  getFormComponentsAttributes,
  getFormComponentsDescription,
  getFormComponentsPrompt
};
