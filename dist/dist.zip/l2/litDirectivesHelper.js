var _a, _b;
/**
 * @license
 * Copyright 2020 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { _$LH } from "./_100554_litHtml";
var ChildPart = _$LH._ChildPart;
var ENABLE_SHADYDOM_NOPATCH = true;
var wrap = ENABLE_SHADYDOM_NOPATCH && ((_a = window.ShadyDOM) === null || _a === void 0 ? void 0 : _a.inUse) && ((_b = window.ShadyDOM) === null || _b === void 0 ? void 0 : _b.noPatch) === true ? window.ShadyDOM.wrap : function(node) {
  return node;
};
var isPrimitive = function(value) {
  return value === null || typeof value != "object" && typeof value != "function";
};
var TemplateResultType = {
  HTML: 1,
  SVG: 2
};
var isTemplateResult = function(value, type) {
  return type === void 0 ? (
    // This property needs to remain unminified.
    (value === null || value === void 0 ? void 0 : value["_$litType$"]) !== void 0
  ) : (value === null || value === void 0 ? void 0 : value["_$litType$"]) === type;
};
var isCompiledTemplateResult = function(value) {
  var _a2;
  return ((_a2 = value === null || value === void 0 ? void 0 : value["_$litType$"]) === null || _a2 === void 0 ? void 0 : _a2.h) != null;
};
var isDirectiveResult = function(value) {
  return (value === null || value === void 0 ? void 0 : value["_$litDirective$"]) !== void 0;
};
var getDirectiveClass = function(value) {
  return value === null || value === void 0 ? void 0 : value["_$litDirective$"];
};
var isSingleExpression = function(part) {
  return part.strings === void 0;
};
var createMarker = function() {
  return document.createComment("");
};
var insertPart = function(containerPart, refPart, part) {
  var _a2;
  var container = wrap(containerPart._$startNode).parentNode;
  var refNode = refPart === void 0 ? containerPart._$endNode : refPart._$startNode;
  if (part === void 0) {
    var startNode = wrap(container).insertBefore(createMarker(), refNode);
    var endNode = wrap(container).insertBefore(createMarker(), refNode);
    part = new ChildPart(startNode, endNode, containerPart, containerPart.options);
  } else {
    var endNode = wrap(part._$endNode).nextSibling;
    var oldParent = part._$parent;
    var parentChanged = oldParent !== containerPart;
    if (parentChanged) {
      (_a2 = part._$reparentDisconnectables) === null || _a2 === void 0 ? void 0 : _a2.call(part, containerPart);
      part._$parent = containerPart;
      var newConnectionState = void 0;
      if (part._$notifyConnectionChanged !== void 0 && (newConnectionState = containerPart._$isConnected) !== oldParent._$isConnected) {
        part._$notifyConnectionChanged(newConnectionState);
      }
    }
    if (endNode !== refNode || parentChanged) {
      var start = part._$startNode;
      while (start !== endNode) {
        var n = wrap(start).nextSibling;
        wrap(container).insertBefore(start, refNode);
        start = n;
      }
    }
  }
  return part;
};
var setChildPartValue = function(part, value, directiveParent) {
  if (directiveParent === void 0) {
    directiveParent = part;
  }
  part._$setValue(value, directiveParent);
  return part;
};
var RESET_VALUE = {};
var setCommittedValue = function(part, value) {
  if (value === void 0) {
    value = RESET_VALUE;
  }
  return part._$committedValue = value;
};
var getCommittedValue = function(part) {
  return part._$committedValue;
};
var removePart = function(part) {
  var _a2;
  (_a2 = part._$notifyConnectionChanged) === null || _a2 === void 0 ? void 0 : _a2.call(part, false, true);
  var start = part._$startNode;
  var end = wrap(part._$endNode).nextSibling;
  while (start !== end) {
    var n = wrap(start).nextSibling;
    wrap(start).remove();
    start = n;
  }
};
var clearPart = function(part) {
  part._$clear();
};
export {
  TemplateResultType,
  clearPart,
  getCommittedValue,
  getDirectiveClass,
  insertPart,
  isCompiledTemplateResult,
  isDirectiveResult,
  isPrimitive,
  isSingleExpression,
  isTemplateResult,
  removePart,
  setChildPartValue,
  setCommittedValue
};
