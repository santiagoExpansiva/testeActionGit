/**
 * @license
 * Copyright 2019 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
var NODE_MODE = false;
var global = NODE_MODE ? globalThis : window;
var supportsAdoptingStyleSheets = global.ShadowRoot && (global.ShadyCSS === void 0 || global.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype;
var constructionToken = Symbol();
var cssTagCache = /* @__PURE__ */ new WeakMap();
var CSSResult = (
  /** @class */
  function() {
    function CSSResult2(cssText, strings, safeToken) {
      this["_$cssResult$"] = true;
      if (safeToken !== constructionToken) {
        throw new Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
      }
      this.cssText = cssText;
      this._strings = strings;
    }
    Object.defineProperty(CSSResult2.prototype, "styleSheet", {
      // This is a getter so that it's lazy. In practice, this means stylesheets
      // are not created until the first element instance is made.
      get: function() {
        var styleSheet = this._styleSheet;
        var strings = this._strings;
        if (supportsAdoptingStyleSheets && styleSheet === void 0) {
          var cacheable = strings !== void 0 && strings.length === 1;
          if (cacheable) {
            styleSheet = cssTagCache.get(strings);
          }
          if (styleSheet === void 0) {
            (this._styleSheet = styleSheet = new CSSStyleSheet())["replaceSync"](this.cssText);
            if (cacheable) {
              cssTagCache.set(strings, styleSheet);
            }
          }
        }
        return styleSheet;
      },
      enumerable: false,
      configurable: true
    });
    CSSResult2.prototype.toString = function() {
      return this.cssText;
    };
    return CSSResult2;
  }()
);
var textFromCSSResult = function(value) {
  if (value["_$cssResult$"] === true) {
    return value.cssText;
  } else if (typeof value === "number") {
    return value;
  } else {
    throw new Error("Value passed to 'css' function must be a 'css' function result: " + "".concat(value, ". Use 'unsafeCSS' to pass non-literal values, but take care ") + "to ensure page security.");
  }
};
var unsafeCSS = function(value) {
  return new CSSResult(typeof value === "string" ? value : String(value), void 0, constructionToken);
};
var css = function(strings) {
  var values = [];
  for (var _i = 1; _i < arguments.length; _i++) {
    values[_i - 1] = arguments[_i];
  }
  var cssText = strings.length === 1 ? strings[0] : values.reduce(function(acc, v, idx) {
    return acc + textFromCSSResult(v) + strings[idx + 1];
  }, strings[0]);
  return new CSSResult(cssText, strings, constructionToken);
};
var adoptStyles = function(renderRoot, styles) {
  if (supportsAdoptingStyleSheets) {
    renderRoot.adoptedStyleSheets = styles.map(function(s) {
      return s instanceof CSSStyleSheet ? s : s.styleSheet;
    });
  } else {
    styles.forEach(function(s) {
      var style = document.createElement("style");
      var nonce = global["litNonce"];
      if (nonce !== void 0) {
        style.setAttribute("nonce", nonce);
      }
      style.textContent = s.cssText;
      renderRoot.appendChild(style);
    });
  }
};
var cssResultFromStyleSheet = function(sheet) {
  var cssText = "";
  for (var _i = 0, _a = sheet.cssRules; _i < _a.length; _i++) {
    var rule = _a[_i];
    cssText += rule.cssText;
  }
  return unsafeCSS(cssText);
};
var getCompatibleStyle = supportsAdoptingStyleSheets || NODE_MODE && global.CSSStyleSheet === void 0 ? function(s) {
  return s;
} : function(s) {
  return s instanceof CSSStyleSheet ? cssResultFromStyleSheet(s) : s;
};
export {
  CSSResult,
  adoptStyles,
  css,
  getCompatibleStyle,
  supportsAdoptingStyleSheets,
  unsafeCSS
};
