var isTrace = false;
function getPathValue(obj, path) {
  return path.split(".").reduce(function(acc, part) {
    var arrayMatch = part.match(/(\w+)\[(\d+)\]/);
    if (arrayMatch) {
      var prop = arrayMatch[1];
      var index = parseInt(arrayMatch[2], 10);
      return acc[prop][index];
    }
    return acc[part];
  }, obj);
}
function setPathValue(obj, path, value) {
  var parts = path.split(".");
  var last = parts.pop();
  if (!last)
    return;
  var lastObj = parts.reduce(function(acc, part) {
    var match = part.match(/(\w+)\[(\d+)\]/);
    return match ? acc[match[1]][parseInt(match[2], 10)] : acc[part];
  }, obj);
  lastObj[last] = value;
}
var IcaState = (
  /** @class */
  function() {
    function IcaState2() {
      this.stateMap = /* @__PURE__ */ new Map();
      this.componentMap = /* @__PURE__ */ new Map();
    }
    IcaState2.prototype.setState = function(key, value) {
      var oldValue = this.stateMap.get(key);
      if (isTrace)
        console.info("setState key: " + key + " value=", value, ", oldValue=", oldValue);
      if (oldValue !== value) {
        this.stateMap.set(key, value);
        setPathValue(window.globalState, key, value);
        this.notify(key);
      }
    };
    IcaState2.prototype.getState = function(key) {
      var value = this.stateMap.get(key);
      if (isTrace)
        console.info("getState key: " + key + " value=", value);
      return getPathValue(window.globalState, key);
    };
    IcaState2.prototype.subscribe = function(keyOrKeys, component) {
      var _this = this;
      var keys = Array.isArray(keyOrKeys) ? keyOrKeys : [keyOrKeys];
      keys.forEach(function(key) {
        if (!_this.componentMap.has(key)) {
          _this.componentMap.set(key, /* @__PURE__ */ new Set());
        }
        _this.componentMap.get(key).add(component);
      });
    };
    IcaState2.prototype.unsubscribe = function(keyOrKeys, component) {
      var _this = this;
      var keys = Array.isArray(keyOrKeys) ? keyOrKeys : [keyOrKeys];
      keys.forEach(function(key) {
        var _a;
        (_a = _this.componentMap.get(key)) === null || _a === void 0 ? void 0 : _a.delete(component);
      });
    };
    IcaState2.prototype.notify = function(key) {
      var _this = this;
      Array.from(this.componentMap).find(function(map) {
        var stateKey = map[0], arr = map[1];
        var path = stateKey.split(";")[1];
        if (path !== key)
          return;
        arr.forEach(function(component) {
          if ("handleIcaStateChange" in component) {
            component["handleIcaStateChange"](key, _this.getState(key));
          }
        });
      });
    };
    IcaState2.prototype.getStateStatistics = function() {
      var statistics = /* @__PURE__ */ new Map();
      this.componentMap.forEach(function(value, key) {
        statistics.set(key, value.size);
      });
      return statistics;
    };
    return IcaState2;
  }()
);
export {
  IcaState
};
