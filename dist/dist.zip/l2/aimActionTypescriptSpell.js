var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from "lit";
import { customElement } from "lit/decorators.js";
import { tasks, updateTaskOnServer } from "./_100554_aimHelper";
import { AimActionBase } from "./_100554_aimActionBase";
var myName = "_100554_aimActionTypescriptSpell";
var message_pt = {
  template_title: "Ir\uFFFD verificar o typescript e procurar por erros de gram\uFFFDtica em ingles",
  prompt_message: "Identifique todas as strings literais no seguinte c\uFFFDdigo TypeScript que devem ser preparadas para internacionaliza\uFFFD\uFFFDo.  N\uFFFDo retornar explica\uFFFD\uFFFDes, apenas retorne uma 'tabela' com as colunas: texto, language (portugues | ingles | ...).",
  btn_cancel: "Cancelar",
  btn_confirm: "Confirmar"
};
var message_en = {
  template_title: "Will check the TypeScript and look for grammar errors in English",
  prompt_message: "Identify all string literals in the following TypeScript code that should be prepared for internationalization. Do not return explanations, just return a 'table' with the columns: text, language (portuguese | english | ...).",
  btn_cancel: "Cancel",
  btn_confirm: "Confirm"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var AimActionTypescriptSpell = (
  /** @class */
  function(_super) {
    __extends(AimActionTypescriptSpell2, _super);
    function AimActionTypescriptSpell2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.msg = messages["en"];
      _this.assistant = "gpt3_typescript";
      _this.title = "Spell Check";
      _this.language = "english";
      return _this;
    }
    AimActionTypescriptSpell2.prototype.getRules = function() {
      return {
        levels: [2],
        tags: ["*serviceSource*"]
      };
    };
    AimActionTypescriptSpell2.prototype.handleCancel = function() {
      this.dispatchEvent(new CustomEvent("add-task", {
        detail: { cancel: "true" },
        bubbles: true,
        composed: true
      }));
    };
    AimActionTypescriptSpell2.prototype.handleAdd = function() {
      var taskRoot = {
        mode: "initializing",
        title: "verify typescript spell / language",
        widget: myName,
        children: [],
        trace: [(/* @__PURE__ */ new Date()).toISOString() + ": trask created at "]
      };
      tasks.unshift(taskRoot);
      this.prepareTask1(taskRoot);
      this.dispatchEvent(new CustomEvent("finished-add-task-root", {
        detail: taskRoot,
        bubbles: true,
        composed: true
      }));
    };
    AimActionTypescriptSpell2.prototype.renderAdd = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n        <p> ", '</p>\n        <br>\n        <div class="buttonGroup">\n          <button @click="', '">', '</button>\n          <button @click="', '">', "</button>\n        </div>\n    "], ["\n        <p> ", '</p>\n        <br>\n        <div class="buttonGroup">\n          <button @click="', '">', '</button>\n          <button @click="', '">', "</button>\n        </div>\n    "])), this.msg.template_title, this.handleCancel, this.msg.btn_cancel, this.handleAdd, this.msg.btn_confirm);
    };
    AimActionTypescriptSpell2.prototype.getPrompt2 = function(source) {
      var prompt = "\nObjective: Check for spelling errors in English within a TypeScript code snippet and return the findings in a formatted table.\n\n\n\nInstructions:\n\n1.Ignore everything above \n\n2. Analyze the provided TypeScript code snippet solely for spelling mistakes in English words.\n\n3. Disregard any other forms of validation or checking (such as syntax errors, code style, etc.).\n\n4. Analyze only non-typescript text\n\n5. Return the findings, no duplicates, in a table with the following columns:\n\n- Message: Original complete string.\n\n- Fix: Suggest the appropriate correction for the spelling mistake to replace the original complete string.\n\n- Detail: Provide a brief comment on the mistake, if necessary.\n\n\n\nExpected Output Format:\n\n\n\nThe output should be clearly formatted as a table for easy reading.\n\nEach spelling mistake should be listed on its own line within the table.\n\nDon't return others comments, return only the table.\n\n\n".concat(source, "\n");
      return prompt;
    };
    AimActionTypescriptSpell2.prototype.getPrompt = function(source) {
      var prompt = "\n".concat(this.msg.prompt_message, "\n\n").concat(source, "\n");
      return prompt;
    };
    AimActionTypescriptSpell2.prototype.prepareTask1 = function(taskRoot) {
      this.mode = taskRoot.mode = "in progress";
      this.addTaskAndWaitForCompletion(taskRoot, {
        mode: "initializing",
        title: "get typescript source",
        widget: "_100554_aimTaskTSSource",
        trace: [],
        nextStep: this.prepareTask2.name
        // danger, loop
      });
    };
    AimActionTypescriptSpell2.prototype.prepareTask2 = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      if (taskFinishResult.status === "error") {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        return;
      }
      var source = taskFinishResult.result;
      if (!source) {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        child.trace.push("invalid finish , must be notify finish with result field");
        this.requestUpdate();
        return;
      }
      child.mode = "processed";
      this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
        mode: "initializing",
        title: "exec prompt",
        widget: "_100554_aimTaskExecLLM",
        agent: this.assistant,
        prompt: this.getPrompt(source),
        trace: [],
        nextStep: this.prepareTask3.name
        // danger, loop
      });
    };
    AimActionTypescriptSpell2.prototype.prepareTask3 = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      var result = child.result || "";
      if (taskFinishResult.status === "error" || !result) {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        return;
      }
      child.mode = "processed";
      this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
        mode: "initializing",
        title: "result",
        widget: "_100554_aimTaskResultTable",
        trace: [],
        _tempResult: result,
        nextStep: this.endTasks.name
        // danger, loop
      });
      this.requestUpdate();
    };
    AimActionTypescriptSpell2.prototype.endTasks = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      if (taskFinishResult.status === "error")
        child.mode = "error";
      else
        child.mode = "processed";
      this.mode = taskFinishResult.taskRoot.mode = child.mode;
      this.requestUpdate();
      updateTaskOnServer(taskFinishResult.taskIndex);
    };
    AimActionTypescriptSpell2 = __decorate([
      customElement("aim-action-typescript-spell-100554")
    ], AimActionTypescriptSpell2);
    return AimActionTypescriptSpell2;
  }(AimActionBase)
);
var templateObject_1;
export {
  AimActionTypescriptSpell
};
