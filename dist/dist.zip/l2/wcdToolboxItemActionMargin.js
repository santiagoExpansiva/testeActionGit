var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { html, LitElement, render } from "lit";
import { customElement, property } from "lit/decorators.js";
var WCDToolboxItemActionMargin = (
  /** @class */
  function(_super) {
    __extends(WCDToolboxItemActionMargin2, _super);
    function WCDToolboxItemActionMargin2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.startX = 0;
      _this.startY = 0;
      _this.startTop = 0;
      _this.startBottom = 0;
      _this.startLeft = 0;
      _this.startRight = 0;
      _this.timeonChangeProp = -1;
      _this.myMsg = {
        margin: "Margin",
        padding: "Padding",
        top: "Top",
        left: "Left",
        bottom: "Bottom",
        right: "Right"
      };
      return _this;
    }
    WCDToolboxItemActionMargin2.prototype.createRenderRoot = function() {
      return this;
    };
    WCDToolboxItemActionMargin2.prototype.render = function() {
      this.renderOutdoorScenary();
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject([""], [""])));
    };
    WCDToolboxItemActionMargin2.prototype.updated = function(changedProperties) {
      var _this = this;
      _super.prototype.updated.call(this, changedProperties);
      if (!this.elMain || !this.myParent)
        return;
      this.myParent.updateSize(this.elMain, this.myParent, true);
      this.onmousedown = function(e) {
        return _this.initDragging(e);
      };
    };
    WCDToolboxItemActionMargin2.prototype.renderOutdoorScenary = function() {
      return __awaiter(this, void 0, void 0, function() {
        var _a;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              if (!this.myParent || this.myParent.level !== "4")
                return [
                  2
                  /*return*/
                ];
              _a = this;
              return [4, this.myParent.getAndSetScenaryOutDoor("Styles")];
            case 1:
              _a.elExternal = _b.sent();
              if (!this.elExternal)
                return [
                  2
                  /*return*/
                ];
              render(this.renderMargin(), this.elExternal);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    WCDToolboxItemActionMargin2.prototype.renderMargin = function() {
      var _this = this;
      if (!this.elMain)
        return html(templateObject_2 || (templateObject_2 = __makeTemplateObject([""], [""])));
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['\n            <div style="display:flex; flex-direction:column; gap:.5rem ;padding:1rem" class="myAuxGroup">\n                <p style=" margin-bottom: 5px;">A propriedade <b>margin</b> do CSS define a \uFFFDrea de margem nos quatro lados do elemento. </p>\n                <h4 style="display:flex; gap:1.5rem;margin:0px" >', '<input type="checkbox" prop="margin"></h4>\n                <div style="display:flex; gap:.5rem">\n                    <div style="width:70px">', '</div>\n                    <input prop="marginTop" type="text" .value="', '"  group="margin" @input="', '" />\n                </div>\n                <div style="display:flex; gap:.5rem">\n                    <div style="width:70px">', '</div>\n                    <input prop="marginRight" type="text" .value="', '"  group="margin" @input="', '" />\n                </div> \n                <div style="display:flex; gap:.5rem">\n                    <div style="width:70px">', '</div>\n                    <input prop="marginBottom" type="text" .value="', '"  group="margin" @input="', '" />\n                </div>\n                <div style="display:flex; gap:.5rem">\n                    <div style="width:70px">', '</div>\n                    <input prop="marginLeft" type="text" .value="', '"  group="margin" @input="', '" />\n                </div>\n                \n            </div>\n        '], ['\n            <div style="display:flex; flex-direction:column; gap:.5rem ;padding:1rem" class="myAuxGroup">\n                <p style=" margin-bottom: 5px;">A propriedade <b>margin</b> do CSS define a \uFFFDrea de margem nos quatro lados do elemento. </p>\n                <h4 style="display:flex; gap:1.5rem;margin:0px" >', '<input type="checkbox" prop="margin"></h4>\n                <div style="display:flex; gap:.5rem">\n                    <div style="width:70px">', '</div>\n                    <input prop="marginTop" type="text" .value="', '"  group="margin" @input="', '" />\n                </div>\n                <div style="display:flex; gap:.5rem">\n                    <div style="width:70px">', '</div>\n                    <input prop="marginRight" type="text" .value="', '"  group="margin" @input="', '" />\n                </div> \n                <div style="display:flex; gap:.5rem">\n                    <div style="width:70px">', '</div>\n                    <input prop="marginBottom" type="text" .value="', '"  group="margin" @input="', '" />\n                </div>\n                <div style="display:flex; gap:.5rem">\n                    <div style="width:70px">', '</div>\n                    <input prop="marginLeft" type="text" .value="', '"  group="margin" @input="', '" />\n                </div>\n                \n            </div>\n        '])), this.myMsg.margin, this.myMsg.top, this.elMain.style.marginTop, function(e) {
        return _this.onChangeProp(e);
      }, this.myMsg.right, this.elMain.style.marginRight, function(e) {
        return _this.onChangeProp(e);
      }, this.myMsg.bottom, this.elMain.style.marginBottom, function(e) {
        return _this.onChangeProp(e);
      }, this.myMsg.left, this.elMain.style.marginLeft, function(e) {
        return _this.onChangeProp(e);
      });
    };
    WCDToolboxItemActionMargin2.prototype.onChangeProp = function(e) {
      var _this = this;
      var el = e.currentTarget;
      clearTimeout(this.timeonChangeProp);
      this.timeonChangeProp = setTimeout(function() {
        _this.changeEl(el);
      }, 500);
    };
    WCDToolboxItemActionMargin2.prototype.changeEl = function(el) {
      var _a;
      var prop = el.getAttribute("prop");
      var group = el ? el.getAttribute("group") : "";
      var elGroup = (_a = el.closest(".myAuxGroup")) === null || _a === void 0 ? void 0 : _a.querySelector('input[prop="'.concat(group, '"]'));
      var isGroup = false;
      if (elGroup)
        isGroup = elGroup.checked;
      if (!prop || !this.elMain || !this.myParent)
        return;
      if (isGroup) {
        this.elMain.style.margin = el.value;
        ["marginTop", "marginBottom", "marginLeft", "marginRight"].forEach(function(pr) {
          var _a2;
          var field = (_a2 = el.closest(".myAuxGroup")) === null || _a2 === void 0 ? void 0 : _a2.querySelector('input[prop="'.concat(pr, '"]'));
          if (field)
            field.value = el.value;
        });
        this.myParent.updateSize(this.elMain, this.myParent, true);
        this.fireEvent('{"margin":"'.concat(this.elMain.style.padding, '"}'));
        return;
      }
      this.elMain.style[prop] = el.value;
      this.myParent.updateSize(this.elMain, this.myParent, true);
      this.fireEvent();
    };
    WCDToolboxItemActionMargin2.prototype.initDragging = function(e) {
      var _this = this;
      if (!this.elMain || !document.defaultView)
        return;
      this.startX = e.clientX;
      this.startY = e.clientY;
      var st = document.defaultView.getComputedStyle(this.elMain);
      this.startTop = parseInt(st.marginTop, 10);
      this.startBottom = parseInt(st.marginBottom, 10);
      this.startLeft = parseInt(st.marginLeft, 10);
      this.startRight = parseInt(st.marginRight, 10);
      var doDragging = function(e2) {
        if (!_this.elMain || !_this.myParent)
          return;
        _this.myParent.style.background = "#f9cc9d80";
        var deltaX = e2.clientX - _this.startX;
        var deltaY = e2.clientY - _this.startY;
        if (!_this.tpChange || ["top"].includes(_this.tpChange)) {
          _this.elMain.style.marginTop = _this.startTop + deltaY * -1 + "px";
        }
        if (!_this.tpChange || ["bottom"].includes(_this.tpChange)) {
          _this.elMain.style.marginBottom = _this.startBottom + deltaY + "px";
        }
        if (!_this.tpChange || ["left"].includes(_this.tpChange)) {
          _this.elMain.style.marginLeft = _this.startLeft + deltaX + "px";
        }
        if (!_this.tpChange || ["right"].includes(_this.tpChange)) {
          _this.elMain.style.marginRight = _this.startRight + deltaX + "px";
        }
        _this.renderOutdoorScenary();
        _this.myParent.updateSize(_this.elMain, _this.myParent, true);
      };
      var stopDragging = function(e2) {
        if (!_this.elMain || !_this.myParent)
          return;
        _this.myParent.style.background = "";
        document.body.removeEventListener("mousemove", doDragging, false);
        document.body.removeEventListener("mouseup", stopDragging, false);
        _this.fireEvent();
      };
      document.body.addEventListener("mousemove", doDragging, false);
      document.body.addEventListener("mouseup", stopDragging, false);
    };
    WCDToolboxItemActionMargin2.prototype.fireEvent = function(ret) {
      if (ret === void 0) {
        ret = "";
      }
      if (!this.elMain || !this.myParent)
        return;
      if (ret === "") {
        if (this.tpChange === "top")
          ret = '{"marginTop":"'.concat(this.elMain.style.marginTop, '"}');
        if (this.tpChange === "bottom")
          ret = '{"marginBottom":"'.concat(this.elMain.style.marginBottom, '"}');
        if (this.tpChange === "left")
          ret = '{"marginLeft":"'.concat(this.elMain.style.marginLeft, '"}');
        if (this.tpChange === "right")
          ret = '{"marginRight":"'.concat(this.elMain.style.marginRight, '"}');
      }
      var evento = new CustomEvent("onChange", {
        detail: { valor: '{"tp":"style","style":'.concat(ret, " }") },
        bubbles: true,
        composed: true
      });
      this.dispatchEvent(evento);
    };
    __decorate([
      property({ type: String, reflect: true }),
      __metadata("design:type", String)
    ], WCDToolboxItemActionMargin2.prototype, "tpChange", void 0);
    WCDToolboxItemActionMargin2 = __decorate([
      customElement("wcd-toolbox-item-action-margin-100554")
    ], WCDToolboxItemActionMargin2);
    return WCDToolboxItemActionMargin2;
  }(LitElement)
);
var getTemplate = function(mode, position) {
  if (mode === void 0) {
    mode = "";
  }
  if (position === void 0) {
    position = "";
  }
  var ret = templateActionMargin.buttonMargin;
  if (mode === "marginTop")
    ret = templateActionMargin.marginTop;
  if (mode === "marginRight")
    ret = templateActionMargin.marginRight;
  if (mode === "marginBottom")
    ret = templateActionMargin.marginBottom;
  if (mode === "marginLeft")
    ret = templateActionMargin.marginLeft;
  if (position !== "")
    ret.position = position;
  return ret;
};
var templateActionMargin = {
  backButton: {
    position: "",
    tp: "back-button",
    format: "",
    title: "Back",
    iconSvg: '<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 512 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M256 48a208 208 0 1 1 0 416 208 208 0 1 1 0-416zm0 464A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM175 175c-9.4 9.4-9.4 24.6 0 33.9l47 47-47 47c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l47-47 47 47c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-47-47 47-47c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-47 47-47-47c-9.4-9.4-24.6-9.4-33.9 0z"/></svg>',
    onclick: function(e, wc) {
      wc.setIconsWcdToolbox([], true, "size");
      wc.backNavigationScenaryOutdoor();
    },
    menuItens: [],
    menuSubItens: [],
    widget: "",
    cursor: "pointer",
    attrs: void 0,
    isDblClick: false
  },
  buttonMargin: {
    position: "p-m4",
    tp: "button",
    format: "",
    title: "Margin",
    iconSvg: '<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M192 32h64H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H384l0 352c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-352H288V448c0 17.7-14.3 32-32 32s-32-14.3-32-32V352H192c-88.4 0-160-71.6-160-160s71.6-160 160-160z"/></svg>',
    onclick: function(e, wc) {
      wc.setIconsWcdToolbox([
        templateActionMargin.backButton,
        templateActionMargin.marginTop,
        templateActionMargin.marginRight,
        templateActionMargin.marginBottom,
        templateActionMargin.marginLeft
      ], false, "size");
      var params = {
        level: 4,
        position: "right",
        wdcPath: wc.title,
        op: "Styles"
      };
      mls.events.fire([4], "WCDEvent", JSON.stringify(params));
    },
    menuItens: [],
    menuSubItens: [],
    widget: "",
    cursor: "pointer",
    attrs: void 0,
    isDblClick: false
  },
  marginTop: {
    position: "p-m1",
    tp: "action",
    format: "square",
    title: "",
    iconSvg: "",
    onclick: void 0,
    menuItens: [],
    menuSubItens: [],
    widget: "wcd-toolbox-item-action-margin-100554",
    cursor: "ns-resize",
    attrs: [{ attr: "tpchange", value: "top" }],
    isDblClick: false
  },
  marginRight: {
    position: "p-r2",
    tp: "action",
    format: "square",
    title: "",
    iconSvg: "",
    onclick: void 0,
    menuItens: [],
    menuSubItens: [],
    widget: "wcd-toolbox-item-action-margin-100554",
    cursor: "ew-resize",
    attrs: [{ attr: "tpchange", value: "right" }],
    isDblClick: false
  },
  marginBottom: {
    position: "p-m3",
    tp: "action",
    format: "square",
    title: "",
    iconSvg: "",
    onclick: void 0,
    menuItens: [],
    menuSubItens: [],
    widget: "wcd-toolbox-item-action-margin-100554",
    cursor: "ns-resize",
    attrs: [{ attr: "tpchange", value: "bottom" }],
    isDblClick: false
  },
  marginLeft: {
    position: "p-l2",
    tp: "action",
    format: "square",
    title: "",
    iconSvg: "",
    onclick: void 0,
    menuItens: [],
    menuSubItens: [],
    widget: "wcd-toolbox-item-action-margin-100554",
    cursor: "ew-resize",
    attrs: [{ attr: "tpchange", value: "left" }],
    isDblClick: false
  }
};
var templateObject_1, templateObject_2, templateObject_3;
export {
  WCDToolboxItemActionMargin,
  getTemplate
};
