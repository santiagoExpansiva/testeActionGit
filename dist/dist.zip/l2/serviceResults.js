var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __assign = function() {
  __assign = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
        t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { html } from "lit";
import { customElement, query, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
import { getDependenciesByMFile } from "./_100554_libCompile";
import { initCodelensCustomElement } from "./_100554_codelensCustomElement";
import { initCodelensComponentDetails } from "./_100554_codelensComponentDetails";
import { initCodelensServiceDetails } from "./_100554_codelensServiceDetails";
var message_pt = {};
var message_en = {};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceResults = (
  /** @class */
  function(_super) {
    __extends(ServiceResults2, _super);
    function ServiceResults2() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.msize = "";
      _this.details = {
        icon: "&#xf1c9",
        state: "background",
        tooltip: "Results",
        visible: true,
        position: "all",
        widget: "_100554_serviceResults",
        level: [2]
      };
      _this.onClickLink = function(op) {
        if (op === "opProdJS")
          return _this.showProdJS();
        if (op === "opProdJS2")
          return _this.showProdJS3();
        if (op === "opTSConfig")
          return _this.showTsConfig();
        if (op === "opTSLibs")
          return _this.showTsLib();
        if (op === "opDevDoc")
          return _this.showDevDoc();
        if (op === "opDevDocJson")
          return _this.showDevDocJson();
        if (op === "opJsonImport")
          return _this.showJsonImport();
        if (op === "opReferences")
          return _this.showFileRefs();
        if (op === "opAssistant")
          return _this.showAssistant();
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.menu = {
        title: "Production - Javascript",
        actions: {
          opProdJS: "Production - Javascript",
          opTSConfig: "Typescript Config",
          opTSLibs: "Typescript Libs",
          opReferences: "References",
          opDevDoc: "Dev - Documentation",
          opDevDocJson: "Dev - Documentation Json",
          opJsonImport: "Json Imports"
        },
        actionDefault: "opProdJS2",
        // call after close icon clicked
        icons: {},
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink
      };
      _this.editorModelName = "serviceresults.js";
      _this.isReferenceOpen = false;
      _this.isHelpAssistant = false;
      _this.actualResultMode = "prodJS";
      _this.results = {
        devDoc: "",
        devJS: "",
        devTS: "",
        errors: "",
        prodJS: "",
        references: [],
        configTS: "",
        libTS: "",
        jsonImport: ""
      };
      _this.resultsLanguages = {
        prodJS: "javascript",
        devJS: "javascript",
        devTS: "typescript",
        devDoc: "json",
        errors: "json",
        configTS: "json",
        libTS: "json",
        jsonImport: "json"
      };
      _this.extensions = {
        javascript: ".js",
        typescript: ".ts",
        json: ".json"
      };
      _this.hasError = false;
      initCodelensCustomElement();
      initCodelensComponentDetails();
      initCodelensServiceDetails();
      _this.editorModelName = "serviceresults_".concat(_this.position, ".js");
      mls.events.addListener(2, "FileAction", function(ev) {
        return _this.onFileActionReceived.bind(_this)(ev);
      });
      mls.events.addListener(2, "MonacoAction", function(ev) {
        return _this.onMonacoEvents(ev);
      });
      return _this;
    }
    ServiceResults2.prototype.createRenderRoot = function() {
      return this;
    };
    ServiceResults2.prototype.onServiceClick = function(visible, reinit, el) {
      this._onServiceClick(visible, reinit, el);
    };
    ServiceResults2.prototype._onServiceClick = function(visible, reinit, el) {
      return __awaiter(this, void 0, void 0, function() {
        var editor, project, shortName;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              editor = mls.l2.editor.editors[this.confInvert];
              if (!!editor) return [3, 2];
              return [4, this.delay(3e3)];
            case 1:
              _a2.sent();
              _a2.label = 2;
            case 2:
              if (!editor) return [3, 4];
              project = editor.project, shortName = editor.shortName;
              return [4, this.getCompileResults(shortName, project)];
            case 3:
              _a2.sent();
              this.actualFileName = shortName;
              this.actualFileProject = project;
              _a2.label = 4;
            case 4:
              if (this.visible)
                this.createEditor();
              if (!reinit) {
                this.setInitialModelProdJS("");
                if (el && typeof el.layout === "function")
                  el.layout();
              }
              if (this.hasError)
                this.openErrorMode();
              else if (this.actualResultMode === "refs")
                this.createListRefs();
              else if (this.actualResultMode === "devDocPage")
                this.openResultsDocsPageMode();
              else if (this.isReferenceOpen)
                this.openReferenceMode();
              else if (this.isHelpAssistant)
                this.openHelpAssistantMode();
              else
                this.openActualResultMode();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    Object.defineProperty(ServiceResults2.prototype, "confE", {
      get: function() {
        return "l".concat(this.level, "_").concat(this.position, "_results");
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(ServiceResults2.prototype, "confInvert", {
      get: function() {
        return "l".concat(this.level, "_").concat(this.position === "left" ? "right" : "left");
      },
      enumerable: false,
      configurable: true
    });
    ServiceResults2.prototype.isServiceVisible = function() {
      return this.visible === "true";
    };
    ServiceResults2.prototype.createEditor = function() {
      if (!this.c2 || this._ed1)
        return;
      this._ed1 = monaco.editor.create(this.c2, mls.editor.conf[this.confE]);
      monaco.languages.typescript.javascriptDefaults.setCompilerOptions({
        noImplicitAny: true
      });
      this.c2["mlsEditor"] = this._ed1;
    };
    ServiceResults2.prototype.createOrGetModel = function(resultName, editorType, src) {
      var project = 100529;
      var shortName = resultName;
      var uri = this.getUri("_".concat(project, "_").concat(shortName));
      var model1 = mls.l2.editor.get({ project, shortName });
      if (!model1) {
        var model = monaco.editor.createModel(src, editorType, uri);
        var extension = this.extensions[editorType];
        model1 = {
          changed: false,
          error: false,
          project,
          shortName,
          model,
          extension
        };
        mls.l2.editor.add(model1);
      }
      return model1;
    };
    ServiceResults2.prototype.setInitialModelProdJS = function(src) {
      var model1 = this.createOrGetModel(this.editorModelName, "javascript", src);
      if (!model1)
        return;
      mls.l2.editor.editors["".concat(this.confE, "_").concat(this.editorModelName)] = model1;
      if (this._ed1)
        this._ed1.setModel(model1.model);
    };
    ServiceResults2.prototype.setModelLanguage = function(language, value) {
      var activeModel = mls.l2.editor.editors["".concat(this.confE, "_").concat(this.editorModelName)];
      if (!activeModel)
        return;
      monaco.editor.setModelLanguage(activeModel.model, language);
      if (this._ed1)
        this._ed1.setScrollTop(0);
      activeModel.model.setValue(value);
    };
    ServiceResults2.prototype.getUri = function(shortFN) {
      return monaco.Uri.parse("file://server/".concat(shortFN, "_").concat(this.position, ".ts"));
    };
    ServiceResults2.prototype.getCompileResults = function(shortName, project) {
      return __awaiter(this, void 0, Promise, function() {
        var editor, mfile, results, errs, libs, libs2, jsonImp;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              editor = mls.l2.editor.editors[this.confInvert];
              if (!editor || !shortName || !project)
                return [
                  2
                  /*return*/
                ];
              mfile = mls.l2.editor.get({ shortName, project });
              if (!mfile)
                return [
                  2
                  /*return*/
                ];
              if (mfile.compilerResults && !mfile.compilerResults.prodJS)
                mfile.compilerResults.modelNeedCompile = true;
              return [4, mls.l2.editor.getCompilerResultTS(mfile)];
            case 1:
              results = _a2.sent();
              errs = {
                Errors: results.errors
              };
              libs = monaco.languages.typescript.typescriptDefaults.getExtraLibs();
              libs2 = {};
              Object.keys(libs).forEach(function(key) {
                libs2[key] = {
                  version: libs[key].version
                };
              });
              return [4, getDependenciesByMFile(mfile)];
            case 2:
              jsonImp = _a2.sent();
              this.hasError = results.errors.length > 0;
              this.results = __assign(__assign({}, results), { errors: JSON.stringify(errs, null, 2), references: [], configTS: JSON.stringify(monaco.languages.typescript.typescriptDefaults.getCompilerOptions(), null, 2), libTS: JSON.stringify(libs2, null, 2), jsonImport: JSON.stringify(jsonImp, null, 2) });
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceResults2.prototype.onFileActionReceived = function(ev) {
      return __awaiter(this, void 0, void 0, function() {
        var params, shortName, project, isServiceVisible;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (!ev.desc)
                return [
                  2
                  /*return*/
                ];
              params = JSON.parse(ev.desc);
              shortName = params.shortName, project = params.project;
              if (params.position === this.position)
                return [
                  2
                  /*return*/
                ];
              isServiceVisible = this.isServiceVisible();
              this.actualFileName = params.shortName;
              this.actualFileProject = params.project;
              if (!((params.action === "changed" || params.action === "open") && isServiceVisible)) return [3, 2];
              return [4, this.getCompileResults(shortName, project)];
            case 1:
              _a2.sent();
              if (this.actualResultMode === "refs")
                this.createListRefs();
              else if (this.actualResultMode === "devDocPage")
                this.openResultsDocsPageMode();
              else if (this.hasError)
                this.openErrorMode();
              else
                this.openActualResultMode();
              return [3, 4];
            case 2:
              if (!(params.action === "fileReference")) return [3, 4];
              return [4, this.getCompileResults(shortName, project)];
            case 3:
              _a2.sent();
              this.isReferenceOpen = true;
              if (this.visible === "true")
                this.openReferenceMode();
              else
                this.openMe();
              _a2.label = 4;
            case 4:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceResults2.prototype.onMonacoEvents = function(ev) {
      if (!ev.desc)
        return;
      var args = JSON.parse(ev.desc);
      if (!args)
        return;
      var action = args.action, position = args.position;
      if (position === this.position)
        return;
      if (action === "helpAssistant") {
        this.actualResultMode = "assistant";
        this.assistantArgs = args;
        this.isHelpAssistant = true;
        if (this.visible === "true")
          this.openHelpAssistantMode();
        else
          this.openMe();
      }
    };
    ServiceResults2.prototype.getReferences = function(shortName, project) {
      return __awaiter(this, void 0, Promise, function() {
        var refs;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              return [4, mls.l2.editor.compileAllProjectIfNeed(project)];
            case 1:
              _a2.sent();
              refs = mls.l2.editor.listAllAffectedFiles(project, shortName);
              return [2, refs];
          }
        });
      });
    };
    ServiceResults2.prototype.showProdJS = function() {
      if (this.menu.setMode)
        this.menu.setMode("initial");
      this.actualResultMode = "prodJS";
      return this.showProdJS2();
    };
    ServiceResults2.prototype.showProdJS2 = function() {
      this.menu.title = "Production - Javascript";
      if (this.menu.updateTitle)
        this.menu.updateTitle();
      if (this.hasError) {
        this.setModelLanguage(this.resultsLanguages.errors, this.results.errors);
        return true;
      }
      this.setModelLanguage(this.resultsLanguages.prodJS, this.results.prodJS);
      return true;
    };
    ServiceResults2.prototype.showProdJS3 = function() {
      this.actualResultMode = "prodJS";
      return this.showProdJS2();
    };
    ServiceResults2.prototype.showTsConfig = function() {
      this.menu.title = "Typescript Config";
      if (this.menu.updateTitle)
        this.menu.updateTitle();
      if (this.menu.setMode)
        this.menu.setMode("editor");
      this.actualResultMode = "configTS";
      this.setModelLanguage(this.resultsLanguages.configTS, this.results.configTS);
      return true;
    };
    ServiceResults2.prototype.showTsLib = function() {
      this.menu.title = "Typescript Libs";
      if (this.menu.updateTitle)
        this.menu.updateTitle();
      if (this.menu.setMode)
        this.menu.setMode("editor");
      this.actualResultMode = "libTS";
      this.setModelLanguage(this.resultsLanguages.libTS, this.results.libTS);
      return true;
    };
    ServiceResults2.prototype.showDevDoc = function() {
      this.menu.title = "Develpoment Docs";
      if (this.menu.updateTitle)
        this.menu.updateTitle();
      this.actualResultMode = "devDocPage";
      if (!this.devDocContainer) {
        this.devDocContainer = document.createElement("mls-load-page-l4-100529");
        this.devDocContainer.setAttribute("path", "_100529_service_results_doc");
      }
      if (this.menu.setMode)
        this.menu.setMode("page", this.devDocContainer);
      return true;
    };
    ServiceResults2.prototype.showFileRefs = function() {
      this.menu.title = "File References";
      if (this.menu.updateTitle)
        this.menu.updateTitle();
      this.menu.title = this.menu.actions["opProdJS"];
      this.actualResultMode = "refs";
      var div1 = document.createElement("div");
      div1.style.padding = "2rem";
      this.list = document.createElement("ul");
      var hr = document.createElement("hr");
      this.refTitle = document.createElement("h2");
      this.createListRefs();
      div1.appendChild(this.refTitle);
      div1.appendChild(hr);
      div1.appendChild(this.list);
      if (this.menu.setMode)
        this.menu.setMode("page", div1);
      return true;
    };
    ServiceResults2.prototype.showAssistant = function() {
      this.menu.title = "Help Assistant";
      if (this.menu.updateTitle)
        this.menu.updateTitle();
      this.menu.title = this.menu.actions["opProdJS"];
      var div1 = document.createElement("div");
      div1.style.padding = "2rem";
      if (this.assistantArgs && this.assistantArgs.codeLenCommand) {
        var el = document.createElement(this.assistantArgs.codeLenCommand.refs);
        div1.appendChild(el);
      }
      if (this.menu.setMode)
        this.menu.setMode("page", div1);
      return true;
    };
    ServiceResults2.prototype.createListRefs = function() {
      return __awaiter(this, void 0, void 0, function() {
        var references;
        var _this = this;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (!this.list)
                return [
                  2
                  /*return*/
                ];
              if (this.refTitle)
                this.refTitle.innerHTML = "<b>File References from:</b> _".concat(this.actualFileProject, "_").concat(this.actualFileName);
              this.list.innerHTML = "Loading...";
              return [4, this.getReferences(this.actualFileName, this.actualFileProject)];
            case 1:
              references = _a2.sent();
              this.results.references = references;
              this.list.innerHTML = "";
              if (this.results.references.length === 0) {
                this.list.innerHTML = "No references.";
                return [
                  2
                  /*return*/
                ];
              }
              this.results.references.forEach(function(ref) {
                var li = document.createElement("li");
                var a = document.createElement("a");
                a.href = "#";
                a.innerHTML = "Project: ".concat(ref.project, " ShortName: ").concat(ref.shortName, " ");
                a.onclick = function(e) {
                  e.preventDefault();
                  var cmdOpen = {
                    action: "open",
                    level: 2,
                    project: ref.project,
                    shortName: ref.shortName,
                    extension: ref.extension,
                    folder: "",
                    position: _this.position
                  };
                  mls.events.fire([2], ["FileAction"], JSON.stringify(cmdOpen), 0);
                };
                li.appendChild(a);
                if (_this.list)
                  _this.list.appendChild(li);
              });
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceResults2.prototype.showDevDocJson = function() {
      this.menu.title = "Develpoment Docs Json";
      if (this.menu.updateTitle)
        this.menu.updateTitle();
      if (this.menu.setMode)
        this.menu.setMode("editor");
      this.actualResultMode = "devDoc";
      this.setModelLanguage(this.resultsLanguages.devDoc, this.results.devDoc);
      return true;
    };
    ServiceResults2.prototype.showJsonImport = function() {
      this.menu.title = "Imports Json";
      if (this.menu.updateTitle)
        this.menu.updateTitle();
      if (this.menu.setMode)
        this.menu.setMode("editor");
      this.actualResultMode = "jsonImport";
      this.setModelLanguage(this.resultsLanguages.jsonImport, this.results.jsonImport);
      return true;
    };
    ServiceResults2.prototype.delay = function(ms) {
      return new Promise(function(resolve) {
        return setTimeout(resolve, ms);
      });
    };
    ServiceResults2.prototype.openActualResultMode = function() {
      return __awaiter(this, void 0, void 0, function() {
        var language, value;
        return __generator(this, function(_a2) {
          language = this.resultsLanguages[this.actualResultMode];
          value = this.results[this.actualResultMode];
          if (language && value)
            this.setModelLanguage(language, value);
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServiceResults2.prototype.openErrorMode = function() {
      this.setModelLanguage(this.resultsLanguages.errors, this.results.errors);
    };
    ServiceResults2.prototype.openResultsDocsPageMode = function() {
      this.menu.title = "Develpoment Docs";
      if (this.menu.updateTitle)
        this.menu.updateTitle();
      this.actualResultMode = "devDocPage";
      if (!this.devDocContainer)
        return;
      this.devDocContainer.setAttribute("force", "true");
      this.devDocContainer.setAttribute("path", "_100529_service_results_doc");
    };
    ServiceResults2.prototype.openReferenceMode = function() {
      if (this.menu.setMenuActive)
        this.menu.setMenuActive("opReferences");
      this.isReferenceOpen = false;
    };
    ServiceResults2.prototype.openHelpAssistantMode = function() {
      if (this.menu.setMenuActive)
        this.menu.setMenuActive("opAssistant");
      this.isHelpAssistant = false;
    };
    ServiceResults2.prototype.updated = function(changedProperties) {
      var _a2;
      if (changedProperties.has("msize")) {
        if (!this.visible)
          return;
        (_a2 = this.c2) === null || _a2 === void 0 ? void 0 : _a2.setAttribute("msize", this.msize);
      }
    };
    ServiceResults2.prototype.render = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['\n            <mls-editor-100529 ismls2="true"></mls-editor-100529>\n        '], ['\n            <mls-editor-100529 ismls2="true"></mls-editor-100529>\n        '])));
    };
    var _a;
    __decorate([
      property({ type: String }),
      __metadata("design:type", Object)
    ], ServiceResults2.prototype, "msize", void 0);
    __decorate([
      query("mls-editor-100529"),
      __metadata("design:type", typeof (_a = typeof HTMLElement !== "undefined" && HTMLElement) === "function" ? _a : Object)
    ], ServiceResults2.prototype, "c2", void 0);
    ServiceResults2 = __decorate([
      customElement("service-results-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceResults2);
    return ServiceResults2;
  }(ServiceBase)
);
var templateObject_1;
export {
  ServiceResults
};
