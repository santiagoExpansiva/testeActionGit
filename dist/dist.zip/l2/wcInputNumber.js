var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, ifDefined, css } from "lit";
import { customElement, property, query } from "lit/decorators.js";
import { IcaFormsInputNumberBase } from "./_100554_icaFormsInputNumberBase";
import { propertyDataSource, propertyCompositeDataSource } from "./_100554_icaLitElement";
var WCInputNumber = (
  /** @class */
  function(_super) {
    __extends(WCInputNumber2, _super);
    function WCInputNumber2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.required = false;
      _this.disabled = false;
      _this.readonly = false;
      _this.autofocus = false;
      _this.hint = "";
      _this.inputmode = "none";
      _this.error = "";
      return _this;
    }
    WCInputNumber2.prototype.render = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['\n        <label class="form-control-label" for="input">\n          ', '\n        </label>\n\n        <input\n            id="input"\n            class="input_control"\n            type="number"\n            name=', "\n            ?disabled=", "\n            ?readonly=", "\n            ?required=", "\n            min=", "    \n            max=", "\n            step=", "\n            .value=", "\n            ?autofocus=", "\n            pattern=", "\n            inputmode=", "\n            @input=", '\n        />\n\n        <div class="form_error_message">', "</div>\n        "], ['\n        <label class="form-control-label" for="input">\n          ', '\n        </label>\n\n        <input\n            id="input"\n            class="input_control"\n            type="number"\n            name=', "\n            ?disabled=", "\n            ?readonly=", "\n            ?required=", "\n            min=", "    \n            max=", "\n            step=", "\n            .value=", "\n            ?autofocus=", "\n            pattern=", "\n            inputmode=", "\n            @input=", '\n        />\n\n        <div class="form_error_message">', "</div>\n        "])), this.label, ifDefined(this.name), this.disabled, this.readonly, this.required, ifDefined(this.minvalue), ifDefined(this.maxvalue), ifDefined(this.step), this.datasource, this.autofocus, ifDefined(this.pattern), ifDefined(this.inputmode), this.handleChange, this.error);
    };
    WCInputNumber2.prototype.handleChange = function() {
      if (!this.input)
        return;
      var newval = +this.input.value;
      if (!isNaN(newval) && (this.minvalue === void 0 || newval >= this.minvalue) && (this.maxvalue === void 0 || newval <= this.maxvalue)) {
        this.datasource = newval;
        this.error = "";
        this.requestUpdate();
      } else {
        this.error = this.errormessage || "";
        this.requestUpdate();
      }
    };
    var _a;
    WCInputNumber2.styles = css(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n    :host {\n        display: block;\n    }\n\n    .input_control {\n        display: block;\n        padding: 0.375rem 0.75rem;\n        font-size: 1rem;\n        font-weight: 400;\n        line-height: 1.5;\n        color: #212529;\n        background-color: #fff;\n        background-clip: padding-box;\n        border: 1px solid #ced4da;\n        -webkit-appearance: none;\n        -moz-appearance: none;\n        appearance: none;\n        border-radius: 0.25rem;\n        transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;\n        outline:none;\n    }\n    .form_error_message{\n        color: red;\n    }\n    "], ["\n    :host {\n        display: block;\n    }\n\n    .input_control {\n        display: block;\n        padding: 0.375rem 0.75rem;\n        font-size: 1rem;\n        font-weight: 400;\n        line-height: 1.5;\n        color: #212529;\n        background-color: #fff;\n        background-clip: padding-box;\n        border: 1px solid #ced4da;\n        -webkit-appearance: none;\n        -moz-appearance: none;\n        appearance: none;\n        border-radius: 0.25rem;\n        transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;\n        outline:none;\n    }\n    .form_error_message{\n        color: red;\n    }\n    "])));
    __decorate([
      propertyDataSource({ type: String }),
      __metadata("design:type", Number)
    ], WCInputNumber2.prototype, "datasource", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WCInputNumber2.prototype, "name", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WCInputNumber2.prototype, "placeholder", void 0);
    __decorate([
      propertyCompositeDataSource({ type: String }),
      __metadata("design:type", String)
    ], WCInputNumber2.prototype, "label", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WCInputNumber2.prototype, "pattern", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WCInputNumber2.prototype, "errormessage", void 0);
    __decorate([
      property({ type: Number }),
      __metadata("design:type", Number)
    ], WCInputNumber2.prototype, "maxvalue", void 0);
    __decorate([
      property({ type: Number }),
      __metadata("design:type", Number)
    ], WCInputNumber2.prototype, "minvalue", void 0);
    __decorate([
      property({ type: Number }),
      __metadata("design:type", Number)
    ], WCInputNumber2.prototype, "step", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Boolean)
    ], WCInputNumber2.prototype, "required", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Boolean)
    ], WCInputNumber2.prototype, "disabled", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Boolean)
    ], WCInputNumber2.prototype, "readonly", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Boolean)
    ], WCInputNumber2.prototype, "autofocus", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WCInputNumber2.prototype, "hint", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WCInputNumber2.prototype, "inputmode", void 0);
    __decorate([
      query(".input_control"),
      __metadata("design:type", typeof (_a = typeof HTMLInputElement !== "undefined" && HTMLInputElement) === "function" ? _a : Object)
    ], WCInputNumber2.prototype, "input", void 0);
    WCInputNumber2 = __decorate([
      customElement("wc-input-number-100554")
    ], WCInputNumber2);
    return WCInputNumber2;
  }(IcaFormsInputNumberBase)
);
var templateObject_1, templateObject_2;
export {
  WCInputNumber
};
