var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css } from "lit";
import { customElement, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
import { initCollabDSInputRange } from "./_100554_collabDsInputRange";
import { initCollabDsInputSelectColor } from "./_100554_collabDsInputSelectColor";
var message_pt = {
  color: "Cor",
  fontFamily: "Fam\uFFFDlia de fontes",
  fontWeight: "Peso da fonte",
  fontStyle: "Estilo da fonte",
  fontSize: "Tamanho da fonte",
  letterSpacing: "Espa\uFFFDamento entre letras",
  wordSpacing: "Espa\uFFFDamento entre palavras",
  lineHeight: "Altura da linha",
  textAlign: "Alinhar texto",
  variant: "Variante",
  transform: "Transformar",
  decoration: "Decora\uFFFD\uFFFDo",
  textOverflow: "Text-overflow"
};
var message_en = {
  color: "Color",
  fontFamily: "Font Family",
  fontWeight: "Font Weight",
  fontStyle: "Font Style",
  fontSize: "Font Size",
  letterSpacing: "Letter Spacing",
  wordSpacing: "Word Spacing",
  lineHeight: "Line Height",
  textAlign: "Text align",
  variant: "Variant",
  transform: "Transform",
  decoration: "Decoration",
  textOverflow: "Text-overflow"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceDsStyleTypography = (
  /** @class */
  function(_super) {
    __extends(ServiceDsStyleTypography2, _super);
    function ServiceDsStyleTypography2() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.myUpp = false;
      _this.error = "";
      _this.helper = "_100554_serviceDsStyleTypography";
      _this.details = {
        icon: "&#xf031",
        state: "foreground",
        position: "right",
        tooltip: "Typography",
        visible: false,
        tags: ["ds_styles"],
        widget: "_100554_serviceDsStyleTypography",
        level: [3]
      };
      _this.onClickLink = function(op) {
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.onClickIcon = function(op) {
      };
      _this.menu = {
        title: "Typography",
        actions: {},
        icons: {},
        actionDefault: "",
        // call after close icon clicked
        iconDefault: "",
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        onClickIcon: _this.onClickIcon
      };
      _this.tpMeasures = ["px", "em", "rem", "vh", "vw", "vmin", "vmax", "ex", "ch", "auto"];
      _this.timeonChangeProp = -1;
      _this.timeLoader = -1;
      initCollabDSInputRange();
      initCollabDsInputSelectColor();
      _this.setEvents();
      return _this;
    }
    ServiceDsStyleTypography2.prototype.onServiceClick = function(visible, reinit) {
      if (visible || reinit) {
        this.fireEventAboutMe();
      }
    };
    ServiceDsStyleTypography2.prototype.setEvents = function() {
      var _this = this;
      mls.events.addEventListener([3], ["DSStyleChanged"], function(ev) {
        _this.onstylechanged(ev.desc);
      });
      mls.events.addEventListener([3], ["DSStyleSelected"], function(ev) {
        _this.onDSStyleSelected(ev);
      });
      mls.events.addEventListener([3], ["DSStyleUnSelected"], function(ev) {
        _this.onDSStyleUnSelected(ev);
      });
      mls.events.addEventListener([3], ["DSStyleCursorChanged"], function(ev) {
        _this.onDSStyleCursorChanged(ev);
      });
    };
    ServiceDsStyleTypography2.prototype.onstylechanged = function(desc) {
      var obj = JSON.parse(desc);
      if (obj.emitter === "left" && this.visible === "true" && obj.value.length > 0) {
        this.setValues(obj.value);
      }
    };
    ServiceDsStyleTypography2.prototype.setValues = function(ar) {
      var _this = this;
      this.myUpp = true;
      ar.forEach(function(i) {
        if (!_this.shadowRoot || !i.key)
          return;
        var value = i.value;
        var prop = i.key;
        var el = _this.shadowRoot.querySelector('*[prop="' + prop + '"]');
        if (el)
          el.value = value;
      });
      this.myUpp = false;
    };
    ServiceDsStyleTypography2.prototype.onDSStyleSelected = function(ev) {
      var params = ev.desc ? JSON.parse(ev.desc) : [];
      if (params.service.length > 0 && !params.service.includes(this.helper) || !this.serviceItemNav)
        return;
      this.serviceItemNav.setAttribute("mode", "A");
      this.showNav2Item(true);
    };
    ServiceDsStyleTypography2.prototype.onDSStyleUnSelected = function(ev) {
      var params = ev.desc ? JSON.parse(ev.desc) : [];
      if (params.service.includes(this.helper) || !this.serviceItemNav)
        return;
      this.serviceItemNav.setAttribute("mode", "H");
      this.showNav2Item(false);
    };
    ServiceDsStyleTypography2.prototype.onDSStyleCursorChanged = function(ev) {
      var rc = JSON.parse(ev.desc);
      if (rc.helper === this.helper) {
        if (this.visible === "true" || !this.serviceItemNav)
          return;
        this.serviceItemNav.click();
      }
    };
    ServiceDsStyleTypography2.prototype.connectedCallback = function() {
      _super.prototype.connectedCallback.call(this);
    };
    ServiceDsStyleTypography2.prototype.render = function() {
      var _this = this;
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['\n            <div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <input type="color" prop="color" @change="', '"></input>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select style="width:160px" prop="font-family" @change="', '">\n                        <option value=""></option>\n                        <option value="COURIER">Courier</option>\n                        <option value="VERDANA">Verdana</option>\n                        <option value="ARIAL">Arial</option>\n                        <option value="TIMES NEW ROMAN">Times new Roman</option>\n                    </select>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select style="width:160px" prop="font-weight" @change="', '">\n                        <option value=""></option>\n                        <option value="100">100</option>\n                        <option value="200">200</option>\n                        <option value="300">300</option>\n                        <option value="400">400</option>\n                        <option value="500">500</option>\n                        <option value="600">600</option>\n                        <option value="700">700</option>\n                        <option value="800">800</option>\n                        <option value="900">900</option>\n                    </select>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select style="width:160px" prop="font-style" @change="', '">\n                        <option value=""></option>\n                        <option value="NULL">null</option>\n                        <option value="NORMAL">normal</option>\n                        <option value="ITALIC">italic</option>\n                    </select>\n                </div> \n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="font-size" value="0px" .arraySelect=', '  group="radius" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit"> \n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="letter-spacing" value="0px" .arraySelect=', '  group="radius" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit"> \n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="word-spacing" value="0px" .arraySelect=', '  group="radius" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit"> \n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="line-height" value="0px" .arraySelect=', '  group="radius" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select style="width:160px" prop="text-align" @change="', '">\n                        <option value=""></option>\n                        <option value="CENTER">center</option>\n                        <option value="END">end</option>\n                        <option value="INHERIT">inherit</option>\n                        <option value="INITIAL">initial</option>\n                        <option value="JUSTIFY">justify</option>\n                        <option value="LEFT">left</option>\n                        <option value="REVERT">revert</option>\n                        <option value="RIGHT">right</option>\n                        <option value="START">start</option>\n                        <option value="UNSET">unset</option>\n                    </select>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select style="width:160px" prop="variant" @change="', '">\n                        <option value=""></option>\n                        <option value="NORMAL">normal</option>\n                        <option value="SMALL-CAPS">small-caps</option>\n                    </select>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select style="width:160px" prop="transform" @change="', '">\n                        <option value=""></option>\n                        <option value="UPPERCASE">uppercase</option>\n                        <option value="LOWERCASE">lowercase</option>\n                        <option value="CAPITALIZE">capitalize</option>\n                    </select>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select style="width:160px" prop="decoration" @change="', '">\n                        <option value=""></option>\n                        <option value="NORMAL">normal</option>\n                        <option value="UNDERLINE">underline</option>\n                        <option value="OVERLINE">overline</option>\n                        <option value="LINE-THROUGH">line-through</option>\n                    </select>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select style="width:160px" prop="text-overflow" @change="', '">\n                        <option value=""></option>\n                        <option value="ELLIPSIS">ellipsis</option>\n                        <option value="CLIP">clip</option>\n                        <option value="INITIAL">initial</option>\n                    </select>\n                </div>\n            </div>\n        '], ['\n            <div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <input type="color" prop="color" @change="', '"></input>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select style="width:160px" prop="font-family" @change="', '">\n                        <option value=""></option>\n                        <option value="COURIER">Courier</option>\n                        <option value="VERDANA">Verdana</option>\n                        <option value="ARIAL">Arial</option>\n                        <option value="TIMES NEW ROMAN">Times new Roman</option>\n                    </select>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select style="width:160px" prop="font-weight" @change="', '">\n                        <option value=""></option>\n                        <option value="100">100</option>\n                        <option value="200">200</option>\n                        <option value="300">300</option>\n                        <option value="400">400</option>\n                        <option value="500">500</option>\n                        <option value="600">600</option>\n                        <option value="700">700</option>\n                        <option value="800">800</option>\n                        <option value="900">900</option>\n                    </select>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select style="width:160px" prop="font-style" @change="', '">\n                        <option value=""></option>\n                        <option value="NULL">null</option>\n                        <option value="NORMAL">normal</option>\n                        <option value="ITALIC">italic</option>\n                    </select>\n                </div> \n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="font-size" value="0px" .arraySelect=', '  group="radius" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit"> \n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="letter-spacing" value="0px" .arraySelect=', '  group="radius" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit"> \n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="word-spacing" value="0px" .arraySelect=', '  group="radius" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit"> \n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="line-height" value="0px" .arraySelect=', '  group="radius" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select style="width:160px" prop="text-align" @change="', '">\n                        <option value=""></option>\n                        <option value="CENTER">center</option>\n                        <option value="END">end</option>\n                        <option value="INHERIT">inherit</option>\n                        <option value="INITIAL">initial</option>\n                        <option value="JUSTIFY">justify</option>\n                        <option value="LEFT">left</option>\n                        <option value="REVERT">revert</option>\n                        <option value="RIGHT">right</option>\n                        <option value="START">start</option>\n                        <option value="UNSET">unset</option>\n                    </select>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select style="width:160px" prop="variant" @change="', '">\n                        <option value=""></option>\n                        <option value="NORMAL">normal</option>\n                        <option value="SMALL-CAPS">small-caps</option>\n                    </select>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select style="width:160px" prop="transform" @change="', '">\n                        <option value=""></option>\n                        <option value="UPPERCASE">uppercase</option>\n                        <option value="LOWERCASE">lowercase</option>\n                        <option value="CAPITALIZE">capitalize</option>\n                    </select>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select style="width:160px" prop="decoration" @change="', '">\n                        <option value=""></option>\n                        <option value="NORMAL">normal</option>\n                        <option value="UNDERLINE">underline</option>\n                        <option value="OVERLINE">overline</option>\n                        <option value="LINE-THROUGH">line-through</option>\n                    </select>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select style="width:160px" prop="text-overflow" @change="', '">\n                        <option value=""></option>\n                        <option value="ELLIPSIS">ellipsis</option>\n                        <option value="CLIP">clip</option>\n                        <option value="INITIAL">initial</option>\n                    </select>\n                </div>\n            </div>\n        '])), this.msg.color, function(e) {
        return _this.onChangeProp2("color");
      }, this.msg.fontFamily, function(e) {
        return _this.onChangeProp2("font-family");
      }, this.msg.fontWeight, function(e) {
        return _this.onChangeProp2("font-weight");
      }, this.msg.fontStyle, function(e) {
        return _this.onChangeProp2("font-style");
      }, this.msg.fontSize, this.tpMeasures, function(e) {
        return _this.onChangeProp(e);
      }, this.msg.letterSpacing, this.tpMeasures, function(e) {
        return _this.onChangeProp(e);
      }, this.msg.wordSpacing, this.tpMeasures, function(e) {
        return _this.onChangeProp(e);
      }, this.msg.lineHeight, this.tpMeasures, function(e) {
        return _this.onChangeProp(e);
      }, this.msg.textAlign, function(e) {
        return _this.onChangeProp2("text-align");
      }, this.msg.variant, function(e) {
        return _this.onChangeProp2("variant");
      }, this.msg.transform, function(e) {
        return _this.onChangeProp2("transform");
      }, this.msg.decoration, function(e) {
        return _this.onChangeProp2("decoration");
      }, this.msg.textOverflow, function(e) {
        return _this.onChangeProp2("text-overflow");
      });
    };
    ServiceDsStyleTypography2.prototype.onChangeProp = function(obj) {
      var _this = this;
      clearTimeout(this.timeonChangeProp);
      this.timeonChangeProp = setTimeout(function() {
        _this.emitEvent(obj.detail);
      }, 500);
    };
    ServiceDsStyleTypography2.prototype.onChangeProp2 = function(prop) {
      var _this = this;
      clearTimeout(this.timeonChangeProp);
      this.timeonChangeProp = setTimeout(function() {
        if (!_this.shadowRoot)
          return;
        var el = _this.shadowRoot.querySelector('*[prop="' + prop + '"]');
        _this.emitEvent({ key: prop, value: el.value });
      }, 500);
    };
    ServiceDsStyleTypography2.prototype.fireEventAboutMe = function() {
      var rc = {
        emitter: "right-get"
      };
      mls.events.fire([3], ["DSStyleChanged"], JSON.stringify(rc), 500);
    };
    ServiceDsStyleTypography2.prototype.emitEvent = function(obj) {
      if (this.myUpp)
        return;
      if (obj.target)
        delete obj.target;
      var rc = {
        emitter: this.position,
        value: [obj],
        helper: this.helper
      };
      if (typeof mls !== "object")
        return;
      mls.events.fire([3], ["DSStyleChanged"], JSON.stringify(rc));
    };
    ServiceDsStyleTypography2.prototype.showLoader = function(loader) {
      var _this = this;
      clearTimeout(this.timeLoader);
      this.timeLoader = setTimeout(function() {
        _this.loading = loader;
      }, 200);
    };
    ServiceDsStyleTypography2.styles = css(templateObject_2 || (templateObject_2 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceDsStyleTypography2.prototype, "error", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceDsStyleTypography2.prototype, "helper", void 0);
    ServiceDsStyleTypography2 = __decorate([
      customElement("service-ds-style-typography-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceDsStyleTypography2);
    return ServiceDsStyleTypography2;
  }(ServiceBase)
);
var templateObject_1, templateObject_2;
export {
  ServiceDsStyleTypography
};
