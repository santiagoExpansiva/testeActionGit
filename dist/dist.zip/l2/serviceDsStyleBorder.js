var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css, repeat } from "lit";
import { customElement, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
import { initCollabDSInputRange } from "./_100554_collabDsInputRange";
import { initCollabDsInputSelectColor } from "./_100554_collabDsInputSelectColor";
var message_pt = {
  border: "Borda",
  top: "Topo",
  left: "Esquerda",
  bottom: "Baixo",
  right: "Direita",
  borderRadius: "Raio da borda",
  topLeft: "Topo/Esquerda",
  topRight: "Topo/Direita",
  bottomLeft: "Baixo/Esquerda",
  bottomRight: "Baixo/Direita"
};
var message_en = {
  border: "Border",
  top: "Top",
  left: "Left",
  bottom: "Bottom",
  right: "Right",
  borderRadius: "Border Radius",
  topLeft: "Top/Left",
  topRight: "Top/Right",
  bottomLeft: "Bottom/Left",
  bottomRight: "Bottom/Right"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceDsStyleBorder = (
  /** @class */
  function(_super) {
    __extends(ServiceDsStyleBorder2, _super);
    function ServiceDsStyleBorder2() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.myUpp = false;
      _this.error = "";
      _this.helper = "_100554_serviceDsStyleBorder";
      _this.details = {
        icon: "&#xf853",
        state: "foreground",
        position: "right",
        tooltip: "Border",
        visible: false,
        tags: ["ds_styles"],
        widget: "_100554_serviceDsStyleBorder",
        level: [3]
      };
      _this.onClickLink = function(op) {
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.onClickIcon = function(op) {
      };
      _this.menu = {
        title: "Border",
        actions: {},
        icons: {},
        actionDefault: "",
        // call after close icon clicked
        iconDefault: "",
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        onClickIcon: _this.onClickIcon
      };
      _this.tpMeasures = ["px", "em", "rem", "vh", "vw", "vmin", "vmax", "ex", "ch", "auto"];
      _this.tpBorder = ["none", "solid", "dotted", "dashed", "double", "groove", "ridge", "inset", "outset", "hidden"];
      _this.timeonChangeProp = -1;
      _this.timeLoader = -1;
      _this.arrayGallery = [
        "border-left: 1px solid #000000; border-right: 1px solid #000000; border-top: 1px solid #000000;",
        "border-left: 1px solid #000000; border-right: 1px solid #000000; border-bottom: 1px solid #000000;",
        "border: 5px dashed #32557f;",
        "border: 4px solid transparent; background: linear-gradient(white, white) padding-box, repeating-linear-gradient(-45deg, #f69ec4 0, #f69ec4 12.5%, transparent 0, transparent 25%, #7eb4e2 0, #7eb4e2 37.5%, transparent 0, transparent 50%) 0 / 15px 15px;",
        "border: 10px solid transparent; border-width: 10px 0; background-color: #7eb4e2; background-color: hsla(0, 0%, 0%, 0); background-image: linear-gradient(#7eb4e2, #32557f), linear-gradient(to bottom right, transparent 50.5%, #7eb4e2 50.5%), linear-gradient(to bottom left, transparent 50.5%, #7eb4e2 50.5%), linear-gradient(to top right, transparent 50.5%, #32557f 50.5%), linear-gradient(to top left, transparent 50.5%, #32557f 50.5%); background-repeat: repeat, repeat-x, repeat-x, repeat-x, repeat-x; background-position: 0 0, 10px 0, 10px 0, 10px 100%, 10px 100%; background-size: auto auto, 20px 20px, 20px 20px, 20px 20px, 20px 20px; background-clip: padding-box, border-box, border-box, border-box, border-box; background-origin: padding-box, border-box, border-box, border-box, border-box;",
        "border: 4px solid transparent; background: linear-gradient(#000, #000) padding-box, radial-gradient(farthest-corner at 50% 50%, #00C9A7, #845EC2) border-box;",
        "border: 4px solid transparent; background: linear-gradient(#000, #000) padding-box, linear-gradient(to bottom left, #f83600, #f9d423) border-box;",
        "border: 4px solid transparent; background: linear-gradient(#000, #000) padding-box, linear-gradient(#f9f047, #0fd850) border-box;",
        "border-left: 4px solid #e85f99; border-right: 4px solid #f18867; border-top: 4px solid #65587f; border-bottom: 4px solid #50bda1;",
        "border: 5px dashed #FF5722; background: linear-gradient(to top, green, 5px, transparent 5px), linear-gradient(to right, green, 5px, transparent 5px), linear-gradient(to bottom, green, 5px, transparent 5px), linear-gradient(to left, green, 5px, transparent 5px); background-origin: border-box;",
        "box-shadow: 0 0 0 4px #009688;border: 4px solid #009688;outline: dashed 4px white;",
        "border: 8px groove;",
        "border-top: 2px solid #3C514D;border-bottom: 3px dashed #3C514D;border-left: 5px double #212410;border-right: 3px dotted rgb(223,112,0);"
      ];
      initCollabDSInputRange();
      initCollabDsInputSelectColor();
      _this.setEvents();
      return _this;
    }
    ServiceDsStyleBorder2.prototype.onServiceClick = function(visible, reinit) {
      if (visible) {
        this.fireEventAboutMe();
      }
    };
    ServiceDsStyleBorder2.prototype.setEvents = function() {
      var _this = this;
      mls.events.addEventListener([3], ["DSStyleChanged"], function(ev) {
        _this.onstylechanged(ev.desc);
      });
      mls.events.addEventListener([3], ["DSStyleSelected"], function(ev) {
        _this.onDSStyleSelected(ev);
      });
      mls.events.addEventListener([3], ["DSStyleUnSelected"], function(ev) {
        _this.onDSStyleUnSelected(ev);
      });
      mls.events.addEventListener([3], ["DSStyleCursorChanged"], function(ev) {
        _this.onDSStyleCursorChanged(ev);
      });
    };
    ServiceDsStyleBorder2.prototype.onstylechanged = function(desc) {
      var obj = JSON.parse(desc);
      if (obj.emitter === "left" && this.visible === "true" && obj.value.length > 0) {
        this.setValues(obj.value);
      }
    };
    ServiceDsStyleBorder2.prototype.setValues = function(ar) {
      var _this = this;
      this.myUpp = true;
      ar.forEach(function(i) {
        if (!_this.shadowRoot || !i.key)
          return;
        var value = i.value;
        var prop = i.key;
        if (prop === "border") {
          _this.uppProp(value, "border");
        } else if (prop === "border-radius") {
          _this.uppProp(value, "radius");
        } else {
          var el = _this.shadowRoot.querySelector('*[prop="' + prop + '"]');
          if (el)
            el.value = value;
        }
      });
      this.myUpp = false;
    };
    ServiceDsStyleBorder2.prototype.onDSStyleSelected = function(ev) {
      var params = ev.desc ? JSON.parse(ev.desc) : [];
      if (params.service.length > 0 && !params.service.includes(this.helper) || !this.serviceItemNav)
        return;
      this.serviceItemNav.setAttribute("mode", "A");
      this.showNav2Item(true);
    };
    ServiceDsStyleBorder2.prototype.onDSStyleUnSelected = function(ev) {
      var params = ev.desc ? JSON.parse(ev.desc) : [];
      if (params.service.includes(this.helper) || !this.serviceItemNav)
        return;
      this.showNav2Item(false);
    };
    ServiceDsStyleBorder2.prototype.onDSStyleCursorChanged = function(ev) {
      var rc = JSON.parse(ev.desc);
      if (rc.helper === this.helper) {
        if (this.visible === "true" || !this.serviceItemNav)
          return;
        this.serviceItemNav.click();
      }
    };
    ServiceDsStyleBorder2.prototype.connectedCallback = function() {
      _super.prototype.connectedCallback.call(this);
    };
    ServiceDsStyleBorder2.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["", "", "", ""], ["", "", "", ""])), this.renderBorder(), this.renderRadius(), this.renderGallery());
    };
    ServiceDsStyleBorder2.prototype.renderBorder = function() {
      var _this = this;
      return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(['\n            <div>\n                <h5 style="display:flex; gap:1.5rem" >', '<input type="checkbox" prop="border"></h5>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-select-color-100554 prop="border-top" valueInput="0px" .arrayInputSelect=', " .arraySelect=", ' valueSelect="none" group="border" @onchange="', '"></collab-ds-input-select-color-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-select-color-100554 prop="border-left" valueInput="0px" .arrayInputSelect=', " .arraySelect=", ' valueSelect="none" group="border" @onchange="', '"></collab-ds-input-select-color-100554>   \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-select-color-100554 prop="border-bottom" valueInput="0px" .arrayInputSelect=', " .arraySelect=", ' valueSelect="none" group="border" @onchange="', '"></collab-ds-input-select-color-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-select-color-100554 prop="border-right" valueInput="0px" .arrayInputSelect=', " .arraySelect=", ' valueSelect="none" group="border" @onchange="', '"></collab-ds-input-select-color-100554>\n                </div>\n            </div>\n        '], ['\n            <div>\n                <h5 style="display:flex; gap:1.5rem" >', '<input type="checkbox" prop="border"></h5>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-select-color-100554 prop="border-top" valueInput="0px" .arrayInputSelect=', " .arraySelect=", ' valueSelect="none" group="border" @onchange="', '"></collab-ds-input-select-color-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-select-color-100554 prop="border-left" valueInput="0px" .arrayInputSelect=', " .arraySelect=", ' valueSelect="none" group="border" @onchange="', '"></collab-ds-input-select-color-100554>   \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-select-color-100554 prop="border-bottom" valueInput="0px" .arrayInputSelect=', " .arraySelect=", ' valueSelect="none" group="border" @onchange="', '"></collab-ds-input-select-color-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-select-color-100554 prop="border-right" valueInput="0px" .arrayInputSelect=', " .arraySelect=", ' valueSelect="none" group="border" @onchange="', '"></collab-ds-input-select-color-100554>\n                </div>\n            </div>\n        '])), this.msg.border, this.msg.top, this.tpMeasures, this.tpBorder, function(e) {
        return _this.onChangeProp(e);
      }, this.msg.left, this.tpMeasures, this.tpBorder, function(e) {
        return _this.onChangeProp(e);
      }, this.msg.bottom, this.tpMeasures, this.tpBorder, function(e) {
        return _this.onChangeProp(e);
      }, this.msg.right, this.tpMeasures, this.tpBorder, function(e) {
        return _this.onChangeProp(e);
      });
    };
    ServiceDsStyleBorder2.prototype.renderRadius = function() {
      var _this = this;
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['\n            <div>\n                <h5 style="display:flex; gap:1.5rem" >', '<input type="checkbox" prop="radius"></h5>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="border-top-left-radius" value="0px" .arraySelect=', '  group="radius" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="border-top-right-radius" value="0px" .arraySelect=', ' group="radius" @onchange="', '"></collab-ds-input-range-100554>    \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="border-bottom-left-radius" value="0px" .arraySelect=', ' group="radius" @onchange="', '"></collab-ds-input-range-100554> \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="border-bottom-right-radius" value="0px" .arraySelect=', ' group="radius" @onchange="', '"></collab-ds-input-range-100554> \n                </div>\n                \n            </div>\n        '], ['\n            <div>\n                <h5 style="display:flex; gap:1.5rem" >', '<input type="checkbox" prop="radius"></h5>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="border-top-left-radius" value="0px" .arraySelect=', '  group="radius" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="border-top-right-radius" value="0px" .arraySelect=', ' group="radius" @onchange="', '"></collab-ds-input-range-100554>    \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="border-bottom-left-radius" value="0px" .arraySelect=', ' group="radius" @onchange="', '"></collab-ds-input-range-100554> \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="border-bottom-right-radius" value="0px" .arraySelect=', ' group="radius" @onchange="', '"></collab-ds-input-range-100554> \n                </div>\n                \n            </div>\n        '])), this.msg.borderRadius, this.msg.topLeft, this.tpMeasures, function(e) {
        return _this.onChangeProp(e);
      }, this.msg.topRight, this.tpMeasures, function(e) {
        return _this.onChangeProp(e);
      }, this.msg.bottomLeft, this.tpMeasures, function(e) {
        return _this.onChangeProp(e);
      }, this.msg.bottomRight, this.tpMeasures, function(e) {
        return _this.onChangeProp(e);
      });
    };
    ServiceDsStyleBorder2.prototype.renderGallery = function() {
      var _this = this;
      return html(templateObject_5 || (templateObject_5 = __makeTemplateObject(['\n            <div style="display: flex; justify-content: center; align-items: center; gap: 1rem; padding: 1rem; flex-wrap: wrap; cursor:pointer">\n                ', "\n            </div>\n        \n        "], ['\n            <div style="display: flex; justify-content: center; align-items: center; gap: 1rem; padding: 1rem; flex-wrap: wrap; cursor:pointer">\n                ', "\n            </div>\n        \n        "])), repeat(this.arrayGallery, function(key) {
        return key;
      }, function(css2, index) {
        return html(templateObject_4 || (templateObject_4 = __makeTemplateObject(['<h5 style="', '" @click="', '" .gallery=', ">Item</h5>"], ['<h5 style="', '" @click="', '" .gallery=', ">Item</h5>"])), css2, _this.clickGallery, css2);
      }));
    };
    ServiceDsStyleBorder2.prototype.onChangeProp = function(e) {
      var _this = this;
      clearTimeout(this.timeonChangeProp);
      this.timeonChangeProp = setTimeout(function() {
        var el = e.detail.target;
        _this.beforeEmitEvent(el, e.detail);
      }, 500);
    };
    ServiceDsStyleBorder2.prototype.beforeEmitEvent = function(el, obj) {
      if (!this.shadowRoot)
        return;
      var group = el ? el.getAttribute("group") : "";
      var elGroup = this.shadowRoot.querySelector('input[prop="'.concat(group, '"]'));
      var isGroup = false;
      if (elGroup)
        isGroup = elGroup.checked;
      if (isGroup) {
        this.uppProp(el.value, group);
        return;
      }
      this.emitEvent({
        key: el.getAttribute("prop"),
        value: el.value
      });
    };
    ServiceDsStyleBorder2.prototype.uppProp = function(value, group) {
      if (!this.shadowRoot)
        return;
      var info = {
        border: {
          p1: "border-top",
          p2: "border-left",
          p3: "border-right",
          p4: "border-bottom"
        },
        radius: {
          p1: "border-top-left-radius",
          p2: "border-top-right-radius",
          p3: "border-bottom-left-radius",
          p4: "border-bottom-right-radius"
        }
      };
      var prop = group === "border" ? group : "border-radius";
      var elP1 = this.shadowRoot.querySelector('*[prop="'.concat(info[group].p1, '"]'));
      var elP2 = this.shadowRoot.querySelector('*[prop="'.concat(info[group].p2, '"]'));
      var elP3 = this.shadowRoot.querySelector('*[prop="'.concat(info[group].p3, '"]'));
      var elP4 = this.shadowRoot.querySelector('*[prop="'.concat(info[group].p4, '"]'));
      var ar = [];
      if (elP1)
        ar.push(elP1);
      if (elP2)
        ar.push(elP2);
      if (elP3)
        ar.push(elP3);
      if (elP4)
        ar.push(elP4);
      console.info(ar);
      ar.forEach(function(i) {
        i.value = value;
      });
      this.emitEvent({
        key: prop,
        value: elP1.value
      });
    };
    ServiceDsStyleBorder2.prototype.fireEventAboutMe = function() {
      console.info("fireEventAboutMe");
      var rc = {
        emitter: "right-get"
      };
      mls.events.fire([3], ["DSStyleChanged"], JSON.stringify(rc), 500);
    };
    ServiceDsStyleBorder2.prototype.emitEvent = function(obj) {
      if (this.myUpp)
        return;
      var rc = {
        emitter: this.position,
        value: [obj],
        helper: this.helper
      };
      if (typeof mls !== "object")
        return;
      mls.events.fire([3], ["DSStyleChanged"], JSON.stringify(rc));
    };
    ServiceDsStyleBorder2.prototype.showLoader = function(loader) {
      var _this = this;
      clearTimeout(this.timeLoader);
      this.timeLoader = setTimeout(function() {
        _this.loading = loader;
      }, 200);
    };
    ServiceDsStyleBorder2.prototype.clickGallery = function(e) {
      var el = e.target;
      if (!el)
        return;
      var css2 = el.gallery;
      if (!css2)
        return;
      var commands = css2.split(";");
      var changes = [];
      commands.forEach(function(item) {
        var _a = item.split(":"), key = _a[0], value = _a[1];
        if (!key)
          return;
        changes.push({
          key: key.trim(),
          value: value.trim()
        });
      });
      var rc = {
        emitter: "right",
        value: changes,
        helper: this.helper
      };
      this.setValues(changes);
      mls.events.fire([3], ["DSStyleChanged"], JSON.stringify(rc));
    };
    ServiceDsStyleBorder2.styles = css(templateObject_6 || (templateObject_6 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceDsStyleBorder2.prototype, "error", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceDsStyleBorder2.prototype, "helper", void 0);
    ServiceDsStyleBorder2 = __decorate([
      customElement("service-ds-style-border-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceDsStyleBorder2);
    return ServiceDsStyleBorder2;
  }(ServiceBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6;
export {
  ServiceDsStyleBorder
};
