var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, unsafeHTML } from "lit";
import { customElement } from "lit/decorators.js";
import { CollabLitElement } from "./_100554_collabLitElement";
function initCodelensCustomElement() {
  return true;
}
var message_pt = {
  p1: "\uFFFD um recurso poderoso fornecido pelo Lit, uma biblioteca JavaScript para construir interfaces de usu\uFFFDrio web eficientes e reativas. \uFFFD usado para definir e registrar elementos personalizados com a API customElements do navegador. Elementos personalizados permitem que voc\uFFFD crie componentes reutiliz\uFFFDveis e autocontidos que podem ser usados como elementos HTML padr\uFFFDo dentro de sua aplica\uFFFD\uFFFDo web.  Uso Para criar um elemento personalizado usando o decorador @customElement no Lit, voc\uFFFD precisa definir uma classe que estende LitElement, a classe base fornecida pelo Lit. Esta classe encapsular\uFFFD o comportamento, a renderiza\uFFFD\uFFFDo e a l\uFFFDgica de atualiza\uFFFD\uFFFDo para o seu elemento personalizado.",
  usage: "Uso",
  p2: 'O decorador @customElement registra automaticamente seu elemento personalizado com a API customElements do navegador usando o nome da tag especificado. No exemplo acima, o elemento personalizado \uFFFD registrado com o nome da tag "my-custom-element". Isso permite que voc\uFFFD use o elemento personalizado como se fosse um elemento HTML padr\uFFFDo dentro de sua aplica\uFFFD\uFFFDo.'
};
var message_en = {
  p1: "Is a powerful feature provided by Lit, a JavaScript library for building efficient and reactive web user interfaces. It is used to define and register custom elements with the browsers customElements API. Custom elements allow you to create reusable and self-contained components that can be used like standard HTML elements within your web application.  Usage To create a custom element using the @customElement decorator in Lit, you need to define a class that extends LitElement, the base class provided by Lit. This class will encapsulate the behavior, rendering, and updating logic for your custom element.",
  usage: "Usage",
  p2: 'The @customElement decorator automatically registers your custom element with the browsers customElements API using the specified tag name. In the example above, the custom element is registered with the tag name "my-custom-element". This allows you to use the custom element as if it were a standard HTML element within your application.'
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var CodeLensCustomElement100554 = (
  /** @class */
  function(_super) {
    __extends(CodeLensCustomElement1005542, _super);
    function CodeLensCustomElement1005542() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.msg = messages["en"];
      _this.textCode = "\n    import { customElement, LitElement, html } from 'lit';\n    <br>\n    <br>\n    @customElement('my-custom-element')\n    <br>\n    class MyCustomElement extends LitElement {\n    <br>\n     [...]\n    <br>\n    }\n    ";
      return _this;
    }
    CodeLensCustomElement1005542.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n        <h1> @customElement</h1>\n        <p> ", "</p>\n        <hr>\n        <h2>", ":</h2>\n        <code>", "</code>\n        <div>\n            <p>", '</p>\n        </div>\n        <hr>\n        <div class="container-image">\n            <img src="https://lit.dev/images/docs/components/lit-element-inheritance.png" data-mlsline="11">\n        </div>\n        <a href="https://lit.dev/docs/components/overview/" target="_blank" data-mlsline="12">see more</a>\n        '], ["\n        <h1> @customElement</h1>\n        <p> ", "</p>\n        <hr>\n        <h2>", ":</h2>\n        <code>", "</code>\n        <div>\n            <p>", '</p>\n        </div>\n        <hr>\n        <div class="container-image">\n            <img src="https://lit.dev/images/docs/components/lit-element-inheritance.png" data-mlsline="11">\n        </div>\n        <a href="https://lit.dev/docs/components/overview/" target="_blank" data-mlsline="12">see more</a>\n        '])), this.msg.p1, this.msg.usage, unsafeHTML(this.textCode), this.msg.p2);
    };
    CodeLensCustomElement1005542.styles = css(templateObject_2 || (templateObject_2 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    CodeLensCustomElement1005542 = __decorate([
      customElement("codelens-custom-element-100554")
    ], CodeLensCustomElement1005542);
    return CodeLensCustomElement1005542;
  }(CollabLitElement)
);
var templateObject_1, templateObject_2;
export {
  CodeLensCustomElement100554,
  initCodelensCustomElement
};
