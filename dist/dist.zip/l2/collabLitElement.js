var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { LitElement } from "lit";
import { property } from "lit/decorators.js";
import { CollabState } from "./_100554_collabState";
var isTrace = false;
var state1 = new CollabState();
function collabState(customKey) {
  return function(proto, propertyKey) {
    var key = customKey || String(propertyKey);
    var _a = proto, connectedCallback = _a.connectedCallback, disconnectedCallback = _a.disconnectedCallback;
    proto.connectedCallback = function() {
      if (isTrace)
        console.log("connectedCallback, key=" + key);
      connectedCallback === null || connectedCallback === void 0 ? void 0 : connectedCallback.call(this);
      state1.subscribe(key, this);
    };
    proto.disconnectedCallback = function() {
      if (isTrace)
        console.log("disconnectedCallback, key=" + key);
      disconnectedCallback === null || disconnectedCallback === void 0 ? void 0 : disconnectedCallback.call(this);
      state1.unsubscribe(key, this);
    };
    proto.handleCollabStateChange = function(changedKey, value) {
      if (isTrace)
        console.log("handleCollabStateChange, key=" + key + ", value=", value);
      this[propertyKey] = value;
      this.requestUpdate(propertyKey, value);
    };
  };
}
var CollabLitElement = (
  /** @class */
  function(_super) {
    __extends(CollabLitElement2, _super);
    function CollabLitElement2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.globalVariation = window.globalVariation || 0;
      return _this;
    }
    CollabLitElement2.prototype.setCollabState = function(key, value) {
      state1.setState(key, value);
    };
    CollabLitElement2.prototype.collabRequestUpdate = function() {
      _super.prototype.requestUpdate.call(this);
    };
    CollabLitElement2.prototype.updated = function(changedProperties) {
      _super.prototype.updated.call(this, changedProperties);
      if (changedProperties.has("globalVariation") && changedProperties.get("globalVariation") !== void 0) {
        this.requestUpdate();
      }
    };
    CollabLitElement2.prototype.getMessageKey = function(messages) {
      var keys = Object.keys(messages);
      if (!keys || keys.length < 1)
        throw new Error("Error Message not valid for international");
      var firstKey = keys[0];
      var lang = (document.documentElement.lang || "").toLowerCase();
      if (!lang)
        return firstKey;
      if (messages.hasOwnProperty(lang))
        return lang;
      var similarLang = keys.find(function(key) {
        return lang.substring(0, 2) === key;
      });
      if (similarLang)
        return similarLang;
      return firstKey;
    };
    __decorate([
      property({ type: Number }),
      __metadata("design:type", Number)
    ], CollabLitElement2.prototype, "globalVariation", void 0);
    return CollabLitElement2;
  }(LitElement)
);
export {
  CollabLitElement,
  collabState
};
