var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css } from "lit";
import { customElement, query } from "lit/decorators.js";
import { CollabLitElement } from "./_100554_collabLitElement";
import { collab_ban } from "./_100554_collabIcons";
var message_pt = {
  "btn_cancel": "Cancelar",
  "btn_confirm": "Confirmar",
  "label_select_all": "Selecionar todos",
  "clear_all": "Limpar sele\uFFFD\uFFFDo"
};
var message_en = {
  "btn_cancel": "Cancel",
  "btn_confirm": "Confirm",
  "label_select_all": "Select all",
  "clear_all": "Clear selection"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var AimSelectWidget100554 = (
  /** @class */
  function(_super) {
    __extends(AimSelectWidget1005542, _super);
    function AimSelectWidget1005542() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.msg = messages["en"];
      return _this;
    }
    Object.defineProperty(AimSelectWidget1005542.prototype, "value", {
      get: function() {
        if (!this.listcontainer)
          return [];
        var all = this.listcontainer.querySelectorAll("input");
        var values = Array.from(all).map(function(inp) {
          return inp.checked ? inp["file"] : void 0;
        }).filter(function(item) {
          return !!item;
        });
        return values;
      },
      enumerable: false,
      configurable: true
    });
    AimSelectWidget1005542.prototype.getFilesNames = function() {
      var project = mls.actual[5].project;
      if (project === void 0)
        throw new Error("Invalid project selected");
      var filesInProject = Object.keys(mls.stor.files).filter(function(key) {
        return key.startsWith("".concat(project, "_2")) && key.endsWith(".ts");
      });
      return filesInProject.map(function(item) {
        return item.substring(9, item.length - 3);
      });
    };
    AimSelectWidget1005542.prototype.handleSelectAll = function(e) {
      var inp = e.target;
      if (!this.listcontainer)
        return;
      var all = this.listcontainer.querySelectorAll("input");
      if (inp.checked)
        all.forEach(function(inp2) {
          return inp2.checked = true;
        });
      else
        all.forEach(function(inp2) {
          return inp2.checked = false;
        });
    };
    AimSelectWidget1005542.prototype.handleClearAll = function(e) {
      var _a2;
      var all = (_a2 = this.shadowRoot) === null || _a2 === void 0 ? void 0 : _a2.querySelectorAll("input");
      if (all)
        all.forEach(function(inp) {
          return inp.checked = false;
        });
    };
    AimSelectWidget1005542.prototype.handleConfirm = function() {
      var val = this.value;
      this.dispatchEvent(new CustomEvent("select-widget-confirm", {
        detail: val,
        bubbles: true,
        composed: true
      }));
    };
    AimSelectWidget1005542.prototype.handleCancel = function() {
      this.dispatchEvent(new CustomEvent("select-widget-cancel"));
    };
    AimSelectWidget1005542.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      var files = this.getFilesNames();
      return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(['\n        <div> \n            <div class="select-btn">\n                <div class="select-btn-group">\n                    <div class="select-check-all">\n                        <button>\n                            <input id="select-check-all" type="checkbox" @change=', '></input>\n                            <label for="select-check-all">', '</label>\n                        </button>\n                    </div>\n                    <div class="select-clear-all">\n                        <button @click=', ">\n                            <div>", "</div>\n                            <span>", '</span>\n                        </button>\n                    </div>\n                </div>\n                <div class="select-btn-actions">\n                    <button @click=', ">", "</button>\n                    <button  @click=", ">", '</button>\n                </div>\n            </div>\n            <hr>\n\n            <div class="select-grid">\n                ', "\n            </div>\n        </div>"], ['\n        <div> \n            <div class="select-btn">\n                <div class="select-btn-group">\n                    <div class="select-check-all">\n                        <button>\n                            <input id="select-check-all" type="checkbox" @change=', '></input>\n                            <label for="select-check-all">', '</label>\n                        </button>\n                    </div>\n                    <div class="select-clear-all">\n                        <button @click=', ">\n                            <div>", "</div>\n                            <span>", '</span>\n                        </button>\n                    </div>\n                </div>\n                <div class="select-btn-actions">\n                    <button @click=', ">", "</button>\n                    <button  @click=", ">", '</button>\n                </div>\n            </div>\n            <hr>\n\n            <div class="select-grid">\n                ', "\n            </div>\n        </div>"])), this.handleSelectAll, this.msg.label_select_all, this.handleClearAll, collab_ban, this.msg.clear_all, this.handleConfirm, this.msg.btn_confirm, this.handleCancel, this.msg.btn_cancel, files.map(function(filename) {
        return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['\n                    <div class="select-grid-item">\n                        <input id="sl_', '" .file=', ' type="checkbox"></input>\n                        <label for="sl_', '">', "</label>\n                    </div>\n                    "], ['\n                    <div class="select-grid-item">\n                        <input id="sl_', '" .file=', ' type="checkbox"></input>\n                        <label for="sl_', '">', "</label>\n                    </div>\n                    "])), filename, filename, filename, filename);
      }));
    };
    var _a;
    AimSelectWidget1005542.styles = css(templateObject_3 || (templateObject_3 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      query(".select-grid"),
      __metadata("design:type", typeof (_a = typeof HTMLElement !== "undefined" && HTMLElement) === "function" ? _a : Object)
    ], AimSelectWidget1005542.prototype, "listcontainer", void 0);
    AimSelectWidget1005542 = __decorate([
      customElement("aim-select-widget-100554")
    ], AimSelectWidget1005542);
    return AimSelectWidget1005542;
  }(CollabLitElement)
);
var templateObject_1, templateObject_2, templateObject_3;
export {
  AimSelectWidget100554
};
