var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css, LitElement, repeat } from "lit";
import { customElement, property } from "lit/decorators.js";
function initCollabDSInputRange() {
}
;
var CollabDSInputRange = (
  /** @class */
  function(_super) {
    __extends(CollabDSInputRange2, _super);
    function CollabDSInputRange2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.arraySelect = [];
      _this.useSelect = "true";
      _this.value = "";
      _this.prop = "";
      _this.min = 0;
      _this.max = 100;
      return _this;
    }
    CollabDSInputRange2.prototype.render = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n            ", "\n            ", "\n            \n        "], ["\n            ", "\n            ", "\n            \n        "])), this.renderInput(), this.renderSelect());
    };
    CollabDSInputRange2.prototype.renderInput = function() {
      var _this = this;
      return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(['\n            <input type="range" .value="', '" min="', '" max="', '"   @input="', '"></input>\n        '], ['\n            <input type="range" .value="', '" min="', '" max="', '"   @input="', '"></input>\n        '])), this.onlyNumber(this.value), this.min, this.max, function(e) {
        return _this.changeRange(e);
      });
    };
    CollabDSInputRange2.prototype.renderSelect = function() {
      return html(templateObject_4 || (templateObject_4 = __makeTemplateObject(['\n            <div>\n                <input type="search" .value="', '" @input="', '"> </input>\n                <select @change="', '" style="', '">\n                    ', "\n                </select>\n            </div>\n        "], ['\n            <div>\n                <input type="search" .value="', '" @input="', '"> </input>\n                <select @change="', '" style="', '">\n                    ', "\n                </select>\n            </div>\n        "])), this.onlyNumber(this.value), this.changeInput, this.changeSelect, this.useSelect === "false" ? "display:none" : "", repeat(this.arraySelect, function(key) {
        return key;
      }, function(k, index) {
        return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['<option value="', '">', "</option>"], ['<option value="', '">', "</option>"])), k, k);
      }));
    };
    CollabDSInputRange2.prototype.updated = function() {
      if (!this.shadowRoot)
        return;
      var sel = this.shadowRoot.querySelector("select");
      if (!sel)
        return;
      sel.value = this.onlyTxt(this.value);
    };
    CollabDSInputRange2.prototype.onlyNumber = function(str) {
      var regexNum = /(\d+(?:\.\d+)?)/;
      var res = str.match(regexNum);
      return res && res[0] ? res[0] : "";
    };
    CollabDSInputRange2.prototype.onlyTxt = function(str) {
      var regexStr = /[a-zA-Z]+/;
      var res = str.match(regexStr);
      return res && res[0] ? res[0].replace(".", "") : "";
    };
    CollabDSInputRange2.prototype.changeRange = function(e) {
      this.allChange(e, "range");
    };
    CollabDSInputRange2.prototype.changeInput = function(e) {
      this.allChange(e, "input");
    };
    CollabDSInputRange2.prototype.changeSelect = function(e) {
      this.allChange(e, "sel");
    };
    CollabDSInputRange2.prototype.allChange = function(e, mode) {
      e.stopPropagation();
      if (!this.shadowRoot)
        return;
      var parent = this.shadowRoot;
      var input = parent.querySelector('input[type="search"]');
      var range = parent.querySelector('input[type="range"]');
      var sel = parent.querySelector("select");
      if (!input || !sel || !range)
        return;
      if (mode === "range") {
        input.value = range.value;
      } else if (mode === "input") {
        var tot = this.onlyNumber(input.value);
        var max = range.max;
        if (!max || max < tot)
          range.max = tot;
        range.value = tot;
      }
      this.value = input.value + sel.value;
      this.fireEvents({
        key: this.prop,
        value: input.value + sel.value
      });
    };
    CollabDSInputRange2.prototype.fireEvents = function(obj) {
      obj.target = this;
      var onChangePropEvento = new CustomEvent("onchange", {
        bubbles: true,
        detail: obj
      });
      this.dispatchEvent(onChangePropEvento);
    };
    CollabDSInputRange2.styles = css(templateObject_5 || (templateObject_5 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", String)
    ], CollabDSInputRange2.prototype, "useSelect", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], CollabDSInputRange2.prototype, "value", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], CollabDSInputRange2.prototype, "prop", void 0);
    CollabDSInputRange2 = __decorate([
      customElement("collab-ds-input-range-100554")
    ], CollabDSInputRange2);
    return CollabDSInputRange2;
  }(LitElement)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5;
export {
  CollabDSInputRange,
  initCollabDSInputRange
};
