var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var __asyncValues = function(o) {
  if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
  var m = o[Symbol.asyncIterator], i;
  return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
    return this;
  }, i);
  function verb(n) {
    i[n] = o[n] && function(v) {
      return new Promise(function(resolve, reject) {
        v = o[n](v), settle(resolve, reject, v.done, v.value);
      });
    };
  }
  function settle(resolve, reject, d, v) {
    Promise.resolve(v).then(function(v2) {
      resolve({ value: v2, done: d });
    }, reject);
  }
};
var __spreadArray = function(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};
import { html, css, LitElement } from "lit";
import { customElement, property, query } from "lit/decorators.js";
import { convertFileNameToTag } from "./_100554_utilsLit";
import { ServiceBase } from "./_100554_serviceBase";
import { getAttributeDefinitionsLit, getFormComponentsDescription } from "./_100554_icaBaseDescription";
var initServiceListFilesAdd = function() {
};
var message_pt = {
  labelProject: "Projeto",
  labelShortName: "Nome curto",
  labelType: "Por favor, selecione um modelo abaixo ou clique",
  btnAdd: "Adicionar",
  btnCancel: "Cancelar",
  please: "Por facor selecione um projeto primeiro!"
};
var message_en = {
  labelProject: "Project",
  labelShortName: "Shortname",
  labelType: "Please select a template below or click",
  btnAdd: "Add",
  btnCancel: "cancel",
  please: "Please select a project first!"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceListFilesAdd100554 = (
  /** @class */
  function(_super) {
    __extends(ServiceListFilesAdd1005542, _super);
    function ServiceListFilesAdd1005542() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.msg = messages["en"];
      _this.level = -1;
      _this.error = "";
      _this.position = "";
      _this.templates = [];
      _this.loading = true;
      _this.enhancementModules = {};
      return _this;
    }
    ServiceListFilesAdd1005542.prototype.connectedCallback = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              _super.prototype.connectedCallback.call(this);
              return [4, this.getTemplates()];
            case 1:
              _a2.sent();
              this.loading = false;
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceListFilesAdd1005542.prototype.render = function() {
      var _a2;
      var lang = (_a2 = this.father) === null || _a2 === void 0 ? void 0 : _a2.getMessageKey(messages);
      this.msg = lang ? messages[lang] : message_en;
      var project = mls.actual[5].project;
      return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n            ", "\n        "], ["\n            ", "\n        "])), project ? this.renderAdd(project) : html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["", ""], ["", ""])), this.msg.please));
    };
    ServiceListFilesAdd1005542.prototype.renderAdd = function(project) {
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['\n            <div class="section-add">\n                <div class="row-form">\n                    <div>\n                        <label>', ':</label>\n                        <input type="text" disabled value="', '"/>\n                    </div>\n                    <div>\n                        <label>', ':</label>\n                        <input type="text" id="iptShortName"/>\n                        <span>', '</span>\n                    </div>\n                </div>\n                <hr>\n                <div class="row-form">\n                    <div>\n                        <label>', '</label> <button class="btn-cancel" @click="', '">', "</button>\n                         ", "\n                    </div>\n                </div>\n            </div>\n\n        "], ['\n            <div class="section-add">\n                <div class="row-form">\n                    <div>\n                        <label>', ':</label>\n                        <input type="text" disabled value="', '"/>\n                    </div>\n                    <div>\n                        <label>', ':</label>\n                        <input type="text" id="iptShortName"/>\n                        <span>', '</span>\n                    </div>\n                </div>\n                <hr>\n                <div class="row-form">\n                    <div>\n                        <label>', '</label> <button class="btn-cancel" @click="', '">', "</button>\n                         ", "\n                    </div>\n                </div>\n            </div>\n\n        "])), this.msg.labelProject, project.toString(), this.msg.labelShortName, this.error, this.msg.labelType, this.clickCancel, this.msg.btnCancel, this.renderTemplates());
    };
    ServiceListFilesAdd1005542.prototype.renderTemplates = function() {
      var _this = this;
      return html(templateObject_7 || (templateObject_7 = __makeTemplateObject(['\n            <div class="template-container">\n             ', "\n            </div>\n        "], ['\n            <div class="template-container">\n             ', "\n            </div>\n        "])), this.loading ? html(templateObject_4 || (templateObject_4 = __makeTemplateObject(["<p>Loading...</p>"], ["<p>Loading...</p>"]))) : this.templates.map(function(template) {
        return html(templateObject_6 || (templateObject_6 = __makeTemplateObject(['\n                        <div  class="template-item" @click=', '>\n                            <div class="template-item-content">\n                                <div class="template-item-title">', '</div>\n                                <div class="template-item-body">\n                                    ', '\n                                </div>\n                                <div class="template-item-tags">\n                                        Tags: ', "\n                                </div>\n                            </div>\n                        </div>\n                    "], ['\n                        <div  class="template-item" @click=', '>\n                            <div class="template-item-content">\n                                <div class="template-item-title">', '</div>\n                                <div class="template-item-body">\n                                    ', '\n                                </div>\n                                <div class="template-item-tags">\n                                        Tags: ', "\n                                </div>\n                            </div>\n                        </div>\n                    "])), function() {
          _this.add(template);
        }, template.title, template.description.split("\n").map(function(paragraph) {
          return html(templateObject_5 || (templateObject_5 = __makeTemplateObject(["\n                                        <p>", "</p>\n                                    "], ["\n                                        <p>", "</p>\n                                    "])), paragraph);
        }), template.tags.join(", "));
      }));
    };
    ServiceListFilesAdd1005542.prototype.getTemplates = function() {
      return __awaiter(this, void 0, void 0, function() {
        var temp;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              return [4, this.getAllEnhacementsTemplates()];
            case 1:
              temp = _a2.sent();
              this.templates = __spreadArray([], temp, true);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceListFilesAdd1005542.prototype.clickCancel = function() {
      if (!this.father)
        return;
      this.father.mode = "list";
    };
    ServiceListFilesAdd1005542.prototype.showLoader = function(loader) {
      if (!this.father)
        return;
      this.father.loading = loader;
    };
    ServiceListFilesAdd1005542.prototype.add = function(template) {
      return __awaiter(this, void 0, void 0, function() {
        var project, name, newName, params, fEnh, ts, posInv, opInstance, e_1;
        var _this = this;
        var _a2, _b2, _c;
        return __generator(this, function(_d) {
          switch (_d.label) {
            case 0:
              _d.trys.push([0, 2, , 3]);
              if (!this.shadowRoot)
                return [
                  2
                  /*return*/
                ];
              if (!this.inputShortName)
                return [
                  2
                  /*return*/
                ];
              project = mls.actual[5].project;
              if (!project)
                throw new Error("No project selected");
              if (!this.enhancementModules)
                throw new Error("No modules enhancement loaded");
              name = this.inputShortName.value;
              newName = this.getNewNameAndValid(project, name);
              params = {};
              if (!template.enhancementKey)
                throw new Error("No enhancementKey in template");
              fEnh = this.enhancementModules[template.enhancementKey];
              if (!fEnh) {
                this.showLoader(false);
                throw new Error("No enhancement founded");
              }
              ;
              this.showLoader(true);
              ts = this.createContentNewFile(fEnh, template.example, name, project);
              params.action = "new";
              params.level = +this.level;
              params.project = mls.actual[5].project;
              params.newProject = mls.actual[5].project;
              params.shortName = newName;
              params.newshortName = newName;
              params.folder = "";
              params.newfolder = "";
              params.newEnhancement = fEnh ? "_".concat(fEnh.storFile.project, "_").concat(fEnh.storFile.shortName) : "_blank";
              params.extension = ".ts";
              params.newTSSource = ts;
              mls.actual[this.level].setFullName("_" + params.project + "_" + params.shortName);
              mls.actual[this.level][this.position] = {
                project: params.project,
                shortName: params.shortName
              };
              return [4, this.fireComunication(params)];
            case 1:
              _d.sent();
              posInv = this.position === "left" ? "right" : "left";
              if (template.aimActionSuggest) {
                (_a2 = this.father) === null || _a2 === void 0 ? void 0 : _a2.openService("_100554_serviceAim", posInv, 2);
                opInstance = (_c = (_b2 = this.father) === null || _b2 === void 0 ? void 0 : _b2.nav3Service) === null || _c === void 0 ? void 0 : _c.getActiveInstance(posInv);
                if (opInstance) {
                  opInstance.setAttribute("actiontoopen", template.aimActionSuggest);
                }
              }
              this.showLoader(false);
              this.saveLocalHistory(params.project, params.shortName, params.extension, params.folder);
              return [3, 3];
            case 2:
              e_1 = _d.sent();
              setTimeout(function() {
                _this.showLoader(false);
                _this.error = e_1.message;
              }, 200);
              return [3, 3];
            case 3:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceListFilesAdd1005542.prototype.createContentNewFile = function(enhecementModule, template, name, project) {
      var ret = "";
      var grp = "other";
      var newExample = "";
      newExample = this.checkIfAsIcaAndCreateIfNeeded(name, project);
      if (!newExample) {
        newExample = template;
        newExample = this.changeTagName(newExample, convertFileNameToTag("_".concat(project, "_").concat(name)));
        newExample = this.changeClassName(newExample, project, name);
        newExample = this.changeWidget(newExample, project, name);
      }
      ret = '/// <mls shortName="'.concat(name, '" project="').concat(project, '" enhancement="_').concat(enhecementModule.storFile.project, "_").concat(enhecementModule.storFile.shortName, '" groupName="').concat(grp, '" />\n').concat(newExample, "\n");
      return ret;
    };
    ServiceListFilesAdd1005542.prototype.checkIfAsIcaAndCreateIfNeeded = function(name, project) {
      var _this = this;
      if (project !== 100554)
        return "";
      if (!name.startsWith("ica"))
        return "";
      if (!name.endsWith("Base"))
        return "";
      var parts = this.splitStringByUppercase(name.substring(0, name.length - 4));
      if (parts.length < 4)
        return "";
      parts = parts.map(function(part) {
        return _this.capitalizeFirstLetter(part);
      });
      var ica, root, subgroup, finalgroup = "";
      ica = parts.shift();
      root = parts.shift();
      subgroup = parts.shift();
      finalgroup = parts.join(" ");
      var desc = getFormComponentsDescription(root, subgroup, finalgroup);
      if (!desc)
        return "";
      return this.createTemplateIca(root, subgroup, finalgroup);
    };
    ServiceListFilesAdd1005542.prototype.splitStringByUppercase = function(str) {
      return str.split(/(?=[A-Z])/);
    };
    ServiceListFilesAdd1005542.prototype.capitalizeFirstLetter = function(str) {
      return str.charAt(0).toUpperCase() + str.slice(1);
    };
    ServiceListFilesAdd1005542.prototype.createTemplateIca = function(root, subgroup, finalgroup) {
      var props = getAttributeDefinitionsLit(root, subgroup, finalgroup);
      var res = props.map(function(line) {
        var cleanedLine = line.replace(/@property\(\{.*\}\)\s*/, "");
        cleanedLine = cleanedLine.replace(/=.+?;/, ";");
        cleanedLine = "abstract " + cleanedLine;
        return cleanedLine;
      });
      var fg = finalgroup.replace(/\s/g, "");
      var className = "Ica".concat(root).concat(subgroup).concat(fg, "Base");
      var extend = "IcaLitElement";
      var extendFile = "./_100554_icaLitElement";
      var interfaces = /* @__PURE__ */ new Map();
      res.forEach(function(str, index) {
        var matches = str.match(/abstract (\w+): ('.*?'(?: \| '.*?')*)/);
        if (matches && matches.length >= 3) {
          var propName = matches[1];
          var types = matches[2].match(/'[^']+'/g);
          if (types && types.length > 1) {
            var interfaceName = "I".concat(propName.charAt(0).toUpperCase() + propName.slice(1));
            interfaces.set(interfaceName, types);
            res[index] = "abstract ".concat(propName, ": ").concat(interfaceName, " | undefined; // ").concat(matches.input);
          }
        }
      });
      var interfaceString = "";
      interfaces.forEach(function(types, interfaceName) {
        interfaceString += "export type ".concat(interfaceName, " = ").concat(types.join(" | "), ";\n");
      });
      var temp = "\nimport { ".concat(extend, " } from '").concat(extendFile, "';\n\nexport abstract class ").concat(className, " extends ").concat(extend, " {\n    \n    ").concat(res.join("\n	"), "\n\n}\n\n").concat([interfaceString].join("\n"), "\n");
      return temp;
    };
    ServiceListFilesAdd1005542.prototype.saveLocalHistory = function(project, shortName, extension, folder) {
      var info = localStorage.getItem("mlsInfoHistoryL" + this.level);
      var res = info ? JSON.parse(info) : [];
      var idx = -1;
      res.forEach(function(i, index) {
        if (i.project !== project || i.shortName !== shortName)
          return;
        idx = index;
      });
      if (idx >= 0)
        res.splice(idx, 1);
      res.unshift({ project, shortName, extension, folder });
      if (res.length > 10)
        res.length = 10;
      localStorage.setItem("mlsInfoHistoryL" + this.level, JSON.stringify(res));
    };
    ServiceListFilesAdd1005542.prototype.getNewNameAndValid = function(prj, name) {
      if (name === "" || !name || name === null)
        throw new Error("Invalid name ");
      var isValidName = this.isValidNewName({
        shortName: name,
        project: prj,
        level: +this.level,
        folder: "",
        extension: ".ts"
      });
      if (!isValidName)
        throw new Error("Invalid name ");
      return name;
    };
    ServiceListFilesAdd1005542.prototype.isValidNewName = function(obj) {
      if (obj.shortName === "")
        return false;
      if (obj.shortName.length === 0 || obj.shortName.length > 255)
        return false;
      var invalidCharacters = /[_\/{}\[\]\*$@#=\-+!|?,<>=.;^~��""''``�������������������������������]/;
      if (invalidCharacters.test(obj.shortName))
        return false;
      var key = mls.stor.getKeyToFiles(obj.project, obj.level, obj.shortName, obj.folder, obj.extension);
      var find = false;
      var keys = Object.keys(mls.stor.files);
      for (var _i = 0, keys_1 = keys; _i < keys_1.length; _i++) {
        var k = keys_1[_i];
        if (key.toLocaleLowerCase() === k.toLocaleLowerCase())
          find = true;
      }
      return !mls.stor.files[key] && !find;
    };
    ServiceListFilesAdd1005542.prototype.changeClassName = function(source, project, shortname) {
      var newClassName = shortname.charAt(0).toUpperCase() + shortname.substring(1, shortname.length) + project.toString();
      var outputString = source.replace(/\[className\]/g, newClassName);
      return outputString;
    };
    ServiceListFilesAdd1005542.prototype.changeWidget = function(source, project, shortname) {
      var newWidget = "_".concat(project.toString(), "_").concat(shortname);
      var outputString = source.replace(/\[widgetName\]/g, newWidget);
      return outputString;
    };
    ServiceListFilesAdd1005542.prototype.changeTagName = function(source, tagName) {
      var outputString = source.replace(/\[tagName\]/g, tagName);
      return outputString;
    };
    ServiceListFilesAdd1005542.prototype.getEnhacementsDetails = function() {
      var _this = this;
      var array = [];
      var keys = Object.keys(mls.stor.files);
      keys.forEach(function(i) {
        var f = mls.stor.files[i];
        if (f.level !== +_this.level || !f.shortName.startsWith("enhancement") || f.extension !== ".ts")
          return;
        var opt = {
          key: "".concat(f.project, "_").concat(f.shortName),
          value: i
        };
        array.push(opt);
      });
      mls.l2.enhancement.getEnhancementDetails;
      return __spreadArray([], array, true);
    };
    ServiceListFilesAdd1005542.prototype.getAllEnhacementsTemplates = function() {
      return __awaiter(this, void 0, void 0, function() {
        var templates, enhancementDetails, _a2;
        return __generator(this, function(_b2) {
          switch (_b2.label) {
            case 0:
              templates = [];
              enhancementDetails = this.getEnhacementsDetails();
              _a2 = this;
              return [4, this.getEnhacementsInstancies(enhancementDetails)];
            case 1:
              _a2.enhancementModules = _b2.sent();
              if (!this.enhancementModules)
                return [2, templates];
              Object.entries(this.enhancementModules).map(function(entry) {
                var entryKey = entry[0], entryValue = entry[1];
                if (!entryValue.instance.getAddNewFileDetails)
                  return;
                var temp = entryValue.instance.getAddNewFileDetails();
                temp.forEach(function(t) {
                  return t.enhancementKey = entryKey;
                });
                templates = __spreadArray(__spreadArray([], templates, true), temp, true);
              });
              return [2, templates];
          }
        });
      });
    };
    ServiceListFilesAdd1005542.prototype.getEnhacementsInstancies = function(enhancementDetails) {
      return __awaiter(this, void 0, void 0, function() {
        var enhancementModules, details, value, key, storFile, project, shortName, mfile, enhancementModule, e_2_1;
        var _a2, enhancementDetails_1, enhancementDetails_1_1;
        var _b2, e_2, _c, _d;
        return __generator(this, function(_e) {
          switch (_e.label) {
            case 0:
              enhancementModules = {};
              _e.label = 1;
            case 1:
              _e.trys.push([1, 12, 13, 18]);
              _a2 = true, enhancementDetails_1 = __asyncValues(enhancementDetails);
              _e.label = 2;
            case 2:
              return [4, enhancementDetails_1.next()];
            case 3:
              if (!(enhancementDetails_1_1 = _e.sent(), _b2 = enhancementDetails_1_1.done, !_b2)) return [3, 11];
              _d = enhancementDetails_1_1.value;
              _a2 = false;
              details = _d;
              value = details.value, key = details.key;
              storFile = mls.stor.files[value];
              if (!storFile)
                return [
                  2
                  /*return*/
                ];
              project = storFile.project, shortName = storFile.shortName;
              mfile = mls.l2.editor.get({ project, shortName });
              if (!!mfile) return [3, 5];
              return [4, this.loadMyMFiles(value, project)];
            case 4:
              _e.sent();
              _e.label = 5;
            case 5:
              if (!mfile)
                throw new Error("Error on load mfile");
              return [4, mls.l2.enhancement.getEnhancementModule(mfile)];
            case 6:
              enhancementModule = _e.sent();
              if (!!enhancementModule) return [3, 9];
              return [4, this.loadMyMFiles(value, project)];
            case 7:
              _e.sent();
              return [4, mls.l2.enhancement.getEnhancementModule(mfile)];
            case 8:
              enhancementModule = _e.sent();
              _e.label = 9;
            case 9:
              ;
              if (!enhancementModule)
                throw new Error("Error on load enhancementModule");
              enhancementModules[key] = {
                instance: enhancementModule,
                storFile
              };
              _e.label = 10;
            case 10:
              _a2 = true;
              return [3, 2];
            case 11:
              return [3, 18];
            case 12:
              e_2_1 = _e.sent();
              e_2 = { error: e_2_1 };
              return [3, 18];
            case 13:
              _e.trys.push([13, , 16, 17]);
              if (!(!_a2 && !_b2 && (_c = enhancementDetails_1.return))) return [3, 15];
              return [4, _c.call(enhancementDetails_1)];
            case 14:
              _e.sent();
              _e.label = 15;
            case 15:
              return [3, 17];
            case 16:
              if (e_2) throw e_2.error;
              return [
                7
                /*endfinally*/
              ];
            case 17:
              return [
                7
                /*endfinally*/
              ];
            case 18:
              return [2, enhancementModules];
          }
        });
      });
    };
    ServiceListFilesAdd1005542.prototype.fireComunication = function(obj) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              obj.position = this.position;
              return [4, mls.events.fire([+this.level], ["FileAction"], JSON.stringify(obj), 0)];
            case 1:
              _a2.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceListFilesAdd1005542.prototype.loadMyMFiles = function(key, project) {
      return __awaiter(this, void 0, void 0, function() {
        var params, fEnh;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              params = {};
              fEnh = mls.stor.files[key];
              if (!fEnh)
                return [
                  2
                  /*return*/
                ];
              params.action = "preLoadProject";
              params.level = +this.level;
              params.project = project;
              params.newProject = project;
              return [4, this.fireComunication(params)];
            case 1:
              _a2.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    var _a, _b;
    ServiceListFilesAdd1005542.styles = css(templateObject_8 || (templateObject_8 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", Number)
    ], ServiceListFilesAdd1005542.prototype, "level", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceListFilesAdd1005542.prototype, "error", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceListFilesAdd1005542.prototype, "position", void 0);
    __decorate([
      property(),
      __metadata("design:type", typeof (_a = typeof ServiceBase !== "undefined" && ServiceBase) === "function" ? _a : Object)
    ], ServiceListFilesAdd1005542.prototype, "father", void 0);
    __decorate([
      property(),
      __metadata("design:type", Array)
    ], ServiceListFilesAdd1005542.prototype, "templates", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Boolean)
    ], ServiceListFilesAdd1005542.prototype, "loading", void 0);
    __decorate([
      query("#iptShortName"),
      __metadata("design:type", typeof (_b = typeof HTMLInputElement !== "undefined" && HTMLInputElement) === "function" ? _b : Object)
    ], ServiceListFilesAdd1005542.prototype, "inputShortName", void 0);
    ServiceListFilesAdd1005542 = __decorate([
      customElement("service-list-files-add-100554")
    ], ServiceListFilesAdd1005542);
    return ServiceListFilesAdd1005542;
  }(LitElement)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6, templateObject_7, templateObject_8;
export {
  ServiceListFilesAdd100554,
  initServiceListFilesAdd
};
