var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __assign = function() {
  __assign = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
        t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html } from "lit";
import { customElement, property } from "lit/decorators.js";
import { tasks } from "./_100554_aimHelper";
import { AimBase } from "./_100554_aimBase";
var AimTaskBase = (
  /** @class */
  function(_super) {
    __extends(AimTaskBase2, _super);
    function AimTaskBase2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.childIndex = -1;
      _this.taskRoot = {
        mode: "error",
        title: "invalid task index: " + _this.taskIndex,
        widget: "",
        children: [],
        trace: ["invalid task index on AimTaskBase"]
      };
      _this.taskChild = {
        mode: "error",
        title: "invalid child index: " + _this.childIndex,
        widget: "",
        trace: ["invalid child index on AimTaskBase"]
      };
      return _this;
    }
    AimTaskBase2.prototype.createRenderRoot = function() {
      return this;
    };
    AimTaskBase2.prototype.render = function() {
      return this.renderTaskStatus();
    };
    AimTaskBase2.prototype.renderTaskStatus = function() {
      var _a;
      this.initTaskRootAndTaskChild();
      if (this.mode === "initializing" && this.taskChild.mode === "initializing") {
        this.onInitializing();
      }
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n      <details>\n        <summary> ", " ", "</summary>\n          ", "\n      </details>\n    "], ["\n      <details>\n        <summary> ", " ", "</summary>\n          ", "\n      </details>\n    "])), this.renderToolbar(), (_a = this.taskChild) === null || _a === void 0 ? void 0 : _a.title, this.renderBody(this.taskRoot, this.taskChild));
    };
    AimTaskBase2.prototype.initTaskRootAndTaskChild = function() {
      if (this.taskIndex < 0 || this.taskIndex >= tasks.length) {
        this.taskRoot = {
          mode: "error",
          title: "invalid task index: " + this.taskIndex,
          widget: "",
          children: [],
          trace: ["invalid task index on AimTaskBase"]
        };
      } else {
        this.taskRoot = tasks[this.taskIndex];
        if (this.childIndex < 0 || this.childIndex >= this.taskRoot.children.length) {
          this.taskRoot.mode = "error";
          this.taskChild = {
            mode: "error",
            title: "invalid child index: " + this.childIndex,
            widget: "",
            trace: ["invalid child index on AimTaskBase, taskRoot.length=" + this.taskRoot.children.length]
          };
        } else {
          this.taskChild = this.taskRoot.children[this.childIndex];
        }
      }
    };
    AimTaskBase2.prototype.renderBody = function(taskRoot, child) {
      var _a;
      var promptTitle = "prompt len=".concat((_a = child.prompt) === null || _a === void 0 ? void 0 : _a.length, ", tokens=").concat(child.promptTokens);
      var resultTitle = "no result yeat";
      if (child.result)
        resultTitle = "result len=".concat(child.result.length, ", tokens=").concat(child.resultTokens);
      return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n            ", "\n            ", "\n            ", "\n        "], ["\n            ", "\n            ", "\n            ", "\n        "])), child.prompt ? this.renderDetails(promptTitle, child.prompt) : "", child.result ? this.renderDetails(resultTitle, child.result) : "", child ? this.renderTraceList("trace", child) : "");
    };
    AimTaskBase2.prototype.renderDetails = function(title, body) {
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(["\n      <details>\n        <summary>", '</summary>\n        <pre style="white-space: break-spaces;">', "</pre> \n      </details>\n    "], ["\n      <details>\n        <summary>", '</summary>\n        <pre style="white-space: break-spaces;">', "</pre> \n      </details>\n    "])), title, body);
    };
    AimTaskBase2.prototype.renderTraceList = function(title, child) {
      var _this = this;
      var traceString = JSON.stringify(child, null, 2);
      var root = __assign({}, this.taskRoot);
      root.children = [];
      var traceRootString = JSON.stringify(root, null, 2);
      return html(templateObject_5 || (templateObject_5 = __makeTemplateObject(["\n      <details>\n        <summary>", "</summary>\n        <ul>\n          ", "\n        </ul>\n        <p>Trace Object:</p>\n        <pre>", "</pre>\n        <p>Trace root Object:</p>\n        <pre>", "</pre>\n      </details>\n    "], ["\n      <details>\n        <summary>", "</summary>\n        <ul>\n          ", "\n        </ul>\n        <p>Trace Object:</p>\n        <pre>", "</pre>\n        <p>Trace root Object:</p>\n        <pre>", "</pre>\n      </details>\n    "])), title, child.trace.map(function(item) {
        return html(templateObject_4 || (templateObject_4 = __makeTemplateObject(["<li>", "</li>"], ["<li>", "</li>"])), _this.locateDateTimeInTrace(item));
      }), traceString, traceRootString);
    };
    AimTaskBase2.prototype.locateDateTimeInTrace = function(line) {
      var _a = line.split("Z:"), isoDatePart = _a[0], descriptionParts = _a.slice(1);
      var description = descriptionParts.join("Z:");
      try {
        var date = new Date("".concat(isoDatePart, "Z"));
        if (isNaN(date.getTime()))
          return description;
        var localDate = date.toLocaleString();
        return "".concat(localDate, ": ").concat(description);
      } catch (error) {
        console.error(isoDatePart, error);
        return line;
      }
    };
    AimTaskBase2.prototype.sendFinishedNotification = function(detail) {
      this.dispatchEvent(new CustomEvent("task-finished", {
        detail,
        bubbles: true,
        composed: true
      }));
    };
    AimTaskBase2.prototype.notifyCompleteByStatus = function(status, result, prompt) {
      this.sendFinishedNotification({
        status,
        result,
        newPrompt: prompt,
        taskIndex: this.taskIndex,
        childIndex: this.childIndex,
        taskRoot: this.taskRoot,
        taskChild: this.taskChild
      });
    };
    __decorate([
      property({ type: Number }),
      __metadata("design:type", Object)
    ], AimTaskBase2.prototype, "childIndex", void 0);
    AimTaskBase2 = __decorate([
      customElement("aim-task-base-100554")
    ], AimTaskBase2);
    return AimTaskBase2;
  }(AimBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5;
export {
  AimTaskBase
};
