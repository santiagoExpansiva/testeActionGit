var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var _a, _b, _c, _d;
var _e, _f;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { ReactiveElement } from "_100554_litReactiveElement";
import { render, noChange } from "_100554_litHtml";
export * from "_100554_litReactiveElement";
export * from "_100554_litHtml";
export * from "_100554_litClassMap";
export * from "_100554_litIfDefined";
export * from "_100554_litLive";
export * from "_100554_litStyleMap";
export * from "_100554_litDirectivesHelper";
export * from "_100554_litWhen";
var repeat = function(array, func, func2) {
  if (func === void 0) {
    func = function() {
    };
  }
  if (func2 === void 0) {
    func2 = function() {
    };
  }
  console.info(array, func, func2);
};
var UpdatingElement = ReactiveElement;
var DEV_MODE = true;
var issueWarning;
if (DEV_MODE) {
  var issuedWarnings_1 = (_a = (_e = globalThis).litIssuedWarnings) !== null && _a !== void 0 ? _a : _e.litIssuedWarnings = /* @__PURE__ */ new Set();
  issueWarning = function(code, warning) {
    warning += " See https://lit.dev/msg/".concat(code, " for more information.");
    if (!issuedWarnings_1.has(warning)) {
      console.warn(warning);
      issuedWarnings_1.add(warning);
    }
  };
}
var LitElement = (
  /** @class */
  function(_super) {
    __extends(LitElement2, _super);
    function LitElement2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.renderOptions = { host: _this };
      _this.__childPart = void 0;
      return _this;
    }
    LitElement2.prototype.createRenderRoot = function() {
      var _a2;
      var _b2;
      var renderRoot = _super.prototype.createRenderRoot.call(this);
      (_a2 = (_b2 = this.renderOptions).renderBefore) !== null && _a2 !== void 0 ? _a2 : _b2.renderBefore = renderRoot.firstChild;
      return renderRoot;
    };
    LitElement2.prototype.update = function(changedProperties) {
      var value = this.render();
      if (!this.hasUpdated) {
        this.renderOptions.isConnected = this.isConnected;
      }
      _super.prototype.update.call(this, changedProperties);
      this.__childPart = render(value, this.renderRoot, this.renderOptions);
    };
    LitElement2.prototype.connectedCallback = function() {
      var _a2;
      _super.prototype.connectedCallback.call(this);
      (_a2 = this.__childPart) === null || _a2 === void 0 ? void 0 : _a2.setConnected(true);
    };
    LitElement2.prototype.disconnectedCallback = function() {
      var _a2;
      _super.prototype.disconnectedCallback.call(this);
      (_a2 = this.__childPart) === null || _a2 === void 0 ? void 0 : _a2.setConnected(false);
    };
    LitElement2.prototype.render = function() {
      return noChange;
    };
    LitElement2["finalized"] = true;
    LitElement2["_$litElement$"] = true;
    return LitElement2;
  }(ReactiveElement)
);
(_c = (_b = globalThis).litElementHydrateSupport) === null || _c === void 0 ? void 0 : _c.call(_b, { LitElement });
var polyfillSupport = DEV_MODE ? globalThis.litElementPolyfillSupportDevMode : globalThis.litElementPolyfillSupport;
polyfillSupport === null || polyfillSupport === void 0 ? void 0 : polyfillSupport({ LitElement });
if (DEV_MODE) {
  LitElement["finalize"] = function() {
    var finalized = ReactiveElement.finalize.call(this);
    if (!finalized) {
      return false;
    }
    var warnRemovedOrRenamed = function(obj, name, renamed) {
      if (renamed === void 0) {
        renamed = false;
      }
      if (obj.hasOwnProperty(name)) {
        var ctorName = (typeof obj === "function" ? obj : obj.constructor).name;
        issueWarning(renamed ? "renamed-api" : "removed-api", "`".concat(name, "` is implemented on class ").concat(ctorName, ". It ") + "has been ".concat(renamed ? "renamed" : "removed", " ") + "in this version of LitElement.");
      }
    };
    warnRemovedOrRenamed(this, "render");
    warnRemovedOrRenamed(this, "getStyles", true);
    warnRemovedOrRenamed(this.prototype, "adoptStyles");
    return true;
  };
}
var _$LE = {
  _$attributeToProperty: function(el, name, value) {
    el._$attributeToProperty(name, value);
  },
  // eslint-disable-next-line
  _$changedProperties: function(el) {
    return el._$changedProperties;
  }
};
((_d = (_f = globalThis).litElementVersions) !== null && _d !== void 0 ? _d : _f.litElementVersions = []).push("3.3.2");
if (DEV_MODE && globalThis.litElementVersions.length > 1) {
  issueWarning("multiple-versions", "Multiple versions of Lit loaded. Loading multiple versions is not recommended.");
}
export {
  LitElement,
  UpdatingElement,
  _$LE,
  repeat
};
