var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { html } from "lit";
import { customElement, property, query } from "lit/decorators.js";
import { AimTaskBase } from "./_100554_aimTaskBase";
import { initCollabShowCodeDiff100554, CollabShowCodeDiff } from "./_100554_collabShowCodeDiff";
import { getActiveOpServiceIfIsValid } from "./_100554_aimActionAddIca";
var message_pt = {
  title_result: "Ver typescript resultado",
  tryagain_title_1: "M\uFFFDtodos para implementar",
  tryagain_title_2: "Por favor digite as mudan\uFFFDas necess\uFFFDrias abaixo.",
  tryagain_placeholder: "Digite aqui seu prompt.",
  accept_answer: "Deseja gerar o .HTML para o componente ?",
  btn_confirmar: "Confirmar",
  btn_cancelar: "Cancelar",
  btn_yes: "Sim",
  btn_no: "N\uFFFDo"
};
var message_en = {
  title_result: "View TypeScript Result",
  tryagain_title_1: "Methods to implement",
  tryagain_title_2: "Please type the necessary changes below.",
  tryagain_placeholder: "Type your prompt here.",
  accept_answer: "Do you want to generate the .HTML for the component?",
  btn_confirmar: "Confirm",
  btn_cancelar: "Cancel",
  btn_yes: "Yes",
  btn_no: "No"
};
var messages = {
  "en-us": message_en,
  "pt-br": message_pt
};
var AimTaskResulAddIca = (
  /** @class */
  function(_super) {
    __extends(AimTaskResulAddIca2, _super);
    function AimTaskResulAddIca2() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en-us"];
      _this.withDiff = false;
      _this.isTryAgain = false;
      _this.isAccept = false;
      _this.result = "";
      _this.alreadyInit = false;
      initCollabShowCodeDiff100554();
      return _this;
    }
    AimTaskResulAddIca2.prototype.onInitializing = function() {
      if (this.taskChild.mode !== "error" && this.taskChild.mode !== "processed") {
        this.modeInternal = this.taskRoot.mode = this.taskChild.mode = "waiting for user";
      }
      this.openMe();
    };
    AimTaskResulAddIca2.prototype.setValues = function() {
      return __awaiter(this, void 0, void 0, function() {
        var activeOpService, value;
        return __generator(this, function(_a2) {
          if (!this.codeDiff)
            return [
              2
              /*return*/
            ];
          this.codeDiff.actualTextResult = this.result.trim();
          this.codeDiff.actualTextDiffModified = this.result.trim();
          activeOpService = getActiveOpServiceIfIsValid(this);
          if (!activeOpService)
            return [
              2
              /*return*/
            ];
          this.withDiff = false;
          if (this.withDiff)
            this.codeDiff.setAttribute("withdiff", "true");
          if (this.modeInternal === "waiting for user") {
            this.codeDiff.setAttribute("withaccept", "true");
            this.codeDiff.setAttribute("withreject", "true");
            this.codeDiff.setAttribute("withtryagain", "true");
          }
          value = activeOpService.getEditorValue();
          this.codeDiff.actualTextDiffOriginal = value.trim();
          return [
            2
            /*return*/
          ];
        });
      });
    };
    AimTaskResulAddIca2.prototype.handleClick = function(e) {
      var _a2;
      this.setValues();
      if (this.alreadyInit)
        return;
      (_a2 = this.codeDiff) === null || _a2 === void 0 ? void 0 : _a2.init();
      this.alreadyInit = true;
    };
    AimTaskResulAddIca2.prototype.renderBody = function(taskRoot, child) {
      var body = child.result || "";
      var _a2 = this.extractBlocks(body), contentTS = _a2.contentTS, contentsAfterTS = _a2.contentsAfterTS, contentsBeforeTS = _a2.contentsBeforeTS;
      this.result = contentTS;
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n        <details @click=", ">\n            <summary>", "</summary>\n            <div style=", ">\n                <div>", `</div>
                <div style='margin: 10px;'>
                    <collab-show-code-diff-100554
                        language="typescript"
                        .onAccept=`, "\n                        .onTryAgain=", "\n                        .onReject=", "      \n                    ></collab-show-code-diff-100554>\n                </div> \n                <div>", "</div>\n            </div>\n            ", "\n            ", "\n\n\n        </details>\n        "], ["\n        <details @click=", ">\n            <summary>", "</summary>\n            <div style=", ">\n                <div>", `</div>
                <div style='margin: 10px;'>
                    <collab-show-code-diff-100554
                        language="typescript"
                        .onAccept=`, "\n                        .onTryAgain=", "\n                        .onReject=", "      \n                    ></collab-show-code-diff-100554>\n                </div> \n                <div>", "</div>\n            </div>\n            ", "\n            ", "\n\n\n        </details>\n        "])), this.handleClick, this.msg.title_result, !this.isTryAgain && !this.isAccept ? "display: block" : "display:none", contentsBeforeTS, this.onAccept.bind(this), this.onTryAgain.bind(this), this.onReject.bind(this), contentsAfterTS, this.isAccept ? this.renderAccept() : "", this.isTryAgain ? this.renderTryAgain() : "");
    };
    AimTaskResulAddIca2.prototype.renderAccept = function() {
      return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n            <div>\n                <div>\n                    <div>", `</div>
                    <div style='margin: 10px;'>
                        <div class="buttonGroup">
                            <button @click="`, '">', '</button>\n                            <button @click="', '">', "</button>\n                        </div>\n                    </div> \n                </div> \n            </div>\n        "], ["\n            <div>\n                <div>\n                    <div>", `</div>
                    <div style='margin: 10px;'>
                        <div class="buttonGroup">
                            <button @click="`, '">', '</button>\n                            <button @click="', '">', "</button>\n                        </div>\n                    </div> \n                </div> \n            </div>\n        "])), this.msg.accept_answer, this.handleCancelAcceptHTML, this.msg.btn_no, this.handleConfirmAcceptHTML, this.msg.btn_yes);
    };
    AimTaskResulAddIca2.prototype.renderTryAgain = function() {
      var _this = this;
      var methodsToImplements = this.getFcToImplements(this.result);
      return html(templateObject_4 || (templateObject_4 = __makeTemplateObject(["\n            <div>\n                <div>\n                    <label>", '</label>\n                    <div class="prompt-suggestion">\n                        ', "\n                    </div>\n                    <div>", `</div>
                    <div style='margin: 10px;'>
                        <div>
                            <label>Prompt:</label>
                            <textarea rows="5" placeholder=`, ' style="width:100%"></textarea>\n                        </div>\n                        <br>\n                        <div class="buttonGroup">\n                            <button @click="', '">', '</button>\n                            <button @click="', '">', "</button>\n                        </div>\n                    </div> \n                </div> \n            </div>\n            "], ["\n            <div>\n                <div>\n                    <label>", '</label>\n                    <div class="prompt-suggestion">\n                        ', "\n                    </div>\n                    <div>", `</div>
                    <div style='margin: 10px;'>
                        <div>
                            <label>Prompt:</label>
                            <textarea rows="5" placeholder=`, ' style="width:100%"></textarea>\n                        </div>\n                        <br>\n                        <div class="buttonGroup">\n                            <button @click="', '">', '</button>\n                            <button @click="', '">', "</button>\n                        </div>\n                    </div> \n                </div> \n            </div>\n            "])), this.msg.tryagain_title_1, methodsToImplements.map(function(prompt) {
        return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(["\n                            <span @click=", ">\n                                <span >", "</span>\n                            </span>\n                        "], ["\n                            <span @click=", ">\n                                <span >", "</span>\n                            </span>\n                        "])), _this.onSuggestClick, prompt);
      }), this.msg.tryagain_title_2, this.msg.tryagain_placeholder, this.handleCancelTryAgain, this.msg.btn_cancelar, this.handleConfirmTryAgain, this.msg.btn_confirmar);
    };
    AimTaskResulAddIca2.prototype.onSuggestClick = function(e) {
      if (!this.textarea)
        return;
      var text = "";
      var target = e.target;
      var txtEl = target.querySelector("span");
      if (!txtEl)
        text = target.innerText;
      else
        text = txtEl.innerText;
      this.textarea.value = "implement  " + text;
    };
    AimTaskResulAddIca2.prototype.getFcToImplements = function(result) {
      var lines = result.split("\n");
      var methods = [];
      for (var i = 0; i <= lines.length; i++) {
        var line = lines[i];
        if (!line)
          continue;
        if (line.includes("**implement_here**")) {
          var previLine = i - 1;
          if (i < 0)
            continue;
          var fcLine = lines[previLine];
          var regex = /^\s*(\w+)\s*\(/;
          var regex2 = /(?:private\s+)?(\b\w+\b)\s*\(/g;
          var match = regex.exec(fcLine);
          var fcName = match ? match[1] : null;
          if (!fcName) {
            var match2 = regex2.exec(fcLine);
            fcName = match2 ? match2[1] : null;
          }
          if (fcName)
            methods.push(fcName);
        }
      }
      ;
      return methods;
    };
    AimTaskResulAddIca2.prototype.closeMe = function() {
      var det = this.querySelector("details");
      if (det)
        det.open = false;
    };
    AimTaskResulAddIca2.prototype.openMe = function() {
      var det = this.closest("details");
      if (det)
        det.open = true;
    };
    AimTaskResulAddIca2.prototype.handleCancelTryAgain = function() {
      this.isTryAgain = false;
    };
    AimTaskResulAddIca2.prototype.handleConfirmTryAgain = function() {
      var prompt = "";
      if (this.textarea)
        prompt = this.textarea.value;
      this.isTryAgain = false;
      this.notifyCompleteByStatus("userEvent", this.result, prompt);
      this.closeMe();
    };
    AimTaskResulAddIca2.prototype.handleCancelAcceptHTML = function() {
      this.notifyCompleteByStatus("ok", this.result);
      this.modeInternal = "processed";
      this.isAccept = false;
      this.closeMe();
    };
    AimTaskResulAddIca2.prototype.handleConfirmAcceptHTML = function() {
      this.isAccept = false;
      this.notifyCompleteByStatus("userEvent", this.result, "[html]");
    };
    AimTaskResulAddIca2.prototype.onAccept = function() {
      if (this.detailsResult)
        this.detailsResult.open = false;
      this.isAccept = true;
    };
    AimTaskResulAddIca2.prototype.onReject = function() {
      this.notifyCompleteByStatus("rejected", "");
      this.modeInternal = "processed";
      this.closeMe();
    };
    AimTaskResulAddIca2.prototype.onTryAgain = function(e) {
      if (this.detailsResult)
        this.detailsResult.open = false;
      this.isTryAgain = true;
    };
    AimTaskResulAddIca2.prototype.extractBlocks = function(src) {
      var regex = new RegExp("^(.*?)```typescript(.*)```(.*)", "s");
      var matches = src.match(regex);
      var contentTS = "";
      var contentsBeforeTS = "";
      var contentsAfterTS = "";
      if (matches) {
        contentsBeforeTS = matches[1] || "";
        contentTS = matches[2] || "";
        contentsAfterTS = matches[3] || "";
      }
      return { contentTS, contentsAfterTS, contentsBeforeTS };
    };
    var _a, _b, _c, _d;
    __decorate([
      query("collab-show-code-diff-100554"),
      __metadata("design:type", typeof (_a = typeof CollabShowCodeDiff !== "undefined" && CollabShowCodeDiff) === "function" ? _a : Object)
    ], AimTaskResulAddIca2.prototype, "codeDiff", void 0);
    __decorate([
      query("#details_result"),
      __metadata("design:type", typeof (_b = typeof HTMLDetailsElement !== "undefined" && HTMLDetailsElement) === "function" ? _b : Object)
    ], AimTaskResulAddIca2.prototype, "detailsResult", void 0);
    __decorate([
      query("textarea"),
      __metadata("design:type", typeof (_c = typeof HTMLTextAreaElement !== "undefined" && HTMLTextAreaElement) === "function" ? _c : Object)
    ], AimTaskResulAddIca2.prototype, "textarea", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Object)
    ], AimTaskResulAddIca2.prototype, "withDiff", void 0);
    __decorate([
      property({ type: Boolean, reflect: true }),
      __metadata("design:type", Object)
    ], AimTaskResulAddIca2.prototype, "isTryAgain", void 0);
    __decorate([
      property({ type: Boolean, reflect: true }),
      __metadata("design:type", Object)
    ], AimTaskResulAddIca2.prototype, "isAccept", void 0);
    __decorate([
      property({ type: String, reflect: true }),
      __metadata("design:type", typeof (_d = typeof cbe !== "undefined" && cbe.IMode) === "function" ? _d : Object)
    ], AimTaskResulAddIca2.prototype, "modeInternal", void 0);
    AimTaskResulAddIca2 = __decorate([
      customElement("aim-task-result-add-ica-100554"),
      __metadata("design:paramtypes", [])
    ], AimTaskResulAddIca2);
    return AimTaskResulAddIca2;
  }(AimTaskBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4;
export {
  AimTaskResulAddIca
};
