var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css, repeat } from "lit";
import { customElement, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
var message_pt = {
  gallery: "Galeria",
  background: "Background",
  angle: "Anglo",
  color: "Cor",
  transparency: "Transparencia",
  stop: "Parar",
  add: "Add",
  del: "Del"
};
var message_en = {
  gallery: "Gallery",
  background: "Background",
  angle: "Angle",
  color: "Color",
  transparency: "Transparency",
  stop: "Stop",
  add: "Add",
  del: "Del"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceDsStyleBackground = (
  /** @class */
  function(_super) {
    __extends(ServiceDsStyleBackground2, _super);
    function ServiceDsStyleBackground2() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.myUpp = false;
      _this.error = "";
      _this.css = "";
      _this.helper = "_100554_serviceDsStyleBackground";
      _this.info = { tp: "background", aux: "", itens: [] };
      _this.details = {
        icon: "&#xf043",
        state: "foreground",
        position: "right",
        tooltip: "Background",
        visible: false,
        tags: ["ds_styles"],
        widget: "_100554_serviceDsStyleBackground",
        level: [3]
      };
      _this.onClickLink = function(op) {
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.onClickIcon = function(op) {
      };
      _this.menu = {
        title: "Background",
        actions: {},
        icons: {},
        actionDefault: "",
        // call after close icon clicked
        iconDefault: "",
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        onClickIcon: _this.onClickIcon
      };
      _this.timeonChangeProp = -1;
      _this.timeLoader = -1;
      _this.myMsg = {
        columnsCount: "Columns Count"
      };
      _this.arrayGallery = [
        "background: radial-gradient(circle, rgb(2, 0, 36) 36%, rgb(60, 70, 193) 66%);",
        "background: linear-gradient(342deg, rgba(34, 193, 195, 0.76) 50%, rgba(45, 253, 121, 0.24) 100%);",
        "background: radial-gradient(circle, rgb(63, 94, 251) 0%, rgb(252, 70, 107) 100%);",
        "background: linear-gradient(342deg, rgb(131, 58, 180) 0%, rgb(253, 29, 29) 50%, rgb(252, 176, 69) 100%);",
        "background: radial-gradient(circle, rgb(238, 174, 202) 0%, rgb(148, 187, 233) 100%);",
        "background: linear-gradient(135deg, rgba(30, 87, 153,1) 0%, rgba(41, 137, 216,1) 50%, rgba(32, 124, 202,1) 51%, rgba(125, 185, 232,1) 100%)",
        "background: linear-gradient(135deg, rgba(76, 76, 76,1) 0%, rgba(89, 89, 89,1) 12%, rgba(102, 102, 102,1) 25%, rgba(71, 71, 71,1) 39%, rgba(44, 44, 44,1) 50%, rgba(0, 0, 0,1) 51%, rgba(17, 17, 17,1) 60%, rgba(43, 43, 43) 76%, rgba(28, 28, 28,1) 91%, rgba(19, 19, 19,1) 100%)",
        "background: linear-gradient(135deg, rgba(243, 197, 189,1) 0%, rgba(232, 108, 87,1) 50%, rgba(234, 40, 3,1) 51%, rgba(255, 102, 0,1) 75%, rgba(199, 34, 0,1) 100%)",
        "background: linear-gradient(90deg, rgba(2, 0, 36,1) 0%, rgba(9, 9, 121,1) 35%, rgba(0, 212, 255,1) 100%)",
        "background: linear-gradient(0deg, rgba(34, 193, 195,1) 0%, rgba(253, 187, 45,1) 100%)",
        "background: linear-gradient(90deg, rgba(131, 58, 180,1) 0%, rgba(253, 29, 29,1) 50%, rgba(252, 176, 69,1) 100%)",
        "background: linear-gradient(310deg, rgba(5, 25, 55, 1) 0%, rgba(0, 77, 122,1) 20%, rgba(0, 135, 147, 1) 40%, rgba(0, 191 ,114, 1) 60%, rgba(168, 235 ,18, 1) 80%)",
        "background: linear-gradient(270deg, rgba(112, 225, 245, 1), rgba(255, 209, 148, 1))",
        "background: linear-gradient(90deg, rgba(85, 98, 112, 1), rgba(255, 107, 107, 1))",
        "background: linear-gradient(90deg, rgba(120, 2, 6,1), rgba(6, 17, 97,1))",
        "background: linear-gradient(120deg, rgba(45, 195, 195,1), rgba(158, 17, 17,1))",
        "background: linear-gradient(90deg, rgba(255, 78, 80,1), rgba(249, 212, 35,1))",
        "background: linear-gradient(90deg, rgba(255,239,0,1) 0%, rgba(127,164,8,1) 35%, rgba(0,212,255,1) 100%)",
        "background: rgba(240, 236, 227,1)",
        "background: rgba(223, 211, 195, 1)",
        "background: rgba(199, 177, 152,1)",
        "background: rgba(221, 221, 221,1)",
        "background: rgba(243, 225, 225, 1)",
        "background: rgba(249, 249, 249, 1)",
        "background: rgba(252, 247, 187, 1)",
        "background: rgba(255, 236, 199, 1)",
        "background: rgba(181, 144, 202, 1)",
        "background: rgba(166, 177, 225, 1)",
        "background: rgba(229, 138, 138, 1)",
        "background: rgba(212, 235, 208, 1)",
        "background: rgba(186, 223, 219, 1)",
        "background: rgba(255, 241, 172, 1)",
        "background: rgba(249, 188, 221, 1)",
        "background: rgba(56, 81, 112, 1)",
        "background: rgba(238, 238, 238, 1)"
      ];
      _this.setEvents();
      return _this;
    }
    ServiceDsStyleBackground2.prototype.onServiceClick = function(visible, reinit) {
      if (visible || reinit) {
        this.fireEventAboutMe();
      }
    };
    ServiceDsStyleBackground2.prototype.setEvents = function() {
      var _this = this;
      mls.events.addEventListener([3], ["DSStyleChanged"], function(ev) {
        _this.onstylechanged(ev.desc);
      });
      mls.events.addEventListener([3], ["DSStyleSelected"], function(ev) {
        _this.onDSStyleSelected(ev);
      });
      mls.events.addEventListener([3], ["DSStyleUnSelected"], function(ev) {
        _this.onDSStyleUnSelected(ev);
      });
      mls.events.addEventListener([3], ["DSStyleCursorChanged"], function(ev) {
        _this.onDSStyleCursorChanged(ev);
      });
    };
    ServiceDsStyleBackground2.prototype.onstylechanged = function(desc) {
      var _this = this;
      var obj = JSON.parse(desc);
      if (obj.emitter === "left" && this.visible === "true" && obj.value.length > 0) {
        obj.value.forEach(function(i) {
          if (!_this.shadowRoot || !i.key)
            return;
          var value = i.value;
          var prop = i.key;
          if (!["background", "background-color"].includes(prop))
            return;
          _this.configString("background:" + value);
        });
      }
    };
    ServiceDsStyleBackground2.prototype.onDSStyleSelected = function(ev) {
      var params = ev.desc ? JSON.parse(ev.desc) : [];
      if (params.service.length > 0 && !params.service.includes(this.helper) || !this.serviceItemNav)
        return;
      this.serviceItemNav.setAttribute("mode", "A");
      this.showNav2Item(true);
    };
    ServiceDsStyleBackground2.prototype.onDSStyleUnSelected = function(ev) {
      var params = ev.desc ? JSON.parse(ev.desc) : [];
      if (params.service.includes(this.helper) || !this.serviceItemNav)
        return;
      this.serviceItemNav.setAttribute("mode", "H");
      this.showNav2Item(false);
    };
    ServiceDsStyleBackground2.prototype.onDSStyleCursorChanged = function(ev) {
      var rc = JSON.parse(ev.desc);
      if (rc.helper === this.helper) {
        if (this.visible === "true" || !this.serviceItemNav)
          return;
        this.serviceItemNav.click();
      }
    };
    ServiceDsStyleBackground2.prototype.connectedCallback = function() {
      _super.prototype.connectedCallback.call(this);
      this.updateMyMessages();
    };
    ServiceDsStyleBackground2.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['<div class="container">', "</div>"], ['<div class="container">', "</div>"])), this.renderBody());
    };
    ServiceDsStyleBackground2.prototype.renderBody = function() {
      return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(['\n            <div class="showtransparent"></div>\n            <div class="showres" style="', '"></div>\n            <div class="showConfigContainer" >\n                \n                <div class="showConfig" >\n                    ', "\n                    ", '\n                </div>\n                <div class="showConfig" style="border-left: 1px solid #dfe1e6;" >\n                    <h4 style="text-align:center;margin-bottom:1rem">', "</h4>\n                    ", "\n                </div>\n            </div>\n\n        "], ['\n            <div class="showtransparent"></div>\n            <div class="showres" style="', '"></div>\n            <div class="showConfigContainer" >\n                \n                <div class="showConfig" >\n                    ', "\n                    ", '\n                </div>\n                <div class="showConfig" style="border-left: 1px solid #dfe1e6;" >\n                    <h4 style="text-align:center;margin-bottom:1rem">', "</h4>\n                    ", "\n                </div>\n            </div>\n\n        "])), this.css, this.renderConfig(), this.renderItens(), this.msg.gallery, this.renderGallery());
    };
    ServiceDsStyleBackground2.prototype.renderConfig = function() {
      var _this = this;
      if (this.info.tp === "background") {
        return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['\n                <div class="showConfigItem">\n                    <div class="active" style="border: 1px solid #d0cccc; font-size: 80%; padding: 0.2rem; border-radius: 5px; width:130px; text-align:center; cursor:pointer">', "</div>\n                </div>\n            "], ['\n                <div class="showConfigItem">\n                    <div class="active" style="border: 1px solid #d0cccc; font-size: 80%; padding: 0.2rem; border-radius: 5px; width:130px; text-align:center; cursor:pointer">', "</div>\n                </div>\n            "])), this.msg.background);
      } else if (this.info.tp !== "") {
        return html(templateObject_4 || (templateObject_4 = __makeTemplateObject(['\n                <div class="showConfigItem" style="flex-direction:row; margin-bottom:10px">\n                    <div class="', '" style="border: 1px solid #d0cccc; font-size: 80%; padding: 0.2rem; border-top-left-radius: 5px; border-bottom-left-radius: 5px; border-right:0px; width:130px; text-align:center; cursor:pointer" @click="', '">Linear-gradient</div>\n                    <div class="', '" style="border: 1px solid #d0cccc; font-size: 80%; padding: 0.2rem; border-top-right-radius: 5px; border-bottom-right-radius: 5px; width:130px; text-align:center; cursor:pointer" @click="', '">Radial-gradient</div>\n                </div>\n                ', "\n            "], ['\n                <div class="showConfigItem" style="flex-direction:row; margin-bottom:10px">\n                    <div class="', '" style="border: 1px solid #d0cccc; font-size: 80%; padding: 0.2rem; border-top-left-radius: 5px; border-bottom-left-radius: 5px; border-right:0px; width:130px; text-align:center; cursor:pointer" @click="', '">Linear-gradient</div>\n                    <div class="', '" style="border: 1px solid #d0cccc; font-size: 80%; padding: 0.2rem; border-top-right-radius: 5px; border-bottom-right-radius: 5px; width:130px; text-align:center; cursor:pointer" @click="', '">Radial-gradient</div>\n                </div>\n                ', "\n            "])), this.info.tp === "linear-gradient" ? "active" : "", function() {
          return _this.changeType("linear-gradient");
        }, this.info.tp === "radial-gradient" ? "active" : "", function() {
          return _this.changeType("radial-gradient");
        }, this.renderAux());
      } else {
        return html(templateObject_5 || (templateObject_5 = __makeTemplateObject([""], [""])));
      }
    };
    ServiceDsStyleBackground2.prototype.renderAux = function() {
      var _this = this;
      if (this.info.tp !== "linear-gradient")
        return html(templateObject_6 || (templateObject_6 = __makeTemplateObject([""], [""])));
      return html(templateObject_7 || (templateObject_7 = __makeTemplateObject(['\n            <div class="showConfigItem" style="flex-direction:row;  margin-bottom:10px">\n                <span style="width:50px;text-align:center;font-size:80%; color:#6d6d6d;">', ':</span>\n                <input type="number" style="width:50px;text-align:center;font-size:80%; color:#6d6d6d; " .value=', ' prop="aux" @input="', '"/>\n            </div>\n        '], ['\n            <div class="showConfigItem" style="flex-direction:row;  margin-bottom:10px">\n                <span style="width:50px;text-align:center;font-size:80%; color:#6d6d6d;">', ':</span>\n                <input type="number" style="width:50px;text-align:center;font-size:80%; color:#6d6d6d; " .value=', ' prop="aux" @input="', '"/>\n            </div>\n        '])), this.msg.angle, this.onlyNumber(this.info.aux), function(e) {
        return _this.onChangeAux("aux");
      });
    };
    ServiceDsStyleBackground2.prototype.renderItens = function() {
      var _this = this;
      return html(templateObject_9 || (templateObject_9 = __makeTemplateObject(['\n            <div class="showConfigItem">\n                <div style="display:flex; gap:.5rem; font-size:80%; color:#6d6d6d;margin-bottom:.5rem">\n                    <div style="width:50px;text-align:center; ">', '</div> \n                    <div style="width:132px;text-align:center;">', '</div> \n                    <div style="width:60px;text-align:center;" >', '</div>\n                    <div style="width:50px;text-align:center; cursor:pointer" @click="', '">', "</div>\n                </div>  \n                ", "\n            </div>\n        "], ['\n            <div class="showConfigItem">\n                <div style="display:flex; gap:.5rem; font-size:80%; color:#6d6d6d;margin-bottom:.5rem">\n                    <div style="width:50px;text-align:center; ">', '</div> \n                    <div style="width:132px;text-align:center;">', '</div> \n                    <div style="width:60px;text-align:center;" >', '</div>\n                    <div style="width:50px;text-align:center; cursor:pointer" @click="', '">', "</div>\n                </div>  \n                ", "\n            </div>\n        "])), this.msg.color, this.msg.transparency, this.msg.stop, this.add, this.msg.add, repeat(this.info.itens, function(key) {
        return key.value;
      }, function(i, index) {
        return html(templateObject_8 || (templateObject_8 = __makeTemplateObject(['\n                        <div style="display:flex; gap:.5rem;margin-bottom:.5rem" index="', '" class="groupEdit">\n                            <input type="color" .value="', '" style="width:50px" prop="color" index="', '" @change="', '"/> \n                            <input type="range" min="0" max="100" .value="', '" style="width:132px" prop="transp" index="', '" @input="', '"/> \n                            <input type="number" style="width:50px" min="0" max="100" .value="', '" prop="stop" index="', '" @input="', '"></input>\n                            <div style="width:50px;text-align:center;font-size:80%; color:#6d6d6d;cursor:pointer" @click="', '">', "</div>\n                        </div>    \n                    "], ['\n                        <div style="display:flex; gap:.5rem;margin-bottom:.5rem" index="', '" class="groupEdit">\n                            <input type="color" .value="', '" style="width:50px" prop="color" index="', '" @change="', '"/> \n                            <input type="range" min="0" max="100" .value="', '" style="width:132px" prop="transp" index="', '" @input="', '"/> \n                            <input type="number" style="width:50px" min="0" max="100" .value="', '" prop="stop" index="', '" @input="', '"></input>\n                            <div style="width:50px;text-align:center;font-size:80%; color:#6d6d6d;cursor:pointer" @click="', '">', "</div>\n                        </div>    \n                    "])), index, i.value, index, function(e) {
          return _this.onChangeProp(index);
        }, i.transp, index, function(e) {
          return _this.onChangeProp(index);
        }, i.stop, index, function(e) {
          return _this.onChangeProp(index);
        }, function(e) {
          return _this.del(index);
        }, _this.msg.del);
      }));
    };
    ServiceDsStyleBackground2.prototype.renderGallery = function() {
      var _this = this;
      return html(templateObject_11 || (templateObject_11 = __makeTemplateObject(['\n            <div style="display:flex; gap:.5rem; flex-wrap:wrap">\n            ', "\n            </div>\n        "], ['\n            <div style="display:flex; gap:.5rem; flex-wrap:wrap">\n            ', "\n            </div>\n        "])), repeat(this.arrayGallery, function(key) {
        return key;
      }, function(css2, index) {
        return html(templateObject_10 || (templateObject_10 = __makeTemplateObject(['<div style="width:40px; border-radius:5px; height:30px; cursor:pointer;', '" @click="', '" .gallery=', "></div>"], ['<div style="width:40px; border-radius:5px; height:30px; cursor:pointer;', '" @click="', '" .gallery=', "></div>"])), css2, _this.clickGallery, css2);
      }));
    };
    ServiceDsStyleBackground2.prototype.clickGallery = function(e) {
      var el = e.target;
      if (!el)
        return;
      var css2 = el["gallery"];
      this.configString(css2);
      this.mountMyValue();
    };
    ServiceDsStyleBackground2.prototype.onlyNumber = function(str) {
      var regexNum = /(\d+(?:\.\d+)?)/;
      var res = str.match(regexNum);
      return res && res[0] ? res[0] : "";
    };
    ServiceDsStyleBackground2.prototype.changeType = function(tp) {
      if (this.info.tp === tp)
        return;
      if (tp === "linear-gradient") {
        this.info.tp = "linear-gradient";
        this.info.aux = "90deg";
      } else if (tp === "radial-gradient") {
        this.info.tp = "radial-gradient";
        this.info.aux = "circle";
      }
      this.mountMyValue();
    };
    ServiceDsStyleBackground2.prototype.add = function() {
      this.info.itens.push({ value: "#000000", transp: "100", stop: "100" });
      if (this.info.itens.length >= 2 && this.info.tp === "background") {
        this.info.tp = "linear-gradient";
        this.info.aux = "84deg";
      }
      this.mountMyValue();
    };
    ServiceDsStyleBackground2.prototype.del = function(index) {
      this.info.itens.splice(index, 1);
      if (this.info.itens.length <= 1 && this.info.tp !== "background") {
        this.info.tp = "background";
        this.info.aux = "";
      }
      this.mountMyValue();
    };
    ServiceDsStyleBackground2.prototype.configString = function(str) {
      var _this = this;
      this.css = str;
      this.info = { tp: "", aux: "", itens: [] };
      if (str.indexOf("linear-gradient") >= 0) {
        this.info.tp = "linear-gradient";
      } else if (str.indexOf("radial-gradient") >= 0) {
        this.info.tp = "radial-gradient";
      } else {
        this.info.tp = "background";
      }
      if (this.info.tp === "background") {
        var cl = str.split(":")[1];
        if (cl.indexOf("rgb") >= 0)
          cl = this.rgbaToHex(cl).vl;
        this.info.itens = [{ value: cl, transp: "100", stop: "" }];
      } else {
        var ar = [];
        str = str.substr(str.indexOf("("));
        str = this.changeStr(str);
        ar = str.split(",");
        var auxCount_1 = 100 / (ar.length - 1);
        ar.forEach(function(i, idx) {
          if (idx === 0) {
            _this.info.aux = i;
            return;
          }
          if (i.indexOf("#") >= 0 || i.indexOf("abgr") >= 0 || i.indexOf("bgr") >= 0) {
            var vl = "";
            var start = auxCount_1 * idx + "";
            var a2 = i.trim().split(" ");
            if (a2.length > 0)
              vl = a2[0].replace("abgr", "rgba").replace("bgr", "rgb").replace(/;/g, ",");
            if (a2.length > 1)
              start = a2[1].replace("%", "");
            if (vl === "")
              return;
            var vlI = { vl, transp: "100" };
            if (vl.indexOf("rgb") >= 0) {
              vlI = _this.rgbaToHex(vl);
            }
            if (!_this.info.itens)
              _this.info.itens = [{ value: vlI.vl, transp: vlI.transp, stop: start }];
            else
              _this.info.itens.push({ value: vlI.vl, transp: vlI.transp, stop: start });
          }
        });
      }
    };
    ServiceDsStyleBackground2.prototype.rgbaToHex = function(rgbaString) {
      var match = rgbaString.match(/(\d+(?:\.\d+)?)/g);
      if (!match) {
        return { vl: "", transp: "" };
      }
      var r = parseInt(match[0], 10);
      var g = parseInt(match[1], 10);
      var b = parseInt(match[2], 10);
      var a = match[3] ? (+match[3] * 100).toString() : "100";
      var toHex = function(component) {
        var hex = component.toString(16);
        return hex.length === 1 ? "0" + hex : hex;
      };
      var hexR = toHex(r);
      var hexG = toHex(g);
      var hexB = toHex(b);
      var hexColor = "#".concat(hexR).concat(hexG).concat(hexB);
      return { vl: hexColor, transp: a };
    };
    ServiceDsStyleBackground2.prototype.hexToRgba = function(hex, alpha) {
      if (alpha === void 0) {
        alpha = 1;
      }
      hex = hex.replace(/^#/, "");
      var bigint = parseInt(hex, 16);
      var r = bigint >> 16 & 255;
      var g = bigint >> 8 & 255;
      var b = bigint & 255;
      return "rgba(".concat(r, ", ").concat(g, ", ").concat(b, ", ").concat(alpha, ")");
    };
    ServiceDsStyleBackground2.prototype.changeStr = function(s) {
      if (s.indexOf("rgba") >= 0 || s.indexOf("rgb") >= 0) {
        var tp = s.indexOf("rgba") >= 0 ? "rgba" : "rgb";
        var tpR = s.indexOf("rgba") >= 0 ? "abgr" : "bgr";
        var newst = "";
        var oldstr = "";
        var st = s.indexOf(tp);
        var ste = -1;
        st = s.substr(st).indexOf("(") + st;
        ste = s.substr(st).indexOf(")") + st;
        newst = s.slice(st, ste);
        oldstr = newst;
        newst = newst.replace(/ ,/g, ",").replace(/, /g, ",").replace(/,/g, ";");
        s = s.replace(oldstr, newst).replace(tp, tpR);
        return this.changeStr(s);
      } else {
        if (s.indexOf("(") === 0)
          s = s.substr(1);
        if (s.lastIndexOf(")") === s.length - 1)
          s = s.substring(0, s.length - 1);
        if (s.lastIndexOf(");") === s.length - 2)
          s = s.substring(0, s.lastIndexOf(");"));
        return s;
      }
    };
    ServiceDsStyleBackground2.prototype.onChangeProp = function(index) {
      var _this = this;
      clearTimeout(this.timeonChangeProp);
      this.timeonChangeProp = setTimeout(function() {
        if (!_this.shadowRoot)
          return;
        var el = _this.shadowRoot.querySelector('.groupEdit[index="' + index + '"]');
        if (!el)
          return;
        _this.changeValues(el, index);
      }, 500);
    };
    ServiceDsStyleBackground2.prototype.onChangeAux = function(prop) {
      var _this = this;
      clearTimeout(this.timeonChangeProp);
      this.timeonChangeProp = setTimeout(function() {
        if (!_this.shadowRoot)
          return;
        var el = _this.shadowRoot.querySelector('*[prop="' + prop + '"]');
        _this.info.aux = el.value + "deg";
        _this.mountMyValue();
      }, 500);
    };
    ServiceDsStyleBackground2.prototype.changeValues = function(el, idx) {
      var elC = el.querySelector('input[prop="color"]');
      var elT = el.querySelector('input[prop="transp"]');
      var elS = el.querySelector('input[prop="stop"]');
      if (!elC || !elT || !elS || !this.info.itens[idx])
        return;
      this.info.itens[idx].value = elC.value;
      this.info.itens[idx].transp = elT.value;
      this.info.itens[idx].stop = elS.value;
      this.info.itens.sort(function(a, b) {
        return a.stop - b.stop;
      });
      this.mountMyValue();
    };
    ServiceDsStyleBackground2.prototype.mountMyValue = function() {
      var _this = this;
      var aux = "background:";
      var text = "";
      if (this.info.tp === "background" && this.info.itens.length > 0) {
        text = this.hexToRgba(this.info.itens[0].value, +this.info.itens[0].transp / 100);
      } else if (this.info.itens.length > 0) {
        text = "".concat(this.info.tp, "( ").concat(this.info.aux, ",");
        this.info.itens.forEach(function(i, idx) {
          var aux2 = idx === _this.info.itens.length - 1 ? "" : ",";
          text = text + " ".concat(_this.hexToRgba(i.value, +i.transp / 100), " ").concat(i.stop, "%").concat(aux2);
        });
        text = text + ")";
      }
      this.css = aux + text;
      this.info = Object.assign({}, this.info);
      this.emitEvent({ key: "background", value: text });
    };
    ServiceDsStyleBackground2.prototype.fireEventAboutMe = function() {
      var rc = {
        emitter: "right-get"
      };
      mls.events.fire([3], ["DSStyleChanged"], JSON.stringify(rc), 500);
    };
    ServiceDsStyleBackground2.prototype.emitEvent = function(obj) {
      if (this.myUpp)
        return;
      var rc = {
        emitter: this.position,
        value: [obj, { key: "background-color", value: "" }],
        helper: this.helper
      };
      if (typeof mls !== "object")
        return;
      mls.events.fire([3], ["DSStyleChanged"], JSON.stringify(rc));
    };
    ServiceDsStyleBackground2.prototype.showLoader = function(loader) {
      var _this = this;
      clearTimeout(this.timeLoader);
      this.timeLoader = setTimeout(function() {
        _this.loading = loader;
      }, 200);
    };
    ServiceDsStyleBackground2.prototype.updateMyMessages = function() {
      if (!window["message"])
        return;
      var m = window["message"];
      if (m.columnsCount)
        this.myMsg.columnsCount = m.columnsCount;
    };
    ServiceDsStyleBackground2.styles = css(templateObject_12 || (templateObject_12 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceDsStyleBackground2.prototype, "error", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceDsStyleBackground2.prototype, "css", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceDsStyleBackground2.prototype, "helper", void 0);
    __decorate([
      property(),
      __metadata("design:type", Object)
    ], ServiceDsStyleBackground2.prototype, "info", void 0);
    ServiceDsStyleBackground2 = __decorate([
      customElement("service-ds-style-background-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceDsStyleBackground2);
    return ServiceDsStyleBackground2;
  }(ServiceBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6, templateObject_7, templateObject_8, templateObject_9, templateObject_10, templateObject_11, templateObject_12;
export {
  ServiceDsStyleBackground
};
