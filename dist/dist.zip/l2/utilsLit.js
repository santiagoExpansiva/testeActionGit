function convertTagToFileName(tag) {
  var regex = /(.+)-(\d+)/;
  var match = tag.match(regex);
  if (match) {
    var rest = match[1], number = match[2];
    var convertedSrc = rest.replace(/-(.)/g, function(_, letter) {
      return letter.toUpperCase();
    });
    tag = "_".concat(number, "_").concat(convertedSrc);
  }
  return tag;
}
function convertFileNameToTag(widget) {
  var regex = /_([0-9]+)_?(.*)/;
  var match = widget.match(regex);
  if (match) {
    var number = match[1], rest = match[2];
    var convertedSrc = rest.replace(/([A-Z])/g, "-$1").toLowerCase();
    widget = "".concat(convertedSrc, "-").concat(number);
  }
  if (widget.startsWith("-"))
    widget = widget.substring(1);
  return widget;
}
export {
  convertFileNameToTag,
  convertTagToFileName
};
