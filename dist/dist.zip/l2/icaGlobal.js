const PREFIX = "ica";
const PREFIXWCD = "wcd";
const ATTRGROUP = "isicagroup";
const ICAPAGE = "ica-page-100554";
export {
  ATTRGROUP,
  ICAPAGE,
  PREFIX,
  PREFIXWCD
};
