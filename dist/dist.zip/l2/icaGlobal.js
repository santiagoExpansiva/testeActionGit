var PREFIX = "ica";
var PREFIXWCD = "wcd";
var ATTRGROUP = "isicagroup";
var ICAPAGE = "ica-page-100554";
export {
  ATTRGROUP,
  ICAPAGE,
  PREFIX,
  PREFIXWCD
};
