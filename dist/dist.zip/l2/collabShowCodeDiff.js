var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { html, css } from "lit";
import { customElement, property, query } from "lit/decorators.js";
import { collab_check, collab_copy, collab_repeat, collab_thumbs_down, collab_thumbs_up } from "./_100554_collabIcons";
import { CollabLitElement } from "./_100554_collabLitElement";
function initCollabShowCodeDiff100554() {
  return true;
}
var message_pt = {
  diff: "Com Diferen\uFFFDa",
  reject: "Rejeitar",
  tryAgain: "Tentar Novamente",
  accept: "Aceitar",
  copy: "Copiar",
  copied: "Copiado"
};
var message_en = {
  diff: "With Diff",
  reject: "Reject",
  tryAgain: "Try Again",
  accept: "Accept",
  copy: "Copy",
  copied: "Copied"
};
var messages = {
  "en-us": message_en,
  "pt-br": message_pt
};
var CollabShowCodeDiff = (
  /** @class */
  function(_super) {
    __extends(CollabShowCodeDiff2, _super);
    function CollabShowCodeDiff2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.msg = messages["en-us"];
      _this.msize = "400.00,420.00,106.00,0";
      _this.language = "typescript";
      _this.withCopy = true;
      _this.withAccept = false;
      _this.withReject = false;
      _this.withTryAgain = false;
      _this.withDiff = false;
      _this.coping = false;
      _this.onAccept = function() {
        console.info("not implement");
      };
      _this.onReject = function() {
        console.info("not implement");
      };
      _this.onTryAgain = function() {
        console.info("not implement");
      };
      _this.actualEditor = "result";
      _this.actualTextDiffOriginal = "";
      _this.actualTextDiffModified = "";
      _this.actualTextResult = "";
      return _this;
    }
    CollabShowCodeDiff_1 = CollabShowCodeDiff2;
    CollabShowCodeDiff2.prototype.init = function() {
      if (this.actualEditor === "diff")
        this.setDiffValue(this.actualTextDiffOriginal, this.actualTextDiffModified);
      else
        this.setResultValue(this.actualTextResult);
    };
    CollabShowCodeDiff2.prototype.createEditorDiff = function() {
      var _a2;
      if (!this.c1 || this._ed1Diff)
        return;
      if (this._ed1Result) {
        this._ed1Result.dispose();
        (_a2 = this.modelResult) === null || _a2 === void 0 ? void 0 : _a2.dispose();
        this._ed1Result = void 0;
        this.modelResult = void 0;
      }
      var opt = {
        automaticLayout: true,
        renderSideBySide: false,
        readOnly: true
      };
      this._ed1Diff = monaco.editor.createDiffEditor(this.c1, opt);
      this.c1["mlsEditor"] = this._ed1Diff;
    };
    CollabShowCodeDiff2.prototype.createEditorResult = function() {
      var _a2, _b2;
      if (!this.c1 || this._ed1Result)
        return;
      if (this._ed1Diff) {
        this._ed1Diff.dispose();
        (_a2 = this.modelDiffModified) === null || _a2 === void 0 ? void 0 : _a2.dispose();
        (_b2 = this.modelDiffOriginal) === null || _b2 === void 0 ? void 0 : _b2.dispose();
        this._ed1Diff = void 0;
        this.modelDiffModified = void 0;
        this.modelDiffOriginal = void 0;
      }
      var opt = {
        automaticLayout: true,
        readOnly: true
      };
      this._ed1Result = monaco.editor.create(this.c1, opt);
      this.c1["mlsEditor"] = this._ed1Result;
    };
    CollabShowCodeDiff2.prototype.createModelDiff = function(editorType, srcOriginal, srcModified) {
      if (!this.modelDiffModified)
        this.modelDiffModified = monaco.editor.createModel(srcModified, editorType);
      else
        this.modelDiffModified.setValue(srcModified);
      if (!this.modelDiffOriginal)
        this.modelDiffOriginal = monaco.editor.createModel(srcOriginal, editorType);
      else
        this.modelDiffOriginal.setValue(srcOriginal);
    };
    CollabShowCodeDiff2.prototype.createModelResult = function(editorType, src) {
      if (!this.modelResult)
        this.modelResult = monaco.editor.createModel(src, editorType);
      else
        this.modelResult.setValue(src);
    };
    CollabShowCodeDiff2.prototype.setDiffValue = function(srcOriginal, srcModified) {
      this.createEditorDiff();
      this.createModelDiff(this.language, srcOriginal, srcModified);
      if (!this._ed1Diff || !this.modelDiffOriginal || !this.modelDiffModified)
        return;
      this._ed1Diff.setModel({
        original: this.modelDiffOriginal,
        modified: this.modelDiffModified
      });
      this.actualTextDiffModified = srcModified;
      this.actualTextDiffOriginal = srcOriginal;
    };
    CollabShowCodeDiff2.prototype.setResultValue = function(src) {
      this.createEditorResult();
      this.createModelResult(this.language, src);
      if (!this._ed1Result || !this.modelResult)
        return;
      this._ed1Result.setModel(this.modelResult);
      this.actualTextResult = src;
    };
    CollabShowCodeDiff2.prototype.setMsizeEditor = function() {
      var _a2;
      (_a2 = this.c1) === null || _a2 === void 0 ? void 0 : _a2.setAttribute("msize", this.msize);
    };
    CollabShowCodeDiff2.prototype.onCopyClick = function() {
      var _this = this;
      var _a2, _b2;
      this.coping = true;
      var value = this.actualEditor && this.actualEditor === "result" ? (_a2 = this.modelResult) === null || _a2 === void 0 ? void 0 : _a2.getValue() : (_b2 = this.modelDiffModified) === null || _b2 === void 0 ? void 0 : _b2.getValue();
      navigator.clipboard.writeText(value || "");
      setTimeout(function() {
        _this.coping = false;
      }, 3e3);
    };
    CollabShowCodeDiff2.prototype.onAcceptClick = function() {
      if (this.onAccept && typeof this.onAccept === "function") {
        this.onAccept();
      }
    };
    CollabShowCodeDiff2.prototype.onRejectClick = function() {
      if (this.onReject && typeof this.onReject === "function") {
        this.onReject();
      }
    };
    CollabShowCodeDiff2.prototype.onTryAgainClick = function() {
      if (this.onTryAgain && typeof this.onTryAgain === "function") {
        this.onTryAgain();
      }
    };
    CollabShowCodeDiff2.prototype.getCssMonaco = function() {
      return __awaiter(this, void 0, void 0, function() {
        var cssPath, response, cssText;
        var _a2;
        return __generator(this, function(_b2) {
          switch (_b2.label) {
            case 0:
              cssPath = "../../../monaco/".concat((_a2 = window.latest) === null || _a2 === void 0 ? void 0 : _a2.monaco, "/monaco.css");
              return [4, fetch(cssPath)];
            case 1:
              response = _b2.sent();
              return [4, response.text()];
            case 2:
              cssText = _b2.sent();
              return [2, cssText];
          }
        });
      });
    };
    CollabShowCodeDiff2.prototype.loadCSS = function() {
      return __awaiter(this, void 0, void 0, function() {
        var cssText;
        var _a2;
        return __generator(this, function(_b2) {
          switch (_b2.label) {
            case 0:
              if (this.styleElement)
                return [
                  2
                  /*return*/
                ];
              cssText = "";
              if (!CollabShowCodeDiff_1.monaco_css) return [3, 1];
              cssText = CollabShowCodeDiff_1.monaco_css;
              return [3, 5];
            case 1:
              if (!CollabShowCodeDiff_1.inLoadingCss) return [3, 3];
              return [4, CollabShowCodeDiff_1.loadingPromise];
            case 2:
              cssText = _b2.sent();
              return [3, 5];
            case 3:
              CollabShowCodeDiff_1.inLoadingCss = true;
              CollabShowCodeDiff_1.loadingPromise = this.getCssMonaco();
              return [4, CollabShowCodeDiff_1.loadingPromise];
            case 4:
              cssText = _b2.sent();
              CollabShowCodeDiff_1.monaco_css = cssText;
              CollabShowCodeDiff_1.inLoadingCss = false;
              _b2.label = 5;
            case 5:
              if (!cssText)
                return [
                  2
                  /*return*/
                ];
              this.styleElement = document.createElement("style");
              this.styleElement.innerHTML = CollabShowCodeDiff_1.monaco_css;
              (_a2 = this.shadowRoot) === null || _a2 === void 0 ? void 0 : _a2.appendChild(this.styleElement);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    CollabShowCodeDiff2.prototype.renderWithCopy = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n            <div @click=", ' class="action-item" style="display:', '">\n                ', "\n                <span>", '</span>\n            </div>\n            <div class="action-item copied" style="display:', '">\n                ', "\n                <span>", "</span>\n            </div>\n            "], ["\n            <div @click=", ' class="action-item" style="display:', '">\n                ', "\n                <span>", '</span>\n            </div>\n            <div class="action-item copied" style="display:', '">\n                ', "\n                <span>", "</span>\n            </div>\n            "])), this.onCopyClick, this.coping ? "none" : "flex", collab_copy, this.msg.copy, this.coping ? "flex" : "none", collab_check, this.msg.copied);
    };
    CollabShowCodeDiff2.prototype.renderWithAccept = function() {
      return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n            <div @click=", ' class="action-item ', '">\n                ', "\n                <span>", "</span>\n            </div>\n        "], ["\n            <div @click=", ' class="action-item ', '">\n                ', "\n                <span>", "</span>\n            </div>\n        "])), this.onAcceptClick, !this.withAccept ? "disabled" : "", collab_thumbs_up, this.msg.accept);
    };
    CollabShowCodeDiff2.prototype.renderTryAgain = function() {
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(["\n            <div @click=", ' class="action-item ', '">\n                ', "\n                <span>", "</span>\n            </div>\n        "], ["\n            <div @click=", ' class="action-item ', '">\n                ', "\n                <span>", "</span>\n            </div>\n        "])), this.onTryAgainClick, !this.withTryAgain ? "disabled" : "", collab_repeat, this.msg.tryAgain);
    };
    CollabShowCodeDiff2.prototype.renderReject = function() {
      return html(templateObject_4 || (templateObject_4 = __makeTemplateObject(["\n            <div @click=", ' class="action-item ', '">\n                ', "\n                <span>", "</span>\n            </div>\n        "], ["\n            <div @click=", ' class="action-item ', '">\n                ', "\n                <span>", "</span>\n            </div>\n        "])), this.onRejectClick, !this.withReject ? "disabled" : "", collab_thumbs_down, this.msg.reject);
    };
    CollabShowCodeDiff2.prototype.handleChangeDiff = function() {
      if (!this.inputDiff)
        return;
      if (this.inputDiff.checked) {
        this.actualEditor = "diff";
        this.createEditorDiff();
        this.setDiffValue(this.actualTextDiffOriginal, this.actualTextDiffModified);
      } else {
        this.actualEditor = "result";
        this.createEditorResult();
        this.setResultValue(this.actualTextResult);
      }
    };
    CollabShowCodeDiff2.prototype.renderShowDiff = function() {
      return html(templateObject_5 || (templateObject_5 = __makeTemplateObject(['\n            <div class="', '">\n                <input @change=', ' id="diff_check" type="checkbox"></input>\n                <label for="diff_check">', "<label>\n            </div>\n        "], ['\n            <div class="', '">\n                <input @change=', ' id="diff_check" type="checkbox"></input>\n                <label for="diff_check">', "<label>\n            </div>\n        "])), !this.withDiff ? "disabled" : "", this.handleChangeDiff, this.msg.diff);
    };
    CollabShowCodeDiff2.prototype.firstUpdated = function() {
      this.loadCSS();
      this.dispatchEvent(new CustomEvent("show-diff-ready"));
    };
    CollabShowCodeDiff2.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_6 || (templateObject_6 = __makeTemplateObject(['\n            <div class="actions">\n                    <span class="language">', '</span>\n                \n                    <div class="actions-list">\n                        ', "\n                        ", "\n                        ", "\n                        ", "\n                        ", '\n                    </div>\n            </div>\n\n            <mls-editor-100529 style="display: block;height:600px;" ismls2="true"></mls-editor-100529>\n    '], ['\n            <div class="actions">\n                    <span class="language">', '</span>\n                \n                    <div class="actions-list">\n                        ', "\n                        ", "\n                        ", "\n                        ", "\n                        ", '\n                    </div>\n            </div>\n\n            <mls-editor-100529 style="display: block;height:600px;" ismls2="true"></mls-editor-100529>\n    '])), this.language, this.renderShowDiff(), this.renderWithAccept(), this.renderReject(), this.renderTryAgain(), this.withCopy ? this.renderWithCopy() : "");
    };
    var CollabShowCodeDiff_1;
    var _a, _b;
    CollabShowCodeDiff2.monaco_css = "";
    CollabShowCodeDiff2.inLoadingCss = false;
    CollabShowCodeDiff2.styles = css(templateObject_7 || (templateObject_7 = __makeTemplateObject(["\n      :host{\n        display:block;\n      }\n      .actions{\n        height:30px; \n        background: #b4b4b4; \n        display:flex; \n        align-items:center;\n        padding:0 1rem; \n        color:#fff;\n        .actions-list{\n          display:flex;\n          gap:1rem;\n        }\n      }\n      .language {\n        flex:1;\n      }\n      \n      .action-item{\n\n        user-select: none;\n        display:flex; \n        align-items:center;\n        justify-content: center;\n        cursor:pointer;\n        min-width: 50px;\n      }\n      .disabled {\n        cursor:default;\n        text-decoration: line-through;\n        pointer-events: none;\n      }\n      .copied{\n        cursor:default;\n        pointer-events: none;\n      }\n    "], ["\n      :host{\n        display:block;\n      }\n      .actions{\n        height:30px; \n        background: #b4b4b4; \n        display:flex; \n        align-items:center;\n        padding:0 1rem; \n        color:#fff;\n        .actions-list{\n          display:flex;\n          gap:1rem;\n        }\n      }\n      .language {\n        flex:1;\n      }\n      \n      .action-item{\n\n        user-select: none;\n        display:flex; \n        align-items:center;\n        justify-content: center;\n        cursor:pointer;\n        min-width: 50px;\n      }\n      .disabled {\n        cursor:default;\n        text-decoration: line-through;\n        pointer-events: none;\n      }\n      .copied{\n        cursor:default;\n        pointer-events: none;\n      }\n    "])));
    __decorate([
      property({ type: String }),
      __metadata("design:type", Object)
    ], CollabShowCodeDiff2.prototype, "msize", void 0);
    __decorate([
      property({ type: String, reflect: true }),
      __metadata("design:type", Object)
    ], CollabShowCodeDiff2.prototype, "language", void 0);
    __decorate([
      property({ type: Boolean, reflect: true }),
      __metadata("design:type", Object)
    ], CollabShowCodeDiff2.prototype, "withCopy", void 0);
    __decorate([
      property({ type: Boolean, reflect: true }),
      __metadata("design:type", Object)
    ], CollabShowCodeDiff2.prototype, "withAccept", void 0);
    __decorate([
      property({ type: Boolean, reflect: true }),
      __metadata("design:type", Object)
    ], CollabShowCodeDiff2.prototype, "withReject", void 0);
    __decorate([
      property({ type: Boolean, reflect: true }),
      __metadata("design:type", Object)
    ], CollabShowCodeDiff2.prototype, "withTryAgain", void 0);
    __decorate([
      property({ type: Boolean, reflect: true }),
      __metadata("design:type", Object)
    ], CollabShowCodeDiff2.prototype, "withDiff", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Object)
    ], CollabShowCodeDiff2.prototype, "coping", void 0);
    __decorate([
      query("mls-editor-100529"),
      __metadata("design:type", typeof (_a = typeof HTMLElement !== "undefined" && HTMLElement) === "function" ? _a : Object)
    ], CollabShowCodeDiff2.prototype, "c1", void 0);
    __decorate([
      query("#diff_check"),
      __metadata("design:type", typeof (_b = typeof HTMLInputElement !== "undefined" && HTMLInputElement) === "function" ? _b : Object)
    ], CollabShowCodeDiff2.prototype, "inputDiff", void 0);
    CollabShowCodeDiff2 = CollabShowCodeDiff_1 = __decorate([
      customElement("collab-show-code-diff-100554")
    ], CollabShowCodeDiff2);
    return CollabShowCodeDiff2;
  }(CollabLitElement)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6, templateObject_7;
export {
  CollabShowCodeDiff,
  initCollabShowCodeDiff100554
};
