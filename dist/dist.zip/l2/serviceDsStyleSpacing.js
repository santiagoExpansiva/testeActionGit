var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css } from "lit";
import { customElement, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
import { initCollabDSInputRange } from "./_100554_collabDsInputRange";
var message_pt = {
  margin: "Margem",
  padding: "Preenchimento",
  top: "Topo",
  left: "Esquerda",
  bottom: "Inferior",
  right: "Direita"
};
var message_en = {
  margin: "Margin",
  padding: "Padding",
  top: "Top",
  left: "Left",
  bottom: "Bottom",
  right: "Right"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceDsStyleSpacing = (
  /** @class */
  function(_super) {
    __extends(ServiceDsStyleSpacing2, _super);
    function ServiceDsStyleSpacing2() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.myUpp = false;
      _this.error = "";
      _this.helper = "_100554_serviceDsStyleSpacing";
      _this.details = {
        icon: "&#xe4ba",
        state: "foreground",
        position: "right",
        tooltip: "Spacing",
        tags: ["ds_styles"],
        visible: false,
        widget: "_100554_serviceDsStyleSpacing",
        level: [3]
      };
      _this.onClickLink = function(op) {
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.onClickIcon = function(op) {
      };
      _this.menu = {
        title: "Spacing",
        actions: {},
        icons: {},
        actionDefault: "",
        // call after close icon clicked
        iconDefault: "",
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        onClickIcon: _this.onClickIcon
      };
      _this.tpMeasures = ["px", "em", "rem", "vh", "vw", "vmin", "vmax", "ex", "ch", "auto"];
      _this.timeonChangeProp = -1;
      _this.timeLoader = -1;
      initCollabDSInputRange();
      _this.setEvents();
      return _this;
    }
    ServiceDsStyleSpacing2.prototype.onServiceClick = function(visible, reinit) {
      if (visible || reinit) {
        this.fireEventAboutMe();
      }
    };
    ServiceDsStyleSpacing2.prototype.setEvents = function() {
      var _this = this;
      mls.events.addEventListener([3], ["DSStyleChanged"], function(ev) {
        _this.onstylechanged(ev.desc);
      });
      mls.events.addEventListener([3], ["DSStyleSelected"], function(ev) {
        _this.onDSStyleSelected(ev);
      });
      mls.events.addEventListener([3], ["DSStyleUnSelected"], function(ev) {
        _this.onDSStyleUnSelected(ev);
      });
      mls.events.addEventListener([3], ["DSStyleCursorChanged"], function(ev) {
        _this.onDSStyleCursorChanged(ev);
      });
    };
    ServiceDsStyleSpacing2.prototype.onstylechanged = function(desc) {
      var obj = JSON.parse(desc);
      if (obj.emitter === "left" && this.visible === "true" && obj.value.length > 0) {
        this.setValues(obj.value);
      }
    };
    ServiceDsStyleSpacing2.prototype.setValues = function(ar) {
      var _this = this;
      this.myUpp = true;
      ar.forEach(function(i) {
        if (!_this.shadowRoot || !i.key)
          return;
        var value = i.value;
        var prop = i.key;
        if (["margin", "padding"].includes(prop)) {
          _this.uppProp(value, prop);
        } else {
          var el = _this.shadowRoot.querySelector('*[prop="' + prop + '"]');
          if (el)
            el.value = value;
        }
      });
      this.myUpp = false;
    };
    ServiceDsStyleSpacing2.prototype.onDSStyleSelected = function(ev) {
      var params = ev.desc ? JSON.parse(ev.desc) : [];
      if (params.service.length > 0 && !params.service.includes(this.helper) || !this.serviceItemNav)
        return;
      this.serviceItemNav.setAttribute("mode", "A");
      this.showNav2Item(true);
    };
    ServiceDsStyleSpacing2.prototype.onDSStyleUnSelected = function(ev) {
      var params = ev.desc ? JSON.parse(ev.desc) : [];
      if (params.service.includes(this.helper) || !this.serviceItemNav)
        return;
      this.serviceItemNav.setAttribute("mode", "H");
      this.showNav2Item(false);
    };
    ServiceDsStyleSpacing2.prototype.onDSStyleCursorChanged = function(ev) {
      var rc = JSON.parse(ev.desc);
      if (rc.helper === this.helper) {
        if (this.visible === "true" || !this.serviceItemNav)
          return;
        this.serviceItemNav.click();
      }
    };
    ServiceDsStyleSpacing2.prototype.connectedCallback = function() {
      _super.prototype.connectedCallback.call(this);
    };
    ServiceDsStyleSpacing2.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["", "", ""], ["", "", ""])), this.renderMargin(), this.renderPadding());
    };
    ServiceDsStyleSpacing2.prototype.renderMargin = function() {
      var _this = this;
      return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(['\n            <div>\n                <h5 style="display:flex; gap:1.5rem" >', '<input type="checkbox" prop="margin"></h5>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="margin-top" value="0px" .arraySelect=', ' group="margin" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="margin-left" value="0px" .arraySelect=', ' group="margin" @onchange="', '"></collab-ds-input-range-100554>    \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="margin-bottom" value="0px" .arraySelect=', ' group="margin" @onchange="', '"></collab-ds-input-range-100554> \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="margin-right" value="0px" .arraySelect=', ' group="margin" @onchange="', '"></collab-ds-input-range-100554> \n                </div>\n            </div>\n        '], ['\n            <div>\n                <h5 style="display:flex; gap:1.5rem" >', '<input type="checkbox" prop="margin"></h5>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="margin-top" value="0px" .arraySelect=', ' group="margin" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="margin-left" value="0px" .arraySelect=', ' group="margin" @onchange="', '"></collab-ds-input-range-100554>    \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="margin-bottom" value="0px" .arraySelect=', ' group="margin" @onchange="', '"></collab-ds-input-range-100554> \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="margin-right" value="0px" .arraySelect=', ' group="margin" @onchange="', '"></collab-ds-input-range-100554> \n                </div>\n            </div>\n        '])), this.msg.margin, this.msg.top, this.tpMeasures, function(e) {
        return _this.onChangeProp(e);
      }, this.msg.left, this.tpMeasures, function(e) {
        return _this.onChangeProp(e);
      }, this.msg.bottom, this.tpMeasures, function(e) {
        return _this.onChangeProp(e);
      }, this.msg.right, this.tpMeasures, function(e) {
        return _this.onChangeProp(e);
      });
    };
    ServiceDsStyleSpacing2.prototype.renderPadding = function() {
      var _this = this;
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['\n            <div>\n                <h5 style="display:flex; gap:1.5rem" >', '<input type="checkbox" prop="padding"></h5>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="padding-top" value="0px" .arraySelect=', ' group="padding" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="padding-left" value="0px" .arraySelect=', ' group="padding" @onchange="', '"></collab-ds-input-range-100554>    \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="padding-bottom" value="0px" .arraySelect=', ' group="padding" @onchange="', '"></collab-ds-input-range-100554> \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="padding-right" value="0px" .arraySelect=', ' group="padding" @onchange="', '"></collab-ds-input-range-100554> \n                </div>\n            </div>\n        '], ['\n            <div>\n                <h5 style="display:flex; gap:1.5rem" >', '<input type="checkbox" prop="padding"></h5>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="padding-top" value="0px" .arraySelect=', ' group="padding" @onchange="', '"></collab-ds-input-range-100554>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="padding-left" value="0px" .arraySelect=', ' group="padding" @onchange="', '"></collab-ds-input-range-100554>    \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="padding-bottom" value="0px" .arraySelect=', ' group="padding" @onchange="', '"></collab-ds-input-range-100554> \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <collab-ds-input-range-100554 prop="padding-right" value="0px" .arraySelect=', ' group="padding" @onchange="', '"></collab-ds-input-range-100554> \n                </div>\n            </div>\n        '])), this.msg.padding, this.msg.top, this.tpMeasures, function(e) {
        return _this.onChangeProp(e);
      }, this.msg.left, this.tpMeasures, function(e) {
        return _this.onChangeProp(e);
      }, this.msg.bottom, this.tpMeasures, function(e) {
        return _this.onChangeProp(e);
      }, this.msg.right, this.tpMeasures, function(e) {
        return _this.onChangeProp(e);
      });
    };
    ServiceDsStyleSpacing2.prototype.onChangeProp = function(e) {
      var _this = this;
      clearTimeout(this.timeonChangeProp);
      this.timeonChangeProp = setTimeout(function() {
        var el = e.detail.target;
        _this.beforeEmitEvent(el, e.detail);
      }, 500);
    };
    ServiceDsStyleSpacing2.prototype.beforeEmitEvent = function(el, obj) {
      if (!this.shadowRoot)
        return;
      var group = el ? el.getAttribute("group") : "";
      var elGroup = this.shadowRoot.querySelector('input[prop="'.concat(group, '"]'));
      var isGroup = false;
      if (elGroup)
        isGroup = elGroup.checked;
      if (isGroup) {
        this.uppProp(el.value, group);
        return;
      }
      this.emitEvent({
        key: el.getAttribute("prop"),
        value: el.value
      });
    };
    ServiceDsStyleSpacing2.prototype.uppProp = function(value, group) {
      if (!this.shadowRoot)
        return;
      var info = {
        margin: {
          p1: "margin-top",
          p2: "margin-left",
          p3: "margin-right",
          p4: "margin-bottom"
        },
        padding: {
          p1: "padding-top",
          p2: "padding-left",
          p3: "padding-bottom",
          p4: "padding-right"
        }
      };
      var prop = group;
      var elP1 = this.shadowRoot.querySelector('*[prop="'.concat(info[group].p1, '"]'));
      var elP2 = this.shadowRoot.querySelector('*[prop="'.concat(info[group].p2, '"]'));
      var elP3 = this.shadowRoot.querySelector('*[prop="'.concat(info[group].p3, '"]'));
      var elP4 = this.shadowRoot.querySelector('*[prop="'.concat(info[group].p4, '"]'));
      var ar = [];
      if (elP1)
        ar.push(elP1);
      if (elP2)
        ar.push(elP2);
      if (elP3)
        ar.push(elP3);
      if (elP4)
        ar.push(elP4);
      ar.forEach(function(i) {
        i.value = value;
      });
      this.emitEvent({
        key: prop,
        value
      });
    };
    ServiceDsStyleSpacing2.prototype.fireEventAboutMe = function() {
      var rc = {
        emitter: "right-get"
      };
      mls.events.fire([3], ["DSStyleChanged"], JSON.stringify(rc), 500);
    };
    ServiceDsStyleSpacing2.prototype.emitEvent = function(obj) {
      if (this.myUpp)
        return;
      var rc = {
        emitter: this.position,
        value: [obj],
        helper: this.helper
      };
      if (typeof mls !== "object")
        return;
      mls.events.fire([3], ["DSStyleChanged"], JSON.stringify(rc));
    };
    ServiceDsStyleSpacing2.prototype.showLoader = function(loader) {
      var _this = this;
      clearTimeout(this.timeLoader);
      this.timeLoader = setTimeout(function() {
        _this.loading = loader;
      }, 200);
    };
    ServiceDsStyleSpacing2.styles = css(templateObject_4 || (templateObject_4 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceDsStyleSpacing2.prototype, "error", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceDsStyleSpacing2.prototype, "helper", void 0);
    ServiceDsStyleSpacing2 = __decorate([
      customElement("service-ds-style-spacing-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceDsStyleSpacing2);
    return ServiceDsStyleSpacing2;
  }(ServiceBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4;
export {
  ServiceDsStyleSpacing
};
