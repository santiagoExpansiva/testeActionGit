var __spreadArray = function(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};
function getJson(docTS, onlyWithComents) {
  if (onlyWithComents === void 0) {
    onlyWithComents = false;
  }
  var docsJS = !docTS ? exDoc : JSON.parse(docTS);
  var docs = [];
  docsJS.forEach(function(item, index) {
    if (!item.name)
      return;
    if (onlyWithComents && !item.comment && (!item.parameters || item.parameters.length === 0) && (!item.members || item.members.length === 0 || item.members[0].name === item.name))
      return;
    var doc = {
      name: item.name,
      pos: item.pos || 0,
      type: item.type,
      comment: item.comment,
      parameters: item.parameters || [],
      modifiers: [],
      members: [],
      id: index,
      tags: [],
      otherTags: []
    };
    var _a = getTags(item.tags || []), otherTags = _a.otherTags, mainTags = _a.mainTags;
    doc.tags = mainTags;
    doc.otherTags = otherTags;
    if (item.members) {
      for (var i = 0; i < item.members.length; i++) {
        var newMember = createMember(item.members[i], +"".concat(index).concat(i), item.pos, onlyWithComents);
        if (newMember && doc && doc.members)
          doc.members.push(newMember);
      }
    }
    if (doc)
      docs.push(doc);
  });
  return docs;
}
function createMember(member, indexParent, posParent, onlyWithComents) {
  var _a;
  var comment = member.comment, members = member.members, type = member.type, tags = member.tags, parameters = member.parameters, name = member.name, modifiers = member.modifiers, pos = member.pos;
  if (!name)
    return void 0;
  var newMember = {
    comment,
    modifiers: [],
    name,
    parameters: parameters || [],
    members: [],
    tags: [],
    otherTags: [],
    id: indexParent,
    pos: pos || posParent,
    type
  };
  var _b = getTags(tags || []), otherTags = _b.otherTags, mainTags = _b.mainTags;
  newMember.tags = mainTags;
  newMember.otherTags = otherTags;
  if (modifiers) {
    modifiers.forEach(function(modifier) {
      newMember.modifiers.push({ name: modifier });
    });
  }
  if (members) {
    for (var i = 0; i < members.length; i++) {
      var newMember2 = createMember(members[i], +"".concat(indexParent).concat(i), member.pos, onlyWithComents);
      if (newMember2)
        (_a = newMember2.members) === null || _a === void 0 ? void 0 : _a.push(newMember);
    }
  }
  return newMember;
}
function getTags(array) {
  var tags = array.map(function(item) {
    return item.tagName;
  });
  var newArrayTags = Array.from(new Set(__spreadArray([], tags, true)));
  var mainTags = [];
  var otherTags = [];
  var arrMainTags = ["throws", "event", "todo", "param", "result", "link", "see"];
  var a = newArrayTags.map(function(item) {
    return array.filter(function(item2) {
      return item2.tagName === item;
    });
  });
  a.forEach(function(item) {
    var comments = [];
    item.forEach(function(t) {
      var c = t.comment;
      if (t.tagName === "see" || t.tagName === "link") {
        c = c.replace(/{@link/g, "").replace(/{ @link/g, "").replace(/}/g, "");
        c = '<a href="'.concat(c, '" target="_blank">').concat(c, "</a>");
      }
      comments.push({ comment: c });
    });
    var tagName = item[0].tagName;
    if (arrMainTags.includes(tagName))
      mainTags.push({ tagName: item[0].tagName, comments });
    else
      otherTags.push({ tagName: item[0].tagName, comments });
  });
  return { otherTags, mainTags };
}
var exDoc = [
  {
    "name": "testType1",
    "pos": 0,
    "type": "type",
    "comment": "use testType for documentation example",
    "tags": []
  },
  {
    "name": "testDoc",
    "pos": 368,
    "type": "interface",
    "comment": "interface for test documentations\n\nUse Markdown, ex: from https://google.github.io/styleguide/jsguide.html#jsdoc\nComputes weight based on three factors:\n\n - items sent\n - items received\n - last timestamp",
    "tags": [],
    "members": [
      {
        "name": "optional1",
        "type": "string",
        "comment": "test for modifier optional",
        "modifiers": [
          "optional"
        ],
        "tags": [
          {
            "name": "",
            "tagName": "link",
            "comment": "https://www.typescriptlang.org/docs/handbook/interfaces.html#optional-properties"
          }
        ]
      },
      {
        "name": "testExternalDoc",
        "type": "string",
        "comment": "doc for parameter testExternalDoc (in class doc)",
        "modifiers": [],
        "tags": []
      },
      {
        "name": "y",
        "type": "number",
        "comment": "test for modifier readonly",
        "modifiers": [
          "readonly"
        ],
        "tags": [
          {
            "name": "",
            "tagName": "link",
            "comment": "https://www.typescriptlang.org/docs/handbook/interfaces.html#readonly-properties"
          }
        ]
      },
      {
        "name": "[index]",
        "type": "unknown",
        "comment": "test for index property",
        "modifiers": [
          "index"
        ],
        "parameters": [
          {
            "name": "propName",
            "pos": 1183,
            "comment": "",
            "type": "string",
            "modifiers": []
          }
        ],
        "tags": [
          {
            "name": "",
            "tagName": "link",
            "comment": "https://www.typescriptlang.org/docs/handbook/interfaces.html#excess-property-checks"
          }
        ]
      },
      {
        "name": "(call)",
        "type": "boolean",
        "comment": "test for functions types",
        "modifiers": [
          "call"
        ],
        "parameters": [
          {
            "name": "source",
            "pos": 1338,
            "comment": "",
            "type": "string",
            "modifiers": []
          },
          {
            "name": "subString",
            "pos": 1353,
            "comment": "",
            "type": "string",
            "modifiers": []
          }
        ],
        "tags": [
          {
            "name": "",
            "tagName": "link",
            "comment": "https://www.typescriptlang.org/docs/handbook/interfaces.html#function-types"
          }
        ]
      },
      {
        "name": "[index]",
        "type": "string",
        "comment": "test for Indexable Types",
        "modifiers": [
          "index"
        ],
        "parameters": [
          {
            "name": "index",
            "pos": 1511,
            "comment": "",
            "type": "number",
            "modifiers": []
          }
        ],
        "tags": [
          {
            "name": "",
            "tagName": "link",
            "comment": "https://www.typescriptlang.org/docs/handbook/interfaces.html#indexable-types"
          }
        ]
      },
      {
        "name": "setTime",
        "type": "void",
        "comment": "test for interface class type",
        "modifiers": [],
        "parameters": [
          {
            "name": "d",
            "pos": 1705,
            "comment": "doc for parameter d",
            "type": "Date",
            "modifiers": []
          },
          {
            "name": "e",
            "pos": 1713,
            "comment": "",
            "type": "string",
            "modifiers": []
          }
        ],
        "tags": [
          {
            "name": "",
            "tagName": "link",
            "comment": "https://www.typescriptlang.org/docs/handbook/interfaces.html#class-types"
          }
        ]
      },
      {
        "name": "testNoDoc",
        "type": "unknown",
        "comment": "",
        "modifiers": [],
        "tags": []
      },
      {
        "name": "(construct)",
        "type": "testDoc",
        "comment": "test for interface constructor",
        "modifiers": [
          "construct"
        ],
        "parameters": [
          {
            "name": "property",
            "pos": 1981,
            "comment": "doc for parameter property",
            "type": "string",
            "modifiers": []
          }
        ],
        "tags": [
          {
            "name": "",
            "tagName": "link",
            "comment": "https://www.typescriptlang.org/docs/handbook/interfaces.html#class-types"
          }
        ]
      }
    ]
  },
  {
    "name": "clTest2",
    "pos": 2010,
    "type": "class",
    "comment": "comment for class 2",
    "members": [
      {
        "name": "f1",
        "pos": 2128,
        "type": "function",
        "comment": "comment for f1\ncomment for f1",
        "modifiers": [],
        "parameters": [
          {
            "name": "_a",
            "pos": 2452,
            "comment": "",
            "type": "string",
            "modifiers": []
          },
          {
            "name": "_b",
            "pos": 2486,
            "comment": "",
            "type": "any",
            "modifiers": [
              "optional"
            ]
          }
        ],
        "tags": [
          {
            "name": "",
            "tagName": "result",
            "comment": "nothing"
          },
          {
            "name": "b",
            "tagName": "param",
            "comment": "b must by any"
          },
          {
            "name": "",
            "tagName": "todo",
            "comment": "Don't forget the milk"
          },
          {
            "name": "",
            "tagName": "todo",
            "comment": "Make this method do something useful"
          },
          {
            "name": "",
            "tagName": "event",
            "comment": "document#mousedown y"
          },
          {
            "name": "",
            "tagName": "throws",
            "comment": "Error exception if a > 10"
          },
          {
            "name": "",
            "tagName": "throws",
            "comment": "BadError something bad happened"
          },
          {
            "name": "",
            "tagName": "result",
            "comment": "nothing"
          }
        ]
      },
      {
        "name": "clTest",
        "pos": 2559,
        "type": "function",
        "comment": "constructor of clTest \n<br>\nExample\n```\nvar me = getMe();\n\n// do one\n\nme.one();\n\n```",
        "modifiers": [
          "public"
        ],
        "tags": []
      },
      {
        "name": "v1",
        "pos": 2705,
        "type": "property",
        "comment": "",
        "modifiers": [
          "public"
        ],
        "tags": []
      }
    ],
    "tags": [
      {
        "name": "v1",
        "tagName": "param",
        "comment": "comment for member v1 (error, must be next to v1)"
      }
    ]
  }
];
export {
  getJson
};
