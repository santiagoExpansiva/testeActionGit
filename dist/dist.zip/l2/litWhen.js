function when(condition, trueCase, falseCase) {
  return condition ? trueCase() : falseCase === null || falseCase === void 0 ? void 0 : falseCase();
}
export {
  when
};
