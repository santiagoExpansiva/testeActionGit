var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html } from "lit";
import { customElement, query } from "lit/decorators.js";
import { tasks, updateTaskOnServer } from "./_100554_aimHelper";
import { AimActionBase } from "./_100554_aimActionBase";
import { getInfoMyService } from "./_100554_aimHelper";
var myName = "_100554_aimActionStyleNew";
var message_pt = {
  prompt_title: "Objetivo:Criar um novo CSS em LESS.",
  prompt_system_1: "Use LESS para criar um novo estilo baseado na fonte fornecida abaixo, incorporando sugest\uFFFDes do usu\uFFFDrio.",
  prompt_system_2: "Desenvolva um arquivo LESS isolado, empregando tokens conforme descrito no modelo abaixo.",
  prompt_system_3: "Formato de Sa\uFFFDda Esperado: Retorne o CSS rec\uFFFDm-criado na linguagem LESS, em um \uFFFDnico bloco sem a listagem de tokens. Coment\uFFFDrios de c\uFFFDdigo devem estar em ingl\uFFFDs, mas mantenha coment\uFFFDrios existentes que sirvam como auxiliares de UI.",
  template_title: "Ir\uFFFD verificar os tokens e criar um novo conjunto de tokens",
  template_suggest: "Sugest\uFFFDo:",
  textarea_placelholder: "Digite aqui seu prompt",
  btn_cancel: "Cancelar",
  btn_confirm: "Confirmar"
};
var message_en = {
  prompt_title: "Objective:Create a new css in LESS.",
  prompt_system_1: "Use LESS to craft a new style based on the source provided below, incorporating user suggestions.",
  prompt_system_2: "Develop an isolated LESS file, employing tokens as outlined in the model below.",
  prompt_system_3: "Expected Output Format: Return the newly created CSS in the LESS language, in a single block without the token listing. Code comments should be in English, but keep existing comments that serve as UI aids.",
  template_title: "Will check the tokens and create a new set of tokens",
  template_suggest: "Suggestion:",
  textarea_placelholder: "Type your prompt here",
  btn_cancel: "Cancel",
  btn_confirm: "Confirm"
};
var messages = {
  "en-us": message_en,
  "pt-br": message_pt
};
var AimActionStyleNew = (
  /** @class */
  function(_super) {
    __extends(AimActionStyleNew2, _super);
    function AimActionStyleNew2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.msg = messages["en-us"];
      _this.assistant = "gpt3_less";
      _this.title = "New Style";
      _this.language = "english";
      _this.prompts = [
        "Adicionar uma anima\uFFFD\uFFFDo de entrada",
        "Adicionar uma personaliza\uFFFD\uFFFDo no scrollbar, deixando mais minimalista"
      ];
      return _this;
    }
    AimActionStyleNew2.prototype.getRules = function() {
      return {
        levels: [3],
        tags: ["*serviceDsStyle*"]
      };
    };
    AimActionStyleNew2.prototype.handleCancel = function() {
      this.dispatchEvent(new CustomEvent("add-task", {
        detail: { cancel: "true" },
        bubbles: true,
        composed: true
      }));
    };
    AimActionStyleNew2.prototype.handleAdd = function() {
      var _a2;
      this.taskRoot = {
        mode: "initializing",
        title: "verify css and create",
        widget: myName,
        children: [],
        args: ((_a2 = this.textarea) === null || _a2 === void 0 ? void 0 : _a2.value) || "",
        trace: [(/* @__PURE__ */ new Date()).toISOString() + ": trask created at "]
      };
      tasks.unshift(this.taskRoot);
      this.prepareTask1(this.taskRoot);
      this.dispatchEvent(new CustomEvent("finished-add-task-root", {
        detail: this.taskRoot,
        bubbles: true,
        composed: true
      }));
    };
    AimActionStyleNew2.prototype.setResultInEditor = function(value, root) {
      var activeOpService = getActiveOpServiceIfIsValid(this);
      if (!activeOpService) {
        window.collabMessages.add("The service in the opposite position does not refer to this action", "error");
        return false;
      }
      ;
      var isValid = isValidRef(root, activeOpService);
      if (!isValid) {
        window.collabMessages.add("Invalid Ref", "error");
        return false;
      }
      ;
      activeOpService.setEditorSource(value);
      return true;
    };
    AimActionStyleNew2.prototype.onSuggestClick = function(e) {
      if (!this.textarea)
        return;
      var text = "";
      var target = e.target;
      var txtEl = target.querySelector("span");
      if (!txtEl)
        text = target.innerText;
      else
        text = txtEl.innerText;
      this.textarea.value = text;
    };
    AimActionStyleNew2.prototype.renderAdd = function() {
      var _this = this;
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n        <p> ", " </p>\n        <div>\n            <label>", '</label>\n            <div class="prompt-suggestion">\n                ', '\n            </div>\n        <div>\n\n        <div>\n            <label>Prompt:</label>\n            <textarea rows="5" placeholder="', ' style="width:100%"></textarea>\n        </div>\n\n        <div class="buttonGroup">\n          <button @click="', '">', '</button>\n          <button @click="', '">', "</button>\n        </div>\n    "], ["\n        <p> ", " </p>\n        <div>\n            <label>", '</label>\n            <div class="prompt-suggestion">\n                ', '\n            </div>\n        <div>\n\n        <div>\n            <label>Prompt:</label>\n            <textarea rows="5" placeholder="', ' style="width:100%"></textarea>\n        </div>\n\n        <div class="buttonGroup">\n          <button @click="', '">', '</button>\n          <button @click="', '">', "</button>\n        </div>\n    "])), this.msg.template_title, this.msg.template_suggest, this.prompts.map(function(prompt) {
        return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n                    <span @click=", ">\n                        <span >", "</span>\n                    </span>\n                "], ["\n                    <span @click=", ">\n                        <span >", "</span>\n                    </span>\n                "])), _this.onSuggestClick, prompt);
      }), this.msg.textarea_placelholder, this.handleCancel, this.msg.btn_cancel, this.handleAdd, this.msg.btn_confirm);
    };
    AimActionStyleNew2.prototype.getPrompt = function(source, user) {
      var prompt = "\n".concat(this.msg.prompt_title, "\n\nSystem:\n1. ").concat(this.msg.prompt_system_1, "\n2  ").concat(this.msg.prompt_system_2, "\n\nUser:\n1. ").concat(user, "\n\n").concat(this.msg.prompt_system_3, "\n        \n").concat(source);
      return prompt;
    };
    AimActionStyleNew2.prototype.prepareTask1 = function(taskRoot) {
      this.mode = taskRoot.mode = "in progress";
      this.addTaskAndWaitForCompletion(taskRoot, {
        mode: "initializing",
        title: "get less source",
        widget: "_100554_aimTaskDsStyles",
        trace: [],
        nextStep: this.prepareTask2.name
        // danger, loop
      });
    };
    AimActionStyleNew2.prototype.prepareTask2 = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      if (taskFinishResult.status === "error") {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        return;
      }
      var source = taskFinishResult.result;
      if (!source) {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        child.trace.push("invalid finish , must be notify finish with result field");
        this.requestUpdate();
        return;
      }
      child.mode = "processed";
      this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
        mode: "initializing",
        title: "exec prompt",
        widget: "_100554_aimTaskExecLLM",
        ref: child.ref,
        agent: this.assistant,
        prompt: this.getPrompt(source, taskFinishResult.taskRoot.args || ""),
        trace: [],
        nextStep: this.prepareTask3.name
        // danger, loop
      });
      this.requestUpdate();
    };
    AimActionStyleNew2.prototype.prepareTask3 = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      var result = child.result || "";
      if (taskFinishResult.status === "error" || !result) {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        return;
      }
      child.mode = "processed";
      this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
        mode: "initializing",
        title: "result",
        widget: "_100554_aimTaskResultLess",
        ref: child.ref,
        trace: [],
        _tempResult: result,
        nextStep: this.prepareTask4.name
        // danger, loop
      });
      this.requestUpdate();
    };
    AimActionStyleNew2.prototype.prepareTask4 = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      if (taskFinishResult.status === "ok" || taskFinishResult.status === "error" || taskFinishResult.status === "rejected") {
        return this.endTasks(taskFinishResult);
      }
      if (taskFinishResult.status !== "userEvent")
        throw new Error("Event not prepared");
      if (taskFinishResult.taskRoot.children.length > 20)
        throw new Error("Maximum task exceted");
      if (!taskFinishResult.newPrompt)
        throw new Error("Prompt invalid");
      var source = taskFinishResult.result;
      if (!source) {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        child.trace.push("invalid finish , must be notify finish with result field");
        this.requestUpdate();
        return;
      }
      child.mode = "processed";
      this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
        mode: "initializing",
        title: "exec prompt",
        widget: "_100554_aimTaskExecLLM",
        ref: child.ref,
        agent: this.assistant,
        prompt: this.getPrompt(source, taskFinishResult.newPrompt),
        trace: [],
        nextStep: this.prepareTask3.name
        // looping exec prompt
      });
    };
    AimActionStyleNew2.prototype.endTasks = function(taskFinishResult) {
      var taskChild = taskFinishResult.taskChild, taskRoot = taskFinishResult.taskRoot, status = taskFinishResult.status, result = taskFinishResult.result;
      if (status === "error")
        taskChild.mode = "error";
      else if (status === "rejected")
        taskChild.mode = "processed";
      else if (status === "ok") {
        taskChild.mode = "processed";
        this.setResultInEditor(result || "", taskRoot);
      }
      this.mode = taskFinishResult.taskRoot.mode = taskChild.mode;
      this.requestUpdate();
      updateTaskOnServer(taskFinishResult.taskIndex);
    };
    var _a;
    __decorate([
      query("textarea"),
      __metadata("design:type", typeof (_a = typeof HTMLTextAreaElement !== "undefined" && HTMLTextAreaElement) === "function" ? _a : Object)
    ], AimActionStyleNew2.prototype, "textarea", void 0);
    AimActionStyleNew2 = __decorate([
      customElement("aim-action-style-new-100554")
    ], AimActionStyleNew2);
    return AimActionStyleNew2;
  }(AimActionBase)
);
function isValidRef(taskRoot, activeOpService) {
  var actualRef = activeOpService.getActualRef();
  var taskWithRef = taskRoot.children.find(function(task) {
    return task.widget === "_100554_aimTaskDsStyles";
  });
  if (!taskWithRef)
    return false;
  return taskWithRef.ref === actualRef;
}
function getActiveOpServiceIfIsValid(el) {
  var info = getInfoMyService(el);
  if (!info)
    return void 0;
  var activeServiceOp = info.actServiceOp;
  if (activeServiceOp.tagName !== "SERVICE-DS-STYLES-100554")
    return void 0;
  if (!activeServiceOp.isComponent)
    return void 0;
  return activeServiceOp;
}
var templateObject_1, templateObject_2;
export {
  AimActionStyleNew,
  getActiveOpServiceIfIsValid,
  isValidRef
};
