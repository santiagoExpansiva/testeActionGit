var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css, repeat } from "lit";
import { customElement, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
var message_pt = {
  display: "Exibi\uFFFD\uFFFDo",
  flexDirection: "Dire\uFFFD\uFFFDo flex\uFFFDvel",
  flexWrap: "Envolt\uFFFDrio flex\uFFFDvel",
  justifyContent: "Justificar conte\uFFFDdo",
  alignItems: "Alinhar itens",
  alignContent: "Alinhar conte\uFFFDdo",
  alignSelf: "Alinhar-se",
  order: "Ordem"
};
var message_en = {
  display: "Display",
  flexDirection: "Flex direction",
  flexWrap: "Flex wrap",
  justifyContent: "Justify content",
  alignItems: "Align items",
  alignContent: "Align content",
  alignSelf: "Align self",
  order: "Order"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceDsStyleFlex = (
  /** @class */
  function(_super) {
    __extends(ServiceDsStyleFlex2, _super);
    function ServiceDsStyleFlex2() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.myUpp = false;
      _this.error = "";
      _this.helper = "_100554_serviceDsStyleFlex";
      _this.details = {
        icon: "&#xf009",
        state: "foreground",
        position: "right",
        tooltip: "Flex",
        tags: ["ds_styles"],
        visible: false,
        widget: "_100554_serviceDsStyleFlex",
        level: [3]
      };
      _this.onClickLink = function(op) {
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.onClickIcon = function(op) {
      };
      _this.menu = {
        title: "Flex",
        actions: {},
        icons: {},
        actionDefault: "",
        // call after close icon clicked
        iconDefault: "",
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        onClickIcon: _this.onClickIcon
      };
      _this.timeonChangeProp = -1;
      _this.timeLoader = -1;
      _this.arrayGallery = [
        "display: flex;flex-direction: row; justify-content: flex-start;border: 1px solid #cccccc;margin-left: 10px; width:120px;padding: 5px; cursor: pointer;background:white",
        "display: flex; flex-direction: row; justify-content: flex-end; border: 1px solid rgb(204, 204, 204); margin-left: 10px; width: 120px; padding: 5px; cursor: pointer;background:white",
        "display: flex; flex-direction: row; justify-content: center; border: 1px solid rgb(204, 204, 204); margin-left: 10px; width: 120px; padding: 5px; cursor: pointer;background:white",
        "display: flex; flex-direction: row; justify-content: space-between; border: 1px solid rgb(204, 204, 204); margin-left: 10px; width: 120px; padding: 5px; cursor: pointer;background:white",
        "display: flex;flex-direction: column; justify-content: flex-start;border: 1px solid #cccccc;margin-left: 10px; width:60px;height:200px; padding: 5px; cursor: pointer;background:white",
        "display: flex;flex-direction: column; justify-content: flex-end;border: 1px solid #cccccc;margin-left: 10px; width:60px;height:200px; padding: 5px; cursor: pointer;background:white",
        "display: flex;flex-direction: column; justify-content: center;border: 1px solid #cccccc;margin-left: 10px; width:60px;height:200px; padding: 5px; cursor: pointer;background:white",
        "display: flex;flex-direction: column; justify-content: space-between;border: 1px solid #cccccc;margin-left: 10px; width:60px;height:200px; padding: 5px; cursor: pointer;background:white"
      ];
      _this.setEvents();
      return _this;
    }
    ServiceDsStyleFlex2.prototype.onServiceClick = function(visible, reinit) {
      if (visible || reinit) {
        this.fireEventAboutMe();
      }
    };
    ServiceDsStyleFlex2.prototype.setEvents = function() {
      var _this = this;
      mls.events.addEventListener([3], ["DSStyleChanged"], function(ev) {
        _this.onstylechanged(ev.desc);
      });
      mls.events.addEventListener([3], ["DSStyleSelected"], function(ev) {
        _this.onDSStyleSelected(ev);
      });
      mls.events.addEventListener([3], ["DSStyleUnSelected"], function(ev) {
        _this.onDSStyleUnSelected(ev);
      });
      mls.events.addEventListener([3], ["DSStyleCursorChanged"], function(ev) {
        _this.onDSStyleCursorChanged(ev);
      });
    };
    ServiceDsStyleFlex2.prototype.onstylechanged = function(desc) {
      var obj = JSON.parse(desc);
      if (obj.emitter === "left" && this.visible === "true" && obj.value.length > 0) {
        this.setValues(obj.value);
      }
    };
    ServiceDsStyleFlex2.prototype.setValues = function(ar) {
      var _this = this;
      this.myUpp = true;
      ar.forEach(function(i) {
        if (!_this.shadowRoot || !i.key)
          return;
        var value = i.value;
        var prop = i.key;
        var el = _this.shadowRoot.querySelector('*[prop="' + prop + '"]');
        if (el)
          el.value = value;
      });
      this.myUpp = false;
    };
    ServiceDsStyleFlex2.prototype.onDSStyleSelected = function(ev) {
      var params = ev.desc ? JSON.parse(ev.desc) : [];
      if (params.service.length > 0 && !params.service.includes(this.helper) || !this.serviceItemNav)
        return;
      this.serviceItemNav.setAttribute("mode", "A");
      this.showNav2Item(true);
    };
    ServiceDsStyleFlex2.prototype.onDSStyleUnSelected = function(ev) {
      var params = ev.desc ? JSON.parse(ev.desc) : [];
      if (params.service.includes(this.helper) || !this.serviceItemNav)
        return;
      this.serviceItemNav.setAttribute("mode", "H");
      this.showNav2Item(false);
    };
    ServiceDsStyleFlex2.prototype.onDSStyleCursorChanged = function(ev) {
      var rc = JSON.parse(ev.desc);
      if (rc.helper === this.helper) {
        if (this.visible === "true" || !this.serviceItemNav)
          return;
        this.serviceItemNav.click();
      }
    };
    ServiceDsStyleFlex2.prototype.connectedCallback = function() {
      _super.prototype.connectedCallback.call(this);
    };
    ServiceDsStyleFlex2.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["", "", "", ""], ["", "", "", ""])), this.renderFlex(), this.renderFlexItem(), this.renderGallery());
    };
    ServiceDsStyleFlex2.prototype.renderFlex = function() {
      var _this = this;
      return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(['\n            <div>\n                <h5>Flex</h5>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" style="width:150px" prop="display">\n                        <option value=""></option>\n                        <option value="flex">Flex</option>\n                        <option value="inline-flex">Inline Flex</option>\n                    </select>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" style="width:150px" prop="flex-direction">\n                        <option value=""></option>\n                        <option value="row">Row</option>\n                        <option value="row-reverse">Row Reverse</option>\n                        <option value="column">Column</option>\n                        <option value="column-reverse">Column Reverse</option>\n                    </select>   \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" style="width:150px" prop="flex-wrap">\n                        <option value=""></option>\n                        <option value="nowrap">Nowrap</option>\n                        <option value="wrap">Wrap</option>\n                        <option value="wrap-reverse">Wrap Reverse</option>\n                    </select>  \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" style="width:150px" prop="justify-content">\n                        <option value=""></option>\n                        <option value="flex-start">Flex start</option>\n                        <option value="flex-end">Flex end</option>\n                        <option value="center">Center</option>\n                        <option value="space-between">Space between</option>\n                        <option value="space-around">Space around</option>\n                    </select>  \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" style="width:150px" prop="align-items">\n                        <option value=""></option>\n                        <option value="flex-start">Flex start</option>\n                        <option value="flex-end">Flex end</option>\n                        <option value="center">Center</option>\n                        <option value="baseline">Baseline</option>\n                        <option value="stretch">Stretch</option>\n                    </select>  \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" style="width:150px" prop="align-content">\n                        <option value=""></option>\n                        <option value="flex-start">Flex start</option>\n                        <option value="flex-end">Flex end</option>\n                        <option value="center">Center</option>\n                        <option value="space-between">Space between</option>\n                        <option value="space-around">Space around</option>\n                        <option value="stretch">Stretch</option>\n                    </select>  \n                </div>\n            </div>\n        \n        '], ['\n            <div>\n                <h5>Flex</h5>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" style="width:150px" prop="display">\n                        <option value=""></option>\n                        <option value="flex">Flex</option>\n                        <option value="inline-flex">Inline Flex</option>\n                    </select>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" style="width:150px" prop="flex-direction">\n                        <option value=""></option>\n                        <option value="row">Row</option>\n                        <option value="row-reverse">Row Reverse</option>\n                        <option value="column">Column</option>\n                        <option value="column-reverse">Column Reverse</option>\n                    </select>   \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" style="width:150px" prop="flex-wrap">\n                        <option value=""></option>\n                        <option value="nowrap">Nowrap</option>\n                        <option value="wrap">Wrap</option>\n                        <option value="wrap-reverse">Wrap Reverse</option>\n                    </select>  \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" style="width:150px" prop="justify-content">\n                        <option value=""></option>\n                        <option value="flex-start">Flex start</option>\n                        <option value="flex-end">Flex end</option>\n                        <option value="center">Center</option>\n                        <option value="space-between">Space between</option>\n                        <option value="space-around">Space around</option>\n                    </select>  \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" style="width:150px" prop="align-items">\n                        <option value=""></option>\n                        <option value="flex-start">Flex start</option>\n                        <option value="flex-end">Flex end</option>\n                        <option value="center">Center</option>\n                        <option value="baseline">Baseline</option>\n                        <option value="stretch">Stretch</option>\n                    </select>  \n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" style="width:150px" prop="align-content">\n                        <option value=""></option>\n                        <option value="flex-start">Flex start</option>\n                        <option value="flex-end">Flex end</option>\n                        <option value="center">Center</option>\n                        <option value="space-between">Space between</option>\n                        <option value="space-around">Space around</option>\n                        <option value="stretch">Stretch</option>\n                    </select>  \n                </div>\n            </div>\n        \n        '])), this.msg.display, function() {
        return _this.onChangeProp("display");
      }, this.msg.flexDirection, function() {
        return _this.onChangeProp("flex-direction");
      }, this.msg.flexWrap, function() {
        return _this.onChangeProp("flex-wrap");
      }, this.msg.justifyContent, function() {
        return _this.onChangeProp("justify-content");
      }, this.msg.alignItems, function() {
        return _this.onChangeProp("align-items");
      }, this.msg.alignContent, function() {
        return _this.onChangeProp("align-content");
      });
    };
    ServiceDsStyleFlex2.prototype.renderFlexItem = function() {
      var _this = this;
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['\n            <div>\n                <h5>Flex-Item</h5>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" style="width:150px" prop="align-self">\n                        <option value=""></option>\n                        <option value="auto">auto</option>\n                        <option value="flex-start">Flex start</option>\n                        <option value="flex-end">Flex end</option>\n                        <option value="center">Center</option>\n                        <option value="baseline">Baseline</option>\n                        <option value="stretch">Stretch</option>\n                    </select>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" style="width:150px" prop="order">\n                        <option value=""></option>\n                        <option value="1">1</option>\n                        <option value="2">2</option>\n                        <option value="3">3</option>\n                        <option value="4">4</option>\n                        <option value="5">5</option>\n                        <option value="6">6</option>\n                        <option value="7">7</option>\n                        <option value="8">8</option>\n                        <option value="9">9</option>\n                        <option value="10">10</option>\n                        \n                    </select>   \n                </div>\n                \n            </div>\n        \n        '], ['\n            <div>\n                <h5>Flex-Item</h5>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" style="width:150px" prop="align-self">\n                        <option value=""></option>\n                        <option value="auto">auto</option>\n                        <option value="flex-start">Flex start</option>\n                        <option value="flex-end">Flex end</option>\n                        <option value="center">Center</option>\n                        <option value="baseline">Baseline</option>\n                        <option value="stretch">Stretch</option>\n                    </select>\n                </div>\n                <div class="groupEdit">\n                    <span>', '</span>\n                    <select @change="', '" style="width:150px" prop="order">\n                        <option value=""></option>\n                        <option value="1">1</option>\n                        <option value="2">2</option>\n                        <option value="3">3</option>\n                        <option value="4">4</option>\n                        <option value="5">5</option>\n                        <option value="6">6</option>\n                        <option value="7">7</option>\n                        <option value="8">8</option>\n                        <option value="9">9</option>\n                        <option value="10">10</option>\n                        \n                    </select>   \n                </div>\n                \n            </div>\n        \n        '])), this.msg.alignSelf, function() {
        return _this.onChangeProp("align-self");
      }, this.msg.order, function() {
        return _this.onChangeProp("order");
      });
    };
    ServiceDsStyleFlex2.prototype.renderGallery = function() {
      var _this = this;
      return html(templateObject_6 || (templateObject_6 = __makeTemplateObject(['\n            <div style="display: flex; justify-content: center; align-items: center; gap: 1rem; padding: 1rem; flex-wrap: wrap; cursor:pointer;border:none">\n                ', '\n            </div>\n            <div style="display: flex; justify-content: center; align-items: center; gap: 1rem; padding: 1rem; flex-wrap: wrap; cursor:pointer">\n                ', "\n            </div>\n        \n        "], ['\n            <div style="display: flex; justify-content: center; align-items: center; gap: 1rem; padding: 1rem; flex-wrap: wrap; cursor:pointer;border:none">\n                ', '\n            </div>\n            <div style="display: flex; justify-content: center; align-items: center; gap: 1rem; padding: 1rem; flex-wrap: wrap; cursor:pointer">\n                ', "\n            </div>\n        \n        "])), repeat(this.arrayGallery.slice(0, 4), function(key) {
        return key;
      }, function(css2, index) {
        return html(templateObject_4 || (templateObject_4 = __makeTemplateObject(['<div style="', '" @click="', '" .gallery=', '>\n                            <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=', '></span>\n                            <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=', '></span>\n                            <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=', "></span>\n                        </div>"], ['<div style="', '" @click="', '" .gallery=', '>\n                            <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=', '></span>\n                            <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=', '></span>\n                            <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=', "></span>\n                        </div>"])), css2, _this.clickGallery, css2, css2, css2, css2);
      }), repeat(this.arrayGallery.slice(4, 8), function(key) {
        return key;
      }, function(css2, index) {
        return html(templateObject_5 || (templateObject_5 = __makeTemplateObject(['<div style="', '" @click="', '" .gallery=', '>\n                    <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=', '></span>\n                    <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=', '></span>\n                    <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=', "></span>\n                </div>"], ['<div style="', '" @click="', '" .gallery=', '>\n                    <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=', '></span>\n                    <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=', '></span>\n                    <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=', "></span>\n                </div>"])), css2, _this.clickGallery, css2, css2, css2, css2);
      }));
    };
    ServiceDsStyleFlex2.prototype.onChangeProp = function(prop) {
      var _this = this;
      clearTimeout(this.timeonChangeProp);
      this.timeonChangeProp = setTimeout(function() {
        if (!_this.shadowRoot)
          return;
        var el = _this.shadowRoot.querySelector('*[prop="' + prop + '"]');
        _this.emitEvent({ key: prop, value: el.value });
      }, 500);
    };
    ServiceDsStyleFlex2.prototype.fireEventAboutMe = function() {
      var rc = {
        emitter: "right-get"
      };
      mls.events.fire([3], ["DSStyleChanged"], JSON.stringify(rc), 500);
    };
    ServiceDsStyleFlex2.prototype.emitEvent = function(obj) {
      if (this.myUpp)
        return;
      var rc = {
        emitter: this.position,
        value: [obj],
        helper: this.helper
      };
      if (typeof mls !== "object")
        return;
      mls.events.fire([3], ["DSStyleChanged"], JSON.stringify(rc));
    };
    ServiceDsStyleFlex2.prototype.showLoader = function(loader) {
      var _this = this;
      clearTimeout(this.timeLoader);
      this.timeLoader = setTimeout(function() {
        _this.loading = loader;
      }, 200);
    };
    ServiceDsStyleFlex2.prototype.clickGallery = function(e) {
      var el = e.target;
      if (!el)
        return;
      var css2 = el.gallery;
      if (!css2)
        return;
      var commands = css2.split(";");
      var changes = [];
      commands.forEach(function(item) {
        var _a = item.split(":"), key = _a[0], value = _a[1];
        if (!key)
          return;
        changes.push({
          key: key.trim(),
          value: value.trim()
        });
      });
      var rc = {
        emitter: "right",
        value: changes,
        helper: this.helper
      };
      this.setValues(changes);
      mls.events.fire([3], ["DSStyleChanged"], JSON.stringify(rc));
    };
    ServiceDsStyleFlex2.styles = css(templateObject_7 || (templateObject_7 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceDsStyleFlex2.prototype, "error", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceDsStyleFlex2.prototype, "helper", void 0);
    ServiceDsStyleFlex2 = __decorate([
      customElement("service-ds-style-flex-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceDsStyleFlex2);
    return ServiceDsStyleFlex2;
  }(ServiceBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6, templateObject_7;
export {
  ServiceDsStyleFlex
};
