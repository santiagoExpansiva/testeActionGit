var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __assign = function() {
  __assign = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
        t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var __spreadArray = function(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};
import { html, css } from "lit";
import { customElement, property, query } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
var message_pt = {
  themes: "Temas",
  deleteThisTheme: "Deletar este tema",
  updateThisTheme: "Atualizar este tema",
  revertTokensToOriginal: "Reverter tokens para o original",
  addTheme: "Adicionar tema",
  themeName: "Nome do tema",
  description: "Descri\uFFFD\uFFFDo",
  confirm: "Confirmar",
  cancel: "Cancelar"
};
var message_en = {
  themes: "Themes",
  deleteThisTheme: "Delete this theme",
  updateThisTheme: "Update this theme",
  revertTokensToOriginal: "Revert tokens to original",
  addTheme: "Add theme",
  themeName: "Theme name",
  description: "Description",
  confirm: "Confirm",
  cancel: "Cancel"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceDsColors100554 = (
  /** @class */
  function(_super) {
    __extends(ServiceDsColors1005542, _super);
    function ServiceDsColors1005542() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.details = {
        icon: "&#xf53f",
        state: "foreground",
        tooltip: "Colors",
        visible: false,
        position: "right",
        tags: ["ds_tokens"],
        widget: "_100554_serviceDsColors",
        level: [3]
      };
      _this.onClickLink = function(op) {
        if (op === "opHelper")
          return _this.showHelper();
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.menu = {
        title: "Colors",
        actions: {
          opHelper: "Colors"
        },
        icons: {},
        actionDefault: "opHelper",
        // call after close icon clicked
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        getLastMode: void 0,
        updateTitle: void 0
      };
      _this.themes = {};
      _this.showAddContainer = false;
      _this.themeList = [];
      _this.newDataTokens = {};
      _this.defaultThemeList = [];
      _this.userThemeList = [];
      _this.selectedTheme = "default";
      _this.keysName = {
        default: "",
        lightAiry: "Light and Airy",
        minimalist: "Minimalist Monochrome",
        vibrantenergetic: "Vibrant and Energetic",
        pasteldream: "Pastel Dream",
        retrovibes: "Retro Vibes",
        nature: "Nature-Inspired",
        urbanchic: "Urban Chic",
        sunsetgradient: "Sunset Gradient",
        oceandepths: "Ocean Depths"
      };
      _this.mythemes = {
        lightAiry: {
          isdefault: true,
          description: "This theme uses light and soft tones to create a sense of lightness and space.",
          tokens: [
            { key: "text-primary-color-lighter", value: "#91a9d3", category: "color" },
            { key: "text-primary-color", value: "#1890FF", category: "color" },
            { key: "text-primary-color-darker", value: "#0C53B7", category: "color" },
            { key: "text-secondary-color-lighter", value: "#F0F5FF", category: "color" },
            { key: "text-secondary-color", value: "#096DD9", category: "color" },
            { key: "text-secondary-color-darker", value: "#054A91", category: "color" },
            { key: "bg-primary-color-lighter", value: "#F4F8FF", category: "color" },
            { key: "bg-primary-color", value: "#E6F7FF", category: "color" },
            { key: "bg-primary-color-darker", value: "#D6E4FF", category: "color" },
            { key: "bg-secondary-color-lighter", value: "#F0F5FF", category: "color" },
            { key: "bg-secondary-color", value: "#BAE7FF", category: "color" },
            { key: "bg-secondary-color-darker", value: "#91D5FF", category: "color" },
            { key: "grey-color-lighter", value: "#F5F5F5", category: "color" },
            { key: "grey-color-light", value: "#D9D9D9", category: "color" },
            { key: "grey-color", value: "#BFBFBF", category: "color" },
            { key: "grey-color-dark", value: "#8C8C8C", category: "color" },
            { key: "grey-color-darker", value: "#595959", category: "color" },
            { key: "error-color", value: "#FF4D4F", category: "color" },
            { key: "success-color", value: "#52C41A", category: "color" },
            { key: "warning-color", value: "#FAAD14", category: "color" },
            { key: "info-color", value: "#1890FF", category: "color" },
            { key: "active-color", value: "#1890FF", category: "color" },
            { key: "link-color", value: "#1890FF", category: "color" },
            { key: "link-hover-color", value: "#40A9FF", category: "color" },
            { key: "_dark-text-primary-color-lighter", value: "#e7ebee", category: "color" },
            { key: "_dark-text-primary-color", value: "#1890FF", category: "color" },
            { key: "_dark-text-primary-color-darker", value: "#40A9FF", category: "color" },
            { key: "_dark-text-secondary-color-lighter", value: "#002140", category: "color" },
            { key: "_dark-text-secondary-color", value: "#096DD9", category: "color" },
            { key: "_dark-text-secondary-color-darker", value: "#40A9FF", category: "color" },
            { key: "_dark-bg-primary-color-lighter", value: "#001529", category: "color" },
            { key: "_dark-bg-primary-color", value: "#002140", category: "color" },
            { key: "_dark-bg-primary-color-darker", value: "#002855", category: "color" },
            { key: "_dark-bg-secondary-color-lighter", value: "#001529", category: "color" },
            { key: "_dark-bg-secondary-color", value: "#002140", category: "color" },
            { key: "_dark-bg-secondary-color-darker", value: "#002855", category: "color" },
            { key: "_dark-grey-color-lighter", value: "#F5F5F5", category: "color" },
            { key: "_dark-grey-color-light", value: "#D9D9D9", category: "color" },
            { key: "_dark-grey-color", value: "#BFBFBF", category: "color" },
            { key: "_dark-grey-color-dark", value: "#8C8C8C", category: "color" },
            { key: "_dark-grey-color-darker", value: "#595959", category: "color" },
            { key: "_dark-error-color", value: "#FF4D4F", category: "color" },
            { key: "_dark-success-color", value: "#52C41A", category: "color" },
            { key: "_dark-warning-color", value: "#FAAD14", category: "color" },
            { key: "_dark-info-color", value: "#1890FF", category: "color" },
            { key: "_dark-active-color", value: "#1890FF", category: "color" },
            { key: "_dark-link-color", value: "#1890FF", category: "color" },
            { key: "_dark-link-hover-color", value: "#40A9FF", category: "color" }
          ]
        }
      };
      _this.setEvents();
      return _this;
    }
    ServiceDsColors1005542.prototype.onServiceClick = function(visible, reinit, el) {
      this._onServiceClick(visible, reinit, el);
    };
    ServiceDsColors1005542.prototype._onServiceClick = function(visible, reinit, el) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a2) {
          if (visible && reinit) {
          }
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServiceDsColors1005542.prototype.showHelper = function() {
      return true;
    };
    ServiceDsColors1005542.prototype.setEvents = function() {
      var _this = this;
      mls.events.addEventListener([3], ["DSColorChanged"], function(ev) {
        var visible = _this.visible === "true";
        if (!visible)
          return;
        _this.onDSColorChanged(ev);
      });
      mls.events.addEventListener([3], ["DSTokenSelected"], function(ev) {
        _this.showNav2Item(true);
      });
      mls.events.addEventListener([3], ["DSTokenUnSelected"], function(ev) {
        _this.showNav2Item(false);
      });
    };
    ServiceDsColors1005542.prototype.init = function() {
      return __awaiter(this, void 0, void 0, function() {
        var project, mode;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              project = mls.actual[5].project;
              mode = mls.actual[3].mode;
              if (project === void 0 || mode === void 0)
                return [
                  2
                  /*return*/
                ];
              this.ds = mls.l3.getDSInstance(project, mode);
              if (!this.ds)
                return [
                  2
                  /*return*/
                ];
              return [4, this.ds.init()];
            case 1:
              _a2.sent();
              this.getThemes();
              this.updateActualTokens();
              if (this.actualTokens)
                this.getColorsItem(this.actualTokens["default"]);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsColors1005542.prototype.connectedCallback = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              _super.prototype.connectedCallback.call(this);
              this.loading = true;
              return [4, this.init()];
            case 1:
              _a2.sent();
              this.loading = false;
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsColors1005542.prototype.setTooltip = function() {
      if (!this.tooltipEl)
        return;
      if (this.tooltipEl)
        this.tooltipEl.tooltip(this.service_color_add);
      if (this.tooltipEl)
        this.tooltipEl.tooltip(this.service_color_delete);
      if (this.tooltipEl)
        this.tooltipEl.tooltip(this.service_color_update);
      if (this.tooltipEl)
        this.tooltipEl.tooltip(this.service_color_revert);
    };
    ServiceDsColors1005542.prototype.getThemes = function() {
      return __awaiter(this, void 0, void 0, function() {
        var _a2;
        return __generator(this, function(_b2) {
          switch (_b2.label) {
            case 0:
              _a2 = this;
              return [4, this.getAllThemes()];
            case 1:
              _a2.themeList = _b2.sent();
              this.themeList.unshift("default");
              this.themes = __assign({}, this.mythemes);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsColors1005542.prototype.getAllThemes = function() {
      return __awaiter(this, void 0, Promise, function() {
        var _a2, mergedThemes;
        return __generator(this, function(_b2) {
          switch (_b2.label) {
            case 0:
              this.defaultThemeList = this.getThemesDefault();
              _a2 = this;
              return [4, this.getUserThemes()];
            case 1:
              _a2.userThemeList = _b2.sent();
              mergedThemes = this.mergeThemes(this.userThemeList, this.defaultThemeList);
              return [2, mergedThemes];
          }
        });
      });
    };
    ServiceDsColors1005542.prototype.getThemesDefault = function() {
      return Object.keys(this.mythemes);
    };
    ServiceDsColors1005542.prototype.getUserThemes = function() {
      return __awaiter(this, void 0, Promise, function() {
        var themes;
        var _a2;
        return __generator(this, function(_b2) {
          switch (_b2.label) {
            case 0:
              return [4, ((_a2 = this.ds) === null || _a2 === void 0 ? void 0 : _a2.tokens)["getThemeList"]()];
            case 1:
              themes = _b2.sent();
              return [2, themes];
          }
        });
      });
    };
    ServiceDsColors1005542.prototype.mergeThemes = function(userThemes, defaultThemes) {
      return __spreadArray(__spreadArray([], userThemes, true), defaultThemes, true);
    };
    ServiceDsColors1005542.prototype.getTokens = function(tokens) {
      var themes = {};
      tokens.forEach(function(token) {
        var themeName = "default";
        if (!themes[themeName]) {
          themes[themeName] = {
            isdefault: true,
            tokens: [],
            description: ""
          };
        }
        themes[themeName].tokens.push(token);
      });
      return themes;
    };
    ServiceDsColors1005542.prototype.onDSColorChanged = function(ev) {
      console.info("onDSColorChanged");
      if (!ev.desc)
        return;
      var params = JSON.parse(ev.desc);
      if (params.emitter !== "left")
        return;
      var _a2 = params.value.split(";"), key = _a2[0], value = _a2[1], mode = _a2[2];
      if (mode === "line") {
        this.scrollToKey(key);
        return;
      }
      if (mode === "helper")
        return;
      this.updateActualTokens();
      this.scrollToKey(key);
      if (mode === "refresh")
        return;
      this.onChangeTokens();
    };
    ServiceDsColors1005542.prototype.scrollToKey = function(key) {
      var _this = this;
      if (key.startsWith("["))
        return;
      setTimeout(function() {
        if (!_this.shadowRoot)
          return;
        var allelements = _this.shadowRoot.querySelectorAll("mls-l3-color-item");
        allelements.forEach(function(el) {
          return el.classList.remove("active");
        });
        var element = _this.shadowRoot.querySelector('mls-l3-color-item[key="'.concat(key, '"]'));
        if (!element)
          element = _this.shadowRoot.querySelector('mls-l3-color-item[keydark="'.concat(key, '"]'));
        if (!element)
          return;
        element.classList.add("active");
      }, 300);
    };
    ServiceDsColors1005542.prototype.updateActualTokens = function() {
      if (!this.ds)
        return;
      var tokens = this.ds.tokens.list;
      var arrTokens = Object.keys(tokens).map(function(tok) {
        return tokens[tok];
      });
      var onlyColorsTokens = arrTokens.filter(function(tok) {
        return tok.category === "color";
      });
      this.actualTokens = this.getTokens(onlyColorsTokens);
    };
    ServiceDsColors1005542.prototype.getColorsItem = function(data) {
      var _this = this;
      this.newDataTokens = {};
      data.tokens.forEach(function(token) {
        if (!token.key || !token.value)
          return;
        var isDark = token.key.startsWith("_dark-");
        var key = isDark ? token.key.substring(6, token.key.length) : token.key;
        if (!_this.newDataTokens[key])
          _this.newDataTokens[key] = { light: "", dark: "" };
        _this.newDataTokens[key][isDark ? "dark" : "light"] = token.value;
      });
    };
    ServiceDsColors1005542.prototype.onChangeTokens = function() {
      return __awaiter(this, arguments, void 0, function(fireEvent) {
        var theme, allTokens, params;
        if (fireEvent === void 0) {
          fireEvent = false;
        }
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              this.setError("");
              if (!this.actualTokens)
                return [
                  2
                  /*return*/
                ];
              if (this.selectedTheme === "default") {
                this.getColorsItem(this.actualTokens["default"]);
                return [
                  2
                  /*return*/
                ];
              }
              if (!(this.selectedTheme && !this.themes[this.selectedTheme] && this.ds)) return [3, 2];
              return [4, this.ds.tokens["getTheme"](this.selectedTheme)];
            case 1:
              theme = _a2.sent();
              theme.isdefault = false;
              this.themes[this.selectedTheme] = theme;
              _a2.label = 2;
            case 2:
              if (!fireEvent) {
                if (!this.actualTokens)
                  return [
                    2
                    /*return*/
                  ];
                this.getColorsItem(this.actualTokens["default"]);
                return [
                  2
                  /*return*/
                ];
              }
              this.getColorsItem(this.themes[this.selectedTheme]);
              allTokens = this.themes[this.selectedTheme].tokens;
              this.actualTokens["default"] = __assign({}, this.themes[this.selectedTheme]);
              params = {
                emitter: "right",
                value: JSON.stringify(allTokens) + ";;helper"
              };
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsColors1005542.prototype.onChangeTheme = function(e) {
      this.setError("");
      var target = e.target;
      var theme = target.value;
      this.selectedTheme = theme;
      this.onChangeTokens(true);
    };
    ServiceDsColors1005542.prototype.handleAddThemeClick = function() {
      this.setError("");
      this.showAddContainer = true;
    };
    ServiceDsColors1005542.prototype.onCancelAction = function() {
      this.showAddContainer = false;
    };
    ServiceDsColors1005542.prototype.onConfirmAction = function() {
      return __awaiter(this, void 0, void 0, function() {
        var onlyLetterNumbers;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              this.setError("");
              onlyLetterNumbers = /^[a-zA-Z0-9]+$/;
              if (!this.service_color_inp_themename || !this.service_color_inp_themedesc)
                return [
                  2
                  /*return*/
                ];
              if (!onlyLetterNumbers.test(this.service_color_inp_themename.value)) {
                this.setError("Theme name accept only letters and numbers!");
                return [
                  2
                  /*return*/
                ];
              }
              return [4, this.saveTheme(this.service_color_inp_themename.value, this.service_color_inp_themedesc.value)];
            case 1:
              _a2.sent();
              this.onCancelAction();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsColors1005542.prototype.updateTheme = function() {
      return __awaiter(this, void 0, void 0, function() {
        var theme;
        var _a2, _b2;
        return __generator(this, function(_c2) {
          switch (_c2.label) {
            case 0:
              this.setError("");
              if (((_a2 = this.themes[this.selectedTheme]) === null || _a2 === void 0 ? void 0 : _a2.isdefault) || this.selectedTheme === "default") {
                this.setError("This is a system theme, cannot be updated!");
                return [
                  2
                  /*return*/
                ];
              }
              if (!this.actualTokens || !this.ds)
                return [
                  2
                  /*return*/
                ];
              this.toogleIconOnAction(this.service_color_update, true);
              theme = {
                description: ((_b2 = this.themes[this.selectedTheme]) === null || _b2 === void 0 ? void 0 : _b2.description) || "",
                tokens: this.actualTokens["default"].tokens
              };
              return [4, this.ds.tokens["updateTheme"](this.selectedTheme, theme)];
            case 1:
              _c2.sent();
              this.themes[this.selectedTheme].description = theme.description;
              this.themes[this.selectedTheme].tokens = theme.tokens;
              this.toogleIconOnAction(this.service_color_update, false);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsColors1005542.prototype.deleteTheme = function() {
      return __awaiter(this, void 0, void 0, function() {
        var _a2;
        return __generator(this, function(_b2) {
          switch (_b2.label) {
            case 0:
              this.setError("");
              if (((_a2 = this.themes[this.selectedTheme]) === null || _a2 === void 0 ? void 0 : _a2.isdefault) || this.selectedTheme === "default") {
                this.setError("This is a system theme, cannot be deleted!");
                return [
                  2
                  /*return*/
                ];
              }
              if (!this.ds)
                return [
                  2
                  /*return*/
                ];
              this.toogleIconOnAction(this.service_color_update, true);
              return [4, this.ds.tokens["removeTheme"](this.selectedTheme)];
            case 1:
              _b2.sent();
              this.selectedTheme = "default";
              return [4, this.getThemes()];
            case 2:
              _b2.sent();
              this.toogleIconOnAction(this.service_color_delete, false);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsColors1005542.prototype.saveTheme = function(themename, description) {
      return __awaiter(this, void 0, void 0, function() {
        var tokens, newTheme;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (!this.actualTokens || !this.ds)
                return [
                  2
                  /*return*/
                ];
              tokens = this.actualTokens["default"].tokens;
              newTheme = {
                description,
                tokens
              };
              return [4, this.ds.tokens["setTheme"](themename, JSON.stringify(newTheme))];
            case 1:
              _a2.sent();
              return [4, this.getThemes()];
            case 2:
              _a2.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsColors1005542.prototype.revertTokensColors = function() {
      return __awaiter(this, void 0, void 0, function() {
        var tokens, tokensColors, params, err_1;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              this.setError("");
              this.toogleIconOnAction(this.service_color_revert, true);
              if (!this.ds || !this.actualTokens)
                return [
                  2
                  /*return*/
                ];
              _a2.label = 1;
            case 1:
              _a2.trys.push([1, 3, 4, 5]);
              return [4, this.ds.tokens["getOriginalTokens"]()];
            case 2:
              tokens = _a2.sent();
              tokensColors = tokens.filter(function(tok) {
                return tok.category === "color";
              });
              this.actualTokens["default"].tokens = tokensColors;
              if (this.select_theme)
                this.select_theme.value = "default";
              this.getColorsItem(this.actualTokens["default"]);
              params = {
                emitter: "right",
                value: JSON.stringify(tokensColors) + ";;helper"
              };
              return [3, 5];
            case 3:
              err_1 = _a2.sent();
              this.setError(err_1.message);
              return [3, 5];
            case 4:
              this.toogleIconOnAction(this.service_color_revert, false);
              return [
                7
                /*endfinally*/
              ];
            case 5:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsColors1005542.prototype.toogleIconOnAction = function(el, force) {
      var parent = el.closest(".action-item");
      if (!parent)
        return;
      if (force)
        parent.classList.add("clicked");
      else {
        setTimeout(function() {
          parent.classList.remove("clicked");
        }, 1e3);
      }
    };
    ServiceDsColors1005542.prototype.handleClickColorItem = function(el) {
      this.setActive(el);
      var input = el.querySelector("input");
      if (!input)
        return;
      input.click();
    };
    ServiceDsColors1005542.prototype.handleInputColorItem = function(key, e) {
      var target = e.target;
      var container = target.closest("div");
      var value = target.value;
      if (!container)
        return;
      container.style.backgroundColor = value;
      var params = {
        emitter: "right",
        value: "".concat(key, ";").concat(value, ";helper")
      };
      mls.events.fire([3], ["DSColorChanged"], JSON.stringify(params), 0);
    };
    ServiceDsColors1005542.prototype.setActive = function(element) {
      var mlscolor = element.closest("mls-l3-color");
      if (!mlscolor)
        return;
      var allelements = mlscolor.querySelectorAll("mls-l3-color-item");
      allelements.forEach(function(el) {
        return el.classList.remove("active");
      });
      var actualItem = element.closest("mls-l3-color-item");
      if (actualItem)
        actualItem.classList.add("active");
    };
    ServiceDsColors1005542.prototype.firstUpdated = function(changedProperties) {
      _super.prototype.firstUpdated.call(this, changedProperties);
      this.setTooltip();
    };
    ServiceDsColors1005542.prototype.render = function() {
      var _this = this;
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['\n            <div class="service_tokens_color">\n                <fieldset>\n                    <legend>', '</legend>\n                    <div class="header">\n                        <div class="row-primary ', '">\n                            <div>\n                                <label>', '</label>\n                                <select id="select_theme" @change=', ">\n                                    ", '\n                                </select>\n                            </div>\n                            <div class="actions">\n                                <div \n                                id="service_color_add" \n                                data-tooltip="Add new theme" \n                                class="action-item"\n                                @click=', '>\n                                    <i class="fa fa-plus"></i>\n                                </div>\n                                <div id="service_color_update" data-tooltip="', '" class="action-item" @click=', ' >\n                                    <i class="fa fa-floppy-disk"></i>\n                                </div>\n                                <div id="service_color_delete" data-tooltip="', '" class="action-item" @click=', '>\n                                    <i class="fa fa-trash"></i>\n                                </div>\n                                <div id="service_color_revert" data-tooltip="', '" class="action-item" @click=', '>\n                                    <i class="fa fa-undo"></i>\n                                </div>\n                            </div>\n                        </div>\n                        <div class="row-form" style="', '">\n                            <fieldset>\n                                <legend>', "</legend>\n                                <label>", ':</label>\n                                <input id="service_color_inp_themename">\n                                <label>', ':</label>\n                                <textarea id="service_color_inp_themedesc" maxlength="200"></textarea>\n                            </fieldset>\n                            <div>\n                                <div id="service_color_confirm" class="action-item" @click=', '>\n                                    <i class="fa fa-check" title="', '"></i>\n                                </div>\n                                <div id="service_color_cancel" class="action-item" @click=', '>\n                                    <i class="fa fa-xmark" title="', '"></i>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                </fieldset>\n                <fieldset>\n                    <legend>Colors</legend>\n                    <div>\n                        <mls-l3-color class="ds-colors-section">\n                            <div class="desc"></div>\n                            <div class="colors-container">\n                                ', "\n                            </div>\n                        </mls-l3-color>\n                    </div>\n                </fieldset>\n            </div>\n        "], ['\n            <div class="service_tokens_color">\n                <fieldset>\n                    <legend>', '</legend>\n                    <div class="header">\n                        <div class="row-primary ', '">\n                            <div>\n                                <label>', '</label>\n                                <select id="select_theme" @change=', ">\n                                    ", '\n                                </select>\n                            </div>\n                            <div class="actions">\n                                <div \n                                id="service_color_add" \n                                data-tooltip="Add new theme" \n                                class="action-item"\n                                @click=', '>\n                                    <i class="fa fa-plus"></i>\n                                </div>\n                                <div id="service_color_update" data-tooltip="', '" class="action-item" @click=', ' >\n                                    <i class="fa fa-floppy-disk"></i>\n                                </div>\n                                <div id="service_color_delete" data-tooltip="', '" class="action-item" @click=', '>\n                                    <i class="fa fa-trash"></i>\n                                </div>\n                                <div id="service_color_revert" data-tooltip="', '" class="action-item" @click=', '>\n                                    <i class="fa fa-undo"></i>\n                                </div>\n                            </div>\n                        </div>\n                        <div class="row-form" style="', '">\n                            <fieldset>\n                                <legend>', "</legend>\n                                <label>", ':</label>\n                                <input id="service_color_inp_themename">\n                                <label>', ':</label>\n                                <textarea id="service_color_inp_themedesc" maxlength="200"></textarea>\n                            </fieldset>\n                            <div>\n                                <div id="service_color_confirm" class="action-item" @click=', '>\n                                    <i class="fa fa-check" title="', '"></i>\n                                </div>\n                                <div id="service_color_cancel" class="action-item" @click=', '>\n                                    <i class="fa fa-xmark" title="', '"></i>\n                                </div>\n                            </div>\n                        </div>\n                    </div>\n                </fieldset>\n                <fieldset>\n                    <legend>Colors</legend>\n                    <div>\n                        <mls-l3-color class="ds-colors-section">\n                            <div class="desc"></div>\n                            <div class="colors-container">\n                                ', "\n                            </div>\n                        </mls-l3-color>\n                    </div>\n                </fieldset>\n            </div>\n        "])), this.msg.themes, this.showAddContainer ? "disabled" : "", this.msg.themes, function(e) {
        _this.onChangeTheme(e);
      }, this.themeList.map(function(theme) {
        return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['\n                                        <option value="', '">', "</option>\n                                    "], ['\n                                        <option value="', '">', "</option>\n                                    "])), theme, _this.keysName[theme] || theme);
      }), function() {
        _this.handleAddThemeClick();
      }, this.msg.deleteThisTheme, function() {
        _this.updateTheme();
      }, this.msg.updateThisTheme, function() {
        _this.deleteTheme();
      }, this.msg.revertTokensToOriginal, function() {
        _this.revertTokensColors();
      }, this.showAddContainer ? "display:block" : "display:none;", this.msg.addTheme, this.msg.themeName, this.msg.description, function() {
        _this.onConfirmAction();
      }, this.msg.confirm, function() {
        _this.onCancelAction();
      }, this.msg.cancel, Object.entries(this.newDataTokens).map(function(item) {
        var keyname = item[0], values = item[1];
        var val = values;
        return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n                    <mls-l3-color-item key=", '>\n                        <div class="ds-colors-section-item">\n                            <div class="thumbnail">\n                                <div\n                                    data-tooltip="', '" \n                                    style="background-color: ', '"\n                                    @click=', '\n                                    >\n                                    <input\n                                        type="color"\n                                        @input=', '\n                                        value="', '">\n                                </div>\n                                <div\n                                    data-tooltip="', '" \n                                    style="background-color: ', '"\n                                    @click=', '\n                                >\n                                    <input\n                                    type="color"\n                                    @input=', '\n                                    value="', '">\n                                </div>\n                            </div>\n                            <span class="color-token-name">', "</span>\n                        </div>\n                    \n                    </mls-l3-color-item>"], ["\n                    <mls-l3-color-item key=", '>\n                        <div class="ds-colors-section-item">\n                            <div class="thumbnail">\n                                <div\n                                    data-tooltip="', '" \n                                    style="background-color: ', '"\n                                    @click=', '\n                                    >\n                                    <input\n                                        type="color"\n                                        @input=', '\n                                        value="', '">\n                                </div>\n                                <div\n                                    data-tooltip="', '" \n                                    style="background-color: ', '"\n                                    @click=', '\n                                >\n                                    <input\n                                    type="color"\n                                    @input=', '\n                                    value="', '">\n                                </div>\n                            </div>\n                            <span class="color-token-name">', "</span>\n                        </div>\n                    \n                    </mls-l3-color-item>"])), keyname, val.light, val.light, function(e) {
          _this.handleClickColorItem(e.target);
        }, function(e) {
          _this.handleInputColorItem(keyname, e);
        }, val.light, val.dark, val.dark, function(e) {
          _this.handleClickColorItem(e.target);
        }, function(e) {
          _this.handleInputColorItem(keyname, e);
        }, val.dark, keyname);
      }));
    };
    var _a, _b, _c, _d, _e, _f, _g;
    ServiceDsColors1005542.styles = css(templateObject_4 || (templateObject_4 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", Boolean)
    ], ServiceDsColors1005542.prototype, "showAddContainer", void 0);
    __decorate([
      property(),
      __metadata("design:type", Array)
    ], ServiceDsColors1005542.prototype, "themeList", void 0);
    __decorate([
      property(),
      __metadata("design:type", Object)
    ], ServiceDsColors1005542.prototype, "newDataTokens", void 0);
    __decorate([
      query("#service_color_add"),
      __metadata("design:type", typeof (_a = typeof HTMLElement !== "undefined" && HTMLElement) === "function" ? _a : Object)
    ], ServiceDsColors1005542.prototype, "service_color_add", void 0);
    __decorate([
      query("#service_color_delete"),
      __metadata("design:type", typeof (_b = typeof HTMLElement !== "undefined" && HTMLElement) === "function" ? _b : Object)
    ], ServiceDsColors1005542.prototype, "service_color_delete", void 0);
    __decorate([
      query("#service_color_update"),
      __metadata("design:type", typeof (_c = typeof HTMLElement !== "undefined" && HTMLElement) === "function" ? _c : Object)
    ], ServiceDsColors1005542.prototype, "service_color_update", void 0);
    __decorate([
      query("#service_color_revert"),
      __metadata("design:type", typeof (_d = typeof HTMLElement !== "undefined" && HTMLElement) === "function" ? _d : Object)
    ], ServiceDsColors1005542.prototype, "service_color_revert", void 0);
    __decorate([
      query("#service_color_inp_themedesc"),
      __metadata("design:type", typeof (_e = typeof HTMLInputElement !== "undefined" && HTMLInputElement) === "function" ? _e : Object)
    ], ServiceDsColors1005542.prototype, "service_color_inp_themedesc", void 0);
    __decorate([
      query("#service_color_inp_themename"),
      __metadata("design:type", typeof (_f = typeof HTMLInputElement !== "undefined" && HTMLInputElement) === "function" ? _f : Object)
    ], ServiceDsColors1005542.prototype, "service_color_inp_themename", void 0);
    __decorate([
      query("#select_theme"),
      __metadata("design:type", typeof (_g = typeof HTMLSelectElement !== "undefined" && HTMLSelectElement) === "function" ? _g : Object)
    ], ServiceDsColors1005542.prototype, "select_theme", void 0);
    ServiceDsColors1005542 = __decorate([
      customElement("service-ds-colors-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceDsColors1005542);
    return ServiceDsColors1005542;
  }(ServiceBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4;
export {
  ServiceDsColors100554
};
