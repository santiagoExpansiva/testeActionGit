var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
import { IcaLitElement } from "./_100554_icaLitElement";
var IcaFormsInputNumberBase = (
  /** @class */
  function(_super) {
    __extends(IcaFormsInputNumberBase2, _super);
    function IcaFormsInputNumberBase2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    return IcaFormsInputNumberBase2;
  }(IcaLitElement)
);
export {
  IcaFormsInputNumberBase
};
