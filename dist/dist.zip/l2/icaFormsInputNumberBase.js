import { IcaLitElement } from "./_100554_icaLitElement";
class IcaFormsInputNumberBase extends IcaLitElement {
  // Whether the field should be automatically focused on page load
}
export {
  IcaFormsInputNumberBase
};
