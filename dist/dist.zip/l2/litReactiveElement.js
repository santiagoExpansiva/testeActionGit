var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var __spreadArray = function(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};
var _a, _b, _c, _d;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
import { getCompatibleStyle, adoptStyles } from "_100554_litCssTag";
export * from "_100554_litCssTag";
var NODE_MODE = false;
var global = NODE_MODE ? globalThis : window;
if (NODE_MODE) {
  (_a = global.customElements) !== null && _a !== void 0 ? _a : global.customElements = customElements;
}
var DEV_MODE = true;
var requestUpdateThenable;
var issueWarning;
var trustedTypes = global.trustedTypes;
var emptyStringForBooleanAttribute = trustedTypes ? trustedTypes.emptyScript : "";
var polyfillSupport = DEV_MODE ? global.reactiveElementPolyfillSupportDevMode : global.reactiveElementPolyfillSupport;
if (DEV_MODE) {
  var issuedWarnings_1 = (_b = global.litIssuedWarnings) !== null && _b !== void 0 ? _b : global.litIssuedWarnings = /* @__PURE__ */ new Set();
  issueWarning = function(code, warning) {
    warning += " See https://lit.dev/msg/".concat(code, " for more information.");
    if (!issuedWarnings_1.has(warning)) {
      console.warn(warning);
      issuedWarnings_1.add(warning);
    }
  };
  issueWarning("dev-mode", "Lit is in dev mode. Not recommended for production!");
  if (((_c = global.ShadyDOM) === null || _c === void 0 ? void 0 : _c.inUse) && polyfillSupport === void 0) {
    issueWarning("polyfill-support-missing", "Shadow DOM is being polyfilled via `ShadyDOM` but the `polyfill-support` module has not been loaded.");
  }
  requestUpdateThenable = function(name) {
    return {
      then: function(onfulfilled, _onrejected) {
        issueWarning("request-update-promise", "The `requestUpdate` method should no longer return a Promise but " + "does so on `".concat(name, "`. Use `updateComplete` instead."));
        if (onfulfilled !== void 0) {
          onfulfilled(false);
        }
      }
    };
  };
}
var debugLogEvent = DEV_MODE ? function(event) {
  var shouldEmit = global.emitLitDebugLogEvents;
  if (!shouldEmit) {
    return;
  }
  global.dispatchEvent(new CustomEvent("lit-debug", {
    detail: event
  }));
} : void 0;
var JSCompiler_renameProperty = function(prop, _obj) {
  return prop;
};
var defaultConverter = {
  toAttribute: function(value, type) {
    switch (type) {
      case Boolean:
        value = value ? emptyStringForBooleanAttribute : null;
        break;
      case Object:
      case Array:
        value = value == null ? value : JSON.stringify(value);
        break;
    }
    return value;
  },
  fromAttribute: function(value, type) {
    var fromValue = value;
    switch (type) {
      case Boolean:
        fromValue = value !== null;
        break;
      case Number:
        fromValue = value === null ? null : Number(value);
        break;
      case Object:
      case Array:
        try {
          fromValue = JSON.parse(value);
        } catch (e) {
          fromValue = null;
        }
        break;
    }
    return fromValue;
  }
};
var notEqual = function(value, old) {
  return old !== value && (old === old || value === value);
};
var defaultPropertyDeclaration = {
  attribute: true,
  type: String,
  converter: defaultConverter,
  reflect: false,
  hasChanged: notEqual
};
var finalized = "finalized";
var ReactiveElement = (
  /** @class */
  function(_super) {
    __extends(ReactiveElement2, _super);
    function ReactiveElement2() {
      var _this = _super.call(this) || this;
      _this.__instanceProperties = /* @__PURE__ */ new Map();
      _this.isUpdatePending = false;
      _this.hasUpdated = false;
      _this.__reflectingProperty = null;
      _this._initialize();
      return _this;
    }
    ReactiveElement2.addInitializer = function(initializer) {
      var _a2;
      this.finalize();
      ((_a2 = this._initializers) !== null && _a2 !== void 0 ? _a2 : this._initializers = []).push(initializer);
    };
    Object.defineProperty(ReactiveElement2, "observedAttributes", {
      /**
       * Returns a list of attributes corresponding to the registered properties.
       * @nocollapse
       * @category attributes
       */
      get: function() {
        var _this = this;
        this.finalize();
        var attributes = [];
        this.elementProperties.forEach(function(v, p) {
          var attr = _this.__attributeNameForProperty(p, v);
          if (attr !== void 0) {
            _this.__attributeToPropertyMap.set(attr, p);
            attributes.push(attr);
          }
        });
        return attributes;
      },
      enumerable: false,
      configurable: true
    });
    ReactiveElement2.createProperty = function(name, options) {
      var _a2;
      if (options === void 0) {
        options = defaultPropertyDeclaration;
      }
      if (options.state) {
        options.attribute = false;
      }
      this.finalize();
      this.elementProperties.set(name, options);
      if (!options.noAccessor && !this.prototype.hasOwnProperty(name)) {
        var key = typeof name === "symbol" ? Symbol() : "__".concat(name);
        var descriptor = this.getPropertyDescriptor(name, key, options);
        if (descriptor !== void 0) {
          Object.defineProperty(this.prototype, name, descriptor);
          if (DEV_MODE) {
            if (!this.hasOwnProperty("__reactivePropertyKeys")) {
              this.__reactivePropertyKeys = new Set((_a2 = this.__reactivePropertyKeys) !== null && _a2 !== void 0 ? _a2 : []);
            }
            this.__reactivePropertyKeys.add(name);
          }
        }
      }
    };
    ReactiveElement2.getPropertyDescriptor = function(name, key, options) {
      return {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        get: function() {
          return this[key];
        },
        set: function(value) {
          var oldValue = this[name];
          this[key] = value;
          this.requestUpdate(name, oldValue, options);
        },
        configurable: true,
        enumerable: true
      };
    };
    ReactiveElement2.getPropertyOptions = function(name) {
      return this.elementProperties.get(name) || defaultPropertyDeclaration;
    };
    ReactiveElement2.finalize = function() {
      var _this = this;
      if (this.hasOwnProperty(finalized)) {
        return false;
      }
      this[finalized] = true;
      var superCtor = Object.getPrototypeOf(this);
      superCtor.finalize();
      if (superCtor._initializers !== void 0) {
        this._initializers = __spreadArray([], superCtor._initializers, true);
      }
      this.elementProperties = new Map(superCtor.elementProperties);
      this.__attributeToPropertyMap = /* @__PURE__ */ new Map();
      if (this.hasOwnProperty(JSCompiler_renameProperty("properties", this))) {
        var props = this.properties;
        var propKeys = __spreadArray(__spreadArray([], Object.getOwnPropertyNames(props), true), Object.getOwnPropertySymbols(props), true);
        for (var _i = 0, propKeys_1 = propKeys; _i < propKeys_1.length; _i++) {
          var p = propKeys_1[_i];
          this.createProperty(p, props[p]);
        }
      }
      this.elementStyles = this.finalizeStyles(this.styles);
      if (DEV_MODE) {
        var warnRemovedOrRenamed = function(name, renamed) {
          if (renamed === void 0) {
            renamed = false;
          }
          if (_this.prototype.hasOwnProperty(name)) {
            issueWarning(renamed ? "renamed-api" : "removed-api", "`".concat(name, "` is implemented on class ").concat(_this.name, ". It ") + "has been ".concat(renamed ? "renamed" : "removed", " ") + "in this version of LitElement.");
          }
        };
        warnRemovedOrRenamed("initialize");
        warnRemovedOrRenamed("requestUpdateInternal");
        warnRemovedOrRenamed("_getUpdateComplete", true);
      }
      return true;
    };
    ReactiveElement2.finalizeStyles = function(styles) {
      var elementStyles = [];
      if (Array.isArray(styles)) {
        var set = new Set(styles["flat"](Infinity).reverse());
        for (var _i = 0, set_1 = set; _i < set_1.length; _i++) {
          var s = set_1[_i];
          elementStyles.unshift(getCompatibleStyle(s));
        }
      } else if (styles !== void 0) {
        elementStyles.push(getCompatibleStyle(styles));
      }
      return elementStyles;
    };
    ReactiveElement2.__attributeNameForProperty = function(name, options) {
      var attribute = options.attribute;
      return attribute === false ? void 0 : typeof attribute === "string" ? attribute : typeof name === "string" ? name.toLowerCase() : void 0;
    };
    ReactiveElement2.prototype._initialize = function() {
      var _this = this;
      var _a2;
      this.__updatePromise = new Promise(function(res) {
        return _this.enableUpdating = res;
      });
      this._$changedProperties = /* @__PURE__ */ new Map();
      this.__saveInstanceProperties();
      this.requestUpdate();
      (_a2 = this.constructor._initializers) === null || _a2 === void 0 ? void 0 : _a2.forEach(function(i) {
        return i(_this);
      });
    };
    ReactiveElement2.prototype.addController = function(controller) {
      var _a2, _b2;
      ((_a2 = this.__controllers) !== null && _a2 !== void 0 ? _a2 : this.__controllers = []).push(controller);
      if (this.renderRoot !== void 0 && this.isConnected) {
        (_b2 = controller.hostConnected) === null || _b2 === void 0 ? void 0 : _b2.call(controller);
      }
    };
    ReactiveElement2.prototype.removeController = function(controller) {
      var _a2;
      (_a2 = this.__controllers) === null || _a2 === void 0 ? void 0 : _a2.splice(this.__controllers.indexOf(controller) >>> 0, 1);
    };
    ReactiveElement2.prototype.__saveInstanceProperties = function() {
      var _this = this;
      this.constructor.elementProperties.forEach(function(_v, p) {
        if (_this.hasOwnProperty(p)) {
          _this.__instanceProperties.set(p, _this[p]);
          delete _this[p];
        }
      });
    };
    ReactiveElement2.prototype.createRenderRoot = function() {
      var _a2;
      var renderRoot = (_a2 = this.shadowRoot) !== null && _a2 !== void 0 ? _a2 : this.attachShadow(this.constructor.shadowRootOptions);
      adoptStyles(renderRoot, this.constructor.elementStyles);
      return renderRoot;
    };
    ReactiveElement2.prototype.connectedCallback = function() {
      var _a2;
      if (this.renderRoot === void 0) {
        this.renderRoot = this.createRenderRoot();
      }
      this.enableUpdating(true);
      (_a2 = this.__controllers) === null || _a2 === void 0 ? void 0 : _a2.forEach(function(c) {
        var _a3;
        return (_a3 = c.hostConnected) === null || _a3 === void 0 ? void 0 : _a3.call(c);
      });
    };
    ReactiveElement2.prototype.enableUpdating = function(_requestedUpdate) {
    };
    ReactiveElement2.prototype.disconnectedCallback = function() {
      var _a2;
      (_a2 = this.__controllers) === null || _a2 === void 0 ? void 0 : _a2.forEach(function(c) {
        var _a3;
        return (_a3 = c.hostDisconnected) === null || _a3 === void 0 ? void 0 : _a3.call(c);
      });
    };
    ReactiveElement2.prototype.attributeChangedCallback = function(name, _old, value) {
      this._$attributeToProperty(name, value);
    };
    ReactiveElement2.prototype.__propertyToAttribute = function(name, value, options) {
      var _a2;
      if (options === void 0) {
        options = defaultPropertyDeclaration;
      }
      var attr = this.constructor.__attributeNameForProperty(name, options);
      if (attr !== void 0 && options.reflect === true) {
        var converter = ((_a2 = options.converter) === null || _a2 === void 0 ? void 0 : _a2.toAttribute) !== void 0 ? options.converter : defaultConverter;
        var attrValue = converter.toAttribute(value, options.type);
        if (DEV_MODE && this.constructor.enabledWarnings.indexOf("migration") >= 0 && attrValue === void 0) {
          issueWarning("undefined-attribute-value", "The attribute value for the ".concat(name, " property is ") + "undefined on element ".concat(this.localName, ". The attribute will be ") + "removed, but in the previous version of `ReactiveElement`, the attribute would not have changed.");
        }
        this.__reflectingProperty = name;
        if (attrValue == null) {
          this.removeAttribute(attr);
        } else {
          this.setAttribute(attr, attrValue);
        }
        this.__reflectingProperty = null;
      }
    };
    ReactiveElement2.prototype._$attributeToProperty = function(name, value) {
      var _a2;
      var ctor = this.constructor;
      var propName = ctor.__attributeToPropertyMap.get(name);
      if (propName !== void 0 && this.__reflectingProperty !== propName) {
        var options = ctor.getPropertyOptions(propName);
        var converter = typeof options.converter === "function" ? { fromAttribute: options.converter } : ((_a2 = options.converter) === null || _a2 === void 0 ? void 0 : _a2.fromAttribute) !== void 0 ? options.converter : defaultConverter;
        this.__reflectingProperty = propName;
        this[propName] = converter.fromAttribute(
          value,
          options.type
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
        );
        this.__reflectingProperty = null;
      }
    };
    ReactiveElement2.prototype.requestUpdate = function(name, oldValue, options) {
      var shouldRequestUpdate = true;
      if (name !== void 0) {
        options = options || this.constructor.getPropertyOptions(name);
        var hasChanged = options.hasChanged || notEqual;
        if (hasChanged(this[name], oldValue)) {
          if (!this._$changedProperties.has(name)) {
            this._$changedProperties.set(name, oldValue);
          }
          if (options.reflect === true && this.__reflectingProperty !== name) {
            if (this.__reflectingProperties === void 0) {
              this.__reflectingProperties = /* @__PURE__ */ new Map();
            }
            this.__reflectingProperties.set(name, options);
          }
        } else {
          shouldRequestUpdate = false;
        }
      }
      if (!this.isUpdatePending && shouldRequestUpdate) {
        this.__updatePromise = this.__enqueueUpdate();
      }
      return DEV_MODE ? requestUpdateThenable(this.localName) : void 0;
    };
    ReactiveElement2.prototype.__enqueueUpdate = function() {
      return __awaiter(this, void 0, void 0, function() {
        var e_1, result;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              this.isUpdatePending = true;
              _a2.label = 1;
            case 1:
              _a2.trys.push([1, 3, , 4]);
              return [4, this.__updatePromise];
            case 2:
              _a2.sent();
              return [3, 4];
            case 3:
              e_1 = _a2.sent();
              Promise.reject(e_1);
              return [3, 4];
            case 4:
              result = this.scheduleUpdate();
              if (!(result != null)) return [3, 6];
              return [4, result];
            case 5:
              _a2.sent();
              _a2.label = 6;
            case 6:
              return [2, !this.isUpdatePending];
          }
        });
      });
    };
    ReactiveElement2.prototype.scheduleUpdate = function() {
      return this.performUpdate();
    };
    ReactiveElement2.prototype.performUpdate = function() {
      var _this = this;
      var _a2, _b2;
      if (!this.isUpdatePending) {
        return;
      }
      debugLogEvent === null || debugLogEvent === void 0 ? void 0 : debugLogEvent({ kind: "update" });
      if (!this.hasUpdated) {
        if (DEV_MODE) {
          var shadowedProperties_1 = [];
          (_a2 = this.constructor.__reactivePropertyKeys) === null || _a2 === void 0 ? void 0 : _a2.forEach(function(p) {
            var _a3;
            if (_this.hasOwnProperty(p) && !((_a3 = _this.__instanceProperties) === null || _a3 === void 0 ? void 0 : _a3.has(p))) {
              shadowedProperties_1.push(p);
            }
          });
          if (shadowedProperties_1.length) {
            throw new Error("The following properties on element ".concat(this.localName, " will not ") + "trigger updates as expected because they are set using class " + "fields: ".concat(shadowedProperties_1.join(", "), ". ") + "Native class fields and some compiled output will overwrite accessors used for detecting changes. See https://lit.dev/msg/class-field-shadowing for more information.");
          }
        }
      }
      if (this.__instanceProperties) {
        this.__instanceProperties.forEach(function(v, p) {
          return _this[p] = v;
        });
        this.__instanceProperties = void 0;
      }
      var shouldUpdate = false;
      var changedProperties = this._$changedProperties;
      try {
        shouldUpdate = this.shouldUpdate(changedProperties);
        if (shouldUpdate) {
          this.willUpdate(changedProperties);
          (_b2 = this.__controllers) === null || _b2 === void 0 ? void 0 : _b2.forEach(function(c) {
            var _a3;
            return (_a3 = c.hostUpdate) === null || _a3 === void 0 ? void 0 : _a3.call(c);
          });
          this.update(changedProperties);
        } else {
          this.__markUpdated();
        }
      } catch (e) {
        shouldUpdate = false;
        this.__markUpdated();
        throw e;
      }
      if (shouldUpdate) {
        this._$didUpdate(changedProperties);
      }
    };
    ReactiveElement2.prototype.willUpdate = function(_changedProperties) {
    };
    ReactiveElement2.prototype._$didUpdate = function(changedProperties) {
      var _a2;
      (_a2 = this.__controllers) === null || _a2 === void 0 ? void 0 : _a2.forEach(function(c) {
        var _a3;
        return (_a3 = c.hostUpdated) === null || _a3 === void 0 ? void 0 : _a3.call(c);
      });
      if (!this.hasUpdated) {
        this.hasUpdated = true;
        this.firstUpdated(changedProperties);
      }
      this.updated(changedProperties);
      if (DEV_MODE && this.isUpdatePending && this.constructor.enabledWarnings.indexOf("change-in-update") >= 0) {
        issueWarning("change-in-update", "Element ".concat(this.localName, " scheduled an update ") + "(generally because a property was set) after an update completed, causing a new update to be scheduled. This is inefficient and should be avoided unless the next update can only be scheduled as a side effect of the previous update.");
      }
    };
    ReactiveElement2.prototype.__markUpdated = function() {
      this._$changedProperties = /* @__PURE__ */ new Map();
      this.isUpdatePending = false;
    };
    Object.defineProperty(ReactiveElement2.prototype, "updateComplete", {
      /**
       * Returns a Promise that resolves when the element has completed updating.
       * The Promise value is a boolean that is `true` if the element completed the
       * update without triggering another update. The Promise result is `false` if
       * a property was set inside `updated()`. If the Promise is rejected, an
       * exception was thrown during the update.
       *
       * To await additional asynchronous work, override the `getUpdateComplete`
       * method. For example, it is sometimes useful to await a rendered element
       * before fulfilling this Promise. To do this, first await
       * `super.getUpdateComplete()`, then any subsequent state.
       *
       * @return A promise of a boolean that resolves to true if the update completed
       *     without triggering another update.
       * @category updates
       */
      get: function() {
        return this.getUpdateComplete();
      },
      enumerable: false,
      configurable: true
    });
    ReactiveElement2.prototype.getUpdateComplete = function() {
      return this.__updatePromise;
    };
    ReactiveElement2.prototype.shouldUpdate = function(_changedProperties) {
      return true;
    };
    ReactiveElement2.prototype.update = function(_changedProperties) {
      var _this = this;
      if (this.__reflectingProperties !== void 0) {
        this.__reflectingProperties.forEach(function(v, k) {
          return _this.__propertyToAttribute(k, _this[k], v);
        });
        this.__reflectingProperties = void 0;
      }
      this.__markUpdated();
    };
    ReactiveElement2.prototype.updated = function(_changedProperties) {
    };
    ReactiveElement2.prototype.firstUpdated = function(_changedProperties) {
    };
    var _e;
    _e = finalized;
    ReactiveElement2[_e] = true;
    ReactiveElement2.elementProperties = /* @__PURE__ */ new Map();
    ReactiveElement2.elementStyles = [];
    ReactiveElement2.shadowRootOptions = { mode: "open" };
    return ReactiveElement2;
  }(HTMLElement)
);
polyfillSupport === null || polyfillSupport === void 0 ? void 0 : polyfillSupport({ ReactiveElement });
if (DEV_MODE) {
  ReactiveElement.enabledWarnings = ["change-in-update"];
  var ensureOwnWarnings_1 = function(ctor) {
    if (!ctor.hasOwnProperty(JSCompiler_renameProperty("enabledWarnings", ctor))) {
      ctor.enabledWarnings = ctor.enabledWarnings.slice();
    }
  };
  ReactiveElement.enableWarning = function(warning) {
    ensureOwnWarnings_1(this);
    if (this.enabledWarnings.indexOf(warning) < 0) {
      this.enabledWarnings.push(warning);
    }
  };
  ReactiveElement.disableWarning = function(warning) {
    ensureOwnWarnings_1(this);
    var i = this.enabledWarnings.indexOf(warning);
    if (i >= 0) {
      this.enabledWarnings.splice(i, 1);
    }
  };
}
((_d = global.reactiveElementVersions) !== null && _d !== void 0 ? _d : global.reactiveElementVersions = []).push("1.6.1");
if (DEV_MODE && global.reactiveElementVersions.length > 1) {
  issueWarning("multiple-versions", "Multiple versions of Lit loaded. Loading multiple versions is not recommended.");
}
export {
  ReactiveElement,
  defaultConverter,
  notEqual
};
