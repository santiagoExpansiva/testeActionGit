var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { html, css } from "lit";
import { customElement, property, query } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
import { collab_plus, collab_chevron_right } from "./_100554_collabIcons";
var message_pt = {
  loading: "Carregando...",
  add: "Adicionar"
};
var message_en = {
  loading: "Loading...",
  add: "Add"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceDsDocList100554 = (
  /** @class */
  function(_super) {
    __extends(ServiceDsDocList1005542, _super);
    function ServiceDsDocList1005542() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.list = [];
      _this.docIdSelected = 0;
      _this.loading = true;
      _this.details = {
        icon: "&#xf02d",
        state: "foreground",
        tooltip: "Documentation List",
        visible: true,
        position: "left",
        tags: ["ds_docs"],
        widget: "_100554_serviceDsDocList",
        level: [3]
      };
      _this.onClickLink = function(op) {
        if (op === "opList")
          return true;
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.menu = {
        title: "List",
        actions: {},
        icons: {},
        actionDefault: "opList",
        // call after close icon clicked
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        getLastMode: void 0,
        updateTitle: void 0
      };
      _this.setEvents();
      return _this;
    }
    ServiceDsDocList1005542.prototype.onServiceClick = function(visible, reinit, el) {
      this._onServiceClick(visible, reinit, el);
    };
    ServiceDsDocList1005542.prototype._onServiceClick = function(visible, reinit, el) {
      return __awaiter(this, void 0, void 0, function() {
        var project, mode;
        return __generator(this, function(_a2) {
          if (visible)
            mls.events.fire([3], ["DSDocSelected"], "Doc Selected", 1e3);
          else
            mls.events.fire([3], ["DSDocUnSelected"], "Doc UnSelected", 0);
          if (reinit) {
            project = mls.actual[5].project;
            mode = mls.actual[3].mode;
            if (this.lastProject !== project || this.lastDsIndex !== mode) {
              this.getState();
            }
          }
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServiceDsDocList1005542.prototype.connectedCallback = function() {
      return __awaiter(this, void 0, void 0, function() {
        var firstItem;
        var _a2;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              _super.prototype.connectedCallback.call(this);
              return [4, this.getState()];
            case 1:
              _b.sent();
              this.loading = false;
              firstItem = (_a2 = this.list[0].item) === null || _a2 === void 0 ? void 0 : _a2.id;
              if (firstItem)
                this.selectDoc(firstItem);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsDocList1005542.prototype.setEvents = function() {
      var _this = this;
      mls.events.addEventListener([3], ["DSDocPageChanged"], function(ev) {
        _this.onDocPageChanged(ev);
      });
    };
    ServiceDsDocList1005542.prototype.getState = function() {
      return __awaiter(this, void 0, void 0, function() {
        var allDocs;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              return [4, this.getListDocs()];
            case 1:
              allDocs = _a2.sent();
              this.list = this.createFolderStructure(allDocs);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsDocList1005542.prototype.getListDocs = function() {
      return __awaiter(this, void 0, Promise, function() {
        var project, mode, dss, dsInfo, allItems;
        var _this = this;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              project = mls.actual[5].project;
              mode = mls.actual[3].mode;
              if (project === void 0 || mode === void 0)
                return [2, []];
              dss = mls.l5.ds.list(project);
              this.lastDsIndex = mode;
              this.lastProject = project;
              dsInfo = dss[mode];
              if (!dsInfo)
                return [2, []];
              this.dsInstance = mls.l3.getDSInstance(project, mode);
              return [4, this.dsInstance.init()];
            case 1:
              _a2.sent();
              this.list = [];
              allItems = [];
              Object.keys(this.dsInstance.docs.list).forEach(function(doc) {
                if (!_this.dsInstance)
                  return;
                allItems.push(_this.dsInstance.docs.list[doc]);
              });
              return [2, allItems];
          }
        });
      });
    };
    ServiceDsDocList1005542.prototype.createFolderStructure = function(arr) {
      var map = /* @__PURE__ */ new Map();
      var root = {
        id: 0,
        item: void 0,
        children: []
      };
      map.set(0, root);
      for (var _i = 0, arr_1 = arr; _i < arr_1.length; _i++) {
        var obj = arr_1[_i];
        var id = obj.id, parentID = obj.parentID;
        var folder = {
          id,
          item: obj,
          children: []
        };
        if (map.has(parentID)) {
          var parentFolder = map.get(parentID);
          parentFolder.children.push(folder);
          map.set(id, folder);
        }
      }
      return root.children;
    };
    ServiceDsDocList1005542.prototype.onDocPageChanged = function(ev) {
      if (!ev.desc)
        return;
      var st = JSON.parse(ev.desc);
      if (st.op === "Add")
        this.addDoc(st.id);
      if (st.op === "Change")
        this.changedMe(st.id, st.content);
      if (st.op === "Update")
        this.updateDoc(st.id, st.parentID, st.title);
      else if (st.op === "Delete")
        this.removeDoc(st.id);
    };
    ServiceDsDocList1005542.prototype.addDoc = function(parentID) {
      return __awaiter(this, void 0, void 0, function() {
        var idx;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (!this.dsInstance)
                return [
                  2
                  /*return*/
                ];
              return [4, this.dsInstance.docs.add(parentID, "NewDocument", "Describe your new documentation here")];
            case 1:
              idx = _a2.sent();
              return [4, this.getState()];
            case 2:
              _a2.sent();
              this.selectDoc(idx);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsDocList1005542.prototype.changedMe = function(id, content) {
      return __awaiter(this, void 0, void 0, function() {
        var doc;
        return __generator(this, function(_a2) {
          if (!this.dsInstance)
            return [
              2
              /*return*/
            ];
          doc = this.dsInstance.docs.list[id];
          if (!doc)
            return [
              2
              /*return*/
            ];
          doc.setContent(content);
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServiceDsDocList1005542.prototype.updateDoc = function(id, parentID, title) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (!this.dsInstance)
                return [
                  2
                  /*return*/
                ];
              return [4, this.dsInstance.docs.update(id, parentID, title, "")];
            case 1:
              _a2.sent();
              this.getState();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsDocList1005542.prototype.removeDoc = function(id) {
      return __awaiter(this, void 0, void 0, function() {
        var el, doc, nextEl, nextElId;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (!this.dsInstance)
                return [
                  2
                  /*return*/
                ];
              if (!this.containerMain)
                return [
                  2
                  /*return*/
                ];
              el = this.containerMain.querySelector('details[docId = "'.concat(id, '"]'));
              if (!el)
                return [
                  2
                  /*return*/
                ];
              doc = this.dsInstance.docs.list[id];
              nextEl = el.nextElementSibling || el.closest('details[docId = "'.concat(doc.parentID, '"]'));
              nextEl = nextEl || el.previousElementSibling;
              nextElId = nextEl === null || nextEl === void 0 ? void 0 : nextEl.getAttribute("docId");
              return [4, this.dsInstance.docs.remove(id)];
            case 1:
              _a2.sent();
              return [4, this.getState()];
            case 2:
              _a2.sent();
              if (nextElId)
                this.selectDoc(+nextElId);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsDocList1005542.prototype.addNewDoc = function() {
      return __awaiter(this, void 0, void 0, function() {
        var selectedParentIndex;
        return __generator(this, function(_a2) {
          selectedParentIndex = 0;
          this.addDoc(selectedParentIndex);
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServiceDsDocList1005542.prototype.selectDoc = function(id) {
      var _this = this;
      setTimeout(function() {
        var docToSelect;
        if (!_this.containerMain)
          return;
        docToSelect = _this.containerMain.querySelector('details[docId = "'.concat(id, '"]'));
        if (docToSelect)
          docToSelect.click();
      }, 100);
    };
    ServiceDsDocList1005542.prototype.onDetailsClick = function(doc, e) {
      var _a2;
      this.docIdSelected = doc.id;
      var target = e.target;
      var details = target.closest("details");
      var summary = details.querySelector("summary");
      var isSelected = summary.classList.contains("selected");
      e.stopPropagation();
      if (details.open && !isSelected)
        e.preventDefault();
      if (isSelected) {
        return;
      }
      this.seeDocumentation(doc.item, (_a2 = doc.item) === null || _a2 === void 0 ? void 0 : _a2.title, doc.children.length > 0);
    };
    ServiceDsDocList1005542.prototype.seeDocumentation = function(item, title, hasChildren) {
      return __awaiter(this, void 0, void 0, function() {
        var text, obj;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (!item || !title)
                return [
                  2
                  /*return*/
                ];
              return [4, item.getContent()];
            case 1:
              text = _a2.sent();
              obj = {
                op: "Open",
                title,
                content: text,
                id: item.id,
                parentID: item.parentID,
                hasChildren
              };
              mls.events.fire([3], ["DSDocPageClicked"], JSON.stringify(obj));
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsDocList1005542.prototype.renderList = function(items) {
      var _this = this;
      return items.map(function(doc) {
        var _a2, _b;
        return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(['\n            <details\n                class="', '"\n                docId="', '"\n                parentId="', '"\n                @click=', '\n            >\n                <summary class= "', '" >\n                    <div>\n                        <p>', "</p>\n                        <span></span>\n                        ", "\n                    </div>\n                </summary>\n                ", "\n            </details>\n            "], ['\n            <details\n                class="', '"\n                docId="', '"\n                parentId="', '"\n                @click=', '\n            >\n                <summary class= "', '" >\n                    <div>\n                        <p>', "</p>\n                        <span></span>\n                        ", "\n                    </div>\n                </summary>\n                ", "\n            </details>\n            "])), doc.children.length > 0 ? "" : "nochildren", doc.id.toString(), (_a2 = doc.item) === null || _a2 === void 0 ? void 0 : _a2.parentID.toString(), function(e) {
          _this.onDetailsClick(doc, e);
        }, doc.id === _this.docIdSelected ? "selected" : "", (_b = doc.item) === null || _b === void 0 ? void 0 : _b.title, collab_chevron_right, doc.children.length > 0 ? html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['<div style="padding-left:1rem">', "<div>"], ['<div style="padding-left:1rem">', "<div>"])), _this.renderList(doc.children)) : "");
      });
    };
    ServiceDsDocList1005542.prototype.render = function() {
      var _this = this;
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_5 || (templateObject_5 = __makeTemplateObject(["\n            <div>\n                ", ""], ["\n            <div>\n                ", ""])), this.loading ? html(templateObject_3 || (templateObject_3 = __makeTemplateObject(["<p>", "</p>"], ["<p>", "</p>"])), this.msg.loading) : html(templateObject_4 || (templateObject_4 = __makeTemplateObject(['\n                <div>\n                    <div class="list-docs-container">\n                        ', '\n                    </div>\n                    <div class="list-docs-actions">\n                        <button @click=', ">\n                            <span>", "</span>\n                            ", "\n                        </button>\n                    </div>\n                    \n\n                </div>"], ['\n                <div>\n                    <div class="list-docs-container">\n                        ', '\n                    </div>\n                    <div class="list-docs-actions">\n                        <button @click=', ">\n                            <span>", "</span>\n                            ", "\n                        </button>\n                    </div>\n                    \n\n                </div>"])), this.renderList(this.list), function() {
        _this.addNewDoc();
      }, this.msg.add, collab_plus));
    };
    var _a;
    ServiceDsDocList1005542.styles = css(templateObject_6 || (templateObject_6 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", Array)
    ], ServiceDsDocList1005542.prototype, "list", void 0);
    __decorate([
      property(),
      __metadata("design:type", Number)
    ], ServiceDsDocList1005542.prototype, "docIdSelected", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Boolean)
    ], ServiceDsDocList1005542.prototype, "loading", void 0);
    __decorate([
      query(".list-docs-container"),
      __metadata("design:type", typeof (_a = typeof HTMLElement !== "undefined" && HTMLElement) === "function" ? _a : Object)
    ], ServiceDsDocList1005542.prototype, "containerMain", void 0);
    ServiceDsDocList1005542 = __decorate([
      customElement("service-ds-doc-list-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceDsDocList1005542);
    return ServiceDsDocList1005542;
  }(ServiceBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6;
export {
  ServiceDsDocList100554
};
