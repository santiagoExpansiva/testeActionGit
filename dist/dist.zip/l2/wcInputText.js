var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, ifDefined, css } from "lit";
import { customElement, property, query } from "lit/decorators.js";
import { IcaFormsInputString } from "./_100554_icaFormsInputString";
import { propertyDataSource } from "./_100554_icaLitElement";
var WcInputText100554 = (
  /** @class */
  function(_super) {
    __extends(WcInputText1005542, _super);
    function WcInputText1005542() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.maxlength = void 0;
      _this.minlength = void 0;
      _this.required = false;
      _this.disabled = false;
      _this.readonly = false;
      _this.autofocus = false;
      _this.autocorrect = void 0;
      _this.autoCapitalize = void 0;
      _this.error = "";
      return _this;
    }
    WcInputText1005542.prototype.render = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['\n        <label class="form-control-label">\n          ', '\n        </label>\n\n        <input\n            class="input_control"\n            type="text"\n            name=', "\n            ?disabled=", "\n            ?readonly=", "\n            ?required=", "\n            maxlength=", "    \n            minlength=", "\n            autocomplete=", "\n            placeholder=", "\n            .value=", "\n            ?autofocus=", "\n            pattern=", "\n            @input=", '\n\n        \n        />\n        <small class="form_hint">', '</small>\n        <div class="form_error_message">', "</div>\n        "], ['\n        <label class="form-control-label">\n          ', '\n        </label>\n\n        <input\n            class="input_control"\n            type="text"\n            name=', "\n            ?disabled=", "\n            ?readonly=", "\n            ?required=", "\n            maxlength=", "    \n            minlength=", "\n            autocomplete=", "\n            placeholder=", "\n            .value=", "\n            ?autofocus=", "\n            pattern=", "\n            @input=", '\n\n        \n        />\n        <small class="form_hint">', '</small>\n        <div class="form_error_message">', "</div>\n        "])), this.label, ifDefined(this.name), this.disabled, this.readonly, this.required, ifDefined(this.minlength), ifDefined(this.maxlength), ifDefined(this.autocomplete), ifDefined(this.placeholder), this.datasource || "", this.autofocus, ifDefined(this.pattern), this.handleChange, this.hint, this.error);
    };
    WcInputText1005542.prototype.handleChange = function(event) {
      var selectElement = event.target;
      this.datasource = selectElement.value;
    };
    var _a;
    WcInputText1005542.styles = css(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n    :host {\n        display: block;\n    }\n    \n    .input_control {\n        display: block;\n        width:100%;\n        padding: 0.375rem 0.75rem;\n        font-size: 1rem;\n        font-weight: 400;\n        line-height: 1.5;\n        color: #212529;\n        background-color: #fff;\n        background-clip: padding-box;\n        border: 1px solid #ced4da;\n        -webkit-appearance: none;\n        -moz-appearance: none;\n        appearance: none;\n        border-radius: 0.25rem;\n        transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;\n        outline:none;\n    }\n    .form_hint{\n        color: blue;\n    }\n    .form_error_message{\n        color: red;\n    }\n    "], ["\n    :host {\n        display: block;\n    }\n    \n    .input_control {\n        display: block;\n        width:100%;\n        padding: 0.375rem 0.75rem;\n        font-size: 1rem;\n        font-weight: 400;\n        line-height: 1.5;\n        color: #212529;\n        background-color: #fff;\n        background-clip: padding-box;\n        border: 1px solid #ced4da;\n        -webkit-appearance: none;\n        -moz-appearance: none;\n        appearance: none;\n        border-radius: 0.25rem;\n        transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;\n        outline:none;\n    }\n    .form_hint{\n        color: blue;\n    }\n    .form_error_message{\n        color: red;\n    }\n    "])));
    __decorate([
      propertyDataSource({ type: String }),
      __metadata("design:type", String)
    ], WcInputText1005542.prototype, "datasource", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WcInputText1005542.prototype, "name", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WcInputText1005542.prototype, "label", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WcInputText1005542.prototype, "pattern", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WcInputText1005542.prototype, "errormessage", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WcInputText1005542.prototype, "placeholder", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WcInputText1005542.prototype, "autocomplete", void 0);
    __decorate([
      property({ type: Number }),
      __metadata("design:type", Number)
    ], WcInputText1005542.prototype, "maxlength", void 0);
    __decorate([
      property({ type: Number }),
      __metadata("design:type", Number)
    ], WcInputText1005542.prototype, "minlength", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Boolean)
    ], WcInputText1005542.prototype, "required", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Boolean)
    ], WcInputText1005542.prototype, "disabled", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Boolean)
    ], WcInputText1005542.prototype, "readonly", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Boolean)
    ], WcInputText1005542.prototype, "autofocus", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WcInputText1005542.prototype, "hint", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WcInputText1005542.prototype, "autocorrect", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WcInputText1005542.prototype, "autoCapitalize", void 0);
    __decorate([
      query(".input_control"),
      __metadata("design:type", typeof (_a = typeof HTMLInputElement !== "undefined" && HTMLInputElement) === "function" ? _a : Object)
    ], WcInputText1005542.prototype, "input", void 0);
    WcInputText1005542 = __decorate([
      customElement("wc-input-text-100554")
    ], WcInputText1005542);
    return WcInputText1005542;
  }(IcaFormsInputString)
);
var templateObject_1, templateObject_2;
export {
  WcInputText100554
};
