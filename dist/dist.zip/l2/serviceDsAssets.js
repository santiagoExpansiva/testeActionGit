var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __assign = function() {
  __assign = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
        t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { html, css, repeat } from "lit";
import { customElement, property, query } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
import { initCollabInputTag, CollabInputTag } from "./_100554_collabInputTag";
var message_pt = {
  loading: "Carregando...",
  cancel: "Cancelar",
  confirm: "Confirmar",
  description: "Descri\uFFFD\uFFFDo",
  name: "Nome",
  versionRef: "Vers\uFFFDo",
  addNewFile: "Aidcionar um novo arquivo"
};
var message_en = {
  loading: "Loading...",
  cancel: "Cancelar",
  confirm: "Confirm",
  description: "Description",
  name: "Name",
  versionRef: "Version Ref",
  addNewFile: "Add new file"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceDsAssets100554 = (
  /** @class */
  function(_super) {
    __extends(ServiceDsAssets1005542, _super);
    function ServiceDsAssets1005542() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.details = {
        icon: "&#xf802",
        state: "foreground",
        tooltip: "Assets",
        visible: true,
        position: "left",
        tags: ["ds_assets"],
        widget: "_100554_serviceDsAssets",
        level: [3]
      };
      _this.onClickLink = function(op) {
        if (op === "opHelper")
          return _this.showInitial();
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.menu = {
        title: "Assets",
        actions: {},
        icons: {},
        actionDefault: "opHelper",
        // call after close icon clicked
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        getLastMode: void 0,
        updateTitle: void 0
      };
      _this.tree = {};
      _this.isAddMode = false;
      _this.actualFiles = [];
      _this.actualPath = "";
      _this.treeController = {
        isNodeReadOnly: true
      };
      _this.filesController = {
        totalFiles: 0,
        totalFilesSelected: 0,
        filesSelected: /* @__PURE__ */ new Set([]),
        filesSelectedArr: [],
        helper: [],
        readOnly: false
      };
      _this.files = {
        readOnlyFiles: [],
        readOnlyFolders: [],
        project: void 0,
        list: {}
      };
      _this.serviceByExtensions = {
        _100554_serviceDsAssetsImage: [".png", ".jpg", ".jpeg", ".webp", ".jfif"],
        _100554_serviceDsAssetsVideo: [".mp4", ".webm"],
        _100554_serviceDsAssetsIcon: [".svg", ".ico"],
        _100554_serviceDsAssetsEditor: [".json", ".ts", ".js", ".css", ".txt", ".css", ".scss", ".less", ".xml", ".html"]
      };
      _this.objIcons = {
        png: "fa-solid fa-image",
        jpeg: "fa-solid fa-image",
        jpg: "fa-solid fa-image",
        webp: "fa-solid fa-image",
        jfif: "fa-solid fa-image",
        js: "fa-brands fa-js",
        ts: "fa-regular fa-file-code",
        html: "fa-regular fa-file-code",
        json: "fa-regular fa-file-code",
        xml: "fa-regular fa-file-code",
        pdf: "fa-solid fa-file-pdf",
        ico: "fa fa-info",
        txt: "fa-solid fa-file-lines",
        doc: "fa-solid fa-file-lines",
        mp3: "fa-sharp fa-regular fa-file-audio",
        zip: "fa-solid fa-file-zipper",
        gz: "fa-solid fa-file-zipper",
        none: "fa-solid fa-file"
      };
      _this.setEvents();
      initCollabInputTag();
      return _this;
    }
    ServiceDsAssets1005542.prototype.onServiceClick = function(visible, reinit, el) {
      this._onServiceClick(visible, reinit, el);
    };
    ServiceDsAssets1005542.prototype._onServiceClick = function(visible, reinit, el) {
      return __awaiter(this, void 0, void 0, function() {
        var params, project, mode, params;
        return __generator(this, function(_a2) {
          if (visible && reinit) {
            params = {
              service: ["_100554_serviceDsAssetsOverview"]
            };
            project = mls.actual[5].project;
            mode = mls.actual[3].mode;
            mls.events.fire([3], ["DSAssetsSelected"], JSON.stringify(params), 100);
            if (this.lastProject !== project || this.lastDsIndex !== mode) {
              this.loading = true;
              this.init();
            }
          }
          if (!visible) {
            params = {
              service: []
            };
            mls.events.fire([3], ["DSAssetsUnSelected"], JSON.stringify(params), 0);
          }
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServiceDsAssets1005542.prototype.setEvents = function() {
      var _this = this;
      mls.events.addEventListener([3], ["DSAssetsChanged"], function(ev) {
        _this.onDsAssetsChanged(ev);
      });
    };
    ServiceDsAssets1005542.prototype.connectedCallback = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a2) {
          _super.prototype.connectedCallback.call(this);
          this.init();
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServiceDsAssets1005542.prototype.init = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              this.tree = {};
              this.actualFiles = [];
              return [4, this.prepareFiles()];
            case 1:
              _a2.sent();
              this.loading = false;
              this.requestUpdate();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsAssets1005542.prototype.showInitial = function() {
      this.menu.title = "Assets";
      return true;
    };
    ServiceDsAssets1005542.prototype.initDsInstance = function(project, dsIndex) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              this.dsInstance = mls.l3.getDSInstance(project, dsIndex);
              return [4, this.dsInstance.init()];
            case 1:
              _a2.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsAssets1005542.prototype.prepareFiles = function() {
      return __awaiter(this, void 0, void 0, function() {
        var project, mode, listDs, nameDs, rc, listFiles, onlyProjects;
        var _this = this;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              project = mls.actual[5].project;
              mode = mls.actual[3].mode;
              if (project === void 0 || mode === void 0)
                return [
                  2
                  /*return*/
                ];
              this.lastProject = project;
              this.lastDsIndex = mode;
              return [4, this.initDsInstance(project, mode)];
            case 1:
              _a2.sent();
              return [4, mls.stor.server.loadProjectInfoIfNeeded(project)];
            case 2:
              _a2.sent();
              listDs = mls.l5.ds.list(project);
              if (!this.dsInstance)
                return [
                  2
                  /*return*/
                ];
              nameDs = listDs[this.dsInstance.dsindex].dsName;
              rc = {};
              listFiles = mls.stor.files;
              onlyProjects = Object.keys(listFiles).filter(function(file) {
                return listFiles[file].project === project;
              });
              onlyProjects.forEach(function(item) {
                var _a3 = listFiles[item], level = _a3.level, folder = _a3.folder, status = _a3.status;
                if (status === "deleted")
                  return;
                if (level === 3 && (folder.startsWith("ds/".concat(nameDs, "/")) || folder === "ds/".concat(nameDs)))
                  rc[item] = listFiles[item];
              });
              this.files.list = rc;
              this.files.project = project;
              this.files.readOnlyFiles = [];
              this.files.readOnlyFolders = ["ds", "ds/".concat(nameDs), "ds/".concat(nameDs, "/docs"), "ds/".concat(nameDs, "/css"), "ds/".concat(nameDs, "/css"), "ds/".concat(nameDs, "/components*")];
              Object.entries(this.files.list).forEach(function(entry) {
                var key = entry[0], value = entry[1];
                var parts = value.folder.split("/");
                var currentFolder = _this.tree;
                parts.forEach(function(folder) {
                  currentFolder[folder] = currentFolder[folder] || {};
                  currentFolder = currentFolder[folder];
                });
                currentFolder[key] = {
                  shortName: value.shortName,
                  folder: value.folder,
                  info: __assign({}, value)
                };
              });
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsAssets1005542.prototype.onDsAssetsChanged = function(ev) {
      return __awaiter(this, void 0, void 0, function() {
        var params;
        return __generator(this, function(_a2) {
          if (!ev.desc)
            return [
              2
              /*return*/
            ];
          params = JSON.parse(ev.desc);
          if (params.position === "left")
            return [
              2
              /*return*/
            ];
          if (params.action === "delete") {
            this.onDelete();
          }
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServiceDsAssets1005542.prototype.onDelete = function() {
      return __awaiter(this, void 0, void 0, function() {
        var params;
        return __generator(this, function(_a2) {
          this.actualFiles = [];
          this.updateActualFiles(this.actualPath);
          params = {
            service: []
          };
          mls.events.fire([3], ["DSAssetsUnSelected"], JSON.stringify(params), 500);
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServiceDsAssets1005542.prototype.handleFolderClick = function(e, folder) {
      e.stopPropagation();
      this.actualPath = folder;
      this.updateActualFiles(folder);
      if (!this.treeEl)
        return;
      var target = e.target;
      var treeItem = target.closest(".tree-item");
      if (!treeItem)
        return;
      var details = treeItem.closest("details");
      if (!treeItem.classList.contains("selected") && details && details.open)
        e.preventDefault();
      this.treeEl.querySelectorAll(".tree-item").forEach(function(it) {
        return it.classList.remove("selected");
      });
      treeItem.classList.add("selected");
    };
    ServiceDsAssets1005542.prototype.updateActualFiles = function(folder) {
      var files = this.getFilesInFolder(folder);
      this.filesController.totalFiles = files.length;
      this.filesController.totalFilesSelected = 0;
      this.filesController.filesSelected = /* @__PURE__ */ new Set([]);
      this.actualFiles = files;
      this.treeController.isNodeReadOnly = this.checkIsReadOnlyNode(folder);
    };
    ServiceDsAssets1005542.prototype.checkIsReadOnlyNode = function(pathFolders) {
      var isreadonly = false;
      this.files.readOnlyFolders.forEach(function(item) {
        var deep = item.endsWith("*");
        var path = deep ? item.substr(0, item.length - 1) : item;
        if (deep && pathFolders.startsWith(path))
          isreadonly = true;
        else if (pathFolders === path)
          isreadonly = true;
      });
      return isreadonly;
    };
    ServiceDsAssets1005542.prototype.getFilesInFolder = function(folder) {
      var _this = this;
      var filesInFolder = Object.keys(this.files.list).map(function(key) {
        if (_this.files.list[key].folder === folder && _this.files.list[key].status !== "deleted")
          return _this.files.list[key];
      }).filter(function(value) {
        return value !== void 0;
      });
      return filesInFolder;
    };
    ServiceDsAssets1005542.prototype.onCheckAllChange = function(ev) {
      var _this = this;
      var val = ev.target.checked;
      if (!this.tbody)
        return;
      this.tbody.querySelectorAll('input[type="checkbox"').forEach(function(item) {
        var _a2;
        var input = item;
        input.checked = val;
        (_a2 = input.closest("tr")) === null || _a2 === void 0 ? void 0 : _a2.classList.toggle("selected", val);
      });
      if (val)
        this.filesController.totalFilesSelected = 0;
      this.actualFiles.forEach(function(item) {
        if (val)
          _this.addSelectedItem(item);
        else
          _this.removeSelectedItem(item);
      });
    };
    ServiceDsAssets1005542.prototype.addSelectedItem = function(item) {
      this.filesController.totalFilesSelected += 1;
      this.filesController.filesSelected.add(item);
      this.fireEventSelectedsItens();
    };
    ServiceDsAssets1005542.prototype.removeSelectedItem = function(item) {
      this.filesController.totalFilesSelected -= 1;
      this.filesController.filesSelected.delete(item);
      this.fireEventSelectedsItens();
    };
    ServiceDsAssets1005542.prototype.fireEventSelectedsItens = function() {
      var _this = this;
      if (this.filesController.totalFilesSelected === 1) {
        var file_1 = this.filesController.filesSelected[0];
        var extensiosServicesKey = Object.keys(this.serviceByExtensions);
        extensiosServicesKey.forEach(function(key) {
          if (_this.serviceByExtensions[key].includes(file_1.extension))
            _this.filesController.helper = [key, "_100554_serviceDsAssetsOverview"];
        });
        this.filesController.readOnly = this.treeController.isNodeReadOnly;
      } else {
        this.filesController.helper = ["_100554_serviceDsAssetsOverview"];
        this.filesController.readOnly = true;
      }
      this.filesController.filesSelectedArr = Array.from(this.filesController.filesSelected);
      var params = {
        action: "show",
        info: this.filesController,
        position: "left"
      };
      mls.events.fire([3], ["DSAssetsChanged"], JSON.stringify(params));
    };
    ServiceDsAssets1005542.prototype.onFileClick = function(e, item) {
      e.stopPropagation();
      var target = e.target;
      var tr = target.closest("tr");
      if (!tr)
        return;
      var check = tr.querySelector('input[type="checkbox"]');
      tr.classList.toggle("selected");
      if (target.tagName !== "INPUT")
        check.checked = !check.checked;
      if (check.checked)
        this.addSelectedItem(item);
      else
        this.removeSelectedItem(item);
      if (this.filesController.totalFiles === this.filesController.totalFilesSelected)
        this.toogleCheckBoxAll(true);
      else
        this.toogleCheckBoxAll(false);
    };
    ServiceDsAssets1005542.prototype.toogleCheckBoxAll = function(checked) {
      if (!this.checkBoxAll)
        return;
      this.checkBoxAll.checked = checked;
    };
    ServiceDsAssets1005542.prototype.onActionAddConfirm = function() {
      return __awaiter(this, void 0, void 0, function() {
        var tags, description, assetType, file, content, path;
        var _a2, _b2, _c2;
        return __generator(this, function(_d2) {
          switch (_d2.label) {
            case 0:
              if (!this.inputFile || !this.dsInstance)
                return [
                  2
                  /*return*/
                ];
              tags = ((_a2 = this.inputTags) === null || _a2 === void 0 ? void 0 : _a2.value.trim().split(",")) || [];
              description = ((_b2 = this.txtDesc) === null || _b2 === void 0 ? void 0 : _b2.value) || "";
              assetType = (_c2 = this.selectType) === null || _c2 === void 0 ? void 0 : _c2.value;
              file = this.inputFile.files ? this.inputFile.files[0] : void 0;
              if (!file)
                return [
                  2
                  /*return*/
                ];
              content = file;
              path = this.actualPath;
              return [4, this.dsInstance.assets.add(path, file.name, tags, description, assetType, content, void 0)];
            case 1:
              _d2.sent();
              this.updateActualFiles(this.actualPath);
              this.isAddMode = false;
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceDsAssets1005542.prototype.onActionAddCancel = function() {
      this.isAddMode = false;
    };
    ServiceDsAssets1005542.prototype.onAddNewFileClick = function() {
      this.isAddMode = true;
    };
    ServiceDsAssets1005542.prototype.renderNode = function(key, node, folder) {
      var _this = this;
      var isFile = function(str) {
        return str.split("_").length > 1;
        ;
      };
      var hasFolderInNode = function(checkNode) {
        var keysNode = Object.keys(checkNode);
        var check = keysNode.filter(function(nd) {
          return isFile(nd);
        });
        return keysNode.length > check.length;
      };
      if (!isFile(key)) {
        var newFolder_1 = folder ? "".concat(folder, "/").concat(key) : key;
        var hasFolder = hasFolderInNode(node);
        if (hasFolder) {
          return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['\n                    <details style="margin-left: 1rem;" folder=', " @click=", '>\n                        <summary class="tree-item">', "</summary>\n                        ", "\n                    </details>\n                "], ['\n                    <details style="margin-left: 1rem;" folder=', " @click=", '>\n                        <summary class="tree-item">', "</summary>\n                        ", "\n                    </details>\n                "])), newFolder_1, function(e) {
            return _this.handleFolderClick(e, newFolder_1);
          }, key, Object.keys(node).map(function(keyC) {
            return _this.renderNode(keyC, node[keyC], newFolder_1);
          }));
        }
        return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(['\n                    <div class="tree-item" style="margin-left: 1rem;" folder=', " @click=", ">\n                        ", "\n                    </div>\n                "], ['\n                    <div class="tree-item" style="margin-left: 1rem;" folder=', " @click=", ">\n                        ", "\n                    </div>\n                "])), newFolder_1, function(e) {
          return _this.handleFolderClick(e, newFolder_1);
        }, key);
      }
    };
    ServiceDsAssets1005542.prototype.renderTable = function() {
      var _this = this;
      var typesAssets = ["image", "video", "icon", "lib", "other"];
      return html(templateObject_5 || (templateObject_5 = __makeTemplateObject(["\n\n            <table class=", '>\n                <thead>\n                    <tr>\n                        <th>\n                            <input id="checkAll" type="checkbox" @change=', "></input>\n                        </th>\n                        <th>#</th>\n                        <th>", "</th>\n                        <th>", "</th>\n                    </tr>\n                    \n                </thead>\n                <tbody>\n\n                ", '\n                </tbody>\n            </table>\n            <div class="actions" style="display:', '">\n                <button\n                    style="display:', '"\n                    @click=', ">\n                ", '\n                </button>\n            </div>\n\n            <div class="add-file-container ', '">\n                <input class="inputFile" type="file"></input>\n                <select class="selectType">\n                    ', '\n                </select>\n                <textarea class="txtDesc" placeholder="', '"></textarea>\n                <collab-input-tag-100554></collab-input-tag-100554>\n                <div class="add-container-actions ', '">\n                    <button @click=', ">", "</button>\n                    <button @click=", ">", "</button>\n                </div>\n            </div>\n        "], ["\n\n            <table class=", '>\n                <thead>\n                    <tr>\n                        <th>\n                            <input id="checkAll" type="checkbox" @change=', "></input>\n                        </th>\n                        <th>#</th>\n                        <th>", "</th>\n                        <th>", "</th>\n                    </tr>\n                    \n                </thead>\n                <tbody>\n\n                ", '\n                </tbody>\n            </table>\n            <div class="actions" style="display:', '">\n                <button\n                    style="display:', '"\n                    @click=', ">\n                ", '\n                </button>\n            </div>\n\n            <div class="add-file-container ', '">\n                <input class="inputFile" type="file"></input>\n                <select class="selectType">\n                    ', '\n                </select>\n                <textarea class="txtDesc" placeholder="', '"></textarea>\n                <collab-input-tag-100554></collab-input-tag-100554>\n                <div class="add-container-actions ', '">\n                    <button @click=', ">", "</button>\n                    <button @click=", ">", "</button>\n                </div>\n            </div>\n        "])), this.isAddMode ? "hidden" : "", function(ev) {
        _this.onCheckAllChange(ev);
      }, this.msg.name, this.msg.versionRef, repeat(this.actualFiles, function(key) {
        return key;
      }, function(k, index) {
        var extWithoutDot = k.extension.substring(1, k.extension.length);
        var extension = _this.objIcons[extWithoutDot];
        var typeFileIcon = extension || _this.objIcons["none"];
        return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(["\n                            <tr @click=", '>\n                                <td>\n                                    <input type="checkbox"></input>\n                                </td>\n                                <td>\n                                    <i class="', '"></i>\n                                </td>\n                                <td>', "</td>\n                                <td>", "</td>\n                            </tr>\n                        "], ["\n                            <tr @click=", '>\n                                <td>\n                                    <input type="checkbox"></input>\n                                </td>\n                                <td>\n                                    <i class="', '"></i>\n                                </td>\n                                <td>', "</td>\n                                <td>", "</td>\n                            </tr>\n                        "])), function(e) {
          _this.onFileClick(e, k);
        }, typeFileIcon, k.shortName, k.versionRef);
      }), this.treeController.isNodeReadOnly ? "none" : "", this.isAddMode ? "none" : "block", function() {
        _this.onAddNewFileClick();
      }, this.msg.addNewFile, this.isAddMode ? "visible" : "", typesAssets.map(function(t) {
        return html(templateObject_4 || (templateObject_4 = __makeTemplateObject(["\n                            <option value=", ">", "</option>\n                        "], ["\n                            <option value=", ">", "</option>\n                        "])), t, t);
      }), this.msg.description, this.isAddMode ? "visible" : "", function() {
        _this.onActionAddConfirm();
      }, this.msg.confirm, function() {
        _this.onActionAddCancel();
      }, this.msg.cancel);
    };
    ServiceDsAssets1005542.prototype.render = function() {
      var _this = this;
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_8 || (templateObject_8 = __makeTemplateObject(["\n            <div>\n                ", ""], ["\n            <div>\n                ", ""])), this.loading ? html(templateObject_6 || (templateObject_6 = __makeTemplateObject(["<p>", "</p>"], ["<p>", "</p>"])), this.msg.loading) : html(templateObject_7 || (templateObject_7 = __makeTemplateObject(['\n                    <div class="assets-container">\n                        <div class="assets-tree">\n                            ', '\n                        </div>\n                        <div class="assets-details">\n                            ', "\n                        </div> \n                    </div> \n                    "], ['\n                    <div class="assets-container">\n                        <div class="assets-tree">\n                            ', '\n                        </div>\n                        <div class="assets-details">\n                            ', "\n                        </div> \n                    </div> \n                    "])), Object.keys(this.tree).map(function(item) {
        return _this.renderNode(item, _this.tree[item], "");
      }), this.renderTable()));
    };
    var _a, _b, _c, _d, _e, _f, _g;
    ServiceDsAssets1005542.styles = css(templateObject_9 || (templateObject_9 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      query("tbody"),
      __metadata("design:type", typeof (_a = typeof HTMLElement !== "undefined" && HTMLElement) === "function" ? _a : Object)
    ], ServiceDsAssets1005542.prototype, "tbody", void 0);
    __decorate([
      query(".assets-tree"),
      __metadata("design:type", typeof (_b = typeof HTMLElement !== "undefined" && HTMLElement) === "function" ? _b : Object)
    ], ServiceDsAssets1005542.prototype, "treeEl", void 0);
    __decorate([
      query("#checkAll"),
      __metadata("design:type", typeof (_c = typeof HTMLInputElement !== "undefined" && HTMLInputElement) === "function" ? _c : Object)
    ], ServiceDsAssets1005542.prototype, "checkBoxAll", void 0);
    __decorate([
      query("collab-input-tag-100554"),
      __metadata("design:type", typeof (_d = typeof CollabInputTag !== "undefined" && CollabInputTag) === "function" ? _d : Object)
    ], ServiceDsAssets1005542.prototype, "inputTags", void 0);
    __decorate([
      query(".txtDesc"),
      __metadata("design:type", typeof (_e = typeof HTMLTextAreaElement !== "undefined" && HTMLTextAreaElement) === "function" ? _e : Object)
    ], ServiceDsAssets1005542.prototype, "txtDesc", void 0);
    __decorate([
      query(".inputFile"),
      __metadata("design:type", typeof (_f = typeof HTMLInputElement !== "undefined" && HTMLInputElement) === "function" ? _f : Object)
    ], ServiceDsAssets1005542.prototype, "inputFile", void 0);
    __decorate([
      query(".selectType"),
      __metadata("design:type", typeof (_g = typeof HTMLInputElement !== "undefined" && HTMLInputElement) === "function" ? _g : Object)
    ], ServiceDsAssets1005542.prototype, "selectType", void 0);
    __decorate([
      property(),
      __metadata("design:type", Object)
    ], ServiceDsAssets1005542.prototype, "tree", void 0);
    __decorate([
      property(),
      __metadata("design:type", Boolean)
    ], ServiceDsAssets1005542.prototype, "isAddMode", void 0);
    __decorate([
      property(),
      __metadata("design:type", Array)
    ], ServiceDsAssets1005542.prototype, "actualFiles", void 0);
    ServiceDsAssets1005542 = __decorate([
      customElement("service-ds-assets-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceDsAssets1005542);
    return ServiceDsAssets1005542;
  }(ServiceBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6, templateObject_7, templateObject_8, templateObject_9;
export {
  ServiceDsAssets100554
};
