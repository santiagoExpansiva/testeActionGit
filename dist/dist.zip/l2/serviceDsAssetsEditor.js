var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { html } from "lit";
import { customElement, property, query } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
var ServiceDsAssetsEditor100554 = (
  /** @class */
  function(_super) {
    __extends(ServiceDsAssetsEditor1005542, _super);
    function ServiceDsAssetsEditor1005542() {
      var _this = _super.call(this) || this;
      _this.details = {
        icon: "&#xf121",
        state: "foreground",
        tooltip: "Assets Editor",
        visible: false,
        position: "right",
        tags: ["ds_assets"],
        widget: "_100554_serviceDsAssetsEditor",
        level: [3]
      };
      _this.onClickLink = function(op) {
        if (op === "opEditor")
          return _this.showEditor();
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.menu = {
        title: "Assets Editor",
        actions: {
          opEditor: "Editor"
        },
        icons: {},
        actionDefault: "opEditor",
        // call after close icon clicked
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        getLastMode: void 0,
        updateTitle: void 0
      };
      _this.msize = "";
      _this.editorTypeByExtensions = {
        ".json": "json",
        ".txt": "plaintext",
        ".ts": "typescript",
        ".js": "javascript",
        ".css": "css",
        ".less": "less",
        ".html": "html",
        ".java": "java",
        ".scss": "scss",
        ".xml": "xml"
      };
      _this.setEvents();
      return _this;
    }
    ServiceDsAssetsEditor100554_1 = ServiceDsAssetsEditor1005542;
    ServiceDsAssetsEditor1005542.prototype.onServiceClick = function(visible, reinit, el) {
      this._onServiceClick(visible, reinit, el);
    };
    ServiceDsAssetsEditor1005542.prototype._onServiceClick = function(visible, reinit, el) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a2) {
          if (visible) {
            this.createEditor();
            this.showEditor2();
            setTimeout(function() {
              if (el && typeof el.layout === "function")
                el.layout();
            }, 100);
          }
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServiceDsAssetsEditor1005542.prototype.setEvents = function() {
      var _this = this;
      mls.events.addEventListener([this.level], ["DSAssetsUnSelected"], function(ev) {
        _this.onDsAssetsUnSelected(ev);
      });
      mls.events.addEventListener([this.level], ["DSAssetsChanged"], function(ev) {
        _this.onDsAssetsChanged(ev);
      });
    };
    ServiceDsAssetsEditor1005542.prototype.createRenderRoot = function() {
      return this;
    };
    ServiceDsAssetsEditor1005542.prototype.onDsAssetsUnSelected = function(ev) {
      if (!ev.desc)
        return;
      var params = JSON.parse(ev.desc);
      if (params.service.includes("_100554_serviceDsAssetsEditor"))
        return;
      this.showNav2Item(false);
    };
    ServiceDsAssetsEditor1005542.prototype.onDsAssetsChanged = function(ev) {
      if (!ev.desc)
        return;
      var params = JSON.parse(ev.desc);
      if (params.position === "right")
        return;
      if (params.info.helper.includes("_100554_serviceDsAssetsEditor")) {
        this.data = params;
        this.showNav2Item(true);
        this.openMe();
      } else
        this.showNav2Item(false);
    };
    ServiceDsAssetsEditor1005542.prototype.createEditor = function() {
      if (!this.c2)
        return;
      if (this._ed1) {
        this.setInitialModels("Loading...", "textplain");
        this.setMsizeEditor();
        return;
      }
      this._ed1 = monaco.editor.create(this.c2, mls.editor.conf["l3_assets_visualization_editor"]);
      this.c2["mlsEditor"] = this._ed1;
      this.setMsizeEditor();
    };
    ServiceDsAssetsEditor1005542.prototype.getUri = function(shortFN) {
      ServiceDsAssetsEditor100554_1.modelCount = ServiceDsAssetsEditor100554_1.modelCount + 1 || 1;
      return monaco.Uri.parse("file://server/".concat(shortFN, "_").concat(ServiceDsAssetsEditor100554_1.modelCount, ".ts"));
    };
    ServiceDsAssetsEditor1005542.prototype.setInitialModels = function(src, mode) {
      var uri = this.getUri("l3_assets_visualization_editor");
      this.model = monaco.editor.getModel(uri);
      var val = src;
      if (mode === "json")
        val = JSON.stringify(JSON.parse(src), null, 2);
      if (this.model)
        this.model.setValue(src);
      else
        this.model = monaco.editor.createModel(val, mode, uri);
    };
    ServiceDsAssetsEditor1005542.prototype.setMsizeEditor = function() {
      var _a2;
      if (!this.visible)
        return;
      (_a2 = this.c2) === null || _a2 === void 0 ? void 0 : _a2.setAttribute("msize", this.msize);
    };
    ServiceDsAssetsEditor1005542.prototype.showEditor = function() {
      this.menu.title = "Editor";
      this.showEditor2();
      return true;
    };
    ServiceDsAssetsEditor1005542.prototype.showEditor2 = function() {
      return __awaiter(this, void 0, void 0, function() {
        var obj;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              return [4, this.getValue()];
            case 1:
              obj = _a2.sent();
              if (!obj || !this._ed1)
                return [
                  2
                  /*return*/
                ];
              this.setInitialModels(obj.value, obj.mode);
              this._ed1.setModel(this.model);
              return [2, true];
          }
        });
      });
    };
    ServiceDsAssetsEditor1005542.prototype.getValue = function() {
      return __awaiter(this, void 0, Promise, function() {
        var fileSelected, folder, extension, level, project, shortName, keyFile, value, mode;
        var _a2;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              if (!this.data)
                return [
                  2
                  /*return*/
                ];
              if (!this.data.info.filesSelectedArr)
                return [2, void 0];
              fileSelected = this.data.info.filesSelectedArr[0];
              if (!fileSelected)
                return [2, void 0];
              folder = fileSelected.folder, extension = fileSelected.extension, level = fileSelected.level, project = fileSelected.project, shortName = fileSelected.shortName;
              keyFile = mls.stor.getKeyToFiles(project, level, shortName, folder, extension);
              return [4, (_a2 = mls.stor.files[keyFile]) === null || _a2 === void 0 ? void 0 : _a2.getContent()];
            case 1:
              value = _b.sent();
              mode = this.editorTypeByExtensions[extension] ? this.editorTypeByExtensions[extension] : "plaintext";
              return [2, new Promise(function(resolve, reject) {
                if (typeof value === "string") {
                  resolve({ value, mode });
                  return;
                }
                var file = value;
                var reader = new FileReader();
                reader.addEventListener("load", function() {
                  resolve({ value: reader.result, mode });
                });
                reader.readAsBinaryString(file);
              })];
          }
        });
      });
    };
    ServiceDsAssetsEditor1005542.prototype.updated = function(changedProperties) {
      if (changedProperties.has("msize")) {
        if (!this.visible)
          return;
        this.setMsizeEditor();
      }
    };
    ServiceDsAssetsEditor1005542.prototype.render = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['<mls-editor-100529 ismls2="true"></mls-editor-100529>'], ['<mls-editor-100529 ismls2="true"></mls-editor-100529>'])));
    };
    var ServiceDsAssetsEditor100554_1;
    var _a;
    __decorate([
      property({ type: String }),
      __metadata("design:type", Object)
    ], ServiceDsAssetsEditor1005542.prototype, "msize", void 0);
    __decorate([
      query("mls-editor-100529"),
      __metadata("design:type", typeof (_a = typeof HTMLElement !== "undefined" && HTMLElement) === "function" ? _a : Object)
    ], ServiceDsAssetsEditor1005542.prototype, "c2", void 0);
    ServiceDsAssetsEditor1005542 = ServiceDsAssetsEditor100554_1 = __decorate([
      customElement("service-ds-assets-editor-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceDsAssetsEditor1005542);
    return ServiceDsAssetsEditor1005542;
  }(ServiceBase)
);
var templateObject_1;
export {
  ServiceDsAssetsEditor100554
};
