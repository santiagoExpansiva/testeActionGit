var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css, LitElement } from "lit";
import { customElement, property } from "lit/decorators.js";
var SimpleGreeting = (
  /** @class */
  function(_super) {
    __extends(SimpleGreeting2, _super);
    function SimpleGreeting2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.name = new Date(Date.now()).toString();
      return _this;
    }
    SimpleGreeting2.prototype.handleConfirm = function(e) {
      console.info(e.detail);
    };
    SimpleGreeting2.prototype.render = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["<aim-select-widget-100554 @select-widget-confirm=", "> </aim-select-widget-100554>"], ["<aim-select-widget-100554 @select-widget-confirm=", "> </aim-select-widget-100554>"])), this.handleConfirm);
    };
    SimpleGreeting2.styles = css(templateObject_2 || (templateObject_2 = __makeTemplateObject(["p { color: red }"], ["p { color: red }"])));
    __decorate([
      property(),
      __metadata("design:type", String)
    ], SimpleGreeting2.prototype, "name", void 0);
    SimpleGreeting2 = __decorate([
      customElement("ateste-100554")
    ], SimpleGreeting2);
    return SimpleGreeting2;
  }(LitElement)
);
var templateObject_1, templateObject_2;
export {
  SimpleGreeting
};
