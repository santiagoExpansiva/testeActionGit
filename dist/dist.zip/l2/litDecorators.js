var __assign = function() {
  __assign = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
        t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var legacyPrototypeMethod = function(descriptor, proto, name) {
  Object.defineProperty(proto, name, descriptor);
};
var standardPrototypeMethod = function(descriptor, element) {
  return {
    kind: "method",
    placement: "prototype",
    key: element.key,
    descriptor
  };
};
var decorateProperty = function(_a) {
  var finisher = _a.finisher, descriptor = _a.descriptor;
  return function(protoOrDescriptor, name) {
    var _a2;
    if (name !== void 0) {
      var ctor = protoOrDescriptor.constructor;
      if (descriptor !== void 0) {
        Object.defineProperty(protoOrDescriptor, name, descriptor(name));
      }
      finisher === null || finisher === void 0 ? void 0 : finisher(ctor, name);
    } else {
      var key_1 = (
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (_a2 = protoOrDescriptor.originalKey) !== null && _a2 !== void 0 ? _a2 : protoOrDescriptor.key
      );
      var info = descriptor != void 0 ? {
        kind: "method",
        placement: "prototype",
        key: key_1,
        descriptor: descriptor(protoOrDescriptor.key)
      } : __assign(__assign({}, protoOrDescriptor), { key: key_1 });
      if (finisher != void 0) {
        info.finisher = function(ctor2) {
          finisher(ctor2, key_1);
        };
      }
      return info;
    }
  };
};
var legacyCustomElement = function(tagName, clazz) {
  customElements.define(tagName, clazz);
  return clazz;
};
var standardCustomElement = function(tagName, descriptor) {
  var kind = descriptor.kind, elements = descriptor.elements;
  return {
    kind,
    elements,
    // This callback is called once the class is otherwise fully defined
    finisher: function(clazz) {
      customElements.define(tagName, clazz);
    }
  };
};
var customElement = function(tagName) {
  return function(classOrDescriptor) {
    return typeof classOrDescriptor === "function" ? legacyCustomElement(tagName, classOrDescriptor) : standardCustomElement(tagName, classOrDescriptor);
  };
};
function eventOptions(options) {
  return decorateProperty({
    finisher: function(ctor, name) {
      Object.assign(
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        ctor.prototype[name],
        options
      );
    }
  });
}
var standardProperty = function(options, element) {
  if (element.kind === "method" && element.descriptor && !("value" in element.descriptor)) {
    return __assign(__assign({}, element), { finisher: function(clazz) {
      clazz.createProperty(element.key, options);
    } });
  } else {
    return {
      kind: "field",
      key: Symbol(),
      placement: "own",
      descriptor: {},
      // store the original key so subsequent decorators have access to it.
      originalKey: element.key,
      // When @babel/plugin-proposal-decorators implements initializers,
      // do this instead of the initializer below. See:
      // https://github.com/babel/babel/issues/9260 extras: [
      //   {
      //     kind: 'initializer',
      //     placement: 'own',
      //     initializer: descriptor.initializer,
      //   }
      // ],
      initializer: function() {
        if (typeof element.initializer === "function") {
          this[element.key] = element.initializer.call(this);
        }
      },
      finisher: function(clazz) {
        clazz.createProperty(element.key, options);
      }
    };
  }
};
var legacyProperty = function(options, proto, name) {
  proto.constructor.createProperty(name, options);
};
function property(options) {
  return function(protoOrDescriptor, name) {
    return name !== void 0 ? legacyProperty(options, protoOrDescriptor, name) : standardProperty(options, protoOrDescriptor);
  };
}
function queryAll(selector) {
  return decorateProperty({
    descriptor: function(_name) {
      return {
        get: function() {
          var _a, _b;
          return (_b = (_a = this.renderRoot) === null || _a === void 0 ? void 0 : _a.querySelectorAll(selector)) !== null && _b !== void 0 ? _b : [];
        },
        enumerable: true,
        configurable: true
      };
    }
  });
}
function queryAsync(selector) {
  return decorateProperty({
    descriptor: function(_name) {
      return {
        get: function() {
          return __awaiter(this, void 0, void 0, function() {
            var _a;
            return __generator(this, function(_b) {
              switch (_b.label) {
                case 0:
                  return [4, this.updateComplete];
                case 1:
                  _b.sent();
                  return [2, (_a = this.renderRoot) === null || _a === void 0 ? void 0 : _a.querySelector(selector)];
              }
            });
          });
        },
        enumerable: true,
        configurable: true
      };
    }
  });
}
function query(selector, cache) {
  return decorateProperty({
    descriptor: function(name) {
      var descriptor = {
        get: function() {
          var _a, _b;
          return (_b = (_a = this.renderRoot) === null || _a === void 0 ? void 0 : _a.querySelector(selector)) !== null && _b !== void 0 ? _b : null;
        },
        enumerable: true,
        configurable: true
      };
      if (cache) {
        var key_2 = typeof name === "symbol" ? Symbol() : "__".concat(name);
        descriptor.get = function() {
          var _a, _b;
          if (this[key_2] === void 0) {
            this[key_2] = (_b = (_a = this.renderRoot) === null || _a === void 0 ? void 0 : _a.querySelector(selector)) !== null && _b !== void 0 ? _b : null;
          }
          return this[key_2];
        };
      }
      return descriptor;
    }
  });
}
function state(options) {
  return property(__assign(__assign({}, options), { state: true }));
}
export {
  customElement,
  decorateProperty,
  eventOptions,
  legacyPrototypeMethod,
  property,
  query,
  queryAll,
  queryAsync,
  standardPrototypeMethod,
  state
};
