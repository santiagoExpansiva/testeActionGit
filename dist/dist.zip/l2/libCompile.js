var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var __spreadArray = function(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};
var getDependenciesByHtml = function(mfile, html, withCss) {
  if (withCss === void 0) {
    withCss = false;
  }
  return new Promise(function(resolve, reject) {
    return __awaiter(void 0, void 0, void 0, function() {
      var _a, e_1;
      return __generator(this, function(_b) {
        switch (_b.label) {
          case 0:
            _b.trys.push([0, 2, , 3]);
            _a = resolve;
            return [4, getDependencies(mfile, "byHtml", html, withCss)];
          case 1:
            _a.apply(void 0, [_b.sent()]);
            return [3, 3];
          case 2:
            e_1 = _b.sent();
            reject(e_1);
            return [3, 3];
          case 3:
            return [
              2
              /*return*/
            ];
        }
      });
    });
  });
};
var getDependenciesByMFile = function(mfile, withCss) {
  if (withCss === void 0) {
    withCss = false;
  }
  return new Promise(function(resolve, reject) {
    return __awaiter(void 0, void 0, void 0, function() {
      var tag, _a, e_2;
      return __generator(this, function(_b) {
        switch (_b.label) {
          case 0:
            _b.trys.push([0, 2, , 3]);
            if (mfile.storFile.extension !== ".ts")
              throw new Error("Only myfile .ts");
            tag = convertFileNameToTag("_".concat(mfile.storFile.project, "_").concat(mfile.storFile.shortName));
            _a = resolve;
            return [4, getDependencies(mfile, tag, "<".concat(tag, "></").concat(tag, ">"), withCss)];
          case 1:
            _a.apply(void 0, [_b.sent()]);
            return [3, 3];
          case 2:
            e_2 = _b.sent();
            reject(e_2);
            return [3, 3];
          case 3:
            return [
              2
              /*return*/
            ];
        }
      });
    });
  });
};
function getTagsInTypescript(mfile, tags) {
  return __awaiter(this, void 0, Promise, function() {
    var tagsInTypescript, _i, tagsInTypescript_1, tagTs, fileName, mfile_1;
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          tagsInTypescript = getAllWebComponentsInSource(mfile.model.getValue());
          _i = 0, tagsInTypescript_1 = tagsInTypescript;
          _a.label = 1;
        case 1:
          if (!(_i < tagsInTypescript_1.length)) return [3, 4];
          tagTs = tagsInTypescript_1[_i];
          if (!!tags.includes(tagTs)) return [3, 3];
          fileName = convertTagToFileName(tagTs);
          mfile_1 = mls.l2.editor.mfiles[fileName];
          if (!mfile_1) return [3, 3];
          return [4, getTagsInTypescript(mfile_1, tags)];
        case 2:
          _a.sent();
          tags.push(tagTs);
          _a.label = 3;
        case 3:
          _i++;
          return [3, 1];
        case 4:
          return [2, tags];
      }
    });
  });
}
function getDependencies(mfile_2, filename_1, html_1) {
  return __awaiter(this, arguments, void 0, function(mfile, filename, html, withCss) {
    var myImportsMap, myImports, myCss, myTokens, myErrors, myModules, tags, tag;
    if (withCss === void 0) {
      withCss = false;
    }
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          myImportsMap = [];
          myImports = [];
          myCss = [];
          myTokens = [];
          myErrors = [];
          myModules = {};
          tags = extrairTagsCustomizadas(html);
          tag = convertFileNameToTag("_".concat(mfile.storFile.project, "_").concat(mfile.storFile.shortName));
          if (!tags.includes(tag))
            tags.push(tag);
          return [4, getTagsInTypescript(mfile, tags)];
        case 1:
          tags = _a.sent();
          return [4, loadMyNeedsToCompile(tags, myImportsMap, myImports, myCss, myTokens, myErrors, myModules, withCss)];
        case 2:
          _a.sent();
          return [2, {
            file: filename,
            wcComponents: tags,
            importsMap: myImportsMap,
            importsJs: myImports,
            css: myCss,
            tokens: myTokens,
            errors: myErrors
          }];
      }
    });
  });
}
function extrairTagsCustomizadas(html) {
  var regex = /<\/?([a-z][a-z0-9-]*)\b[^>]*>/gi;
  var customTags = [];
  var match;
  while ((match = regex.exec(html)) !== null) {
    var tag = match[1];
    if (tag.indexOf("-") >= 0 && !customTags.includes(tag) && !["mls-showexamplecode-100529", "mls-usecaseadd-100529", "mls-head"].includes(tag.replace("<", "").replace(">", ""))) {
      customTags.push(tag.replace("<", "").replace(">", ""));
    }
  }
  return customTags;
}
function loadMyNeedsToCompile(tags, myImportsMap, myImports, myCss, myTokens, myErrors, myModules, compileCss) {
  return __awaiter(this, void 0, void 0, function() {
    var name, _a, project, path, mfile, enhacementName, mModule, e_3;
    return __generator(this, function(_b) {
      switch (_b.label) {
        case 0:
          _b.trys.push([0, 11, 12, 15]);
          if (tags.length <= 0)
            return [
              2
              /*return*/
            ];
          name = convertTagToFileName(tags[0]);
          mls.actual[0].setFullName(name);
          _a = mls.actual[0], project = _a.project, path = _a.path;
          if (!project || !path)
            return [
              2
              /*return*/
            ];
          mfile = mls.l2.editor.get({ project, shortName: path });
          if (!mfile)
            throw new Error("not found");
          if (!(!mfile.compilerResults || !mfile.compilerResults.prodJS || !mfile.compilerResults.tripleSlashMLS)) return [3, 2];
          if (mfile.compilerResults)
            mfile.compilerResults.modelNeedCompile = true;
          return [4, mls.l2.editor.getCompilerResultTS(mfile, true)];
        case 1:
          _b.sent();
          _b.label = 2;
        case 2:
          enhacementName = mfile.compilerResults.tripleSlashMLS.variables.enhancement;
          if (!enhacementName)
            throw new Error("enhacementName not valid");
          if (!!myModules[enhacementName]) return [3, 4];
          return [4, mls.l2.enhancement.getEnhancementInstance(mfile)];
        case 3:
          mModule = _b.sent();
          myModules[enhacementName] = {
            jsMap: false,
            mModule
          };
          _b.label = 4;
        case 4:
          return [4, addRequeries(enhacementName, mfile, tags, myModules)];
        case 5:
          tags = _b.sent();
          return [4, getJSImporMap(myImportsMap, enhacementName, mfile, myModules)];
        case 6:
          _b.sent();
          return [4, getJS(myImports, enhacementName, mfile, myModules)];
        case 7:
          _b.sent();
          if (!compileCss) return [3, 9];
          return [4, getCss(myCss, name, mfile)];
        case 8:
          _b.sent();
          _b.label = 9;
        case 9:
          return [4, getTokens(myTokens, mfile)];
        case 10:
          _b.sent();
          return [3, 15];
        case 11:
          e_3 = _b.sent();
          if (tags.length <= 0)
            return [
              2
              /*return*/
            ];
          myErrors.push({ tag: tags[0], error: e_3.message });
          return [3, 15];
        case 12:
          tags.shift();
          if (!(tags.length > 0)) return [3, 14];
          return [4, loadMyNeedsToCompile(tags, myImportsMap, myImports, myCss, myTokens, myErrors, myModules, compileCss)];
        case 13:
          _b.sent();
          _b.label = 14;
        case 14:
          return [
            7
            /*endfinally*/
          ];
        case 15:
          return [
            2
            /*return*/
          ];
      }
    });
  });
}
function addRequeries(enhacementName, mfile, array, myModules) {
  return __awaiter(this, void 0, void 0, function() {
    var obj, _i, _a, i, tag;
    return __generator(this, function(_b) {
      switch (_b.label) {
        case 0:
          if (!myModules[enhacementName]) {
            throw new Error("Enhacement not found ");
          }
          if (!myModules[enhacementName].mModule || !myModules[enhacementName].mModule.getDesignDetails)
            return [2, array];
          return [4, myModules[enhacementName].mModule.getDesignDetails(mfile)];
        case 1:
          obj = _b.sent();
          if (!obj || !obj.webComponentDependencies)
            return [2, array];
          for (_i = 0, _a = obj.webComponentDependencies; _i < _a.length; _i++) {
            i = _a[_i];
            tag = convertFileNameToTag(i);
            if (!array.includes(tag)) {
              array.push(tag);
            }
          }
          return [2, array];
      }
    });
  });
}
function getJSImporMap(myImportsMap, enhacementName, mfile, myModules) {
  return __awaiter(this, void 0, void 0, function() {
    var mmodule, aRequire;
    return __generator(this, function(_a) {
      if (!myModules[enhacementName]) {
        throw new Error("Enhacement not found ");
      }
      if (myModules[enhacementName].jsMap)
        return [
          2
          /*return*/
        ];
      myModules[enhacementName].jsMap = true;
      mmodule = myModules[enhacementName].mModule;
      if (!mmodule || !mmodule.requires)
        return [
          2
          /*return*/
        ];
      aRequire = mmodule.requires;
      aRequire.forEach(function(i) {
        if (i.type !== "cdn")
          return;
        myImportsMap.push('"'.concat(i.name, '": "').concat(i.ref, '"'));
      });
      return [
        2
        /*return*/
      ];
    });
  });
}
function getJS(myImports, enhacementName, mfile, myModules) {
  return __awaiter(this, void 0, void 0, function() {
    return __generator(this, function(_a) {
      if (!myModules[enhacementName]) {
        throw new Error("Enhacement not found ");
      }
      if (mfile.compilerResults && mfile.compilerResults.imports && mfile.compilerResults.imports.length > 0) {
        mfile.compilerResults.imports.forEach(function(n) {
          var name = n.replace("./", "/");
          if (!myImports.includes(name) && n.startsWith("./")) {
            myImports.push(name);
          }
        });
      }
      if (myImports.includes("/_".concat(mfile.project, "_").concat(mfile.shortName)))
        return [
          2
          /*return*/
        ];
      myImports.push("/_".concat(mfile.project, "_").concat(mfile.shortName));
      return [
        2
        /*return*/
      ];
    });
  });
}
function verifyMyImportsNeedImport(myImports, name) {
  name = name.replace(".", "").replace("/", "");
  var _a = mls.actual[0].setFullName(name), project = _a.project, path = _a.path;
  var key = mls.l2.editor.getKey({ project, shortName: path });
  var mfile = mls.l2.editor.mfiles[key];
  if (!mfile)
    return myImports;
  if (mfile.compilerResults && mfile.compilerResults.imports && mfile.compilerResults.imports.length > 0) {
    mfile.compilerResults.imports.forEach(function(n) {
      var name2 = n.replace("./", "/");
      if (!myImports.includes(name2) && n.startsWith("./")) {
        myImports.push(name2);
      }
    });
  }
  return myImports;
}
;
function getCss(myCss, fullName, mfile) {
  return __awaiter(this, void 0, void 0, function() {
    var dsindex, ds, css, e_4;
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          _a.trys.push([0, 2, , 3]);
          dsindex = mls.actual[3].mode ? mls.actual[3].mode : 0;
          ds = mls.l3.getDSInstance(mfile.project, dsindex);
          if (!ds)
            return [
              2
              /*return*/
            ];
          return [4, ds.components.getCSS(fullName)];
        case 1:
          css = _a.sent();
          myCss.push(css);
          return [3, 3];
        case 2:
          e_4 = _a.sent();
          if (e_4.message.indexOf("dont exists") < 0)
            throw new Error(e_4.message);
          return [3, 3];
        case 3:
          return [
            2
            /*return*/
          ];
      }
    });
  });
}
function getTokens(myTokens, mfile) {
  return __awaiter(this, void 0, void 0, function() {
    var dsindex, ds, tokens, e_5;
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          _a.trys.push([0, 2, , 3]);
          dsindex = mls.actual[3].mode ? mls.actual[3].mode : 0;
          ds = mls.l3.getDSInstance(mfile.project, dsindex);
          if (!ds)
            return [
              2
              /*return*/
            ];
          return [4, ds.tokens["getTokensCss"]()];
        case 1:
          tokens = _a.sent();
          myTokens.push(tokens);
          return [3, 3];
        case 2:
          e_5 = _a.sent();
          if (e_5.message.indexOf("dont exists") < 0)
            throw new Error(e_5.message);
          return [3, 3];
        case 3:
          return [
            2
            /*return*/
          ];
      }
    });
  });
}
function getAllWebComponentsInSource(source) {
  var regex = /<([a-z0-9]+-[a-z0-9-]*)(?=\s|>|\/|$)/g;
  var matches = source.match(regex) || [];
  var componentNames = matches.map(function(tag) {
    return tag.slice(1);
  });
  return __spreadArray([], new Set(componentNames), true);
}
function convertFileNameToTag(widget) {
  var regex = /_([0-9]+)_?(.*)/;
  var match = widget.match(regex);
  if (match) {
    var number = match[1], rest = match[2];
    var convertedSrc = rest.replace(/([A-Z])/g, "-$1").toLowerCase();
    widget = "".concat(convertedSrc, "-").concat(number);
  }
  return widget;
}
function convertTagToFileName(tag) {
  var regex = /(.+)-(\d+)/;
  var match = tag.match(regex);
  if (match) {
    var rest = match[1], number = match[2];
    var convertedSrc = rest.replace(/-(.)/g, function(_, letter) {
      return letter.toUpperCase();
    });
    tag = "_".concat(number, "_").concat(convertedSrc);
  }
  return tag;
}
export {
  getDependenciesByHtml,
  getDependenciesByMFile
};
