var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, LitElement, ifDefined, css } from "lit";
import { customElement, property, query } from "lit/decorators.js";
var WcInputColor = (
  /** @class */
  function(_super) {
    __extends(WcInputColor2, _super);
    function WcInputColor2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.value = "";
      _this.required = false;
      _this.disabled = false;
      _this.readonly = false;
      _this.autofocus = false;
      _this.error = "";
      return _this;
    }
    WcInputColor2.prototype.render = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['\n        <label class="form-control-label">\n          ', '\n        </label>\n\n        <input\n            class="input_control"\n            type="color"\n            name=', "\n            ?disabled=", "\n            ?readonly=", "\n            ?required=", "\n            .value=", "\n            ?autofocus=", "\n            pattern=", '  \n        />\n        <small class="form_hint">', '</small>\n        <div class="form_error_message">', "</div>\n        "], ['\n        <label class="form-control-label">\n          ', '\n        </label>\n\n        <input\n            class="input_control"\n            type="color"\n            name=', "\n            ?disabled=", "\n            ?readonly=", "\n            ?required=", "\n            .value=", "\n            ?autofocus=", "\n            pattern=", '  \n        />\n        <small class="form_hint">', '</small>\n        <div class="form_error_message">', "</div>\n        "])), this.label, ifDefined(this.name), this.disabled, this.readonly, this.required, this.value, this.autofocus, ifDefined(this.pattern), this.hint, this.error);
    };
    var _a;
    WcInputColor2.styles = css(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n    :host {\n        display: block;\n    }\n    \n    .input_control {\n        display: block;\n        font-size: 1rem;\n        cursor:pointer;\n        font-weight: 400;\n        line-height: 1.5;\n        color: #212529;\n        background-color: #fff;\n        background-clip: padding-box;\n        border: 1px solid #ced4da;\n        -webkit-appearance: none;\n        -moz-appearance: none;\n        appearance: none;\n        border-radius: 0.25rem;\n        transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;\n        outline:none;\n    }\n    .form_hint{\n        color: blue;\n    }\n    .form_error_message{\n        color: red;\n    }\n    "], ["\n    :host {\n        display: block;\n    }\n    \n    .input_control {\n        display: block;\n        font-size: 1rem;\n        cursor:pointer;\n        font-weight: 400;\n        line-height: 1.5;\n        color: #212529;\n        background-color: #fff;\n        background-clip: padding-box;\n        border: 1px solid #ced4da;\n        -webkit-appearance: none;\n        -moz-appearance: none;\n        appearance: none;\n        border-radius: 0.25rem;\n        transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;\n        outline:none;\n    }\n    .form_hint{\n        color: blue;\n    }\n    .form_error_message{\n        color: red;\n    }\n    "])));
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WcInputColor2.prototype, "name", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WcInputColor2.prototype, "label", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WcInputColor2.prototype, "widget", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WcInputColor2.prototype, "pattern", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WcInputColor2.prototype, "errormessage", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WcInputColor2.prototype, "value", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Boolean)
    ], WcInputColor2.prototype, "required", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Boolean)
    ], WcInputColor2.prototype, "disabled", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Boolean)
    ], WcInputColor2.prototype, "readonly", void 0);
    __decorate([
      property({ type: Boolean }),
      __metadata("design:type", Boolean)
    ], WcInputColor2.prototype, "autofocus", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], WcInputColor2.prototype, "hint", void 0);
    __decorate([
      query(".input_control"),
      __metadata("design:type", typeof (_a = typeof HTMLInputElement !== "undefined" && HTMLInputElement) === "function" ? _a : Object)
    ], WcInputColor2.prototype, "input", void 0);
    WcInputColor2 = __decorate([
      customElement("wc-input-color-100554")
    ], WcInputColor2);
    return WcInputColor2;
  }(LitElement)
);
var templateObject_1, templateObject_2;
export {
  WcInputColor
};
