var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
var __asyncValues = function(o) {
  if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
  var m = o[Symbol.asyncIterator], i;
  return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
    return this;
  }, i);
  function verb(n) {
    i[n] = o[n] && function(v) {
      return new Promise(function(resolve, reject) {
        v = o[n](v), settle(resolve, reject, v.done, v.value);
      });
    };
  }
  function settle(resolve, reject, d, v) {
    Promise.resolve(v).then(function(v2) {
      resolve({ value: v2, done: d });
    }, reject);
  }
};
var __spreadArray = function(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};
import { html, css, repeat } from "lit";
import { customElement, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
import { initServiceListFilesAdd } from "./_100554_serviceListFilesAdd";
var message_pt = {
  updateListVerify: "atualizar lista/verificar",
  update: "atualizar",
  addNewFile: "adicionar novo arquivo",
  filter: "Filtrar",
  localProject: "Projeto local",
  totalFiles: "arquivos totais",
  filesWithErrors: "arquivos com erros",
  filesInLocalStorage: "arquivos no armazenamento local",
  filesChangedOnTheServer: "arquivos alterados no servidor",
  history: "Hist\uFFFDrico",
  undo: "desfazer",
  clone: "clonar",
  rename: "renomear",
  delete: "excluir"
};
var message_en = {
  updateListVerify: "update list/ verify",
  update: "update",
  addNewFile: "add new file",
  filter: "Filter",
  localProject: "Local project",
  totalFiles: "total files",
  filesWithErrors: "files with errors",
  filesInLocalStorage: "file in local storage",
  filesChangedOnTheServer: "files changed on the server",
  history: "History",
  undo: "undo",
  clone: "clone",
  rename: "rename",
  delete: "delete"
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceListFiles = (
  /** @class */
  function(_super) {
    __extends(ServiceListFiles2, _super);
    function ServiceListFiles2() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.mode = "list";
      _this.project = 1;
      _this.projectLabel = "1";
      _this.errorAux = "";
      _this.files = [];
      _this.history = [];
      _this.info = {
        tot: 0,
        version: 0,
        storage: 0,
        error: 0
      };
      _this.details = {
        icon: "&#xf15b",
        state: "background",
        position: "all",
        tooltip: "Select",
        visible: true,
        widget: "_100554_serviceListFiles",
        level: [2, 4],
        customConfiguration: {
          2: {
            tooltip: "Select Widget"
          },
          4: {
            tooltip: "Select Page"
          }
        }
      };
      _this.onClickLink = function(op) {
        return false;
      };
      _this.menu = {
        title: "List Files",
        actions: {},
        icons: {},
        actionDefault: "opPlugins",
        // call after close icon clicked
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink
      };
      _this.onMLSEvents = function(ev) {
        return __awaiter(_this, void 0, Promise, function() {
          var fileAction;
          return __generator(this, function(_a) {
            if (this.visible === void 0 || this.visible === null || this.visible && this.visible === "false")
              return [
                2
                /*return*/
              ];
            if (ev.level !== +this.level || ev.type !== "FileAction")
              return [
                2
                /*return*/
              ];
            fileAction = JSON.parse(ev.desc);
            if (fileAction.position !== this.position || !["statusOrErrorChanged", "projectListChanged"].includes(fileAction.action) || fileAction.project === 0)
              return [
                2
                /*return*/
              ];
            this.init();
            return [
              2
              /*return*/
            ];
          });
        });
      };
      _this.changeListTimeout = 0;
      _this.extensionLevel = {
        2: ".ts",
        4: ".html"
      };
      _this.setLoader = -1;
      _this.inFilter = false;
      _this.timeFilterChange = 0;
      initServiceListFilesAdd();
      _this.setEvents();
      return _this;
    }
    ServiceListFiles2.prototype.onServiceClick = function(visible, reinit) {
      this.mode = "list";
      if (visible && reinit) {
        this.init();
        this.firstTimeVerifyProject();
      }
    };
    ServiceListFiles2.prototype.firstTimeVerifyProject = function() {
      if (window.updateFile && window.updateFile.includes(mls.actual[5].project)) {
        return;
      }
      setTimeout(function() {
        if (!window.updateFile) {
          window.updateFile = [mls.actual[5].project];
        } else {
          window.updateFile.push(mls.actual[5].project);
        }
        var keys = Object.keys(mls.stor.files);
        var info;
        for (var _i = 0, keys_1 = keys; _i < keys_1.length; _i++) {
          var key = keys_1[_i];
          info = mls.stor.files[key];
          if (info.project !== mls.actual[5].project)
            continue;
          break;
        }
        mls.events.fireFileAction("updatedOnServer", info, "left", void 0, void 0, void 0, void 0, 600);
      }, 5e3);
    };
    ServiceListFiles2.prototype.showAdd = function() {
      this.inFilter = false;
      this.mode = "add";
      this.menu.setMode;
      return true;
    };
    ServiceListFiles2.prototype.setEvents = function() {
      var _this = this;
      mls.events.addEventListener([2, 5], ["ProjectSelected"], function(ev) {
        if (_this.project === mls.actual[5].project)
          return;
        _this.init();
      });
      mls.events.addListener(5, "FileAction", function(ev) {
        if (ev.type !== "FileAction")
          return;
        if (_this.visible === void 0 || _this.visible === null || _this.visible && _this.visible === "false")
          return;
        var fileAction = JSON.parse(ev.desc);
        if (!["projectListChanged"].includes(fileAction.action))
          return;
        _this.init();
      });
      mls.events.addListener(2, "FileAction", this.onMLSEvents.bind(this));
    };
    ServiceListFiles2.prototype.connectedCallback = function() {
      _super.prototype.connectedCallback.call(this);
      this.init();
    };
    ServiceListFiles2.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      if (this.mode === "list") {
        return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['\n            <div class="contentServiceList scroll-custom">\n                ', "\n                <ul>\n                    ", "\n                    ", "\n                </ul>\n                ", "\n            </div>\n        "], ['\n            <div class="contentServiceList scroll-custom">\n                ', "\n                <ul>\n                    ", "\n                    ", "\n                </ul>\n                ", "\n            </div>\n        "])), this.renderHeader(), this.renderHistory(), this.renderList(), this.renderAuxEdit());
      } else {
        return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["", ""], ["", ""])), this.renderAdd());
      }
    };
    ServiceListFiles2.prototype.renderHeader = function() {
      var auxV = "";
      var auxE = "";
      var auxS = "";
      if (this.info.version > 0) {
        auxV = "<b>[".concat(this.info.version, ']</b> <span class="fa fa-unbalanced"></span> <b>').concat(this.msg.filesChangedOnTheServer, ", </b>");
      }
      if (this.info.error > 0) {
        auxE = "<b>[".concat(this.info.error, ']</b> <span class="fa fa-bug"></span><b>').concat(this.msg.filesWithErrors, ",</b>");
      }
      if (this.info.storage > 0) {
        auxS = "<b>[".concat(this.info.storage, ']</b> <span class="fa fa-location-dot"></span> <b>').concat(this.msg.filesInLocalStorage, ".</b>");
      }
      return html(templateObject_6 || (templateObject_6 = __makeTemplateObject(['\n        <div class="groupHeader">\n            <div class="groupAction"> \n                <a @click="', '" id="listUpdateFiles">', '</a>\n                <a @click="', '">', '</a>\n            </div>\n            <div class="groupFilter">\n                <div class="groupFilterRadio">\n                    <input id="radioProjectActual" name="projectFind" type="radio" checked="checked" value="', '" @click="', '">\n                    <label for="radioProjectActual">', '</label>\n                    <input id="radioProjectZero" name="projectFind" type="radio" value="0" @click="', '">\n                    <label for="radioProjectZero">', '</label>\n                </div>\n                <input type="text" placeholder="Filter" @input="', '">\n            </div>\n            <div class="groupInfo">\n                <span style="margin-right:10px">\n                    [', ']\n				    <span class="fa fa-file"></span> \n                    ', "\n                </span>\n                ", "\n                ", "\n                ", "\n            </div>\n        </div>\n        "], ['\n        <div class="groupHeader">\n            <div class="groupAction"> \n                <a @click="', '" id="listUpdateFiles">', '</a>\n                <a @click="', '">', '</a>\n            </div>\n            <div class="groupFilter">\n                <div class="groupFilterRadio">\n                    <input id="radioProjectActual" name="projectFind" type="radio" checked="checked" value="', '" @click="', '">\n                    <label for="radioProjectActual">', '</label>\n                    <input id="radioProjectZero" name="projectFind" type="radio" value="0" @click="', '">\n                    <label for="radioProjectZero">', '</label>\n                </div>\n                <input type="text" placeholder="Filter" @input="', '">\n            </div>\n            <div class="groupInfo">\n                <span style="margin-right:10px">\n                    [', ']\n				    <span class="fa fa-file"></span> \n                    ', "\n                </span>\n                ", "\n                ", "\n                ", "\n            </div>\n        </div>\n        "])), this.verifyChangeInList, this.msg.updateListVerify, this.showAdd, this.msg.addNewFile, this.projectLabel, this.clickRadioProjectActual, this.projectLabel, this.clickRadioProject0, this.msg.localProject, this.filterLiChange, this.info.tot, this.msg.totalFiles, auxV ? html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['<span .innerHTML="', '" style="margin-right:10px"></span>'], ['<span .innerHTML="', '" style="margin-right:10px"></span>'])), auxV) : "", auxE ? html(templateObject_4 || (templateObject_4 = __makeTemplateObject(['<span .innerHTML="', '" style="margin-right:10px"></span>'], ['<span .innerHTML="', '" style="margin-right:10px"></span>'])), auxE) : "", auxS ? html(templateObject_5 || (templateObject_5 = __makeTemplateObject(['<span .innerHTML="', '" style="margin-right:10px"></span>'], ['<span .innerHTML="', '" style="margin-right:10px"></span>'])), auxS) : "");
    };
    ServiceListFiles2.prototype.renderHistory = function() {
      var _this = this;
      return html(templateObject_8 || (templateObject_8 = __makeTemplateObject(["\n            ", "\n        "], ["\n            ", "\n        "])), this.history.length <= 0 ? "" : html(templateObject_7 || (templateObject_7 = __makeTemplateObject(['\n                    <li class="headerTitle">\n                        ', "\n                    </li>\n                    ", "\n                "], ['\n                    <li class="headerTitle">\n                        ', "\n                    </li>\n                    ", "\n                "])), +this.project === 0 ? "".concat(this.msg.history, " (All Projects)") : "".concat(this.msg.history), repeat(this.history, function(item) {
        return item.shortName;
      }, function(file, index) {
        return _this.renderLiItem(file, index, true);
      })));
    };
    ServiceListFiles2.prototype.renderList = function() {
      var _this = this;
      var letterInit = "";
      return html(templateObject_11 || (templateObject_11 = __makeTemplateObject(["\n            ", "\n        "], ["\n            ", "\n        "])), this.files.length <= 0 ? "" : html(templateObject_10 || (templateObject_10 = __makeTemplateObject(["\n                    ", "\n                "], ["\n                    ", "\n                "])), repeat(this.files, function(item) {
        return item.shortName;
      }, function(file, index) {
        if (letterInit !== file.shortName.charAt(0).toUpperCase()) {
          letterInit = file.shortName.charAt(0).toUpperCase();
          return html(templateObject_9 || (templateObject_9 = __makeTemplateObject(['\n                                    <li class="headerTitle">', " </li>\n                                    ", "\n                                "], ['\n                                    <li class="headerTitle">', " </li>\n                                    ", "\n                                "])), letterInit, _this.renderLiItem(file, index, false));
        }
        return _this.renderLiItem(file, index, false);
      })));
    };
    ServiceListFiles2.prototype.renderAuxEdit = function() {
      return html(templateObject_12 || (templateObject_12 = __makeTemplateObject(['\n            <div class="elContentAux" style="display:none" @click="', '">\n                <div class="elContentAux2">\n                    <span class="spanPrj">\n                        <input style="width: 80px;" .value="', '" @click="', '">\n                    </span>\n                    <span class="spanName">\n                        <input @click="', '">\n                    </span>\n                    <button class="btnActCloneRename fa fa-file-pen" style="margin: 4px 0px;"></button>\n                    <button class="fa fa-ban" title="cancel" @click="', '" style="margin: 4px 0px;"></button>\n                </div>\n                <div class="showError"style="color: red; font-size: 10px;">', "</div>\n            </div>\n        "], ['\n            <div class="elContentAux" style="display:none" @click="', '">\n                <div class="elContentAux2">\n                    <span class="spanPrj">\n                        <input style="width: 80px;" .value="', '" @click="', '">\n                    </span>\n                    <span class="spanName">\n                        <input @click="', '">\n                    </span>\n                    <button class="btnActCloneRename fa fa-file-pen" style="margin: 4px 0px;"></button>\n                    <button class="fa fa-ban" title="cancel" @click="', '" style="margin: 4px 0px;"></button>\n                </div>\n                <div class="showError"style="color: red; font-size: 10px;">', "</div>\n            </div>\n        "])), this.clickOptStop, this.project, this.clickOptStop, this.clickOptStop, this.clickHiddenAux, this.errorAux);
    };
    ServiceListFiles2.prototype.renderLiItem = function(file, index, inHistory) {
      var name = this.project === 0 && inHistory ? "_" + file.project + "_" + file.shortName : file.shortName;
      var nameFilter = inHistory ? "*******" : name.toLocaleLowerCase();
      var auxVersion = "";
      var auxStorage = "";
      var auxBug = "";
      var auxHtml = "";
      var keyHtml = mls.stor.getKeyToFiles(file.project, file.level, file.shortName, file.folder, ".html");
      var htmlLocal = mls.stor.files[keyHtml] && mls.stor.files[keyHtml].inLocalStorage;
      if (file.inLocalStorage) {
        auxStorage = '<span title=".ts'.concat(htmlLocal ? ", .html" : "", ' in localstorage" class="fa fa-location-dot" style="color:lightskyblue; height: 14px; display: flex; justify-content: center; align-items: center;"></span>');
      } else if (htmlLocal) {
        auxStorage = '<span title=".html in localstorage" class="fa fa-location-dot" style="color:lightskyblue; height: 14px; display: flex; justify-content: center; align-items: center;"></span>';
      }
      if (file.hasError) {
        auxBug = '<span title="bug" class="fa fa-bug" style="color:rgb(169, 3, 3); height: 14px; display: flex; justify-content: center; align-items: center;"></span>';
      }
      if (file.isLocalVersionOutdated) {
        auxVersion = '<span title="need conciliation" class="fa fa-unbalanced" style="color:orange; height: 14px; display: flex; justify-content: center; align-items: center;"></span>';
      }
      var style = this.inFilter && inHistory ? "display:none" : "";
      return html(templateObject_13 || (templateObject_13 = __makeTemplateObject(['\n            <li @click="', '" style="', '" .myFile=', ' .nameFilter="', '">\n                <div class="elContent">\n                    <div class="groupHiddenList" @click="', '">\n                        <span class="mls-gpbtnslider-item fa fa-undo" title="', '" @click="', '"></span>\n                        <span class="mls-gpbtnslider-item fa fa-clone" title="', '" @click="', '"></span>\n                        <span class="mls-gpbtnslider-item fa fa-file-pen" title="', '" @click="', '"></span>\n                        <span class="mls-gpbtnslider-item fa fa-trash" title="', '" @click="', '"></span>\n                    </div>\n                    <span class="', '">', '</span>\n                    <div style="display:flex; gap:.5rem" .innerHTML="', '"></div>\n                </div>\n            </li>\n        '], ['\n            <li @click="', '" style="', '" .myFile=', ' .nameFilter="', '">\n                <div class="elContent">\n                    <div class="groupHiddenList" @click="', '">\n                        <span class="mls-gpbtnslider-item fa fa-undo" title="', '" @click="', '"></span>\n                        <span class="mls-gpbtnslider-item fa fa-clone" title="', '" @click="', '"></span>\n                        <span class="mls-gpbtnslider-item fa fa-file-pen" title="', '" @click="', '"></span>\n                        <span class="mls-gpbtnslider-item fa fa-trash" title="', '" @click="', '"></span>\n                    </div>\n                    <span class="', '">', '</span>\n                    <div style="display:flex; gap:.5rem" .innerHTML="', '"></div>\n                </div>\n            </li>\n        '])), this.clickOptOpen, style, file, nameFilter, this.clickGroupHidden, this.msg.undo, this.clickOptUndo, this.msg.clone, this.clickOptClone, this.msg.rename, this.clickOptRename, this.msg.delete, this.clickOptDel, file.status === "deleted" ? "fileDeleted" : "", name, auxStorage + auxBug + auxVersion + auxHtml);
    };
    ServiceListFiles2.prototype.renderAdd = function() {
      return html(templateObject_14 || (templateObject_14 = __makeTemplateObject(['<service-list-files-add-100554 level="', '" position="', '" .father="', '"></service-list-files-add-100554>'], ['<service-list-files-add-100554 level="', '" position="', '" .father="', '"></service-list-files-add-100554>'])), this.level, this.position, this);
    };
    ServiceListFiles2.prototype.clickOptUndo = function(e) {
      e.stopPropagation();
      var mfile = this.getMyFileInElement(e.target);
      if (!mfile)
        return;
      this.fireEvents("undo", mfile, {});
    };
    ServiceListFiles2.prototype.clickOptDel = function(e) {
      e.stopPropagation();
      var mfile = this.getMyFileInElement(e.target);
      if (!mfile)
        return;
      this.fireEvents("delete", mfile, {});
    };
    ServiceListFiles2.prototype.clickOptOpen = function(e) {
      e.stopPropagation();
      var mfile = this.getMyFileInElement(e.target);
      if (!mfile)
        return;
      this.setHistory(mfile);
      this.fireEvents("open", mfile, {});
    };
    ServiceListFiles2.prototype.clickOptRename = function(e) {
      e.stopPropagation();
      var el = e.target;
      if (!el)
        return;
      this.clickOptRenameClone(el, "rename");
    };
    ServiceListFiles2.prototype.clickOptClone = function(e) {
      e.stopPropagation();
      var el = e.target;
      if (!el)
        return;
      this.clickOptRenameClone(el, "clone");
    };
    ServiceListFiles2.prototype.clickOptRenameClone = function(el, mode) {
      var _this = this;
      if (!el)
        return;
      var myfile = this.getMyFileInElement(el);
      if (!myfile)
        return;
      var father = el.closest(".contentServiceList");
      var li = el.closest("li");
      if (!father || !li)
        return;
      var elContentAux = father.querySelector(".elContentAux");
      var btnActCloneRename = father.querySelector(".btnActCloneRename");
      var iptProj = elContentAux.querySelector(".spanPrj input");
      var iptName = elContentAux.querySelector(".spanName input");
      if (!father || !li)
        return;
      li.appendChild(elContentAux);
      elContentAux.style.display = "";
      iptProj.value = mls.actual[5].project;
      iptName.value = "";
      btnActCloneRename.onclick = function(e2) {
        return __awaiter(_this, void 0, void 0, function() {
          var all;
          var _this2 = this;
          var _a;
          return __generator(this, function(_b) {
            try {
              e2.stopPropagation();
              this.validInputsAux(myfile, { mode, project: iptProj.value, name: iptName.value });
              this.fireEvents(mode, myfile, { project: +iptProj.value, shortName: iptName.value });
              elContentAux.style.display = "none";
              all = (_a = this.shadowRoot) === null || _a === void 0 ? void 0 : _a.querySelectorAll(".activegpbtnslider");
              Array.from(all).forEach(function(i) {
                return i.classList.remove("activegpbtnslider");
              });
            } catch (er) {
              this.showLoader(false);
              this.errorAux = er.message;
              setTimeout(function() {
                _this2.errorAux = "";
              }, 2e3);
            }
            return [
              2
              /*return*/
            ];
          });
        });
      };
    };
    ServiceListFiles2.prototype.fireEvents = function(action, file, info, timeout) {
      if (timeout === void 0) {
        timeout = 0;
      }
      var params = {};
      params.action = action;
      params.level = file.level;
      params.project = file.project;
      params.shortName = file.shortName;
      params.extension = file.extension;
      params.folder = file.folder;
      params.position = this.position;
      if (info && info.shortName) {
        params.newshortName = info.shortName;
        params.newProject = info.project;
        params.newfolder = file.folder;
      }
      if (["open"].includes(action)) {
        mls.actual[this.level].setFullName("_".concat(file.project, "_").concat(file.shortName));
        mls.actual[this.level][this.position] = {
          project: file.project,
          shortName: file.shortName,
          extension: file.extension,
          folder: file.folder
        };
      }
      mls.events.fire([+this.level], ["FileAction"], JSON.stringify(params), timeout);
      if (["open"].includes(action))
        return;
      this.changeList(100);
    };
    ServiceListFiles2.prototype.changeList = function(time) {
      var _this = this;
      if (time === void 0) {
        time = 500;
      }
      clearTimeout(this.changeListTimeout);
      this.changeListTimeout = setTimeout(function() {
        return __awaiter(_this, void 0, void 0, function() {
          return __generator(this, function(_a) {
            switch (_a.label) {
              case 0:
                return [4, this.init()];
              case 1:
                _a.sent();
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      }, time);
    };
    ServiceListFiles2.prototype.init = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              this.info.tot = 0;
              this.info.version = 0;
              this.info.storage = 0;
              this.info.error = 0;
              this.project = mls.actual[5].project;
              this.projectLabel = this.project.toString();
              this.showLoader(true);
              return [4, this.getFiles()];
            case 1:
              _a.sent();
              this.showLoader(false);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceListFiles2.prototype.showLoader = function(loader) {
      var _this = this;
      clearTimeout(this.setLoader);
      this.setLoader = setTimeout(function() {
        _this.loading = loader;
      }, 200);
    };
    ServiceListFiles2.prototype.getMyFileInElement = function(el) {
      el = el.closest("li");
      if (!el || !el["myFile"])
        return;
      var mfile = el["myFile"];
      return mfile;
    };
    ServiceListFiles2.prototype.clickGroupHidden = function(e) {
      e.stopPropagation();
      var el = e.target;
      if (!el)
        return;
      if (el.classList.contains("activegpbtnslider")) {
        var li = el.closest("li");
        var elContentAux = li.querySelector(".elContentAux");
        if (elContentAux)
          elContentAux.style.display = "none";
      }
      el.classList.toggle("activegpbtnslider");
    };
    ServiceListFiles2.prototype.clickHiddenAux = function(e) {
      e.stopPropagation();
      var el = e.target;
      if (!el)
        return;
      var elContentAux = el.closest(".elContentAux");
      if (!elContentAux)
        return;
      var iptProj = elContentAux.querySelector(".spanPrj input");
      var iptName = elContentAux.querySelector(".spanName input");
      if (iptName)
        iptName.value = "";
      if (iptProj)
        iptProj.value = this.project.toString();
      elContentAux.style.display = "none";
    };
    ServiceListFiles2.prototype.clickOptStop = function(e) {
      e.stopPropagation();
    };
    ServiceListFiles2.prototype.clickRadioProject0 = function(e) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              this.info.tot = 0;
              this.info.version = 0;
              this.info.storage = 0;
              this.info.error = 0;
              this.project = 0;
              return [4, this.getFiles()];
            case 1:
              _a.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceListFiles2.prototype.clickRadioProjectActual = function(e) {
      this.info.tot = 0;
      this.info.version = 0;
      this.info.storage = 0;
      this.info.error = 0;
      this.project = mls.actual[5].project;
      this.getFiles();
    };
    ServiceListFiles2.prototype.filterLiChange = function(e) {
      var _this = this;
      e.stopPropagation();
      var el = e.target;
      if (!el)
        return;
      clearTimeout(this.timeFilterChange);
      this.timeFilterChange = setTimeout(function() {
        _this.inFilter = el.value.length > 0;
        var contentServiceList = el.closest(".contentServiceList");
        if (!contentServiceList)
          return;
        var all = contentServiceList.querySelectorAll("li");
        all.forEach(function(li) {
          var name = li.nameFilter ? li.nameFilter : "******";
          var inp = el.value.toLocaleLowerCase();
          if (name.indexOf(inp) >= 0) {
            li.style.display = "";
          } else {
            li.style.display = "none";
          }
        });
      }, 500);
    };
    ServiceListFiles2.prototype.verifyChangeInList = function(e) {
      return __awaiter(this, void 0, void 0, function() {
        var e_1;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              _a.trys.push([0, 2, , 3]);
              return [4, this.verifyChangeInList2(e)];
            case 1:
              _a.sent();
              return [3, 3];
            case 2:
              e_1 = _a.sent();
              return [3, 3];
            case 3:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceListFiles2.prototype.verifyChangeInList2 = function(e) {
      return __awaiter(this, void 0, void 0, function() {
        var el_1, isClick, key, e_2;
        var _this = this;
        var _a;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              _b.trys.push([0, 2, , 3]);
              e.stopPropagation();
              el_1 = e.target;
              if (!el_1)
                return [
                  2
                  /*return*/
                ];
              isClick = el_1.innerText === "updated";
              if (isClick)
                return [
                  2
                  /*return*/
                ];
              el_1.innerText = "updated";
              return [4, mls.stor.server.loadProjectInfoIfNeeded(mls.actual[5].project, true)];
            case 1:
              _b.sent();
              key = (_a = Object.keys(mls.stor.files)) === null || _a === void 0 ? void 0 : _a.filter(function(item) {
                return item.indexOf(mls.actual[5].project.toString()) >= 0;
              });
              if (key.length > 0) {
                this.fireEvents("projectListChanged", mls.stor.files[key[0]], {}, 500);
                mls.events.fireFileAction("updatedOnServer", mls.stor.files[key[0]], "left", void 0, void 0, void 0, void 0, 600);
              }
              this.changeList(500);
              setTimeout(function() {
                if (!_this)
                  return;
                el_1.innerText = "update list/ verify";
              }, 5e4);
              return [3, 3];
            case 2:
              e_2 = _b.sent();
              return [3, 3];
            case 3:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceListFiles2.prototype.verifyChangeInList3 = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          return [
            2
            /*return*/
          ];
        });
      });
    };
    ServiceListFiles2.prototype.getFiles = function() {
      return __awaiter(this, void 0, void 0, function() {
        var arraySf, arraySfHistory, e_3;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              _a.trys.push([0, 2, , 3]);
              arraySf = this.getFilesProject();
              return [4, this.getFileHistory()];
            case 1:
              arraySfHistory = _a.sent();
              this.files = __spreadArray([], arraySf, true);
              this.history = __spreadArray([], arraySfHistory, true);
              return [3, 3];
            case 2:
              e_3 = _a.sent();
              console.info(e_3);
              return [3, 3];
            case 3:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    ServiceListFiles2.prototype.getFilesProject = function() {
      if (!window["mls"])
        return [];
      var arraySf = [];
      var ext = this.extensionLevel[this.level];
      for (var _i = 0, _a = Object.keys(mls.stor.files).sort(); _i < _a.length; _i++) {
        var i = _a[_i];
        var sf = mls.stor.files[i];
        if (sf.project !== this.project || sf.level !== +this.level || sf.extension !== ext)
          continue;
        this.info.tot++;
        if (sf.isLocalVersionOutdated)
          this.info.version++;
        if (sf.inLocalStorage)
          this.info.storage++;
        if (sf.hasError)
          this.info.error++;
        arraySf.push(sf);
      }
      return arraySf;
    };
    ServiceListFiles2.prototype.getFileHistory = function() {
      return __awaiter(this, void 0, void 0, function() {
        var arraySfHistory, lh, _a, lh_1, lh_1_1, i, key, e_4_1;
        var _b, e_4, _c, _d;
        return __generator(this, function(_e) {
          switch (_e.label) {
            case 0:
              if (!window["mls"])
                return [2, []];
              arraySfHistory = [];
              lh = this.getHistory();
              if (lh.length <= 0 || !window["mls"])
                return [2, []];
              _e.label = 1;
            case 1:
              _e.trys.push([1, 8, 9, 14]);
              _a = true, lh_1 = __asyncValues(lh);
              _e.label = 2;
            case 2:
              return [4, lh_1.next()];
            case 3:
              if (!(lh_1_1 = _e.sent(), _b = lh_1_1.done, !_b)) return [3, 7];
              _d = lh_1_1.value;
              _a = false;
              i = _d;
              key = mls.stor.getKeyToFiles(i.project, this.level, i.shortName, i.folder, i.extension);
              if (!(!mls.stor.files[key] && +this.project === 0)) return [3, 5];
              return [4, mls.stor.server.loadProjectInfoIfNeeded(i.project)];
            case 4:
              _e.sent();
              key = mls.stor.getKeyToFiles(i.project, this.level, i.shortName, i.folder, i.extension);
              _e.label = 5;
            case 5:
              if (!mls.stor.files[key] || i.project !== +this.project && +this.project !== 0)
                return [3, 6];
              arraySfHistory.push(mls.stor.files[key]);
              _e.label = 6;
            case 6:
              _a = true;
              return [3, 2];
            case 7:
              return [3, 14];
            case 8:
              e_4_1 = _e.sent();
              e_4 = { error: e_4_1 };
              return [3, 14];
            case 9:
              _e.trys.push([9, , 12, 13]);
              if (!(!_a && !_b && (_c = lh_1.return))) return [3, 11];
              return [4, _c.call(lh_1)];
            case 10:
              _e.sent();
              _e.label = 11;
            case 11:
              return [3, 13];
            case 12:
              if (e_4) throw e_4.error;
              return [
                7
                /*endfinally*/
              ];
            case 13:
              return [
                7
                /*endfinally*/
              ];
            case 14:
              return [2, arraySfHistory];
          }
        });
      });
    };
    ServiceListFiles2.prototype.getHistory = function() {
      var info = localStorage.getItem("mlsInfoHistoryL" + this.level);
      return info ? JSON.parse(info) : [];
    };
    ServiceListFiles2.prototype.setHistory = function(file) {
      var info = localStorage.getItem("mlsInfoHistoryL" + this.level);
      var res = info ? JSON.parse(info) : [];
      var idx = -1;
      res.forEach(function(i2, index) {
        if (i2.project !== file.project || i2.shortName !== file.shortName)
          return;
        idx = index;
      });
      if (idx >= 0) {
        res.splice(idx, 1);
      }
      res.unshift({ project: file.project, shortName: file.shortName, extension: file.extension, folder: file.folder });
      if (res.length > 10) {
        for (var i = res.length - 1; i >= 0; i--) {
          if (res.length <= 10)
            break;
          var key = mls.stor.getKeyToFiles(res[i].project, this.level, res[i].shortName, res[i].folder, res[i].extension);
          if (!mls.stor.files[key]) {
            res.splice(i, 1);
          } else if (mls.stor.files[key] && mls.stor.files[key].status === "nochange" && mls.stor.files[key].shortName !== file.shortName) {
            res.splice(i, 1);
          }
        }
      }
      localStorage.setItem("mlsInfoHistoryL" + this.level, JSON.stringify(res));
    };
    ServiceListFiles2.prototype.validInputsAux = function(file, action) {
      if (file.hasError && ["clone", "rename"].includes(action.mode))
        throw new Error("It is not possible to perform this action on files with an error.");
      if (!this.isValidNewName(file, action))
        throw new Error("Invalid name");
    };
    ServiceListFiles2.prototype.isValidNewName = function(file, action) {
      if (action.project === "" || action.name === "")
        return false;
      if (action.name.length === 0 || action.name.length > 255)
        return false;
      var invalidCharacters = /[_\/{}\[\]\*$@#=\-+!|?,<>=.;^~��""''``�������������������������������]/;
      if (invalidCharacters.test(action.name))
        return false;
      var key = mls.stor.getKeyToFiles(+action.project, this.level, action.name, file.folder, file.extension);
      return !mls.stor.files[key];
    };
    ServiceListFiles2.styles = css(templateObject_15 || (templateObject_15 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceListFiles2.prototype, "mode", void 0);
    __decorate([
      property(),
      __metadata("design:type", Number)
    ], ServiceListFiles2.prototype, "project", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceListFiles2.prototype, "projectLabel", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceListFiles2.prototype, "errorAux", void 0);
    __decorate([
      property({ type: Array }),
      __metadata("design:type", Array)
    ], ServiceListFiles2.prototype, "files", void 0);
    __decorate([
      property({ type: Array }),
      __metadata("design:type", Array)
    ], ServiceListFiles2.prototype, "history", void 0);
    ServiceListFiles2 = __decorate([
      customElement("service-list-files-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceListFiles2);
    return ServiceListFiles2;
  }(ServiceBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6, templateObject_7, templateObject_8, templateObject_9, templateObject_10, templateObject_11, templateObject_12, templateObject_13, templateObject_14, templateObject_15;
export {
  ServiceListFiles
};
