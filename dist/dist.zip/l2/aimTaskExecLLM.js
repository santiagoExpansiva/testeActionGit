var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement } from "lit/decorators.js";
import { executePrompt } from "./_100554_aimHelper";
import { AimTaskBase } from "./_100554_aimTaskBase";
var AimTaskExecLLM = (
  /** @class */
  function(_super) {
    __extends(AimTaskExecLLM2, _super);
    function AimTaskExecLLM2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    AimTaskExecLLM2.prototype.onInitializing = function() {
      this.senderToServer(this.taskRoot);
    };
    AimTaskExecLLM2.prototype.senderToServer = function(taskRoot) {
      var _this = this;
      this.taskChild.trace.push((/* @__PURE__ */ new Date()).toISOString() + ": sending to server");
      executePrompt(this.taskIndex).then(function(value) {
        if (!value)
          throw new Error("invalid task retorned");
        _this.taskChild.trace.push((/* @__PURE__ */ new Date()).toISOString() + ": received from server, len=" + JSON.stringify(taskRoot).length);
        _this.taskChild.mode = taskRoot.mode = "processed";
        _this.notifyCompleteByStatus("ok", "");
        return;
      }).catch(function(reason) {
        _this.taskChild.trace.push((/* @__PURE__ */ new Date()).toISOString() + ": error on executePrompt: " + reason.message || "?");
        _this.taskChild.mode = taskRoot.mode = "error";
        _this.notifyCompleteByStatus("error", "");
        return;
      });
    };
    AimTaskExecLLM2.prototype.onIconClick = function(action) {
      this.requestUpdate();
    };
    AimTaskExecLLM2 = __decorate([
      customElement("aim-task-exec-l-l-m-100554")
    ], AimTaskExecLLM2);
    return AimTaskExecLLM2;
  }(AimTaskBase)
);
export {
  AimTaskExecLLM
};
