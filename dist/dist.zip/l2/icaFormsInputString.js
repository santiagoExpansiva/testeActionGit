import { IcaLitElement } from "./_100554_icaLitElement";
class IcaFormsInputString extends IcaLitElement {
  // abstract autocorrect: 'off' | 'on' ; // Indicates whether the browser's autocorrect feature is on or off.
}
export {
  IcaFormsInputString
};
