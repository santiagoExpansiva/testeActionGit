var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html } from "lit";
import { customElement, query } from "lit/decorators.js";
import { tasks, updateTaskOnServer } from "./_100554_aimHelper";
import { AimActionBase } from "./_100554_aimActionBase";
var myName = "_100554_aimActionTokensNew";
var message_pt = {
  title: "verifica os tokens e cria um novo conjunto de tokens",
  prompt: "Prompt",
  suggest: "Sugest\uFFFDo",
  placeholder: "Digite aqui seu prompt",
  cancel: "Cancelar",
  confirm: "Confirmar"
};
var message_en = {
  title: "verify tokens and create a new set",
  suggest: "Suggest",
  prompt: "Prompt",
  placeholder: "Enter your prompt here",
  cancel: "Cancel",
  confirm: "Confirm"
};
var messages = {
  "en-us": message_en,
  "pt-br": message_pt
};
var AimActionTokensNew = (
  /** @class */
  function(_super) {
    __extends(AimActionTokensNew2, _super);
    function AimActionTokensNew2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.msg = messages["en-us"];
      _this.assistant = "gpt3_typescript";
      _this.title = "New Tokens";
      _this.language = "english";
      _this.prompts = [
        "Criar um conjunto de tokens com tema minimalista",
        "Criar um conjunto de tokens com tema retro",
        "Criar um conjunto de tokens com cores mais vibrantes",
        "Criar um conjunto de tokens com cores neutras"
      ];
      return _this;
    }
    AimActionTokensNew2.prototype.getRules = function() {
      return {
        levels: [3],
        tags: ["*serviceDsTokens*"]
      };
    };
    AimActionTokensNew2.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return _super.prototype.render.call(this);
    };
    AimActionTokensNew2.prototype.handleCancel = function() {
      this.dispatchEvent(new CustomEvent("add-task", {
        detail: { cancel: "true" },
        bubbles: true,
        composed: true
      }));
    };
    AimActionTokensNew2.prototype.handleAdd = function() {
      var _a2;
      var taskRoot = {
        mode: "initializing",
        title: this.msg.title,
        widget: myName,
        children: [],
        args: ((_a2 = this.textarea) === null || _a2 === void 0 ? void 0 : _a2.value) || "",
        trace: [(/* @__PURE__ */ new Date()).toISOString() + ": trask created at "]
      };
      tasks.unshift(taskRoot);
      this.prepareTask1(taskRoot);
      this.dispatchEvent(new CustomEvent("finished-add-task-root", {
        detail: taskRoot,
        bubbles: true,
        composed: true
      }));
    };
    AimActionTokensNew2.prototype.onSuggestClick = function(e) {
      if (!this.textarea)
        return;
      var text = "";
      var target = e.target;
      var txtEl = target.querySelector("span");
      if (!txtEl)
        text = target.innerText;
      else
        text = txtEl.innerText;
      this.textarea.value = text;
    };
    AimActionTokensNew2.prototype.renderAdd = function() {
      var _this = this;
      return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["\n        <p> ", " </p>\n\n        <div>\n            <label>", '</label>\n            <div class="prompt-suggestion">\n                ', '\n            \n            </div>\n        <div>\n\n        <div>\n            <label>Prompt:</label>\n            <textarea rows="5" placeholder="', '" style="width:100%"></textarea>\n        </div>\n        <br>\n        <div class="buttonGroup">\n          <button @click="', '">', '</button>\n          <button @click="', '">', "</button>\n        </div>\n    "], ["\n        <p> ", " </p>\n\n        <div>\n            <label>", '</label>\n            <div class="prompt-suggestion">\n                ', '\n            \n            </div>\n        <div>\n\n        <div>\n            <label>Prompt:</label>\n            <textarea rows="5" placeholder="', '" style="width:100%"></textarea>\n        </div>\n        <br>\n        <div class="buttonGroup">\n          <button @click="', '">', '</button>\n          <button @click="', '">', "</button>\n        </div>\n    "])), this.msg.title, this.msg.suggest, this.prompts.map(function(prompt) {
        return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n                    <span @click=", ">\n                        <span >", "</span>\n                    </span>\n                "], ["\n                    <span @click=", ">\n                        <span >", "</span>\n                    </span>\n                "])), _this.onSuggestClick, prompt);
      }), this.msg.placeholder, this.handleCancel, this.msg.cancel, this.handleAdd, this.msg.confirm);
    };
    AimActionTokensNew2.prototype.getPrompt = function(source, user) {
      var prompt = "\nObjective: Criar um conjunto de tokens em LESS.\n\n\n\n\nSystem:\n\n1. Usando less, CSS, criar um novo conjunto de tokens less, baseado nos tokens existentes \n\n2. Criar os tokens conforme o modelo abaixo, mantendo as chaves e alterando os valores \n\n\nUser:\n\n1. ".concat(user, "\n\n\n\n\nExpected Output Format:\n\n\n\n\nRetorna o novo conjunto de tokens em LESS, em um \uFFFDnico bloco, sem coment\uFFFDrios novos no c\uFFFDdigo, e manter coment\uFFFDrios existentes que servem como auxiliar na UI.\n\n\n\n\n").concat(source, "\n");
      return prompt;
    };
    AimActionTokensNew2.prototype.prepareTask1 = function(taskRoot) {
      this.mode = taskRoot.mode = "in progress";
      this.addTaskAndWaitForCompletion(taskRoot, {
        mode: "initializing",
        title: "get tokens source",
        widget: "_100554_aimTaskDsTokens",
        trace: [],
        nextStep: this.prepareTask2.name
        // danger, loop
      });
    };
    AimActionTokensNew2.prototype.prepareTask2 = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      if (taskFinishResult.status === "error") {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        return;
      }
      var source = taskFinishResult.result;
      if (!source) {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        child.trace.push("invalid finish , must be notify finish with result field");
        this.requestUpdate();
        return;
      }
      child.mode = "processed";
      this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
        mode: "initializing",
        title: "exec prompt",
        widget: "_100554_aimTaskExecLLM",
        agent: this.assistant,
        prompt: this.getPrompt(source, taskFinishResult.taskRoot.args || ""),
        trace: [],
        nextStep: this.prepareTask3.name
        // danger, loop
      });
    };
    AimActionTokensNew2.prototype.prepareTask3 = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      var result = child.result || "";
      if (taskFinishResult.status === "error" || !result) {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        return;
      }
      child.mode = "processed";
      this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
        mode: "initializing",
        title: "result",
        widget: "_100554_aimTaskResultTokens",
        trace: [],
        _tempResult: result,
        nextStep: this.endTasks.name
        // danger, loop
      });
      this.requestUpdate();
    };
    AimActionTokensNew2.prototype.endTasks = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      if (taskFinishResult.status === "error")
        child.mode = "error";
      else
        child.mode = "processed";
      this.mode = taskFinishResult.taskRoot.mode = child.mode;
      this.requestUpdate();
      updateTaskOnServer(taskFinishResult.taskIndex);
    };
    var _a;
    __decorate([
      query("textarea"),
      __metadata("design:type", typeof (_a = typeof HTMLTextAreaElement !== "undefined" && HTMLTextAreaElement) === "function" ? _a : Object)
    ], AimActionTokensNew2.prototype, "textarea", void 0);
    AimActionTokensNew2 = __decorate([
      customElement("aim-action-tokens-new-100554")
    ], AimActionTokensNew2);
    return AimActionTokensNew2;
  }(AimActionBase)
);
var templateObject_1, templateObject_2;
export {
  AimActionTokensNew
};
