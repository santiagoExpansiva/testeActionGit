var __assign = function() {
  __assign = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
        t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __spreadArray = function(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
};
function getPropierties(model) {
  var rc = [];
  rc = getPropiertiesByDecorators(model);
  rc = getMoreInfoInJsDoc(model, rc);
  return rc;
}
function getDefaultPropierties() {
  return [
    {
      propertyName: "class",
      propertyType: "string",
      sectionName: "principal",
      defaultValue: "",
      hint: "css classes"
    },
    {
      propertyName: "id",
      propertyType: "string",
      sectionName: "principal",
      defaultValue: "",
      pattern: "^[_a-zA-Z]\\w*$",
      hint: "identifier for javascript manipulation"
    }
  ];
}
function getPropiertiesByDecorators(model) {
  var _a;
  var decorators = (_a = model.compilerResults) === null || _a === void 0 ? void 0 : _a.decorators;
  if (!decorators)
    return [];
  var rc = [];
  var objDecorators = JSON.parse(decorators);
  Object.entries(objDecorators).forEach(function(entrie) {
    var item = entrie[1];
    if (item.type === "PropertyDeclaration") {
      var propertyName_1 = item.parentName;
      item.decorators.forEach(function(decorator) {
        var _a2;
        if (decorator.text.startsWith("property(")) {
          var prop = {};
          var propertyType = (_a2 = getPropType(decorator.text)) === null || _a2 === void 0 ? void 0 : _a2.toLowerCase();
          prop["alias"] = getPropAttribute(decorator.text);
          prop.propertyName = propertyName_1;
          if (propertyType)
            prop.propertyType = propertyType;
          rc.push(prop);
        }
      });
    }
  });
  var defaultProps = getDefaultPropierties();
  return __spreadArray(__spreadArray([], defaultProps, true), rc, true);
}
function getMoreInfoInJsDoc(model, propierties) {
  var _a;
  var devDoc = (_a = model.compilerResults) === null || _a === void 0 ? void 0 : _a.devDoc;
  if (!devDoc)
    return propierties;
  var objDocs = JSON.parse(devDoc);
  var jsDocProps = getJSDocPropierties(objDocs);
  var _loop_1 = function(i2) {
    var prop = propierties[i2];
    var propInPropsJsDoc = jsDocProps.find(function(_prop) {
      return _prop.propertyName === prop.propertyName;
    });
    prop.propertyName = prop["alias"] || prop.propertyName;
    delete prop["alias"];
    if (propInPropsJsDoc) {
      prop = __assign(__assign({}, propInPropsJsDoc), prop);
      propierties[i2] = prop;
    }
  };
  for (var i = 0; i < propierties.length; i++) {
    _loop_1(i);
  }
  return propierties;
}
function getJSDocPropierties(objDocs) {
  var rc = [];
  for (var _i = 0, objDocs_1 = objDocs; _i < objDocs_1.length; _i++) {
    var doc = objDocs_1[_i];
    if (doc.type !== "class")
      continue;
    var docMembersProp = doc.members.filter(function(m) {
      var isProp = m.type === "property";
      var isLitProp = false;
      if (isProp) {
        var modifiers = m.modifiers;
        isLitProp = isDecoratorProp(modifiers);
      }
      return isProp && isLitProp;
    });
    docMembersProp.forEach(function(prop) {
      var propItem = {};
      var fieldType = getFieldTypeInfo(prop.tags);
      var sectionName = getSectionsTag(fieldType);
      var propType = getPropTypeTag(fieldType);
      propItem.hint = prop.comment;
      propItem.propertyName = prop.name;
      propItem.defaultValue = prop.initializerText || (fieldType === null || fieldType === void 0 ? void 0 : fieldType.defaultValue) || "";
      if (propType)
        propItem.propertyType = propType;
      if (sectionName)
        propItem.sectionName = sectionName;
      if (fieldType === null || fieldType === void 0 ? void 0 : fieldType.cols)
        propItem.cols = fieldType === null || fieldType === void 0 ? void 0 : fieldType.cols;
      if (fieldType === null || fieldType === void 0 ? void 0 : fieldType.rows)
        propItem.rows = fieldType === null || fieldType === void 0 ? void 0 : fieldType.rows;
      if (fieldType === null || fieldType === void 0 ? void 0 : fieldType.pattern)
        propItem.pattern = fieldType === null || fieldType === void 0 ? void 0 : fieldType.pattern;
      if (fieldType === null || fieldType === void 0 ? void 0 : fieldType.max)
        propItem.max = fieldType === null || fieldType === void 0 ? void 0 : fieldType.max;
      if (fieldType === null || fieldType === void 0 ? void 0 : fieldType.min)
        propItem.min = fieldType === null || fieldType === void 0 ? void 0 : fieldType.min;
      if (fieldType === null || fieldType === void 0 ? void 0 : fieldType.step)
        propItem.step = fieldType === null || fieldType === void 0 ? void 0 : fieldType.step;
      if (fieldType === null || fieldType === void 0 ? void 0 : fieldType.maxLength)
        propItem.maxLength = fieldType === null || fieldType === void 0 ? void 0 : fieldType.maxLength;
      if (propType === "list") {
        var itens = getItensByType(prop.initializerType);
        propItem.items = (fieldType === null || fieldType === void 0 ? void 0 : fieldType.items) || itens || [];
      }
      rc.push(propItem);
    });
  }
  return rc;
}
function getItensByType(initializerType) {
  if (!initializerType)
    return [];
  var regex = /"(.*?)"/g;
  var matches = initializerType.match(regex);
  if (matches) {
    var resultList = matches.map(function(match) {
      return match.replace(/"/g, "");
    });
    return resultList;
  }
  return [];
}
function getPropType(propertyString) {
  var typeRegex = /type:\s*([A-Za-z]+)/;
  var match = propertyString.match(typeRegex);
  if (match && match.length > 1) {
    var typeProp = match[1];
    return typeProp;
  }
  return void 0;
}
function getPropAttribute(propertyString) {
  var typeRegex = /attribute:\s*['"]([^'"]+)['"]/;
  var match = propertyString.match(typeRegex);
  if (match && match.length > 1) {
    var attr = match[1];
    return attr;
  }
  return void 0;
}
function isDecoratorProp(modifiers) {
  if (!modifiers)
    return false;
  var searchStr = "@property(";
  for (var _i = 0, modifiers_1 = modifiers; _i < modifiers_1.length; _i++) {
    var item = modifiers_1[_i];
    if (item.startsWith(searchStr))
      return true;
  }
  return false;
}
function getFieldTypeInfo(tags) {
  var tag = tags.find(function(item) {
    return item.tagName === "fieldType";
  });
  if (!tag)
    return void 0;
  try {
    var rc = JSON.parse(tag.comment);
    return rc;
  } catch (err) {
    return void 0;
  }
}
function getSectionsTag(fieldType) {
  var defaultSection = "principal";
  if (!fieldType)
    return defaultSection;
  var sectionName = fieldType.sectionName;
  if (!sectionName)
    return defaultSection;
  var valueFormated = sectionName.toLowerCase().trim();
  if (["principal", "optional", "advanced"].includes(valueFormated))
    return valueFormated;
  return defaultSection;
}
function getPropTypeTag(fieldType) {
  var defaultType = "string";
  if (!fieldType)
    return defaultType;
  var propertyType = fieldType.propertyType;
  if (!propertyType)
    return defaultType;
  var valueFormated = propertyType.toLowerCase().trim();
  if (["string", "number", "boolean", "list", "json"].includes(valueFormated))
    return valueFormated;
  return defaultType;
}
export {
  getPropierties
};
