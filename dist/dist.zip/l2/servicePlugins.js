var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __assign = function() {
  __assign = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
        t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css } from "lit";
import { customElement, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
var message_pt = {
  installPlugin: "Instalar plugin",
  createNewPlugin: "Criar novo plugin",
  backList: "Voltar \uFFFD lista",
  noPluginsInstalled: "Nenhum plugin instalado",
  desactivate: "Desativar",
  activate: "Ativar",
  delete: "Excluir",
  reference: "Refer\uFFFDncia",
  noPluginsAvaliables: "Nenhum plugin dispon\uFFFDvel",
  install: "Instalar",
  p1: "O que s\uFFFDo plugins?",
  p2: "Plugins s\uFFFDo trechos de c\uFFFDdigo que incorporam funcionalidades adicionais ao seu projeto. Eles s\uFFFDo desenvolvidos para estender e aprimorar as capacidades do seu projeto.",
  p3: "Como os plugins funcionam?",
  p4: "Quando voc\uFFFD instala e ativa um plugin, ele introduz novos recursos ou funcionalidades ao seu projeto. Os plugins podem modificar a maneira como o seu projeto opera, adicionando novas op\uFFFD\uFFFDes de configura\uFFFD\uFFFDo, intelig\uFFFDncia artificial, widgets, c\uFFFDdigos curtos, entre outras funcionalidades.",
  p5: "Onde encontrar plugins?",
  p6: 'Voc\uFFFD pode localizar plugins diretamente no (L5) do seu projeto, na se\uFFFD\uFFFDo de Servi\uFFFDos (Service) chamado "Plugins". Neste local, \uFFFD poss\uFFFDvel gerenciar e adicionar novos plugins ao seu projeto.',
  p7: "Como criar um plugin?",
  p8: "Para criar um plugin..."
};
var message_en = {
  installPlugin: "Install plugin",
  createNewPlugin: "Create new plugin",
  backList: "Back list",
  noPluginsInstalled: "No plugins  installed",
  desactivate: "Desactivate",
  activate: "Activate",
  delete: "Delete",
  reference: "Reference",
  noPluginsAvaliables: "No plugins avaliables",
  install: "Install",
  p1: "What are plugins?",
  p2: "Plugins are snippets of code that incorporate additional functionality into your project. They are developed to extend and enhance your projects capabilities.",
  p3: "How do plugins work?",
  p4: "When you install and activate a plugin, it introduces new features or functionality to your project. Plugins can modify the way your project operates, adding new configuration options, artificial intelligence, widgets, short codes, among other features.",
  p5: "Where to find plugins?",
  p6: 'You can find plugins directly in (L5) of your project, in the Services section called "Plugins". Here, you can manage and add new plugins to your project.',
  p7: "How to create a plugin?",
  p8: "To create a plugin..."
};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServicePlugins = (
  /** @class */
  function(_super) {
    __extends(ServicePlugins2, _super);
    function ServicePlugins2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.msg = messages["en"];
      _this.userPlugins = _this.getUserPluginsByProject(_this.project);
      _this.avaliablePlugins = _this.getAvaliablePlugins(_this.project);
      _this.filterTerm = "";
      _this.lastPluginIdAdd = -1;
      _this.currentScenario = "list";
      _this.details = {
        icon: "&#xf1e6",
        state: "foreground",
        tooltip: "Plugins",
        visible: true,
        position: "all",
        widget: "_100554_servicePlugins",
        level: [5]
      };
      _this.onClickLink = function(op) {
        if (op === "opPlugins")
          return _this.showInitial();
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.menu = {
        title: "Plugins",
        actions: {},
        icons: {},
        actionDefault: "opPlugins",
        // call after close icon clicked
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink
      };
      return _this;
    }
    Object.defineProperty(ServicePlugins2.prototype, "project", {
      get: function() {
        return window["mls"] ? mls.actual[5].project : 0;
      },
      enumerable: false,
      configurable: true
    });
    ;
    ServicePlugins2.prototype.showInitial = function() {
      return true;
    };
    ServicePlugins2.prototype.onServiceClick = function(visible, reinit) {
      if (visible && reinit) {
        this.userPlugins = this.getUserPluginsByProject(this.project);
        this.avaliablePlugins = this.getAvaliablePlugins(this.project);
        this.currentScenario = "list";
      }
    };
    ServicePlugins2.prototype.getExamplesPlugins = function() {
      return [
        // Exemplos de plugins comuns do WordPress
        { prjID: 1, name: "SEO Optimizer", description: "Enhances your site's SEO.", category: "SEO", ref: "https://example.com/plugin/seo-optimizer", status: "active" },
        { prjID: 2, name: "Contact Form Builder", description: "Create custom contact forms.", category: "Forms", ref: "https://example.com/plugin/contact-form-builder", status: "inactive" },
        { prjID: 3, name: "Social Media Integration", description: "Integrate social media platforms.", category: "Social Media", ref: "https://example.com/plugin/social-media-integration", status: "active" },
        { prjID: 4, name: "E-commerce Solution", description: "Manage your online store.", category: "E-commerce", ref: "https://example.com/plugin/e-commerce-solution", status: "active" },
        { prjID: 5, name: "Event Calendar", description: "Schedule and display events.", category: "Event Management", ref: "https://example.com/plugin/event-calendar", status: "inactive" },
        { prjID: 6, name: "Gallery Manager", description: "Create and manage image galleries.", category: "Media", ref: "https://example.com/plugin/gallery-manager", status: "active" },
        { prjID: 7, name: "Advanced Analytics", description: "Provides detailed analytics for your site.", category: "Analytics", ref: "https://example.com/plugin/advanced-analytics", status: "active" },
        { prjID: 8, name: "Backup and Restore", description: "Back up and restore your site data.", category: "Utilities", ref: "https://example.com/plugin/backup-restore", status: "inactive" },
        { prjID: 9, name: "Custom CSS Editor", description: "Edit the CSS of your site directly.", category: "Design", ref: "https://example.com/plugin/custom-css-editor", status: "active" },
        { prjID: 10, name: "Drag and Drop Builder", description: "Build your pages with a drag and drop interface.", category: "Page Builder", ref: "https://example.com/plugin/drag-drop-builder", status: "active" },
        { prjID: 11, name: "Email Marketing Integration", description: "Integrate email marketing services.", category: "Marketing", ref: "https://example.com/plugin/email-marketing", status: "active" },
        { prjID: 12, name: "Fast Cache Cleaner", description: "Speed up your site by cleaning cache.", category: "Performance", ref: "https://example.com/plugin/fast-cache-cleaner", status: "inactive" },
        { prjID: 13, name: "Google Maps Embed", description: "Embed Google Maps in your site.", category: "Maps", ref: "https://example.com/plugin/google-maps-embed", status: "active" },
        { prjID: 14, name: "Help Desk Support", description: "Add a help desk system to your site.", category: "Support", ref: "https://example.com/plugin/help-desk-support", status: "inactive" },
        { prjID: 15, name: "Image Optimizer", description: "Optimize images for better performance.", category: "Media", ref: "https://example.com/plugin/image-optimizer", status: "active" },
        { prjID: 16, name: "Job Board", description: "Create a job board for your site.", category: "Business", ref: "https://example.com/plugin/job-board", status: "active" },
        { prjID: 17, name: "Knowledge Base", description: "Build a knowledge base for your users.", category: "Content", ref: "https://example.com/plugin/knowledge-base", status: "inactive" },
        { prjID: 18, name: "Live Chat", description: "Enable live chat support on your site.", category: "Communication", ref: "https://example.com/plugin/live-chat", status: "active" },
        { prjID: 19, name: "Membership Management", description: "Manage user memberships on your site.", category: "Community", ref: "https://example.com/plugin/membership-management", status: "inactive" },
        { prjID: 20, name: "Newsletter Subscription", description: "Allow users to subscribe to your newsletters.", category: "Marketing", ref: "https://example.com/plugin/newsletter-subscription", status: "active" },
        { prjID: 21, name: "Online Booking", description: "Manage online bookings and appointments.", category: "Booking", ref: "https://example.com/plugin/online-booking", status: "active" },
        { prjID: 22, name: "Payment Gateway Integration", description: "Integrate various payment gateways.", category: "E-commerce", ref: "https://example.com/plugin/payment-gateway", status: "inactive" },
        { prjID: 23, name: "Quiz and Survey", description: "Create quizzes and surveys for your users.", category: "Interactive", ref: "https://example.com/plugin/quiz-survey", status: "active" },
        { prjID: 24, name: "Related Posts", description: "Show related posts at the end of each article.", category: "Content", ref: "https://example.com/plugin/related-posts", status: "inactive" },
        { prjID: 25, name: "Security Firewall", description: "Enhance the security of your site.", category: "Security", ref: "https://example.com/plugin/security-firewall", status: "active" },
        { prjID: 26, name: "SEO Friendly URLs", description: "Generate SEO friendly URLs for your site.", category: "SEO", ref: "https://example.com/plugin/seo-friendly-urls", status: "inactive" },
        { prjID: 27, name: "Social Sharing Buttons", description: "Add social sharing buttons to your posts.", category: "Social Media", ref: "https://example.com/plugin/social-sharing-buttons", status: "active" },
        { prjID: 28, name: "Theme Customizer", description: "Customize the look and feel of your site.", category: "Design", ref: "https://example.com/plugin/theme-customizer", status: "inactive" },
        { prjID: 29, name: "User Profile Editor", description: "Let users edit their profiles on your site.", category: "User Management", ref: "https://example.com/plugin/user-profile-editor", status: "active" },
        { prjID: 30, name: "Video Embedder", description: "Easily embed videos into your posts.", category: "Media", ref: "https://example.com/plugin/video-embedder", status: "inactive" }
      ];
    };
    ServicePlugins2.prototype.backListClicked = function() {
      this.changeScenario("list");
    };
    ServicePlugins2.prototype.installPluginClicked = function() {
      this.changeScenario("add");
    };
    ServicePlugins2.prototype.createNewPluginClicked = function() {
      this.changeScenario("help");
    };
    ServicePlugins2.prototype.searchInputChanged = function(event) {
      var searchTerm = event.target.value;
      this.filterTerm = searchTerm;
      var plugins = this.filterPlugins(this.getUserPluginsByProject(this.project));
      this.userPlugins = plugins;
    };
    ServicePlugins2.prototype.activateClicked = function(plugin) {
      console.log("Activate clicked for:", plugin.name);
      this.changeStatus(this.project, plugin.prjID, "active");
      this.userPlugins = this.getUserPluginsByProject(this.project);
    };
    ServicePlugins2.prototype.deactivateClicked = function(plugin) {
      console.info("Deactivate clicked for:", plugin.name);
      this.changeStatus(this.project, plugin.prjID, "inactive");
      this.userPlugins = this.getUserPluginsByProject(this.project);
    };
    ServicePlugins2.prototype.deleteClicked = function(plugin) {
      console.log("Delete clicked for:", plugin.name);
      this.deletePlugin(this.project, plugin.prjID);
      this.userPlugins = this.getUserPluginsByProject(this.project);
      this.avaliablePlugins = this.getAvaliablePlugins(this.project);
    };
    ServicePlugins2.prototype.addPluginClicked = function(plugin) {
      var _this = this;
      this.addPlugin(this.project, plugin.prjID);
      this.lastPluginIdAdd = plugin.prjID;
      this.userPlugins = this.getUserPluginsByProject(this.project);
      this.avaliablePlugins = this.getAvaliablePlugins(this.project);
      this.changeScenario("list");
      setTimeout(function() {
        _this.scrollToAddPlugin(plugin.prjID);
      }, 400);
    };
    ServicePlugins2.prototype.getAvaliablePlugins = function(project) {
      var pluginsUser = this.getUserPluginsByProject(project);
      var allPlugins = this.getExamplesPlugins();
      var avaliablePlugins = allPlugins.filter(function(itemA) {
        return !pluginsUser.some(function(itemB) {
          return itemB.prjID === itemA.prjID;
        });
      });
      return avaliablePlugins;
    };
    ServicePlugins2.prototype.getUserPlugins = function() {
      var data = localStorage.getItem("collab-user-plugins");
      var plugins = data ? JSON.parse(data) : {};
      return plugins;
    };
    ServicePlugins2.prototype.getUserPluginsByProject = function(project) {
      var plugins = this.getUserPlugins();
      if (!plugins[project])
        return [];
      var rc = this.mergeAndRemoveMissing(this.getExamplesPlugins(), plugins[project]);
      return rc;
    };
    ServicePlugins2.prototype.mergeAndRemoveMissing = function(arr1, arr2) {
      var filteredArr1 = arr1.filter(function(obj1) {
        return arr2.some(function(obj2) {
          return obj2.prjID === obj1.prjID;
        });
      });
      var mergedArray = filteredArr1.map(function(obj1) {
        var matchingObject = arr2.find(function(obj2) {
          return obj2.prjID === obj1.prjID;
        });
        return __assign(__assign({}, obj1), matchingObject);
      });
      return mergedArray;
    };
    ServicePlugins2.prototype.addPlugin = function(project, pluginId) {
      var userPlugins = __assign({}, this.getUserPlugins());
      if (!userPlugins[project])
        userPlugins[project] = [];
      var findPlugin = userPlugins[project].find(function(item) {
        return item.prjID === pluginId;
      });
      if (findPlugin)
        throw new Error("Plugin already installed");
      userPlugins[project].push({ prjID: pluginId, status: "active" });
      localStorage.setItem("collab-user-plugins", JSON.stringify(userPlugins));
    };
    ServicePlugins2.prototype.changeStatus = function(project, pluginId, status) {
      var plugins = this.getUserPlugins();
      if (!plugins[project])
        plugins[project] = [];
      var findPlugin = plugins[project].find(function(item) {
        return item.prjID === pluginId;
      });
      if (findPlugin) {
        findPlugin.status = status;
      } else
        plugins[project].push({ prjID: pluginId, status });
      localStorage.setItem("collab-user-plugins", JSON.stringify(plugins));
    };
    ServicePlugins2.prototype.deletePlugin = function(project, pluginId) {
      var plugins = this.getUserPlugins();
      if (!plugins[project])
        plugins[project] = [];
      var index = plugins[project].findIndex(function(item) {
        return item.prjID === pluginId;
      });
      if (!index)
        return;
      plugins[project].splice(index, 1);
      localStorage.setItem("collab-user-plugins", JSON.stringify(plugins));
    };
    ServicePlugins2.prototype.groupPluginsByCategory = function(plugins) {
      return plugins.reduce(function(acc, plugin) {
        if (!acc[plugin.category]) {
          acc[plugin.category] = [];
        }
        acc[plugin.category].push(plugin);
        return acc;
      }, {});
    };
    ServicePlugins2.prototype.filterPlugins = function(plugins) {
      if (!this.filterTerm.trim())
        return plugins;
      var searchTerm = this.filterTerm.toLowerCase();
      return plugins.filter(function(plugin) {
        return plugin.name.toLowerCase().includes(searchTerm) || plugin.description.toLowerCase().includes(searchTerm) || plugin.ref.toLowerCase().includes(searchTerm);
      });
    };
    ServicePlugins2.prototype.changeScenario = function(scenario) {
      this.currentScenario = scenario;
    };
    ServicePlugins2.prototype.scrollToAddPlugin = function(pluginId) {
      var el = this.shadowRoot.querySelector('[plugin-id="'.concat(pluginId, '"'));
      if (el)
        el.scrollIntoView({ behavior: "smooth" });
    };
    ServicePlugins2.prototype.renderHeader = function() {
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject([" <div>", "\n                </div>            \n        "], [" <div>", "\n                </div>            \n        "])), this.currentScenario === "list" ? html(templateObject_1 || (templateObject_1 = __makeTemplateObject(['\n                <div class="header">\n                    <div>\n                        <button @click="', '">', '</button>\n                        <button @click="', '">', '</button>\n                    </div>\n                    <input type="text" placeholder="Search plugin..." @input="', '">\n                </div>\n            '], ['\n                <div class="header">\n                    <div>\n                        <button @click="', '">', '</button>\n                        <button @click="', '">', '</button>\n                    </div>\n                    <input type="text" placeholder="Search plugin..." @input="', '">\n                </div>\n            '])), this.installPluginClicked, this.msg.installPlugin, this.createNewPluginClicked, this.msg.createNewPlugin, this.searchInputChanged) : html(templateObject_2 || (templateObject_2 = __makeTemplateObject(['\n                    <div class="header">\n                        <div>\n                            <button @click="', '">', "Back List</button>\n                        </div>\n                    </div>\n                "], ['\n                    <div class="header">\n                        <div>\n                            <button @click="', '">', "Back List</button>\n                        </div>\n                    </div>\n                "])), this.backListClicked, this.msg.backList));
    };
    ServicePlugins2.prototype.renderListPlugins = function() {
      var _this = this;
      var groupedPlugins = this.groupPluginsByCategory(this.userPlugins);
      var sortedCategories = Object.keys(groupedPlugins).sort();
      return html(templateObject_8 || (templateObject_8 = __makeTemplateObject(['\n        <h4 style="', '">', '</h4>\n        <ul class="plugin-list">\n            ', "\n        </ul>\n    "], ['\n        <h4 style="', '">', '</h4>\n        <ul class="plugin-list">\n            ', "\n        </ul>\n    "])), sortedCategories.length === 0 ? "display:block" : "display:none", this.msg.noPluginsInstalled, sortedCategories.map(function(category) {
        return html(templateObject_7 || (templateObject_7 = __makeTemplateObject(['\n                <li class="headerCategory">\n                    <details open ">\n                        <summary>', "</summary>\n                            ", "\n                    </details>\n                </li>        \n            "], ['\n                <li class="headerCategory">\n                    <details open ">\n                        <summary>', "</summary>\n                            ", "\n                    </details>\n                </li>        \n            "])), category, groupedPlugins[category].map(function(plugin) {
          return html(templateObject_6 || (templateObject_6 = __makeTemplateObject(['\n                                <div\n                                plugin-id="', '"\n                                class="', '"\n                                style="', '"\n                                \n                                >\n                                    <div class= "plugin-title">\n                                        <h3>', '</h3>\n                                        <div class="plugin-actions">\n                                            ', '\n                                            <a href="#" @click="', '">', '</a>\n                                        </div>\n                                    </div>\n                                    <div class="plugin-info">    \n                                        <p>', "</p>\n                                        <p><strong>", ":</strong> ", "</p>\n                                    </div>\n                                </div>\n                            "], ['\n                                <div\n                                plugin-id="', '"\n                                class="', '"\n                                style="', '"\n                                \n                                >\n                                    <div class= "plugin-title">\n                                        <h3>', '</h3>\n                                        <div class="plugin-actions">\n                                            ', '\n                                            <a href="#" @click="', '">', '</a>\n                                        </div>\n                                    </div>\n                                    <div class="plugin-info">    \n                                        <p>', "</p>\n                                        <p><strong>", ":</strong> ", "</p>\n                                    </div>\n                                </div>\n                            "])), plugin.prjID, plugin.status === "active" ? "plugin active" : "plugin", plugin.prjID === _this.lastPluginIdAdd ? "background:#edffed" : "", plugin.name, plugin.status === "active" ? html(templateObject_4 || (templateObject_4 = __makeTemplateObject(['<a  href="#" @click="', '">', "</a>"], ['<a  href="#" @click="', '">', "</a>"])), function(e) {
            e.preventDefault();
            _this.deactivateClicked(plugin);
          }, _this.msg.desactivate) : html(templateObject_5 || (templateObject_5 = __makeTemplateObject(['<a  href="#" @click="', '">', "</a>"], ['<a  href="#" @click="', '">', "</a>"])), function(e) {
            e.preventDefault();
            _this.activateClicked(plugin);
          }, _this.msg.activate), function(e) {
            e.preventDefault();
            _this.deleteClicked(plugin);
          }, _this.msg.delete, plugin.description, _this.msg.reference, plugin.ref);
        }));
      }));
    };
    ServicePlugins2.prototype.renderListAvaliablePlugins = function() {
      var _this = this;
      var groupedPlugins = this.groupPluginsByCategory(this.avaliablePlugins);
      var sortedCategories = Object.keys(groupedPlugins).sort();
      return html(templateObject_11 || (templateObject_11 = __makeTemplateObject(['\n        <h4 style="', '">', '!</h4>\n        \n        <ul class="plugin-list">\n            ', "\n        </ul>\n    "], ['\n        <h4 style="', '">', '!</h4>\n        \n        <ul class="plugin-list">\n            ', "\n        </ul>\n    "])), sortedCategories.length === 0 ? "display:block" : "display:none", this.msg.noPluginsAvaliables, sortedCategories.map(function(category) {
        return html(templateObject_10 || (templateObject_10 = __makeTemplateObject(['\n                <li class="headerCategory">\n                    <details open ">\n                        <summary>', "</summary>\n                            ", "\n                    </details>\n                </li>        \n            "], ['\n                <li class="headerCategory">\n                    <details open ">\n                        <summary>', "</summary>\n                            ", "\n                    </details>\n                </li>        \n            "])), category, groupedPlugins[category].map(function(plugin) {
          return html(templateObject_9 || (templateObject_9 = __makeTemplateObject(['\n                                <div class="plugin">\n                                    <div class= "plugin-title">\n                                        <h3>', '</h3>\n                                        <div class="plugin-actions">\n                                            <a href="#" @click="', '">', '</a>\n                                        </div>\n                                    </div>\n                                    <div class="plugin-info">    \n                                        <p>', "</p>\n                                        <p><strong>", ":</strong> ", "</p>\n                                    </div>\n                                </div>\n                            "], ['\n                                <div class="plugin">\n                                    <div class= "plugin-title">\n                                        <h3>', '</h3>\n                                        <div class="plugin-actions">\n                                            <a href="#" @click="', '">', '</a>\n                                        </div>\n                                    </div>\n                                    <div class="plugin-info">    \n                                        <p>', "</p>\n                                        <p><strong>", ":</strong> ", "</p>\n                                    </div>\n                                </div>\n                            "])), plugin.name, function(e) {
            e.preventDefault();
            _this.addPluginClicked(plugin);
          }, _this.msg.install, plugin.description, _this.msg.reference, plugin.ref);
        }));
      }));
    };
    ServicePlugins2.prototype.renderHelper = function() {
      return html(templateObject_12 || (templateObject_12 = __makeTemplateObject(["\n            <h2>", "</h2>\n            <p>", "</p>\n            <h2>", "</h2>\n            <p>", "</p>\n\n            <h2>", "</h2>\n            <p>", "</p>\n\n            <h2>", "</h2>\n            <p>", "</p>\n        "], ["\n            <h2>", "</h2>\n            <p>", "</p>\n            <h2>", "</h2>\n            <p>", "</p>\n\n            <h2>", "</h2>\n            <p>", "</p>\n\n            <h2>", "</h2>\n            <p>", "</p>\n        "])), this.msg.p1, this.msg.p2, this.msg.p3, this.msg.p4, this.msg.p5, this.msg.p6, this.msg.p7, this.msg.p8);
    };
    ServicePlugins2.prototype.renderScenario = function() {
      switch (this.currentScenario) {
        case "list":
          return html(templateObject_13 || (templateObject_13 = __makeTemplateObject(["\n                    ", "\n                    ", "\n                "], ["\n                    ", "\n                    ", "\n                "])), this.renderHeader(), this.renderListPlugins());
        case "add":
          return html(templateObject_14 || (templateObject_14 = __makeTemplateObject(["\n                    ", "\n                    ", "\n                "], ["\n                    ", "\n                    ", "\n                "])), this.renderHeader(), this.renderListAvaliablePlugins());
        case "help":
          return html(templateObject_15 || (templateObject_15 = __makeTemplateObject(["\n                    ", "\n                    ", "\n                "], ["\n                    ", "\n                    ", "\n                "])), this.renderHeader(), this.renderHelper());
      }
    };
    ServicePlugins2.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return html(templateObject_16 || (templateObject_16 = __makeTemplateObject(["\n            <section>\n                ", "\n            </section>\n        "], ["\n            <section>\n                ", "\n            </section>\n        "])), this.renderScenario());
    };
    ServicePlugins2.styles = css(templateObject_17 || (templateObject_17 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property({ type: Array }),
      __metadata("design:type", Array)
    ], ServicePlugins2.prototype, "userPlugins", void 0);
    __decorate([
      property({ type: Array }),
      __metadata("design:type", Array)
    ], ServicePlugins2.prototype, "avaliablePlugins", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], ServicePlugins2.prototype, "filterTerm", void 0);
    __decorate([
      property({ type: Number }),
      __metadata("design:type", Number)
    ], ServicePlugins2.prototype, "lastPluginIdAdd", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], ServicePlugins2.prototype, "currentScenario", void 0);
    ServicePlugins2 = __decorate([
      customElement("service-plugins-100554")
    ], ServicePlugins2);
    return ServicePlugins2;
  }(ServiceBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6, templateObject_7, templateObject_8, templateObject_9, templateObject_10, templateObject_11, templateObject_12, templateObject_13, templateObject_14, templateObject_15, templateObject_16, templateObject_17;
export {
  ServicePlugins
};
