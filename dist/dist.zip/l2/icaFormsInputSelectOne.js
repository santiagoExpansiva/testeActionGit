import { IcaLitElement } from "./_100554_icaLitElement";
class IcaFormsInputSelectOne extends IcaLitElement {
  // Whether the field is ready for input or disabled
}
export {
  IcaFormsInputSelectOne
};
