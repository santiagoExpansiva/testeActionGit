var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html } from "lit";
import { customElement, property, query } from "lit/decorators.js";
import { AimTaskBase } from "./_100554_aimTaskBase";
var message_pt = {
  tryagain_title_2: "O prompt \uFFFD valido",
  tryagain_title_3: "O prompt enviado esta fora de contexto por favor digite um prompt referente a cria\uFFFD\uFFFDo de um web component",
  tryagain_title_4: "O prompt precisa ser melhorado, por favor digite as mudan\uFFFDas necess\uFFFDrias abaixo.",
  tryagain_title_5: "Segue abaixo algumas sugest\uFFFDes para melhorar o seu prompt",
  error_message: "O prompt deve ser preenchido.",
  tryagain_placeholder: "Digite aqui seu prompt.",
  tryagain_processed: "Prompt j\uFFFD validado.",
  btn_confirmar: "Confirmar",
  btn_cancelar: "Cancelar"
};
var message_en = {
  tryagain_title_2: "The prompt is valid",
  tryagain_title_3: "The prompt sent is out of context, please type a prompt related to the creation of a web component",
  tryagain_title_4: "The prompt needs improvement, please type the necessary changes below.",
  tryagain_title_5: "Below are some suggestions to improve your prompt",
  error_message: "The prompt must be filled.",
  tryagain_placeholder: "Type your prompt here.",
  tryagain_processed: "Prompt already validated.",
  btn_confirmar: "Confirm",
  btn_cancelar: "Cancel"
};
var messages = {
  "en-us": message_en,
  "pt-br": message_pt
};
var AimTaskResulAddIcaPrompt = (
  /** @class */
  function(_super) {
    __extends(AimTaskResulAddIcaPrompt2, _super);
    function AimTaskResulAddIcaPrompt2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.msg = messages["en-us"];
      _this.hasError = false;
      return _this;
    }
    AimTaskResulAddIcaPrompt2.prototype.onInitializing = function() {
      if (this.taskChild.mode !== "error" && this.taskChild.mode !== "processed") {
        this.modeInternal = this.taskRoot.mode = this.taskChild.mode = "waiting for user";
      }
      if (!this.taskChild.result) {
        this.taskChild.mode === "error";
        this.notifyCompleteByStatus("error", "");
        return;
      }
      this.result = this.getResult(this.taskChild.result);
      if (this.result === 0) {
        this.notifyCompleteByStatus("ok", "");
        return;
      }
      this.openMe();
    };
    AimTaskResulAddIcaPrompt2.prototype.getResult = function(str) {
      var firstStr = str.substring(0, 24).toLowerCase();
      if (firstStr.startsWith("sim"))
        return 0;
      if (firstStr.startsWith("nao"))
        return 1;
      if (firstStr.startsWith("forne\uFFFDa mais informa\uFFFD\uFFFDes"))
        return 2;
    };
    AimTaskResulAddIcaPrompt2.prototype.renderBody = function(taskRoot, child) {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      var prompt = taskRoot.args ? JSON.parse(taskRoot.args).prompt : "";
      var body = child.result || "";
      this.result = this.getResult(body);
      if (this.modeInternal !== "waiting for user")
        return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["<div>", "</div>"], ["<div>", "</div>"])), this.msg.tryagain_processed);
      return html(templateObject_5 || (templateObject_5 = __makeTemplateObject(["\n         <div>\n             ", "            \n         </div> \n         "], ["\n         <div>\n             ", "            \n         </div> \n         "])), this.result === 0 ? html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["<span>", "</span>"], ["<span>", "</span>"])), this.msg.tryagain_title_2) : html(templateObject_4 || (templateObject_4 = __makeTemplateObject(["\n\n                     ", "\n\n                     <div style='margin: 10px;'>\n                         <label>", ' </label>\n\n                         <textarea\n                         rows="5"\n                         placeholder=', ' \n                         .value="', '"\n                         style="width:100%"></textarea >\n                         ', '\n                     </div>\n                     <br>\n                     <div class="buttonGroup">\n                         <button @click="', '">', '</button>\n                         <button @click="', '">', "</button>\n                     </div>\n             "], ["\n\n                     ", "\n\n                     <div style='margin: 10px;'>\n                         <label>", ' </label>\n\n                         <textarea\n                         rows="5"\n                         placeholder=', ' \n                         .value="', '"\n                         style="width:100%"></textarea >\n                         ', '\n                     </div>\n                     <br>\n                     <div class="buttonGroup">\n                         <button @click="', '">', '</button>\n                         <button @click="', '">', "</button>\n                     </div>\n             "])), this.result === 2 ? this.renderListSuggestions(body) : "", this.result === 2 ? this.msg.tryagain_title_4 : this.msg.tryagain_title_3, this.msg.tryagain_placeholder, prompt, this.hasError ? html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['<small style="color:red;"> ', "</small>"], ['<small style="color:red;"> ', "</small>"])), this.msg.error_message) : "", this.handleCancelTryAgain, this.msg.btn_cancelar, this.handleConfirmTryAgain, this.msg.btn_confirmar));
    };
    AimTaskResulAddIcaPrompt2.prototype.renderListSuggestions = function(str) {
      return html(templateObject_6 || (templateObject_6 = __makeTemplateObject(["\n        <span>", '</span>\n        <pre style="white-space: pre-line;">\n            ', "\n        </pre>\n    "], ["\n        <span>", '</span>\n        <pre style="white-space: pre-line;">\n            ', "\n        </pre>\n    "])), this.msg.tryagain_title_5, str);
    };
    AimTaskResulAddIcaPrompt2.prototype.closeMe = function() {
      var det = this.querySelector("details");
      if (det)
        det.open = false;
    };
    AimTaskResulAddIcaPrompt2.prototype.openMe = function() {
      var _this = this;
      var detRoot = this.closest("details");
      setTimeout(function() {
        var detInternal2 = _this.querySelector("details");
        if (detInternal2)
          detInternal2.open = true;
      }, 150);
      if (detRoot)
        detRoot.open = true;
    };
    AimTaskResulAddIcaPrompt2.prototype.handleCancelTryAgain = function() {
      this.notifyCompleteByStatus("error", "");
    };
    AimTaskResulAddIcaPrompt2.prototype.handleConfirmTryAgain = function() {
      var prompt = "";
      if (this.textarea)
        prompt = this.textarea.value;
      if (prompt === "") {
        this.hasError = true;
        return;
      }
      this.notifyCompleteByStatus("userEvent", "", prompt);
      this.closeMe();
    };
    var _a, _b;
    __decorate([
      property({ type: String, reflect: true }),
      __metadata("design:type", typeof (_a = typeof cbe !== "undefined" && cbe.IMode) === "function" ? _a : Object)
    ], AimTaskResulAddIcaPrompt2.prototype, "modeInternal", void 0);
    __decorate([
      property(),
      __metadata("design:type", Boolean)
    ], AimTaskResulAddIcaPrompt2.prototype, "hasError", void 0);
    __decorate([
      query("textarea"),
      __metadata("design:type", typeof (_b = typeof HTMLTextAreaElement !== "undefined" && HTMLTextAreaElement) === "function" ? _b : Object)
    ], AimTaskResulAddIcaPrompt2.prototype, "textarea", void 0);
    AimTaskResulAddIcaPrompt2 = __decorate([
      customElement("aim-task-result-add-ica-prompt-100554")
    ], AimTaskResulAddIcaPrompt2);
    return AimTaskResulAddIcaPrompt2;
  }(AimTaskBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6;
export {
  AimTaskResulAddIcaPrompt
};
