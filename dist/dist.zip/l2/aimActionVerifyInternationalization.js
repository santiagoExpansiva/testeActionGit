var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from "lit";
import { customElement } from "lit/decorators.js";
import { tasks, updateTaskOnServer, getInfoMyService } from "./_100554_aimHelper";
import { AimActionBase } from "./_100554_aimActionBase";
var myName = "_100554_aimActionVerifyInternationalization";
var message_pt = {
  "action_title": "verificar textos para internacionaliza\uFFFD\uFFFDo",
  "btn_cancel": "Cancelar",
  "btn_confirm": "Confirmar"
};
var message_en = {
  "action_title": "verify text internationalization",
  "btn_cancel": "Cancel",
  "btn_confirm": "Confirm"
};
var messages = {
  "en-us": message_en,
  "pt-br": message_pt
};
var AimActionVerifyInternationalization = (
  /** @class */
  function(_super) {
    __extends(AimActionVerifyInternationalization2, _super);
    function AimActionVerifyInternationalization2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.msg = messages["en-us"];
      _this.assistant = "gpt3_typescript";
      _this.title = "Check Internationalization";
      _this.language = "english";
      return _this;
    }
    AimActionVerifyInternationalization2.prototype.getRules = function() {
      return {
        levels: [2],
        tags: ["*serviceSource*"]
      };
    };
    AimActionVerifyInternationalization2.prototype.render = function() {
      var lang = this.getMessageKey(messages);
      this.msg = messages[lang];
      return _super.prototype.render.call(this);
    };
    AimActionVerifyInternationalization2.prototype.handleCancel = function() {
      this.dispatchEvent(new CustomEvent("add-task", {
        detail: { cancel: "true" },
        bubbles: true,
        composed: true
      }));
    };
    AimActionVerifyInternationalization2.prototype.handleAdd = function() {
      var info = getInfoMyService(this);
      if (!info || info.actServiceOp && info.actServiceOp.tagName !== "SERVICE-SOURCE-100554") {
        throw new Error("Invalid service opposite side");
      }
      var position = info.position === "left" ? "right" : "left";
      if (!mls.actual[2][position])
        throw new Error("Invalid File in mls.actual[2]");
      var _a = mls.actual[2][position], project = _a.project, shortName = _a.shortName;
      var ref = {
        fileName: "_".concat(project, "_").concat(shortName)
      };
      var taskRoot = {
        mode: "initializing",
        title: this.msg.action_title,
        widget: myName,
        children: [],
        args: JSON.stringify(ref),
        trace: [(/* @__PURE__ */ new Date()).toISOString() + ": trask created at "]
      };
      tasks.unshift(taskRoot);
      this.prepareTask1(taskRoot);
      this.dispatchEvent(new CustomEvent("finished-add-task-root", {
        detail: taskRoot,
        bubbles: true,
        composed: true
      }));
    };
    AimActionVerifyInternationalization2.prototype.renderAdd = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n        <p> ", '</p>\n        <br>\n        <div class="buttonGroup">\n          <button @click="', '">', '</button>\n          <button @click="', '">', "</button>\n        </div>\n    "], ["\n        <p> ", '</p>\n        <br>\n        <div class="buttonGroup">\n          <button @click="', '">', '</button>\n          <button @click="', '">', "</button>\n        </div>\n    "])), this.msg.action_title, this.handleCancel, this.msg.btn_cancel, this.handleAdd, this.msg.btn_confirm);
    };
    AimActionVerifyInternationalization2.prototype.getPrompt = function(source) {
      var prompt = "verificar o source abaixo as strings entre (\"\") ('') (``) que devem ser internacionalizadas. \n        N\uFFFDo retornar explica\uFFFD\uFFFDes, apenas retorne uma 'tabela' com as colunas: texto.\n        N\uFFFDo retornar linhas com textos duplicados na tabela\n\nSource: ".concat(source);
      return prompt;
    };
    AimActionVerifyInternationalization2.prototype.prepareTask1 = function(taskRoot) {
      this.mode = taskRoot.mode = "in progress";
      this.addTaskAndWaitForCompletion(taskRoot, {
        mode: "initializing",
        title: "get typescript source",
        widget: "_100554_aimTaskGetSourceLanguageTypescript",
        trace: [],
        nextStep: this.prepareTask2.name
        // danger, loop
      });
    };
    AimActionVerifyInternationalization2.prototype.prepareTask2 = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      if (taskFinishResult.status === "error") {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        return;
      }
      var data = JSON.parse(taskFinishResult.result);
      if (!data.source) {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        child.trace.push("invalid finish , no internationalization find in this file");
        this.requestUpdate();
        return;
      }
      child.mode = "processed";
      this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
        mode: "initializing",
        title: "exec prompt",
        widget: "_100554_aimTaskExecLLM",
        ref: child.ref,
        agent: this.assistant,
        prompt: this.getPrompt(data.source),
        trace: [],
        nextStep: this.prepareTask3.name
        // danger, loop
      });
    };
    AimActionVerifyInternationalization2.prototype.prepareTask3 = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      var result = child.result || "";
      if (taskFinishResult.status === "error" || !result) {
        this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
        return;
      }
      child.mode = "processed";
      this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
        mode: "initializing",
        title: "result",
        ref: child.ref,
        widget: "_100554_aimTaskResultTable",
        trace: [],
        _tempResult: result,
        nextStep: this.endTasks.name
        // danger, loop
      });
      this.requestUpdate();
    };
    AimActionVerifyInternationalization2.prototype.endTasks = function(taskFinishResult) {
      var child = taskFinishResult.taskChild;
      if (taskFinishResult.status === "error")
        child.mode = "error";
      else
        child.mode = "processed";
      this.mode = taskFinishResult.taskRoot.mode = child.mode;
      this.requestUpdate();
      updateTaskOnServer(taskFinishResult.taskIndex);
    };
    AimActionVerifyInternationalization2 = __decorate([
      customElement("aim-action-verify-internationalization-100554")
    ], AimActionVerifyInternationalization2);
    return AimActionVerifyInternationalization2;
  }(AimActionBase)
);
var templateObject_1;
export {
  AimActionVerifyInternationalization
};
