var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { collabState } from "./_100554_collabLitElement";
import { IcaLitElement } from "./_100554_icaLitElement";
import * as icaGlobal from "./_100554_icaGlobal";
import * as states from "./_100554_icaCollabStore";
import { convertFileNameToTag, convertTagToFileName } from "./_100554_utilsLit";
import { initWCDToolbox } from "./_100554_wcdToolbox";
import { html, unsafeHTML } from "lit";
import { property } from "lit/decorators.js";
var IcaLitElementBase = (
  /** @class */
  function(_super) {
    __extends(IcaLitElementBase2, _super);
    function IcaLitElementBase2() {
      var _this = _super.call(this) || this;
      _this.changeState = "";
      _this.styleel = "";
      _this.internalInnerHTML = "";
      _this.isLoadMyAction = {};
      _this.lastWidget = "";
      _this.styleElMain = void 0;
      initWCDToolbox();
      return _this;
    }
    IcaLitElementBase2.prototype.createRenderRoot = function() {
      return this;
    };
    IcaLitElementBase2.prototype.connectedCallback = function() {
      _super.prototype.connectedCallback.call(this);
      this.setInitialConfigs();
    };
    IcaLitElementBase2.prototype.firstUpdated = function(changedProperties) {
      return __awaiter(this, void 0, void 0, function() {
        var tempeEl;
        return __generator(this, function(_a) {
          _super.prototype.firstUpdated.call(this, changedProperties);
          tempeEl = document.createElement("span");
          tempeEl.style.cssText = this.styleel ? this.styleel : "";
          this.styleElMain = tempeEl.style;
          return [
            2
            /*return*/
          ];
        });
      });
    };
    IcaLitElementBase2.prototype.updated = function(changedProperties) {
      _super.prototype.updated.call(this, changedProperties);
      if (this.lastWidget !== this.widget) {
        this.lastWidget = this.widget;
        this.updateStyleDisplay();
      }
      if (this.renderType === "edit") {
        this.setEventsIfRenderTypeEdit();
      }
      if (this.renderType === "editactive") {
        this.addWCDToolbox();
      }
      this.performPreSlotAllocationOperations();
    };
    IcaLitElementBase2.prototype.changeStateStyle = function(style) {
      debugger;
      if (!this.styleElMain || !style)
        return;
      var el = this.querySelector("".concat(this.widget, ":first-child"));
      if (el) {
        this.styleElMain.cssText = el.style.cssText;
        Object.assign(this.styleElMain, style);
        el.style.cssText = this.styleElMain.cssText;
        this.styleel = el.style.cssText;
      }
    };
    IcaLitElementBase2.prototype.addWCDToolbox = function() {
      var wcd = document.createElement("wcd-toolbox-100554");
      if (this.level)
        wcd.setAttribute("level", this.level.toString());
      if (this.widget)
        wcd.setAttribute("widget", this.widget);
      var act = this.actions[this.level];
      if (!act)
        act = [];
      wcd.actions = act;
      this.appendChild(wcd);
    };
    IcaLitElementBase2.prototype.updateStyleDisplay = function() {
      var el = this.querySelector(this.widget);
      if (el) {
        var d = window.getComputedStyle(el);
        this.style.display = d.display;
      }
    };
    IcaLitElementBase2.prototype.setEventsIfRenderTypeEdit = function() {
      var _this = this;
      this.onclick = function(e) {
        return __awaiter(_this, void 0, void 0, function() {
          var all, inGroup;
          return __generator(this, function(_a) {
            switch (_a.label) {
              case 0:
                e.stopPropagation();
                if (e.target.tagName.startsWith("WCD-"))
                  return [
                    2
                    /*return*/
                  ];
                all = this.findElementsStartingWithIca();
                Array.from(all).forEach(function(i) {
                  var wcd = i.querySelector("wcd-toolbox-100554");
                  if (wcd)
                    wcd.remove();
                  i.setAttribute("renderType", "edit");
                });
                inGroup = this.closest("*[".concat(icaGlobal.ATTRGROUP, "]"));
                if (inGroup && inGroup !== this && inGroup.getAttribute("".concat(icaGlobal.ATTRGROUP)) === "true") {
                  inGroup.click();
                  return [
                    2
                    /*return*/
                  ];
                }
                this.onclick = void 0;
                if (!(!this.isLoadMyAction[this.level] || this.isLoadMyAction[this.level] === false)) return [3, 2];
                this.isLoadMyAction[this.level] = true;
                return [4, this.setActions(this.level)];
              case 1:
                _a.sent();
                _a.label = 2;
              case 2:
                this.setAttribute("renderType", "editactive");
                if (this.level !== "4")
                  return [
                    2
                    /*return*/
                  ];
                mls.events.fire(4, "WCDEvent", '{"op":"Navigation"}');
                mls.events.fire(+this.level, "WCDEventChange", '{"op":"Navigation"}');
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      };
    };
    IcaLitElementBase2.prototype.findElementsStartingWithIca = function() {
      var elements = [];
      function traverseShadowRoot(element) {
        if (element.tagName.toLowerCase().startsWith("ica")) {
          elements.push(element);
          return;
        }
        if (element.shadowRoot) {
          element.shadowRoot.querySelectorAll("*").forEach(function(item) {
            traverseShadowRoot(item);
          });
        } else {
          var children = Array.from(element.children);
          if (children.length > 0) {
            children.forEach(function(child) {
              return traverseShadowRoot(child);
            });
          }
        }
      }
      document.body.querySelectorAll("*").forEach(function(item) {
        traverseShadowRoot(item);
      });
      return elements;
    };
    IcaLitElementBase2.prototype.shouldUpdate = function(changedProperties) {
      var oldValue = changedProperties.get("renderType");
      if (oldValue === "editactive" && this.renderType !== "editactive") {
        _super.prototype.setCollabState.call(this, states.CHANGESTATE, "");
      } else if (changedProperties.get("changeState") !== void 0 && this.changeState) {
        return false;
      }
      if (changedProperties.get("level") && !this.isLoadMyAction[this.level] && this.renderType === "editactive") {
        this.auxSetMyActions();
      }
      return true;
    };
    IcaLitElementBase2.prototype.auxSetMyActions = function() {
      return __awaiter(this, void 0, void 0, function() {
        var _this = this;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              return [4, this.setActions(this.level)];
            case 1:
              _a.sent();
              this.isLoadMyAction[this.level] = true;
              this.renderType = "edit";
              setTimeout(function() {
                _this.click();
              }, 200);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    IcaLitElementBase2.prototype.importAction = function(imports_1, actions_1, level_1) {
      return __awaiter(this, arguments, void 0, function(imports, actions, level, mode, position) {
        var getTemplate, temp, e_1;
        if (mode === void 0) {
          mode = "";
        }
        if (position === void 0) {
          position = "";
        }
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              _a.trys.push([0, 2, , 3]);
              if (!imports.startsWith("./"))
                imports = "./" + imports;
              return [4, import(imports)];
            case 1:
              getTemplate = _a.sent().getTemplate;
              temp = getTemplate(mode, position);
              actions[level].push(temp);
              return [3, 3];
            case 2:
              e_1 = _a.sent();
              console.info(e_1);
              return [3, 3];
            case 3:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    IcaLitElementBase2.prototype.getICAComponents = function(scope) {
      var ret = [];
      var reentrance = function(el) {
        var tag = el.tagName.toLowerCase();
        if (tag.startsWith("".concat(icaGlobal.PREFIX, "-"))) {
          ret.push(el);
        }
        var isGroup = el.getAttribute("".concat(icaGlobal.ATTRGROUP));
        if (!isGroup || isGroup === "false") {
          Array.from(el.children).forEach(function(i) {
            reentrance(i);
          });
        }
      };
      Array.from(scope.children).forEach(function(i) {
        reentrance(i);
      });
      return ret;
    };
    IcaLitElementBase2.prototype.getMyScope = function() {
      var ret = this.closest("".concat(icaGlobal.ICAPAGE));
      if (!ret)
        ret = this.closest("body");
      return ret;
    };
    IcaLitElementBase2.prototype.getIcaParent = function(target) {
      var parent = target.parentElement;
      if (!parent)
        return;
      var tag = parent.tagName.toLowerCase();
      if (!tag.startsWith("".concat(icaGlobal.PREFIX, "-")))
        return this.getIcaParent(parent);
      else if (tag.startsWith("".concat(icaGlobal.PREFIX, "-")))
        return parent;
    };
    IcaLitElementBase2.prototype.doChangeState = function(js) {
      var info = JSON.parse(js);
      if (this.renderType === "editactive") {
        switch (info.tp) {
          case "menu":
            console.info(info.menu);
            break;
          case "style":
            this.changeStateStyle(info.style);
            break;
          case "html":
            this.changeStateHtml(info.html);
            break;
          default:
            "";
            break;
        }
      }
      mls.events.fire(+this.level, "WCDEventChange", '{"op":"Navigation"}');
    };
    IcaLitElementBase2.prototype.performPreSlotAllocationOperations = function() {
      return __awaiter(this, void 0, void 0, function() {
        var tag;
        var _this = this;
        return __generator(this, function(_a) {
          if (!this.widget)
            return [
              2
              /*return*/
            ];
          tag = convertFileNameToTag(this.widget);
          if (tag.startsWith(icaGlobal.PREFIX) || tag.startsWith(icaGlobal.PREFIXWCD))
            return [
              2
              /*return*/
            ];
          Promise.all([tag].map(function(wc) {
            return customElements.whenDefined(wc);
          })).then(function() {
            return __awaiter(_this, void 0, void 0, function() {
              var childrens, widgetElement, slots, slotWithoutName;
              return __generator(this, function(_a2) {
                childrens = Array.from(this.children).filter(function(child) {
                  return child.tagName !== tag.toUpperCase();
                });
                widgetElement = this.querySelector(tag);
                if (!widgetElement || !childrens || childrens.length === 0)
                  return [
                    2
                    /*return*/
                  ];
                childrens.forEach(function(child) {
                  if (child.tagName.toLowerCase().startsWith(icaGlobal.PREFIXWCD))
                    return;
                  child.remove();
                  widgetElement.appendChild(child);
                });
                slots = widgetElement.shadowRoot ? Array.from(widgetElement.shadowRoot.querySelectorAll("slot")) : Array.from(widgetElement.querySelectorAll("slot"));
                if (!slots || slots.length === 0)
                  return [
                    2
                    /*return*/
                  ];
                slotWithoutName = slots.find(function(slot) {
                  return !slot.getAttribute("name");
                });
                childrens.forEach(function(element) {
                  var _a3, _b;
                  var elementSlotName = element.getAttribute("slot");
                  if (elementSlotName) {
                    var slotByName = slots.find(function(slot) {
                      return slot.getAttribute("name") === elementSlotName;
                    });
                    if (slotByName)
                      (_a3 = slotByName.parentNode) === null || _a3 === void 0 ? void 0 : _a3.insertBefore(element, slotByName);
                  } else if (slotWithoutName) {
                    (_b = slotWithoutName.parentNode) === null || _b === void 0 ? void 0 : _b.insertBefore(element, slotWithoutName);
                  }
                });
                slots.forEach(function(sl) {
                  return sl.remove();
                });
                return [
                  2
                  /*return*/
                ];
              });
            });
          });
          return [
            2
            /*return*/
          ];
        });
      });
    };
    IcaLitElementBase2.prototype.setInitialConfigs = function() {
      return __awaiter(this, void 0, void 0, function() {
        var fileName;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (!this.widget) return [3, 2];
              fileName = convertTagToFileName(this.widget);
              return [4, import("./" + fileName)];
            case 1:
              _a.sent();
              _a.label = 2;
            case 2:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    IcaLitElementBase2.prototype.render = function() {
      this.style.display = "block";
      var attrs = this.getAttributes();
      var code = "\n            <".concat(this.widget, " ").concat(attrs, ">\n            </").concat(this.widget, ">\n        ");
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["", ""], ["", ""])), unsafeHTML(code));
    };
    IcaLitElementBase2.prototype.getAttributes = function() {
      var excludesProps = ["rendertype", "level", "widget"];
      var attributes = "";
      var attributeNames = this.getAttributeNames();
      for (var _i = 0, attributeNames_1 = attributeNames; _i < attributeNames_1.length; _i++) {
        var attrName = attributeNames_1[_i];
        if (excludesProps.includes(attrName))
          continue;
        var attrValue = this.getAttribute(attrName);
        if (attrName === "style")
          attrValue = this.styleel || null;
        if (attrValue !== null) {
          attributes += "".concat(attrName, '="').concat(attrValue, '" ');
        }
      }
      return attributes;
    };
    __decorate([
      property({ type: String }),
      collabState(states.CHANGESTATE),
      __metadata("design:type", String)
    ], IcaLitElementBase2.prototype, "changeState", void 0);
    __decorate([
      property({ type: String, reflect: true }),
      __metadata("design:type", String)
    ], IcaLitElementBase2.prototype, "widget", void 0);
    __decorate([
      property({ type: Boolean, reflect: true }),
      __metadata("design:type", Boolean)
    ], IcaLitElementBase2.prototype, "isICAGroup", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], IcaLitElementBase2.prototype, "renderType", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], IcaLitElementBase2.prototype, "level", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], IcaLitElementBase2.prototype, "styleel", void 0);
    return IcaLitElementBase2;
  }(IcaLitElement)
);
var templateObject_1;
export {
  IcaLitElementBase
};
