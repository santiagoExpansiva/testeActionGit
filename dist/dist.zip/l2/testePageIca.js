var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, LitElement } from "lit";
import { customElement } from "lit/decorators.js";
var IcaTestPage100554 = (
  /** @class */
  function(_super) {
    __extends(IcaTestPage1005542, _super);
    function IcaTestPage1005542() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    IcaTestPage1005542.prototype.render = function() {
      window.globalState = {
        tables: {
          sex: [{ key: "m", value: "masculino" }, { key: "f", value: "feminino" }]
        },
        users: [
          {
            name: "Wagner",
            age: 63,
            city: "SP",
            sex: "m"
          },
          {
            name: "Guilherme",
            age: 28,
            city: "SP",
            sex: "m"
          }
        ]
      };
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject([""], [""])));
    };
    IcaTestPage1005542.styles = css(templateObject_2 || (templateObject_2 = __makeTemplateObject([":host {\n        display: flex;\n    }"], [":host {\n        display: flex;\n    }"])));
    IcaTestPage1005542 = __decorate([
      customElement("teste-page-ica-100554")
    ], IcaTestPage1005542);
    return IcaTestPage1005542;
  }(LitElement)
);
var templateObject_1, templateObject_2;
export {
  IcaTestPage100554
};
