var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html } from "lit";
import { customElement, query } from "lit/decorators.js";
import { AimTaskBase } from "./_100554_aimTaskBase";
import { initCollabShowCodeSnippet100554, CollabShowCodeSnippet100554 } from "./_100554_collabShowCodeSnippet";
import { initCollabShowCodeDiff100554, CollabShowCodeDiff } from "./_100554_collabShowCodeDiff";
import { getInfoMyService } from "./_100554_aimHelper";
var AimTaskResultCode = (
  /** @class */
  function(_super) {
    __extends(AimTaskResultCode2, _super);
    function AimTaskResultCode2() {
      var _this = _super.call(this) || this;
      _this.result = "";
      initCollabShowCodeSnippet100554();
      initCollabShowCodeDiff100554();
      return _this;
    }
    AimTaskResultCode2.prototype.onInitializing = function() {
      this.notifyCompleteByStatus("ok", "");
    };
    AimTaskResultCode2.prototype.renderBody = function(taskRoot, child) {
      var title = child.title;
      var body = child._tempResult || "";
      this.result = this.extractScript(body);
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n        <details open>\n            <summary>", `- Code</summary>
            <div style='margin: 10px'>
                <collab-show-code-snippet-100554 withAccept="true" .onAccept=`, ">\n                </collab-show-code-snippet-100554>\n            </div> \n        </details>\n        "], ["\n        <details open>\n            <summary>", `- Code</summary>
            <div style='margin: 10px'>
                <collab-show-code-snippet-100554 withAccept="true" .onAccept=`, ">\n                </collab-show-code-snippet-100554>\n            </div> \n        </details>\n        "])), title, this.onAccept.bind(this));
    };
    AimTaskResultCode2.prototype.onAccept = function() {
      var info = getInfoMyService(this);
      if (!info || !info.actServiceOp)
        return;
      if (info.actServiceOp.tagName !== "SERVICE-SOURCE-100554")
        return;
      info.actServiceOp.setEditorValue(this.result);
    };
    AimTaskResultCode2.prototype.extractScript = function(src) {
      var regex = /```typescript([\s\S]+?)```/g;
      var matches = src.match(regex);
      var contents = [];
      var ret = src;
      if (matches) {
        for (var _i = 0, matches_1 = matches; _i < matches_1.length; _i++) {
          var m = matches_1[_i];
          var conteudo = m.replace(/```typescript|```/g, "").trim();
          contents.push(conteudo);
        }
        ret = contents[0];
      }
      return ret;
    };
    AimTaskResultCode2.prototype.firstUpdated = function(a) {
      _super.prototype.firstUpdated.call(this, a);
      if (this.codeSnippet)
        this.codeSnippet.textIn = this.result;
    };
    var _a, _b;
    __decorate([
      query("collab-show-code-snippet-100554"),
      __metadata("design:type", typeof (_a = typeof CollabShowCodeSnippet100554 !== "undefined" && CollabShowCodeSnippet100554) === "function" ? _a : Object)
    ], AimTaskResultCode2.prototype, "codeSnippet", void 0);
    __decorate([
      query("collab-show-code-diff-100554"),
      __metadata("design:type", typeof (_b = typeof CollabShowCodeDiff !== "undefined" && CollabShowCodeDiff) === "function" ? _b : Object)
    ], AimTaskResultCode2.prototype, "codeDif", void 0);
    AimTaskResultCode2 = __decorate([
      customElement("aim-task-result-code-100554"),
      __metadata("design:paramtypes", [])
    ], AimTaskResultCode2);
    return AimTaskResultCode2;
  }(AimTaskBase)
);
var templateObject_1;
export {
  AimTaskResultCode
};
