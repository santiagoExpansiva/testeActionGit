var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css, repeat } from "lit";
import { customElement, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
var message_pt = {};
var message_en = {};
var messages = {
  "en": message_en,
  "pt": message_pt
};
var ServiceDsStyleClippath = (
  /** @class */
  function(_super) {
    __extends(ServiceDsStyleClippath2, _super);
    function ServiceDsStyleClippath2() {
      var _this = _super.call(this) || this;
      _this.msg = messages["en"];
      _this.error = "";
      _this.helper = "_100554_serviceDsStyleClippath";
      _this.details = {
        icon: "&#xf0c4",
        state: "foreground",
        position: "right",
        tooltip: "ClipPath",
        visible: false,
        tags: ["ds_styles"],
        widget: "_100554_serviceDsStyleClippath",
        level: [3]
      };
      _this.onClickLink = function(op) {
        if (_this.menu.setMode)
          _this.menu.setMode("initial");
        return false;
      };
      _this.onClickIcon = function(op) {
      };
      _this.menu = {
        title: "ClipPath",
        actions: {},
        icons: {},
        actionDefault: "",
        // call after close icon clicked
        iconDefault: "",
        setMode: void 0,
        // child will set this
        onClickLink: _this.onClickLink,
        onClickIcon: _this.onClickIcon
      };
      _this.arrayGallery = [
        { css: "", name: "none" },
        { css: "clip-path: polygon(50% 0%, 0% 100%, 100% 100%);", name: "triangle" },
        { css: "clip-path: polygon(20% 0%, 80% 0%, 100% 100%, 0% 100%)", name: "trapezoid" },
        { css: "clip-path: polygon(25% 0%, 100% 0%, 75% 100%, 0% 100%)", name: "parallelogram" },
        { css: "clip-path: polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)", name: "rhombus" },
        { css: "clip-path: polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%)", name: "pentagon" },
        { css: "clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)", name: "hexagon" },
        { css: "clip-path: polygon(50% 0%, 90% 20%, 100% 60%, 75% 100%, 25% 100%, 0% 60%, 10% 20%)", name: "heptagon" },
        { css: "clip-path: polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%)", name: "octagon" },
        { css: "clip-path: polygon(50% 0%, 83% 12%, 100% 43%, 94% 78%, 68% 100%, 32% 100%, 6% 78%, 0% 43%, 17% 12%)", name: "nonagon" },
        { css: "clip-path: polygon(50% 0%, 80% 10%, 100% 35%, 100% 70%, 80% 90%, 50% 100%, 20% 90%, 0% 70%, 0% 35%, 20% 10%)", name: "decagon" },
        { css: "clip-path: polygon(20% 0%, 80% 0%, 100% 20%, 100% 80%, 80% 100%, 20% 100%, 0% 80%, 0% 20%)", name: "bevel" },
        { css: "clip-path: polygon(0% 15%, 15% 15%, 15% 0%, 85% 0%, 85% 15%, 100% 15%, 100% 85%, 85% 85%, 85% 100%, 15% 100%, 15% 85%, 0% 85%)", name: "rabbet" },
        { css: "clip-path: polygon(40% 0%, 40% 20%, 100% 20%, 100% 80%, 40% 80%, 40% 100%, 0% 50%)", name: "left-arrow" },
        { css: "clip-path: polygon(0% 20%, 60% 20%, 60% 0%, 100% 50%, 60% 100%, 60% 80%, 0% 80%)", name: "right-arrow" },
        { css: "clip-path: polygon(25% 0%, 100% 1%, 100% 100%, 25% 100%, 0% 50%)", name: "left-poin" },
        { css: "clip-path: polygon(0% 0%, 75% 0%, 100% 50%, 75% 100%, 0% 100%)", name: "right-point" },
        { css: "clip-path: polygon(100% 0%, 75% 50%, 100% 100%, 25% 100%, 0% 50%, 25% 0%)", name: "left-chevron" },
        { css: "clip-path: polygon(75% 0%, 100% 50%, 75% 100%, 0% 100%, 25% 50%, 0% 0%)", name: "right-chevron" },
        { css: "clip-path: polygon(50% 0%, 61% 35%, 98% 35%, 68% 57%, 79% 91%, 50% 70%, 21% 91%, 32% 57%, 2% 35%, 39% 35%)", name: "star" },
        { css: "clip-path: polygon(10% 25%, 35% 25%, 35% 0%, 65% 0%, 65% 25%, 90% 25%, 90% 50%, 65% 50%, 65% 100%, 35% 100%, 35% 50%, 10% 50%)", name: "cross" },
        { css: "clip-path: polygon(0% 0%, 100% 0%, 100% 75%, 75% 75%, 75% 100%, 50% 75%, 0% 75%)", name: "message" },
        { css: "clip-path: polygon(0% 0%, 0% 100%, 25% 100%, 25% 25%, 75% 25%, 75% 75%, 25% 75%, 25% 100%, 100% 100%, 100% 0%)", name: "frame" },
        { css: "clip-path: polygon(20% 0%, 0% 20%, 30% 50%, 0% 80%, 20% 100%, 50% 70%, 80% 100%, 100% 80%, 70% 50%, 100% 20%, 80% 0%, 50% 30%)", name: "close" },
        { css: "clip-path: circle(40% at 50% 50%)", name: "circle" },
        { css: "clip-path: ellipse(25% 40% at 50% 50%)", name: "ellipse" }
      ];
      _this.timeLoader = -1;
      _this.setEvents();
      return _this;
    }
    ServiceDsStyleClippath2.prototype.onServiceClick = function(visible, reinit) {
      if (visible) {
      }
    };
    ServiceDsStyleClippath2.prototype.setEvents = function() {
      var _this = this;
      mls.events.addEventListener([3], ["DSStyleSelected"], function(ev) {
        _this.onDSStyleSelected(ev);
      });
      mls.events.addEventListener([3], ["DSStyleUnSelected"], function(ev) {
        _this.onDSStyleUnSelected(ev);
      });
      mls.events.addEventListener([3], ["DSStyleCursorChanged"], function(ev) {
        _this.onDSStyleCursorChanged(ev);
      });
    };
    ServiceDsStyleClippath2.prototype.onDSStyleSelected = function(ev) {
      var params = ev.desc ? JSON.parse(ev.desc) : [];
      if (params.service.length > 0 && !params.service.includes(this.helper) || !this.serviceItemNav)
        return;
      this.serviceItemNav.setAttribute("mode", "A");
      this.showNav2Item(true);
    };
    ServiceDsStyleClippath2.prototype.onDSStyleUnSelected = function(ev) {
      var params = ev.desc ? JSON.parse(ev.desc) : [];
      if (params.service.includes(this.helper) || !this.serviceItemNav)
        return;
      this.serviceItemNav.setAttribute("mode", "H");
      this.showNav2Item(false);
    };
    ServiceDsStyleClippath2.prototype.onDSStyleCursorChanged = function(ev) {
      var rc = JSON.parse(ev.desc);
      if (rc.helper === this.helper) {
        if (this.visible === "true" || !this.serviceItemNav)
          return;
        this.serviceItemNav.click();
      }
    };
    ServiceDsStyleClippath2.prototype.connectedCallback = function() {
      _super.prototype.connectedCallback.call(this);
    };
    ServiceDsStyleClippath2.prototype.render = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["", ""], ["", ""])), this.renderGallery());
    };
    ServiceDsStyleClippath2.prototype.renderGallery = function() {
      var _this = this;
      return html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['\n            <div style="display: flex; justify-content: center; align-items: center; gap: 1rem; padding: 1rem; flex-wrap: wrap; cursor:pointer">\n                ', "\n            </div>\n        \n        "], ['\n            <div style="display: flex; justify-content: center; align-items: center; gap: 1rem; padding: 1rem; flex-wrap: wrap; cursor:pointer">\n                ', "\n            </div>\n        \n        "])), repeat(this.arrayGallery, function(key) {
        return key;
      }, function(css2, index) {
        return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(['\n                            <div @click="', '" style="display: flex; justify-content: center; align-items: center;flex-direction:column; width:120px;margin-top:1rem" .gallery=', '>\n                                <div style="background:black; width:60px;height:80px;', '" .gallery=', "></div>\n                                <div .gallery=", ">", "</div>\n                            </div>\n                        "], ['\n                            <div @click="', '" style="display: flex; justify-content: center; align-items: center;flex-direction:column; width:120px;margin-top:1rem" .gallery=', '>\n                                <div style="background:black; width:60px;height:80px;', '" .gallery=', "></div>\n                                <div .gallery=", ">", "</div>\n                            </div>\n                        "])), _this.clickGallery, css2.css, css2.css, css2.css, css2.css, css2.name);
      }));
    };
    ServiceDsStyleClippath2.prototype.clickGallery = function(e) {
      var el = e.target;
      if (!el)
        return;
      var css2 = el.gallery;
      if (!css2 && css2 !== "")
        return;
      var commands = css2.split(";");
      var changes = [];
      commands.forEach(function(item) {
        var _a = item.split(":"), key = _a[0], value = _a[1];
        if (!key)
          return;
        changes.push({
          key: key.trim(),
          value: value.trim()
        });
      });
      if (changes.length === 0)
        changes.push({ key: "clip-path", value: "" });
      var rc = {
        emitter: "right",
        value: changes,
        helper: this.helper
      };
      mls.events.fire([3], ["DSStyleChanged"], JSON.stringify(rc));
    };
    ServiceDsStyleClippath2.prototype.showLoader = function(loader) {
      var _this = this;
      clearTimeout(this.timeLoader);
      this.timeLoader = setTimeout(function() {
        _this.loading = loader;
      }, 200);
    };
    ServiceDsStyleClippath2.styles = css(templateObject_4 || (templateObject_4 = __makeTemplateObject(["[[mls_getDefaultDesignSystem]]"], ["[[mls_getDefaultDesignSystem]]"])));
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceDsStyleClippath2.prototype, "error", void 0);
    __decorate([
      property(),
      __metadata("design:type", String)
    ], ServiceDsStyleClippath2.prototype, "helper", void 0);
    ServiceDsStyleClippath2 = __decorate([
      customElement("service-ds-style-clippath-100554"),
      __metadata("design:paramtypes", [])
    ], ServiceDsStyleClippath2);
    return ServiceDsStyleClippath2;
  }(ServiceBase)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4;
export {
  ServiceDsStyleClippath
};
