var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { html, css, LitElement } from "lit";
import { customElement, property } from "lit/decorators.js";
import { getDescriptionsRootGroup, getDescriptionsFinalGroup, getDescriptionsSubGroup, getFormComponentsDescription } from "./_100554_icaBaseDescription";
function initIcaSelectGroup() {
  return true;
}
var IcaSelectGroup = (
  /** @class */
  function(_super) {
    __extends(IcaSelectGroup2, _super);
    function IcaSelectGroup2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.rootBread = "";
      _this.actualGroups = [];
      _this.actualBreadCrumb = [];
      _this.actualMode = "root";
      _this.messages = {
        "selectICA": "Select ICA"
      };
      return _this;
    }
    IcaSelectGroup2.prototype.connectedCallback = function() {
      _super.prototype.connectedCallback.call(this);
      this.rootBread = this.messages.selectICA;
      this.actualBreadCrumb = [this.rootBread];
    };
    IcaSelectGroup2.prototype._handleInternalAction = function() {
      var customEvent = new CustomEvent("selection-changed", {
        bubbles: true,
        composed: true,
        detail: {
          selection: this.actualBreadCrumb.slice(1, this.actualBreadCrumb.length)
        }
      });
      this.dispatchEvent(customEvent);
    };
    IcaSelectGroup2.prototype.clear = function() {
      this.actualGroups = [];
      this.actualBreadCrumb = [this.rootBread = this.messages.selectICA];
      this.actualMode = "root";
    };
    IcaSelectGroup2.prototype.render = function() {
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject([" \n            ", "\n            ", "        \n        "], [" \n            ", "\n            ", "        \n        "])), this.renderBreadCrumb(), this.renderGroups());
    };
    IcaSelectGroup2.prototype.renderGroups = function() {
      switch (this.actualMode) {
        case "root":
          return this.renderGroupsRoot();
        case "subgroup":
          return this.renderSubGroups();
        case "finalgroup":
          return this.renderFinalGruops();
        default:
          return html(templateObject_2 || (templateObject_2 = __makeTemplateObject([""], [""])));
      }
    };
    IcaSelectGroup2.prototype.renderBreadCrumb = function() {
      var _this = this;
      return html(templateObject_6 || (templateObject_6 = __makeTemplateObject(['\n            <div class="breadcrumb">\n                ', "\n            </div>\n        "], ['\n            <div class="breadcrumb">\n                ', "\n            </div>\n        "])), this.actualBreadCrumb.map(function(breadItem, index) {
        var isLast = index === _this.actualBreadCrumb.length - 1;
        return html(templateObject_5 || (templateObject_5 = __makeTemplateObject(["\n            ", "\n            "], ["\n            ", "\n            "])), isLast ? html(templateObject_3 || (templateObject_3 = __makeTemplateObject(["\n                    <span @click=", ">\n                        ", "", "\n                    </span>"], ["\n                    <span @click=", ">\n                        ", "", "\n                    </span>"])), function(e) {
          return _this.onBreadClick(breadItem, e);
        }, breadItem, !isLast ? " > " : "") : html(templateObject_4 || (templateObject_4 = __makeTemplateObject(['\n                    <a href="#" @click=', ">\n                        ", "", "\n                    </a>"], ['\n                    <a href="#" @click=', ">\n                        ", "", "\n                    </a>"])), function(e) {
          return _this.onBreadClick(breadItem, e);
        }, breadItem, !isLast ? " > " : ""));
      }));
    };
    IcaSelectGroup2.prototype.renderGroupsRoot = function() {
      var _this = this;
      var groups = getDescriptionsRootGroup();
      return html(templateObject_8 || (templateObject_8 = __makeTemplateObject(['\n        <div class="group-container">\n            ', "\n        </div>\n        "], ['\n        <div class="group-container">\n            ', "\n        </div>\n        "])), groups.map(function(group) {
        var desc = getFormComponentsDescription(group, null, null);
        return html(templateObject_7 || (templateObject_7 = __makeTemplateObject(['\n            <div class="group-item" @click=', '>\n                <span class="group-title">', '</span>\n                <span class="group-desc">', "</span>\n            </div>\n        "], ['\n            <div class="group-item" @click=', '>\n                <span class="group-title">', '</span>\n                <span class="group-desc">', "</span>\n            </div>\n        "])), function() {
          _this.onClickRootGroup(group);
        }, group, desc);
      }));
    };
    IcaSelectGroup2.prototype.renderSubGroups = function() {
      var _this = this;
      var _a = this.actualBreadCrumb, rootSelected = _a[1];
      var groups = getDescriptionsSubGroup(rootSelected);
      return html(templateObject_10 || (templateObject_10 = __makeTemplateObject(['\n        <div class="group-container">\n            ', "\n        </div>\n        "], ['\n        <div class="group-container">\n            ', "\n        </div>\n        "])), groups.map(function(subGroup) {
        var desc = getFormComponentsDescription(rootSelected, subGroup, null);
        return html(templateObject_9 || (templateObject_9 = __makeTemplateObject(['\n            <div class="group-item" @click=', '>\n                <span class="group-title">', '</span>\n                <span class="group-desc">', "</span>\n            </div>\n        "], ['\n            <div class="group-item" @click=', '>\n                <span class="group-title">', '</span>\n                <span class="group-desc">', "</span>\n            </div>\n        "])), function() {
          _this.onClickSubGroup(rootSelected, subGroup);
        }, subGroup, desc);
      }));
    };
    IcaSelectGroup2.prototype.renderFinalGruops = function() {
      var _this = this;
      var _a = this.actualBreadCrumb, rootSelected = _a[1], subGroupSelected = _a[2];
      var groups = getDescriptionsFinalGroup(rootSelected, subGroupSelected);
      return html(templateObject_12 || (templateObject_12 = __makeTemplateObject(['\n        <div class="group-container">\n            ', "\n        </div>\n        "], ['\n        <div class="group-container">\n            ', "\n        </div>\n        "])), groups.map(function(finalGroup) {
        var desc = getFormComponentsDescription(rootSelected, subGroupSelected, finalGroup);
        return html(templateObject_11 || (templateObject_11 = __makeTemplateObject(['\n                <div class="group-item" @click=', '>\n                    <span class="group-title">', '</span>\n                    <span class="group-desc">', "</span>\n                </div>\n            "], ['\n                <div class="group-item" @click=', '>\n                    <span class="group-title">', '</span>\n                    <span class="group-desc">', "</span>\n                </div>\n            "])), function() {
          _this.onClickFinalGroup(rootSelected, subGroupSelected, finalGroup);
        }, finalGroup, desc);
      }));
    };
    IcaSelectGroup2.prototype.onClickRootGroup = function(rootGroup) {
      this.actualBreadCrumb = [this.rootBread, rootGroup];
      this.actualMode = "subgroup";
      this.requestUpdate();
      this._handleInternalAction();
    };
    IcaSelectGroup2.prototype.onClickSubGroup = function(rootGroup, subGroup) {
      this.actualBreadCrumb = [this.rootBread, rootGroup, subGroup];
      this.actualMode = "finalgroup";
      this.requestUpdate();
      this._handleInternalAction();
    };
    IcaSelectGroup2.prototype.onClickFinalGroup = function(rootGroup, subGroup, finalGroup) {
      this.actualBreadCrumb = [this.rootBread, rootGroup, subGroup, finalGroup];
      this.actualMode = "empty";
      this.requestUpdate();
      this._handleInternalAction();
    };
    IcaSelectGroup2.prototype.onBreadClick = function(breadItem, e) {
      e.preventDefault();
      var index = this.actualBreadCrumb.findIndex(function(item) {
        return item === breadItem;
      });
      if (index < 0)
        throw new Error("Invalid breadcrumb item");
      this.actualBreadCrumb = this.actualBreadCrumb.slice(0, index + 1);
      if (index === 0)
        this.actualMode = "root";
      if (index === 1)
        this.actualMode = "subgroup";
      if (index === 2)
        this.actualMode = "finalgroup";
      this.requestUpdate();
      this._handleInternalAction();
    };
    IcaSelectGroup2.styles = css(templateObject_13 || (templateObject_13 = __makeTemplateObject(["\n        :host{\n            font-size: 16px;\n        }\n        .group-container{\n            display: grid;\n            grid-template-columns: repeat(auto-fill, minmax(20em, 1fr));\n            grid-template-rows: max-content;\n            gap: 1em;\n            padding: 1em;\n        }\n        .group-item {\n            cursor: pointer;\n            width: 20em;\n            background-color: rgb(243, 229, 245);\n            box-shadow: rgba(55, 27, 61, 0.18) 7px 7px 2px 0px;\n            display: flex;\n            justify-content: center;\n            align-items: center;\n            flex-direction: column;\n            border-radius: 4px;\n            padding: 1rem;\n        }\n        .group-title{\n            font-weight:bold;\n            text-transform: uppercase;\n        }\n        .group-desc{\n            margin-top: .3rem;\n        }\n        .breadcrumb {\n            padding: 1em;\n        }\n        .breadcrumb a{\n            text-decoration:none;\n        }\n        .breadcrumb a:visited {\n            color: #1890FF;\n            text-decoration: inherit;\n        }\n    "], ["\n        :host{\n            font-size: 16px;\n        }\n        .group-container{\n            display: grid;\n            grid-template-columns: repeat(auto-fill, minmax(20em, 1fr));\n            grid-template-rows: max-content;\n            gap: 1em;\n            padding: 1em;\n        }\n        .group-item {\n            cursor: pointer;\n            width: 20em;\n            background-color: rgb(243, 229, 245);\n            box-shadow: rgba(55, 27, 61, 0.18) 7px 7px 2px 0px;\n            display: flex;\n            justify-content: center;\n            align-items: center;\n            flex-direction: column;\n            border-radius: 4px;\n            padding: 1rem;\n        }\n        .group-title{\n            font-weight:bold;\n            text-transform: uppercase;\n        }\n        .group-desc{\n            margin-top: .3rem;\n        }\n        .breadcrumb {\n            padding: 1em;\n        }\n        .breadcrumb a{\n            text-decoration:none;\n        }\n        .breadcrumb a:visited {\n            color: #1890FF;\n            text-decoration: inherit;\n        }\n    "])));
    __decorate([
      property({ type: Array }),
      __metadata("design:type", Array)
    ], IcaSelectGroup2.prototype, "actualGroups", void 0);
    __decorate([
      property({ type: Array }),
      __metadata("design:type", Array)
    ], IcaSelectGroup2.prototype, "actualBreadCrumb", void 0);
    __decorate([
      property({ type: String }),
      __metadata("design:type", String)
    ], IcaSelectGroup2.prototype, "actualMode", void 0);
    IcaSelectGroup2 = __decorate([
      customElement("ica-select-group-100554")
    ], IcaSelectGroup2);
    return IcaSelectGroup2;
  }(LitElement)
);
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6, templateObject_7, templateObject_8, templateObject_9, templateObject_10, templateObject_11, templateObject_12, templateObject_13;
export {
  IcaSelectGroup,
  initIcaSelectGroup
};
