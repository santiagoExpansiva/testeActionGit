var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { html, unsafeHTML } from "lit";
import { customElement } from "lit/decorators.js";
import { convertFileNameToTag } from "./_100554_utilsLit";
import { AimBase } from "./_100554_aimBase";
import { tasks, getUserConfigs } from "./_100554_aimHelper";
var AimActionBase = (
  /** @class */
  function(_super) {
    __extends(AimActionBase2, _super);
    function AimActionBase2() {
      var _this = _super.call(this) || this;
      _this.childThis = void 0;
      _this.addTaskAndWaitForCompletion = function(taskRoot, child) {
        if (taskRoot.mode === "error" || child.mode === "error")
          return;
        _this.prepareNextStep(child);
        taskRoot.children.push(child);
        tasks[_this.taskIndex] = taskRoot;
      };
      _this.prepareNextStep = function(child) {
        if (!child.nextStep)
          throw new Error("please define nextStep");
        var nextStep = _this[child.nextStep];
        if (typeof nextStep !== "function")
          throw new Error("nextStep must be a function");
        verifyCyclicLoop(child.nextStep);
        _this.childThis = _this;
      };
      _this.addEventListener("task-finished", _this.onTaskFinishedEvent);
      return _this;
    }
    AimActionBase2.prototype.render = function() {
      if (this.mode === "add")
        return this.renderAdd();
      return this.renderTaskRoot();
    };
    AimActionBase2.prototype.onTaskFinishedEvent = function(e) {
      var _a, _b;
      if (!e.detail || e.detail.childIndex < 0 || !e.detail.status)
        throw new Error('invalid task-finished event, childIndex="' + ((_a = e.detail) === null || _a === void 0 ? void 0 : _a.childIndex) + '", status="' + ((_b = e.detail) === null || _b === void 0 ? void 0 : _b.status) + '"');
      var st = e.detail.status;
      if (st !== "ok" && st !== "error" && st !== "rejected" && st !== "userEvent")
        throw new Error("invalid task-finished event, status=" + st);
      var status = st;
      var childIndex = e.detail.childIndex;
      var newPrompt = e.detail.newPrompt;
      if (typeof childIndex !== "number")
        throw new Error("invalid task-finished event, childIndex=" + childIndex);
      var result = e.detail.result;
      if (typeof result !== "string")
        throw new Error("invalid task-finished event, result=" + result);
      if (this.taskIndex < 0 || this.taskIndex >= tasks.length)
        throw new Error("invalid task-finished event, taskIndex=" + this.taskIndex + ", tasks length=" + tasks.length);
      var taskRoot = tasks[this.taskIndex];
      if (childIndex < 0 || childIndex >= taskRoot.children.length)
        throw new Error("invalid task-finished event, childIndex=" + childIndex + ", children length=" + taskRoot.children.length);
      var taskChild = taskRoot.children[childIndex];
      var taskFinishResult = { status, taskIndex: this.taskIndex, childIndex, result, taskRoot, taskChild, newPrompt };
      if (taskChild.mode === "initializing")
        taskChild.mode = "in progress";
      if (!this.childThis)
        throw new Error("invalid finished event, actionBase is not waiting for this event");
      var oriChildThis = this.childThis;
      this.childThis = null;
      if (!taskChild.nextStep)
        throw new Error("please define nextStep");
      var nextStep = oriChildThis[taskChild.nextStep];
      if (typeof nextStep !== "function")
        throw new Error("nextStep must be a function");
      nextStep.call(oriChildThis, taskFinishResult);
      oriChildThis.requestUpdate();
    };
    AimActionBase2.prototype.getPromptUser = function(task) {
      var ret = "";
      if (task.children.length <= 0)
        return ret;
      var child = task.children.find(function(i) {
        return i.widget === "_100554_aimTaskExecLLM";
      });
      if (!child || !child.prompt)
        return ret;
      var regex = new RegExp("User:(.*?)(?=\\n\\n\\n|$)", "s");
      var match = child.prompt.match(regex);
      if (match && match.length > 0) {
        ret = match[1].trim();
      }
      return ret;
    };
    AimActionBase2.prototype.getRef = function(taskRoot) {
      var ref = "";
      for (var _i = 0, _a = taskRoot.children; _i < _a.length; _i++) {
        var task = _a[_i];
        if (task.ref) {
          ref = task.ref;
          break;
        }
      }
      return ref;
    };
    AimActionBase2.prototype.getLastUpdateDate = function(taskRoot) {
      var _this = this;
      var lastDate;
      taskRoot.children.forEach(function(task) {
        task.trace.forEach(function(trace) {
          var dt = _this.getLocateDateTimeInTrace(trace);
          if (dt && !lastDate)
            lastDate = dt;
          else if (dt && lastDate && dt > lastDate)
            lastDate = dt;
        });
      });
      return lastDate ? lastDate.toLocaleString() : "";
    };
    AimActionBase2.prototype.getLocateDateTimeInTrace = function(line) {
      var _a = line.split("Z:"), isoDatePart = _a[0], descriptionParts = _a.slice(1);
      try {
        var date = new Date("".concat(isoDatePart, "Z"));
        if (isNaN(date.getTime()))
          return void 0;
        return date;
      } catch (error) {
        console.error(isoDatePart, error);
      }
    };
    AimActionBase2.prototype.renderTaskRoot = function() {
      var _this = this;
      var _a;
      var renderChild = function(child, index2) {
        _this.loadDynamicWidget(taskRoot, child, child.widget);
        if (child.mode !== "processed" && child.mode !== "error" && child.nextStep)
          _this.prepareNextStep(child);
        var taskName = convertFileNameToTag(child.widget);
        var sHtml = "<".concat(taskName, ' mode="').concat(child.mode, '" taskindex="').concat(_this.taskIndex, '" childindex="').concat(index2, '" />');
        return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["", ""], ["", ""])), unsafeHTML(sHtml));
      };
      if (this.taskIndex < 0 || this.taskIndex >= tasks.length)
        return html(templateObject_2 || (templateObject_2 = __makeTemplateObject(["invalid task index"], ["invalid task index"])));
      var taskRoot = tasks[this.taskIndex];
      var index = Number((_a = taskRoot.key) === null || _a === void 0 ? void 0 : _a.split("/").pop()) || 0;
      var cost = taskRoot.cost || 0;
      var promptUser = this.getPromptUser(taskRoot);
      var ref = this.getRef(taskRoot);
      var lastUpdateDate = this.getLastUpdateDate(taskRoot);
      var configs = getUserConfigs();
      return html(templateObject_11 || (templateObject_11 = __makeTemplateObject(['\n            <details>\n                <summary>\n                    <div class="action-title">\n                        ', " \n                        ", "\n                        ", "\n                        ", "\n                        ", "\n                        ", "\n                        ", "\n                        ", "\n                        ", "                                         \n                    </div>\n\n                    \n                </summary>\n                ", "\n            </details>\n        "], ['\n            <details>\n                <summary>\n                    <div class="action-title">\n                        ', " \n                        ", "\n                        ", "\n                        ", "\n                        ", "\n                        ", "\n                        ", "\n                        ", "\n                        ", "                                         \n                    </div>\n\n                    \n                </summary>\n                ", "\n            </details>\n        "])), this.renderToolbar(), configs.cost ? html(templateObject_3 || (templateObject_3 = __makeTemplateObject(['<span title="Cost" class="ac ac-cost"> ', " ", "</span>"], ['<span title="Cost" class="ac ac-cost"> ', " ", "</span>"])), this.iconMoney, cost.toFixed(4)) : "", configs.sequencial ? html(templateObject_4 || (templateObject_4 = __makeTemplateObject(['<span title="Sequential" class="ac ac-id">', "</span>"], ['<span title="Sequential" class="ac ac-id">', "</span>"])), index.toString().padStart(5, "0")) : "", configs.countChild ? html(templateObject_5 || (templateObject_5 = __makeTemplateObject(['    <span title="Count Child" class="ac ac-count">', " ", "</span>"], ['    <span title="Count Child" class="ac ac-count">', " ", "</span>"])), this.iconHash, taskRoot.children.length) : "", configs.title ? html(templateObject_6 || (templateObject_6 = __makeTemplateObject(['    <span title="Title" class="ac ac-title">', "</span>"], ['    <span title="Title" class="ac ac-title">', "</span>"])), this.title) : "", configs.prompt ? html(templateObject_7 || (templateObject_7 = __makeTemplateObject(['    <span title="Prompt" class="ac ac-prompt"> ', " ", "</span>"], ['    <span title="Prompt" class="ac ac-prompt"> ', " ", "</span>"])), this.iconPrompt, promptUser || "...") : "", configs.user ? html(templateObject_8 || (templateObject_8 = __makeTemplateObject(['<span title="User" class="ac ac-user"> ', " ", " </span>"], ['<span title="User" class="ac ac-user"> ', " ", " </span>"])), this.iconUser, taskRoot.userName) : "", configs.reference ? html(templateObject_9 || (templateObject_9 = __makeTemplateObject(['<span title="Reference" class="ac ac-ref"> ', " ", " </span>     "], ['<span title="Reference" class="ac ac-ref"> ', " ", " </span>     "])), this.iconRef, ref) : "", configs.lastUpdateDate ? html(templateObject_10 || (templateObject_10 = __makeTemplateObject(['<span title="Last update date " class="ac ac-date"> ', "  ", " </span>"], ['<span title="Last update date " class="ac ac-date"> ', "  ", " </span>"])), this.iconDate, lastUpdateDate) : "", taskRoot.children.map(function(child, index2) {
        return renderChild(child, index2);
      }));
    };
    AimActionBase2.prototype.loadDynamicWidget = function(taskRoot, child, widget) {
      return __awaiter(this, void 0, Promise, function() {
        var tryLoad;
        var _this = this;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              tryLoad = function() {
                return __awaiter(_this, void 0, Promise, function() {
                  var componentModule, error_1;
                  return __generator(this, function(_a2) {
                    switch (_a2.label) {
                      case 0:
                        if (!widget)
                          return [2, false];
                        _a2.label = 1;
                      case 1:
                        _a2.trys.push([1, 3, , 4]);
                        return [4, import("./" + widget)];
                      case 2:
                        componentModule = _a2.sent();
                        if (!componentModule)
                          return [2, false];
                        return [3, 4];
                      case 3:
                        error_1 = _a2.sent();
                        return [2, false];
                      case 4:
                        return [2, true];
                    }
                  });
                });
              };
              return [4, tryLoad()];
            case 1:
              if (_a.sent() === false) {
                child.trace.push("Error on load widget ".concat(widget));
                taskRoot.mode = child.mode = "error";
              }
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    AimActionBase2 = __decorate([
      customElement("aim-action-base-100554"),
      __metadata("design:paramtypes", [])
    ], AimActionBase2);
    return AimActionBase2;
  }(AimBase)
);
function verifyCyclicLoop(functionName) {
  try {
    throw new Error("Simulated error for stack trace");
  } catch (error) {
    if (error instanceof Error && error.stack) {
      var stackLines = error.stack.split("\n").map(function(line) {
        return line.trim();
      });
      var functionInStack = stackLines.some(function(line) {
        return line.includes(functionName);
      });
      if (functionInStack) {
        throw new Error("Detected potential cyclic loop involving function: ".concat(functionName));
      }
    }
  }
}
var findActions = function(levelsToVerify, tagsToVerify) {
  return __awaiter(void 0, void 0, Promise, function() {
    var rc, keys, _loop_1, _i, keys_1, fnKey;
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          rc = [];
          keys = Object.keys(mls.stor.files).filter(function(key) {
            return key.endsWith(".ts") && key.indexOf("aimAction") > 0 && key.indexOf("aimActionBase") < 0;
          });
          _loop_1 = function(fnKey2) {
            var storFile, jsName, className, module, i1, rules_1, regexps_1, err_1;
            return __generator(this, function(_b) {
              switch (_b.label) {
                case 0:
                  storFile = mls.stor.files[fnKey2];
                  if (storFile.level !== 2 || storFile.hasError)
                    return [2, "continue"];
                  jsName = "./_".concat(storFile.project, "_").concat(storFile.shortName);
                  className = storFile.shortName.charAt(0).toUpperCase() + storFile.shortName.slice(1);
                  _b.label = 1;
                case 1:
                  _b.trys.push([1, 3, , 4]);
                  return [4, import(jsName)];
                case 2:
                  module = _b.sent();
                  if (!module || !module[className]) {
                    console.error("error, aim action invalid, js not found or class ".concat(storFile.shortName, " not found in module: ").concat(fnKey2));
                    return [2, "continue"];
                  }
                  if (!(module[className].prototype instanceof AimActionBase)) {
                    console.error("error, aim action invalid, must be extends from AimActionBase: ".concat(fnKey2));
                    return [2, "continue"];
                  }
                  i1 = new module[className]();
                  rules_1 = i1.getRules();
                  regexps_1 = rules_1.tags.map(function(tag) {
                    return new RegExp(tag.replace(/\*/g, ".*"));
                  });
                  rc.push({
                    shortName: storFile.shortName,
                    project: storFile.project,
                    title: i1.title || "?",
                    levelsValid: levelsToVerify.some(function(level) {
                      return rules_1.levels.includes(level);
                    }),
                    tagsValid: tagsToVerify.some(function(tagToVerify) {
                      return regexps_1.some(function(regexp) {
                        return regexp.test(tagToVerify);
                      });
                    })
                  });
                  return [3, 4];
                case 3:
                  err_1 = _b.sent();
                  console.error("error, aim action invalid, abend: ".concat(fnKey2, ": ").concat(err_1 === null || err_1 === void 0 ? void 0 : err_1.message));
                  return [3, 4];
                case 4:
                  return [
                    2
                    /*return*/
                  ];
              }
            });
          };
          _i = 0, keys_1 = keys;
          _a.label = 1;
        case 1:
          if (!(_i < keys_1.length)) return [3, 4];
          fnKey = keys_1[_i];
          return [5, _loop_1(fnKey)];
        case 2:
          _a.sent();
          _a.label = 3;
        case 3:
          _i++;
          return [3, 1];
        case 4:
          return [2, rc];
      }
    });
  });
};
var templateObject_1, templateObject_2, templateObject_3, templateObject_4, templateObject_5, templateObject_6, templateObject_7, templateObject_8, templateObject_9, templateObject_10, templateObject_11;
export {
  AimActionBase,
  findActions
};
