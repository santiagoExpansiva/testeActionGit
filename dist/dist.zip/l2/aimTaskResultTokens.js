var __extends = /* @__PURE__ */ function() {
  var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  };
  return function(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  };
}();
var __makeTemplateObject = function(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", { value: raw });
  } else {
    cooked.raw = raw;
  }
  return cooked;
};
var __decorate = function(decorators, target, key, desc) {
  var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
  else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = function(k, v) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var __generator = function(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g;
  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
};
import { html } from "lit";
import { customElement, query } from "lit/decorators.js";
import { AimTaskBase } from "./_100554_aimTaskBase";
import { getInfoMyService } from "./_100554_aimHelper";
import { initCollabShowCodeSnippet100554, CollabShowCodeSnippet100554 } from "./_100554_collabShowCodeSnippet";
import { initCollabShowCodeDiff100554, CollabShowCodeDiff } from "./_100554_collabShowCodeDiff";
var AimTaskResultTokens = (
  /** @class */
  function(_super) {
    __extends(AimTaskResultTokens2, _super);
    function AimTaskResultTokens2() {
      var _this = _super.call(this) || this;
      _this.result = "";
      initCollabShowCodeSnippet100554();
      initCollabShowCodeDiff100554();
      return _this;
    }
    AimTaskResultTokens2.prototype.onInitializing = function() {
      this.notifyCompleteByStatus("ok", "");
    };
    AimTaskResultTokens2.prototype.firstUpdated = function(a) {
      _super.prototype.firstUpdated.call(this, a);
      if (this.codeSnippet)
        this.codeSnippet.textIn = this.result;
    };
    AimTaskResultTokens2.prototype.renderBody = function(taskRoot, child) {
      var title = child.title;
      var body = child._tempResult || "";
      var _a2 = this.extractBlocks(body), contentLess = _a2.contentLess, contentsAfterLess = _a2.contentsAfterLess, contentsBeforeLess = _a2.contentsBeforeLess;
      this.result = contentLess;
      return html(templateObject_1 || (templateObject_1 = __makeTemplateObject(["\n        <details open>\n            <summary>", "</summary>\n            <div style='margin: 10px'>\n                <div>", '</div>\n                <collab-show-code-snippet-100554 language="less" withAccept="true" .onAccept=', "></collab-show-code-snippet-100554>\n                <div>", "</div>\n            </div>\n        </details>\n            \n        "], ["\n        <details open>\n            <summary>", "</summary>\n            <div style='margin: 10px'>\n                <div>", '</div>\n                <collab-show-code-snippet-100554 language="less" withAccept="true" .onAccept=', "></collab-show-code-snippet-100554>\n                <div>", "</div>\n            </div>\n        </details>\n            \n        "])), title, contentsBeforeLess, this.onAccept.bind(this), contentsAfterLess);
    };
    AimTaskResultTokens2.prototype.onToogleDetails = function(event) {
      var detailsElement = event.target;
      detailsElement = detailsElement.closest("details");
      if (!detailsElement)
        return;
      if (!detailsElement.open) {
        this.setTokensDiff();
      }
    };
    AimTaskResultTokens2.prototype.setTokensDiff = function() {
      return __awaiter(this, void 0, void 0, function() {
        var activeOpService, value;
        return __generator(this, function(_a2) {
          if (!this.codeDiff)
            return [
              2
              /*return*/
            ];
          activeOpService = this.getActiveOpServiceIfIsValid();
          if (!activeOpService) {
            return [
              2
              /*return*/
            ];
          }
          ;
          value = activeOpService.getEditorSource();
          return [
            2
            /*return*/
          ];
        });
      });
    };
    AimTaskResultTokens2.prototype.getActiveOpServiceIfIsValid = function() {
      var info = getInfoMyService(this);
      if (!info)
        return void 0;
      var activeServiceOp = info.actServiceOp;
      if (activeServiceOp.tagName !== "SERVICE-DS-TOKENS-100554")
        return void 0;
      return activeServiceOp;
    };
    AimTaskResultTokens2.prototype.onAccept = function() {
      var activeOpService = this.getActiveOpServiceIfIsValid();
      if (!activeOpService) {
        window.collabMessages.add("The service in the opposite position does not refer to this action", "error");
        return;
      }
      ;
      var taskWithRef = this.taskRoot.children.find(function(task) {
        return task.widget === "_100554_aimTaskDsTokens";
      });
      if (!taskWithRef || !taskWithRef.ref) {
        window.collabMessages.add("This action dont have any file ref", "error");
        return;
      }
      ;
      var actualRef = activeOpService.getActualRef();
      if (taskWithRef.ref !== actualRef) {
        window.collabMessages.add("The current reference: ".concat(actualRef, ",  does not match the action reference:").concat(taskWithRef.ref), "error");
        return;
      }
      ;
      var tokensType = taskWithRef.ref.split("_").pop() || "";
      activeOpService.setEditorSource(this.result, tokensType);
    };
    AimTaskResultTokens2.prototype.extractBlocks = function(src) {
      var regex = new RegExp("^(.*?)```less(.*)```(.*)", "s");
      var matches = src.match(regex);
      var contentLess = "";
      var contentsBeforeLess = "";
      var contentsAfterLess = "";
      if (matches) {
        contentsBeforeLess = matches[1] || "";
        contentLess = matches[2] || "";
        contentsAfterLess = matches[3] || "";
      }
      return { contentLess, contentsAfterLess, contentsBeforeLess };
    };
    var _a, _b;
    __decorate([
      query("collab-show-code-diff-100554"),
      __metadata("design:type", typeof (_a = typeof CollabShowCodeDiff !== "undefined" && CollabShowCodeDiff) === "function" ? _a : Object)
    ], AimTaskResultTokens2.prototype, "codeDiff", void 0);
    __decorate([
      query("collab-show-code-snippet-100554"),
      __metadata("design:type", typeof (_b = typeof CollabShowCodeSnippet100554 !== "undefined" && CollabShowCodeSnippet100554) === "function" ? _b : Object)
    ], AimTaskResultTokens2.prototype, "codeSnippet", void 0);
    AimTaskResultTokens2 = __decorate([
      customElement("aim-task-result-tokens-100554"),
      __metadata("design:paramtypes", [])
    ], AimTaskResultTokens2);
    return AimTaskResultTokens2;
  }(AimTaskBase)
);
var templateObject_1;
export {
  AimTaskResultTokens
};
